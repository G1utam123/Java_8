package com.gautam.ps.api.service;

import java.util.Random;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gautam.ps.api.entity.Payment;
import com.gautam.ps.api.repository.PaymentRepository;

@Service
public class PaymentService {

	@Autowired
	private PaymentRepository paymentRepository;
	
	private Logger log=LoggerFactory.getLogger(PaymentService.class);
	
	public Payment doPaymnet(Payment payment) throws JsonProcessingException {
		payment.setPaymentStatus(paymentProcessing());
		payment.setTransactionId(UUID.randomUUID().toString());
		
		log.info("PayemntService payment {}: ", new ObjectMapper().writeValueAsString(payment));
		
		return paymentRepository.save(payment);
	}
	
	public String paymentProcessing() {
		return new Random().nextBoolean()?"success":"fail";
	}

	public Payment findOrderHistoryByOrderId(int orderId) throws JsonProcessingException {
		Payment payment=paymentRepository.findByOrderId(orderId);
		
		log.info("Payment findOrderHistoryByOrderId {} : ", new ObjectMapper().writeValueAsString(payment));
		
		return payment;
	}
	

}
