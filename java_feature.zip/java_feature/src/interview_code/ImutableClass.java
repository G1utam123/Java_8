package interview_code;

public final class ImutableClass {      // 1. final class
	
	private final int id;               // 2. private final instance variable
	 
	public int getId() {                // 3. only getter method
		return id;
	}
	
	public ImutableClass(int id) {        // 4. initialize the instance variable using constructor 
		this.id=id;
	}
	
	
	public static void main(String[] args) {
		
		ImutableClass i=new ImutableClass(4);
		
	//	i.id=7;       we can+'t change
		
		
		
		
	}
	

}
