package singleToneClass;

import java.io.Serializable;

public class LazySingletone extends MyClone implements Serializable{


	private static LazySingletone instance;
	
	private LazySingletone() {
		if(instance!=null) {
			throw new IllegalStateException("new obj clan't be initiated !");
		}
		
	}
	
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		
		throw new CloneNotSupportedException();
	}
	
 
  protected Object readResolve(){
		return instance;
		
	}
	
	
	public static synchronized LazySingletone getInstance() {
		
		if(instance==null) {
			return instance=new LazySingletone();  // 2 thread will create 2 obj
		}else {
			return instance;
		}
		
	}
	
}
