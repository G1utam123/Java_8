package singleToneClass;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class App{

	public static void main(String[] args) throws CloneNotSupportedException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, FileNotFoundException, IOException, ClassNotFoundException{
		
		
		
//		EagerSingletone a=EagerSingletone.getInstance();
//		EagerSingletone b=EagerSingletone.getInstance();
//		System.out.println(a.hashCode());
//		System.out.println(b.hashCode());
//		
		
		LazySingletone a1=LazySingletone.getInstance();
//		 LazySingletone b1=(LazySingletone)a1.clone();
		System.out.println(a1.hashCode());
//		System.out.println(b1.hashCode());
		
//		LazySingletone reflactionInstance=null;
//		
//		Constructor[] constructors=LazySingletone.class.getDeclaredConstructors();
//		for(Constructor constructor: constructors) {
//			constructor.setAccessible(true);
//			reflactionInstance=(LazySingletone)constructor.newInstance();
//		}
//		
//		System.out.println(reflactionInstance.hashCode());
		
		
		//Serialize
		ObjectOutput out=new ObjectOutputStream(new FileOutputStream("singleton.ser"));
		out.writeObject(a1);
		out.close();
		
		//Deserialize
		ObjectInput in=new ObjectInputStream(new FileInputStream("singleton.ser"));
	    LazySingletone b1=(LazySingletone)in.readObject();
		in.close();
		System.out.println(in.hashCode());
		
		
//		DoubleCheckingSingletone a2=DoubleCheckingSingletone.getInstance();
//		DoubleCheckingSingletone b2=DoubleCheckingSingletone.getInstance();
//		System.out.println(a2.hashCode());
//		System.out.println(b2.hashCode());
		
		
//		LazzyInnerClassSingleton a3=LazzyInnerClassSingleton.getInstance();
//		LazzyInnerClassSingleton b3=LazzyInnerClassSingleton.getInstance();
//		System.out.println(a3.hashCode());
//		System.out.println(b3.hashCode());

	}

}



