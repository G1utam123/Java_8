package singleToneClass;

public class EagerSingletone {
	
	
	private EagerSingletone() {}        // 1. private constructor
	
	private final static EagerSingletone instance=new EagerSingletone();  // 2. Obj is created at the time of class loading i.e EagerSingletone
	
	public static EagerSingletone getInstance() {                              // 3. get intance
		return instance;
	}
	

}
