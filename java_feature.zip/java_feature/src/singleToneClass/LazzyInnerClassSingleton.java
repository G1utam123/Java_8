package singleToneClass;

public class LazzyInnerClassSingleton {
	
	
	private LazzyInnerClassSingleton() {}
	
	private static class SingletonHelper{
		private final static LazzyInnerClassSingleton instance=new LazzyInnerClassSingleton();
	}
	
	public static LazzyInnerClassSingleton getInstance() {
		return SingletonHelper.instance;
	}
	

}
