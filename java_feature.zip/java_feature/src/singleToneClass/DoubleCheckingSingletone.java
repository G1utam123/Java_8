package singleToneClass;

public class DoubleCheckingSingletone {

	private DoubleCheckingSingletone() {}
	
	private static DoubleCheckingSingletone instance;
	
	
	public static DoubleCheckingSingletone getInstance() {
		if(instance==null) {
			synchronized (DoubleCheckingSingletone.class) {
				if(instance==null) {
					instance=new DoubleCheckingSingletone();
				}
			}
		}
		return instance;
	}
	
	
}
