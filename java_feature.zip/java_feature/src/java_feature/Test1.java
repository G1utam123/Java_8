package java_feature;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Test1 {

	public static void main(String[] args) {
		
		
//		Screening Program :-
//		Write a program to print the count of each charecter in a string. Approach should not use nested for loops. 
		//Extra points if the lines of code can be reduced using ternary operator.
//
//		Example :-
//		Input : Infinivis
//		Output : I:4 n:2 f:1 v:1 s:1
		
		
		String s="Infinivis";
		
		char[] ch=s.toCharArray();
		
		      
		List<Character> list=new ArrayList<>();
		
		for(int i=0;i<ch.length;i++) {
			list.add(ch[i]);
		}
		
		      
		for(int i=0;i<ch.length;i++) {
			
			System.out.println(ch[i]+" : "+ Collections.frequency(list, ch[i]));
		}
		
		

	}

}
