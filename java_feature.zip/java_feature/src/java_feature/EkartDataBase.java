package java_feature;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EkartDataBase {
	
	public static List<Customer> getAll(){
		
		return Stream.of(new Customer(4, "sohan", "kaju@gmail.com", Arrays.asList("324432","32","32","32")),
				new Customer(4, "mohan", "kaju@gmail.com", Arrays.asList("3232","32","32","32")),
				new Customer(6, "sohan", "sohan@gmail.com", Arrays.asList("2","32","3564","3546")),
				new Customer(5, "raju", "raju@gmail.com", Arrays.asList("773","773","36","56"))
				)
				.collect(Collectors.toList());
	}

}
