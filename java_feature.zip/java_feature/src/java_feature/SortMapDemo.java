package java_feature;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;



public class SortMapDemo {

	public static void main(String[] args) {
		
		
		Map<String, Integer> map=new HashMap<>();
		
		map.put("Kumar", 2);
		map.put("Gautam", 3);
		map.put("Raju", 1);
		map.put("Mohan", 7);
		map.put("Sohan", 5);
		map.put("Rohan", 9);
		
		
		Map<Employee,Integer> empMap=new TreeMap<>(	( o1,  o2) ->  (o1.getSalary() - o2.getSalary()));
		
		
		empMap.put(new Employee(1, "p", "IT", 120000), 3);
		empMap.put(new Employee(1, "b", "CSE", 20000), 4);
		empMap.put(new Employee(1, "c", "MATH", 30000), 5);
		empMap.put(new Employee(1, "d", "Science", 40000), 1);
		empMap.put(new Employee(1, "e", "BIO", 60000), 9);
		
		
//		System.out.println(empMap);
		
//		empMap.entrySet().stream().sorted(Map.Entry.comparingByKey((a,b)-> a.getSalary() - b.getSalary()))
//		.forEach(System.out::println);
//		
		
		empMap.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.comparing(Employee::getDept)))
				.forEach(System.out::println);
		
//		List<Entry<String, Integer>> list=new ArrayList<>(map.entrySet());
//		
//		Collections.sort(list, (a,b) -> a.getKey().compareToIgnoreCase(b.getKey()));
//		
//		for(Entry<String,Integer> e:list) {
//			System.out.println("key: "+e.getKey()+ " value : "+ e.getValue());
//		}
//		
//		System.out.println(list);
		
		
    // map.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(System.out::println);
     
//     map.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(System.out::println);
//     
		
		
	}

}
