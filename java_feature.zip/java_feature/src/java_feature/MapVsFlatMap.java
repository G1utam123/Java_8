package java_feature;

import java.util.List;
import java.util.stream.Collectors;

public class MapVsFlatMap {

	public static void main(String[] args) {
		
		List<Customer> list=EkartDataBase.getAll();
		
	List<String> email=list.stream().map(Customer::getEmail).collect(Collectors.toList());
//	System.out.println(email);
	
	List<List<String>> phone = list.stream().map(Customer::getPhoneNumbers).collect(Collectors.toList());
	
//		System.out.println(phone);
		
		List<String> ph=list.stream().flatMap(Customer -> Customer.getPhoneNumbers().stream())
				.collect(Collectors.toList());
		
		
		System.out.println(ph);

	}

}
