package java_feature;

import java.util.List;
import java.util.stream.Collectors;

public class EmployeeService {

	
	public static List<Employee> getTaxPayEmpolyee(String input){
		
		if(input.equalsIgnoreCase("tax")) {
		return EmployeeDAO.getEmployees().stream().filter(emp -> emp.getSalary() >= 120000).collect(Collectors.toList());
	}else {
		return EmployeeDAO.getEmployees().stream().filter(emp -> emp.getSalary()<120000).collect(Collectors.toList());
	}
	}
	public static void main(String[] args) {
		System.out.println(getTaxPayEmpolyee("non tax"));
	}
}
