package java_feature;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class MapReduce {

	public static void main(String[] args) {
	
		
		List<Integer> num=Arrays.asList(1,25,4,3,2,7,8,9);
		
		List<String> name=Arrays.asList("gautam","kumarGautam","Mohan","Ram");
		
		int sum=num.stream().mapToInt(i->i).sum();
		System.out.println(sum);
		
		
		Integer s=num.stream().reduce(0,(a,b)-> a+b);
		System.out.println(s);
		
		Optional<Integer> s2 = num.stream().reduce(Integer::sum);
		System.out.println(s2.get());
		

		String max=name.stream().reduce((w1,w2)-> w1.length() > w2.length() ? w1 : w2).get();
		System.out.println(max);
	}

}
