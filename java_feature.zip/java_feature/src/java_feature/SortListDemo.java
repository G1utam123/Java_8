package java_feature;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class SortListDemo {

	public static void main(String[] args) {
		
		List<Integer> list=new ArrayList<>();
		list.add(12);
		list.add(6);
		list.add(24);
		list.add(3);
		
//		Collections.sort(list);
//		Collections.reverse(list);
//		System.out.println(list);
		
	//	list.stream().sorted(Comparator.reverseOrder()).forEach(a->System.out.println(a));
		
		List<Employee> emp=EmployeeDAO.getEmployees();
//		Collections.sort(emp, (a,b)-> (int)(a.getSalary() - b.getSalary()));
//		System.out.println(emp);
		
//		EmployeeDAO.getEmployees().stream().sorted((a,b) -> 
//		(int) (a.getSalary() - b.getSalary())).forEach(System.out::print);
		
	
		emp.stream().sorted(Comparator.comparing(Employee::getName)).forEach(System.out::println);
		
		
		
		
		
	}

}
