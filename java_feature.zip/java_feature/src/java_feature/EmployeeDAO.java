package java_feature;

import java.util.ArrayList;
import java.util.List;

public class EmployeeDAO {

	public static List<Employee> getEmployees(){
		
		List<Employee> list=new ArrayList<>();
		
		list.add(new Employee(1, "Gautam", "IT", 120000));
		list.add(new Employee(2, "Kumar", "DEV", 130000));
		list.add(new Employee(3, "Mohan", "MG", 140000));
		list.add(new Employee(4, "Sohan", "DR", 150000));
		list.add(new Employee(5, "Raju", "VP", 110000));
		list.add(new Employee(6, "Kaju", "IT", 190000));
		
		return list;
		
	}
	
}
