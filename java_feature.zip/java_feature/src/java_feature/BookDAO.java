package java_feature;

import java.util.ArrayList;
import java.util.List;

public class BookDAO {
	
	public List<Book> getBooks(){
		
		List<Book> books=new ArrayList<>();
		
		books.add(new Book(1,"Ramayan",273));
		books.add(new Book(2, "Mahabharat", 330));
		books.add(new Book(3, "Maths", 450));
		books.add(new Book(4, "Grammer", 321));
		
		return books;
	}

}
