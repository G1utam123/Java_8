package java_feature;



public class Functional_Interface{

	public static void main(String[] args) {
		
		
		

	}

	
}

