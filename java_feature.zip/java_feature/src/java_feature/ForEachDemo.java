package java_feature;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ForEachDemo {

	public static void main(String[] args) {
		
		List<String> list=new ArrayList<>();
		
		list.add("gautam");
		list.add("Kumar");
		list.add("Ram");
		list.add("Mohan");
		list.add("Rohan");
		
//		for(String s:list) {
//			System.out.println(s);
//		}
		
		
//		list.stream().forEach((s)-> System.out.println(s));
		
		list.stream().filter((t)-> t.startsWith("R")).forEach((t)-> System.out.println(t));
		
		
		Map<Integer, String> map=new HashMap<>();
		
		map.put(1, "a");
		map.put(2, "b");
		map.put(3, "c");
		map.put(4, "d");
		map.put(5, "e");
		
//		map.forEach((k,v)-> System.out.println("key: "+ k+" value :"+ v));
		
//		map.entrySet().stream().forEach((obj)-> System.out.println(obj));
		
		map.entrySet().stream().filter((t)-> t.getKey()%2==0).forEach((c)->System.out.println(c));
	}

}
