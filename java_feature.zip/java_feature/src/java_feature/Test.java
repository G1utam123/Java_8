package java_feature;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Test {
	
	

	public static void main(String[] args) {
		
		List<Integer> numbers = Arrays.asList(new Integer[]{1,2,1,3,4,4});  
//		
//		numbers.stream().filter(i -> Collections.frequency(numbers, i) >1)
//        .collect(Collectors.toSet()).forEach(System.out::println);
		
		
		List<String> name=Arrays.asList("gautam","gautam","gautam","kumar","kumar","mohan");
		
		
//		name.stream().filter(e -> Collections.frequency(name, e) > 1).collect(Collectors.toSet())
//		.forEach(System.out::println);
		
		
		List<String>  fruite=Arrays.asList("apple","apple","mango","mango","banana","papaya");
		
		
//		fruite.stream().filter(e -> Collections.frequency(fruite, e)>1).collect(Collectors.toSet())
//.forEach(System.out::println);
//		
		
		
		String s="I am from India";

		List<String> list=Arrays.asList(s.split(" "));


		List<String>  even=new ArrayList<>();
		List<String>  odd=new ArrayList<>();


		list.stream().forEach(e -> 
		                      {
							  if(e.length()%2==0){
							  even.add(e);
							  }else{
							  odd.add(e);
							  }
							  });
							  
							  
							  even.stream().forEach(System.out::println);
							  System.out.println("============");
							  odd.stream().forEach(System.out::println);
							  
							  
							  
							  
							  
							  
							  
							  
							  
							  
							  
							  
							  

		

	}

}
