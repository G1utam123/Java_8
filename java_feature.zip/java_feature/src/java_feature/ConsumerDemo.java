package java_feature;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class ConsumerDemo {

	public static void main(String[] args) {
		
		
//		Consumer<Book>   : void accept(T t);
//		Predicate<Book>  : boolean test(T t);
//		Supplier<Book>   : T get();
		
		
	
		Consumer<Integer> c= (t) -> System.out.println(t);
		c.accept(5);
		
		List<Integer> list=Arrays.asList(1,2,3,4,5,6,7,8);
		
		list.stream().forEach(i -> System.out.println(" "+i));
		
		
		
	}

	
	

}
