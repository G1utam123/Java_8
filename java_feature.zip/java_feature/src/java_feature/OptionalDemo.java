package java_feature;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class OptionalDemo {

	public static void main(String[] args) {
		
		Customer customer=new Customer(3, "ram", null, Arrays.asList("2553441","43451","3424","323"));
		Customer cus=new Customer(0, null, null, null);
		
//		Optional<String> obj=Optional.empty();
//		System.out.println(obj);
//		
//		Optional<String> email=Optional.of(customer.getEmail());
//		System.out.println(email);
		
		Optional<String> email1=Optional.ofNullable(customer.getEmail());
		System.out.println(email1.orElseThrow(()-> new IllegalArgumentException("Email not present")));

	}

}
