const { defineConfig } = require('cypress');

module.exports = defineConfig({
    chromeWebSecurity: false,
    defaultCommandTimeout: 10000,
    pageLoadTimeout: 150000,
    reporter: 'junit',
    reporterOptions: {
        mochaFile: 'tests/business/reports/cypress-business.[hash].xml',
    },
    viewportHeight: 960,
    viewportWidth: 1280,
    e2e: {
        baseUrl: 'https://localhost:9090',
        fixturesFolder: 'tests/business/fixtures',
        screenshotsFolder: 'tests/business/screenshots',
        specPattern: 'tests/business/specs/**/*.feature',
        supportFile: 'tests/business/support/index.js',
        videosFolder: 'tests/business/videos',
        setupNodeEvents(on, config) {
            require('@cypress/code-coverage/task')(on, config);
            on('file:preprocessor', require('@cypress/code-coverage/use-babelrc'));
            on('file:preprocessor', require('cypress-cucumber-preprocessor').default());

            require('dotenv').config();
            config.env.VUE_APP_CUSTOMIZE = process.env.VUE_APP_CUSTOMIZE;

            return config;
        },
    },
});
