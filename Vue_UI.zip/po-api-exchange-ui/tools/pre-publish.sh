#!/bin/bash
set -e

if [ $1 == 'library' ]; then
    if [ -f package-library.json ]; then
        echo 'Rename old package.json by package-library-base.json'
        mv package.json package-library-base.json
        echo 'Rename package-library.json by package.json'
        mv package-library.json package.json
    fi
else
    if [ -f package-component.json ]; then
        echo 'Rename old package.json by package-component-base.json'
        mv package.json package-component-base.json
        echo 'Rename package-component.json by package.json'
        mv package-component.json package.json
    fi
fi
