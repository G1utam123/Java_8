#!/bin/bash

set -e

source tools/test-post.sh
exit 1
