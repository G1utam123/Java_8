#!/usr/bin/env node
'use strict';

let runVersion = null;
try {
    runVersion = require('@centurylink/po-microapp-base/package.json').version;
    console.log('using base installed from ctl');
} catch {
    console.log('using base installed from pf');
    runVersion = require('@portal-framework/po-microapp-base/package.json').version;
}
let installVersion;

try {
    const fs = require('fs');
    installVersion = fs.readFileSync(`./.baserc`, { encoding: 'utf8' });
} catch {
    installVersion = '0.0.0';
}

if (runVersion !== installVersion) {
    console.log(`
     ===============================================================================
    |                                                                               |
    |       Please, run NPM CI command to get the latest MICROAPP-BASE version      |
    |                                                                               |
     ===============================================================================
    * MICROAPP-BASE versions
        >> running:   ${runVersion}
        >> installed: ${installVersion}
    `);

    process.exitCode = 1;
}
