#!/bin/bash

{
    bash tools/test-pre.sh 'qae2e' &&
    npm run test:qae2e:jenkins -- $1 &&
    bash tools/test-post.sh 'qae2e'
} || bash tools/test-post-error.sh 'qae2e'
