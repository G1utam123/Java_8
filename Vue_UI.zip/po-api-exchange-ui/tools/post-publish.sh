#!/bin/bash
set -e

if [ $1 == 'library' ]; then
    echo 'Rename package-library-base.json by package.json'
    mv package-library-base.json package.json
else
    echo 'Rename package.json by package-component.json'
    mv package.json package-component.json    
    echo 'Rename package-component-base.json by package.json'
    mv package-component-base.json package.json
fi
