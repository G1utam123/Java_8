'use strict';

const fs = require('fs');

let raw = fs.readFileSync('package.json');
let packageJson = JSON.parse(raw);

let libraryPackageJson = {
    name: packageJson.name,
    version: packageJson.version,
    main: packageJson.main,
    types: 'index.d.ts',
    files: ['dist/**/*', 'index.d.ts'],
    private: false,
    publishConfig: {
        registry: 'https://npm.pkg.github.com/',
    },
    repository: {
        type: 'git',
        url: packageJson.repository.url,
    },
};

fs.writeFileSync('package-library.json', JSON.stringify(libraryPackageJson, null, 2));
