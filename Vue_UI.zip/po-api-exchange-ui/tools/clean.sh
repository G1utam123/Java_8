#!/bin/bash
set -e

if [ -d dist ]; then
    echo 'Deleting dist directory'
    rm -r dist   
fi

if [ -f package-library.json ]; then
    echo 'Delete package-library.json'
    rm package-library.json
fi