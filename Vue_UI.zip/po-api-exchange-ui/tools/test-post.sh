#!/bin/bash

set -e

source tools/test-common.sh

echo "moving to $1 folders..."

if [[ $1 == 'unit' ]]
then
  nyc merge .nyc_output_unit_tmp .nyc_output_unit/out.json
else
  nyc=".nyc_output"
  coverage="coverage"
  sufix=$1

  remove_folder "${nyc}_${sufix}"
  remove_folder "${coverage}_${sufix}"

  copy_file $nyc $sufix
  copy_file $coverage $sufix

  remove_folder $nyc
  remove_folder $coverage
fi

if [[ $1 == 'unit' ]]
then
  target="node_modules/istanbul-lib-source-maps/lib/get-mapping.js"
  old_expresion="source: origFile,"
  new_expresion="source: pathutils.relativeTo(start.source, origFile),"

  replace_string $target "$old_expresion" "$new_expresion"
fi

if [[ $1 == 'sanity' || $1 == 'regression' || $1 == 'qae2e' ]]
then

  reports="tests/business/reports/cucumber-json"
  report_dir="tests/business/reports"

  if [[ -d "$reports" ]]
  then
    node tests/business/plugins/reports.js
  fi

  mkdir "tests/business/reports/$1"
  find tests/business/reports/*  \! -name "$1" -maxdepth 0 -exec mv {} "$report_dir/$1" \;
fi
