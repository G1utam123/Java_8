#!/bin/bash

replace_string() {
  machine="$(uname -s)"

  echo "s/$2/$3/"

  if [[ "$machine" == "Darwin" ]]
  then
      sed -i '' "s/$2/$3/" "$1"
  else
      sed -i "s/$2/$3/" "$1"
  fi

  echo "replaced value in '$1' (using $machine)..."
}

remove_folder () {
  if [[ -d "$1" ]]
  then
    rm -fR $1
    echo "removing $1"
  fi
}

copy_file () {
  if [[ -d "$1" ]]
  then
    cp -R "$1/" "$1_$2/"
    echo "copying $1 => $1_$2"
  fi
}

copy_json_files () {
  folder=$1
  sufix=$2

  for source in ${folder}${sufix}/*
  do
    if [[ -f "$source" ]]
    then
      filename=${source#*/}
      filename=${filename%.*}

      cp "${source}" "${folder}/${filename}${sufix}.json"
      echo "copying $source => $folder/$filename$sufix.json"
    fi
  done
}
