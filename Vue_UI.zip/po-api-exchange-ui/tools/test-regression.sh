#!/bin/bash

{
    bash tools/test-pre.sh 'regression' &&
    npm run test:regression:jenkins -- $1 &&
    bash tools/test-post.sh 'regression'
} || bash tools/test-post-error.sh 'regression'
