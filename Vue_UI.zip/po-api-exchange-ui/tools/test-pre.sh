#!/bin/bash

set -e

source tools/test-common.sh

echo "removing $1 (nyc & coverage) folders..."

nyc=".nyc_output"
coverage="coverage"

remove_folder $nyc
remove_folder $coverage

if [[ $1 == 'unit' ]]
then
  nyc=".nyc_output_$1"
  coverage="coverage_$1"

  remove_folder $nyc
  remove_folder $coverage

  echo "removing $1 (nyc temporal) folder..."

  nyc=".nyc_output_$1_tmp"
  remove_folder $nyc

  target="node_modules/istanbul-lib-source-maps/lib/get-mapping.js"
  old_expresion="source: pathutils.relativeTo(start.source, origFile),"
  new_expresion="source: origFile,"

  replace_string $target "$old_expresion" "$new_expresion"
fi

if [[ $1 == 'sanity' || $1 == 'regression' || $1 == 'qae2e' ]]
then
  reports="tests/business/reports"
  remove_folder $reports
fi
