const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;
const MomentLocalesPlugin = require('moment-locales-webpack-plugin');
const CopyPlugin = require('copy-webpack-plugin');
const NodePolyfillPlugin = require('node-polyfill-webpack-plugin');

const { APP_MODE, APP_TARGET, APP_CUSTOMIZE, isAppCustomized, getPublicPath } = require('./src/utils/constants');

module.exports = {
    pages: {
        app: {
            entry: 'src/main.ts',
            template: 'public/index.html',
            filename: 'index.html',
        },
        bs: {
            entry: 'src/main.ts',
            template: 'public/index_bs.html',
            filename: 'index_bs.html',
        },
        smb: {
            entry: 'src/main.ts',
            template: 'public/index_smb.html',
            filename: 'index_smb.html',
        },
    },
    configureWebpack: (config) => {
        config.externals = {};

        if (config.devtool) {
            delete config.devtool;
        }

        config.plugins.push(new NodePolyfillPlugin());
        config.plugins.push(
            new MomentLocalesPlugin({
                localesToKeep: ['de', 'es', 'fr', 'pt', 'zh-cn', 'ja'],
            })
        );

        switch (process.env.VUE_APP_MODE) {
            case APP_MODE.PROD:
                config.mode = 'production';
                config.optimization.minimize = true;
                break;

            case APP_MODE.PR:
            case APP_MODE.STAGE:
                config.mode = 'development';
                break;

            case APP_MODE.TEST_E2E:
                config.mode = 'development';
                config.devtool = 'source-map';
                break;

            case APP_MODE.DEV:
                config.mode = 'development';
                config.devtool = 'source-map';
                config.plugins.push(new BundleAnalyzerPlugin());
                break;

            case APP_MODE.TEST_UNIT:
                break;

            default:
        }

        if (process.env.VUE_APP_TARGET === APP_TARGET.STANDALONE) {
            if (process.env.VUE_APP_MODE === APP_MODE.PROD) {
                config.output.filename = '[name].[hash:8].js';
                config.output.chunkFilename = '[name].[hash:8].js';
            } else {
                config.output.filename = '[name].js';
                config.output.chunkFilename = '[name].js';
            }

            if (isAppCustomized(APP_CUSTOMIZE.SHELL)) {
                let patterns = [
                    {
                        from: '@centurylink/po-enterprise-shell/dist',
                        context: 'node_modules',
                        globOptions: {
                            ignore: ['.DS_Store'],
                        },
                    },
                ];

                config.plugins.push(new CopyPlugin({ patterns }));
            } else {
                config.externals.vue = 'Vue';
                config.externals.shell = 'shell';
            }
        }

        if (process.env.VUE_APP_TARGET === APP_TARGET.COMPONENT) {
            // dependencies used in the µcomponent
        } else {
            // copy µcomponents libraries
            // let patterns = [].concat([
            //     { from: '@centurylink/µcomponent-repository/dist' },
            // ]);
            // patterns = patterns.map((pattern) => {
            //     pattern.context = 'node_modules';
            //     pattern.globOptions = {
            //         ignore: ['.DS_Store'],
            //     };
            //     return pattern;
            // });
            // config.plugins.push(new CopyPlugin({ patterns }));
        }
    },
    chainWebpack: (config) => {
        if ([APP_MODE.PROD].includes(process.env.VUE_APP_MODE)) {
            config.optimization.minimizer('terser').tap((args) => {
                args[0].terserOptions = {
                    compress: {
                        drop_console: true,
                        drop_debugger: true,
                    },
                    keep_classnames: true,
                    keep_fnames: true,
                };

                return args;
            });
        }
    },
    publicPath: getPublicPath(),
    css: {
        extract: process.env.VUE_APP_MODE === APP_MODE.PROD,
    },
    devServer: {
        client: {
            progress: false,
            overlay: {
                warnings: true,
                errors: true,
            },
        },
        static: {
            watch: {
                ignored: /node_modules/,
                // if aggregateTimeout and poll values should be changed on local, create a .env.local file
                aggregateTimeout: process.env.WEBPACK_AGGREGATE_TIMEOUT,
                poll: process.env.WEBPACK_POLL,
            },
        },
        port: 9090,
        host: 'localhost',
        https: true,
        // proxy: 'https://url-backend.test/',
    },
    transpileDependencies: ['vuex-module-decorators'],
};
