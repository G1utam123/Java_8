declare class ComponentLibrary {
    components: Record<string, any>;
}

export declare const library: ComponentLibrary;
export {};
