import { DataTableConfig, HeadItem } from '@/models/chiTableTypes';
export const MONTHS: string[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
export const MYAPPS_TABLE_CONFIG: DataTableConfig = {
    columnResize: false,
    noResultsMessage: 'No Records.',
    activePage: 1,
    style: {
        portal: true,
        noBorder: false,
        bordered: false,
        hover: false,
        size: 'md',
        striped: true,
    },
    pagination: {
        hideOnSinglePage: true,
        compact: true,
        firstLast: false,
        pageJumper: false,
    },
    selectable: false,
    columnSizes: {
        xs: [20, 10, 10, 20, 10],
        sm: [20, 10, 10, 20, 10],
        md: [20, 10, 10, 20, 10],
        lg: [20, 10, 10, 20, 10],
        xl: [20, 10, 10, 20, 10],
    },
    resultsPerPage: 9999, //Change this parameter in future if pagination is required
    defaultSort: {
        key: 'name',
        sortBy: 'name',
        direction: 'ascending',
    },
};

export const MYAPPS_TABLE_TEMPLATES = {
    NAME: 'name',
    ENVIRONMENT: 'environment',
    API_PRODUCT: 'api_product',
    CREATED: 'created',
    APP_NAME: 'appName',
};

export const APPS_TABLE_TEMPLATES = {
    APIPRODUCT: 'apiproduct',
    STATUS: 'status',
};

export const MYAPPS_TABLE_COLUMNS: Record<string, HeadItem> = {
    name: { label: 'Name', sortable: true, sortBy: MYAPPS_TABLE_TEMPLATES.NAME, sortDataType: 'string' },
    environment: {
        label: 'Environment',
        sortable: true,
        sortBy: MYAPPS_TABLE_TEMPLATES.ENVIRONMENT,
        sortDataType: 'string',
    },
    api_product: {
        label: 'API Products',
        sortable: true,
        sortBy: MYAPPS_TABLE_TEMPLATES.API_PRODUCT,
        sortDataType: 'number',
        align: 'right',
    },
    created: { label: 'Created', sortable: true, sortBy: MYAPPS_TABLE_TEMPLATES.CREATED, sortDataType: 'date' },
    actions: { label: 'Actions', sortable: false, align: 'center', allowOverflow: true },
};

export const APPS_TABLE_CONFIG: DataTableConfig = {
    columnResize: false,
    style: {
        portal: true,
        noBorder: false,
        bordered: false,
        hover: true,
        size: 'md',
        striped: true,
    },
    pagination: {
        hideOnSinglePage: true,
        compact: true,
        firstLast: false,
        pageJumper: false,
    },
    selectable: true,
    columnSizes: {
        xs: [60, 5],
        sm: [60, 5],
        md: [60, 5],
        lg: [60, 5],
        xl: [60, 5],
    },
    resultsPerPage: 9999,
};

export const APPS_TABLE_COLUMNS: Record<string, HeadItem> = {
    apiproduct: { label: 'API Products' },
    status: { label: 'Status', align: 'center' },
};

export interface AppListTableRow {
    id: number;
    appName: string;
    name: string;
    environment: string;
    api_product: number;
    status: string;
    created: string;
    consumerkey: string;
    consumersecret: string;
    apiProduct: string[];
}

export interface AlertObj {
    dyclass: string;
    icon: string;
    message: string;
    navigateTo: {
        path: string;
        name: string;
    };
}
