<template>
    <AppLayout>
        <template v-slot:credentials>
            <div class="myapps chi" data-ut="ut-myapps" data-cy="cy-parent-router__element">
                <div class="chi-app -w--95" style="min-height: 52vh">
                    <div class="wrapper -bg--white">
                        <!-- start -->
                        <div class="chi-grid">
                            <div
                                class="chi-col -w-md--10 -mt--1 chi-main__title-heading -text--boldest--navy"
                                data-cy="cy-my-app__title"
                            >
                                Credentials
                            </div>

                            <div v-if="featureFlag" class="chi-col -w-sm--2 -text-xl--right">
                                <router-link
                                    data-cy="cy-create__appbtn"
                                    :to="{
                                        name: 'addnew',
                                        params: {
                                            page: 'create',
                                            alert: '',
                                            alertmsg: '',
                                        },
                                    }"
                                >
                                    <button class="chi-button -primary" data-cy="cy-create-new-app__btn">
                                        Create New
                                    </button>
                                </router-link>
                            </div>
                            <div class="chi-col -w-sm--12 -pt--3">
                                <div
                                    class="chi-alert"
                                    data-cy="cy-alert__lbl"
                                    v-bind:class="alertObj.dyclass"
                                    role="alert"
                                    v-if="failureAlert"
                                >
                                    <i
                                        class="chi-alert__icon chi-icon"
                                        v-bind:class="alertObj.icon"
                                        aria-hidden="true"
                                    ></i>
                                    <div class="chi-alert__content">
                                        <p class="chi-alert__text">{{ alertObj.message }}</p>
                                    </div>
                                    <button
                                        data-cy="chi-alert_dismiss"
                                        class="chi-alert__close-button chi-button -icon -close"
                                        aria-label="Close"
                                        @click="toogleAlert(false)"
                                    >
                                        <div class="chi-button__content">
                                            <i class="chi-icon icon-x" aria-hidden="true"></i>
                                        </div>
                                    </button>
                                </div>
                            </div>
                            <div class="chi-col -w-sm--12">
                                <h3 class="-text--boldest text_20 -mb--1" data-cy="cy-manage__label">Manage</h3>
                            </div>
                            <div class="chi-col -w-sm--12">
                                <ChiDataTable
                                    :config="config"
                                    :data="table"
                                    data-cy="cy-myapps__table"
                                    v-if="fetchDataCount"
                                >
                                    <template #name="payload">
                                        {{ payload.name }}
                                    </template>
                                    <template #environment="payload">
                                        {{ payload.environment }}
                                    </template>
                                    <template #api_product="payload">
                                        {{ payload.api_product }}
                                    </template>

                                    <template #created="payload">
                                        {{ getFormatedDate(payload.created) }}
                                    </template>
                                    <template #appName="payload">
                                        <div class="-w--50 -text--center">
                                            <ActionLayout :data="payload" @childAppDetails="deleteSelectedApp" />
                                        </div>
                                    </template>
                                    <template #accordionContent="payload">
                                        <div
                                            class="-d--flex -flex--column sub_chi_tbl -w--100 -bg--white -px--5 -py--2"
                                        >
                                            <div class="-w--80">
                                                <chi-label for="consumer_key" data-cy="cy-consumerKey__lbl"
                                                    >Consumer Key</chi-label
                                                >

                                                <div data-cy="cy-consumerkey" class="-text--md">
                                                    {{ payload.consumerkey }}

                                                    <a
                                                        id="details_link"
                                                        class="chi-link -pl--4"
                                                        v-on:click="(e) => copyClip(e, payload.consumerkey)"
                                                    >
                                                        <i
                                                            class="chi-icon icon-copy -icon--primary -sm"
                                                            aria-hidden="true"
                                                        ></i
                                                        >&nbsp;
                                                        <span class="-text--md">Copy</span>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="-w--60 -py--2">
                                                <ChiDataTable
                                                    :config="payload.element.data.config"
                                                    :data="payload.element.data.table"
                                                >
                                                    <template #apiproduct="payload">
                                                        <div style="white-space: normal; word-wrap: break-word">
                                                            {{ payload.apiproduct }}
                                                        </div>
                                                    </template>
                                                    <template #status="payload">
                                                        <div
                                                            class="chi-badge -success"
                                                            v-if="payload.status.toLowerCase() === 'approved'"
                                                        >
                                                            <span>Approved</span>
                                                        </div>
                                                        <div
                                                            class="chi-badge -warning"
                                                            v-if="payload.status.toLowerCase() === 'pending'"
                                                        >
                                                            <span>Pending</span>
                                                        </div>
                                                        <div
                                                            class="chi-badge -muted"
                                                            v-if="payload.status.toLowerCase() === 'revoked'"
                                                        >
                                                            <span>Revoked</span>
                                                        </div>
                                                    </template>
                                                </ChiDataTable>
                                            </div>
                                        </div>
                                    </template>
                                </ChiDataTable>
                            </div>
                        </div>
                    </div>
                    <div class="chi-col -w-sm--12">
                        <div
                            class="chi-data-table -portal -px--3 -mb--3"
                            v-if="numRecord > 0 && numRecord < recPerPage"
                        >
                            <div class="chi-data-table__footer chi-data-table__row chi-table-footer">
                                <nav
                                    role="navigation"
                                    aria-label="Pagination"
                                    class="chi-pagination"
                                    data-cy="cy-pagination__block"
                                >
                                    <div class="chi-pagination__content">
                                        <div class="chi-pagination__start">
                                            <div class="chi-pagination__results">
                                                <span class="chi-pagination__label" data-cy="cy-results__label">{{
                                                    numRecText
                                                }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </nav>
                            </div>
                        </div>
                    </div>

                    <div
                        class="chi-alert -info -m--3"
                        role="alert"
                        v-if="!fetchDataCount"
                        data-cy="cy-no-apps-info__title"
                    >
                        <i class="chi-alert__icon chi-icon icon-circle-info" aria-hidden="true"></i>
                        <div class="chi-alert__content">
                            <p class="chi-alert__text">
                                You currently don’t have any Credentials.
                                <span v-if="featureFlag">
                                    Click <router-link :to="'/credentials/addnew'">here</router-link> to get
                                    started.</span
                                >
                            </p>
                        </div>
                    </div>
                </div>
                <div class="-d--none">
                    <chi-button data-target="#delete-api-modal" id="delete-api-modal-trigger" @click="deleteClick()">
                        <chi-icon icon="delete"></chi-icon> <span class="-pl--1">Delete API</span>
                    </chi-button>
                </div>
                <Modal :modalObject="deleteAPIModal" :id="`delete-api-modal`" />
            </div>
        </template>
    </AppLayout>
</template>
<script lang="ts">
import { DataTableUtils } from '@/utils/dataTableUtils';
import { Component, Vue } from 'vue-property-decorator';
import { getModule } from 'vuex-module-decorators';
import { CustomModal } from '@/models/custom-modal';
import Modal from '@/modules/common/_components/Modal.vue';
import { DataTableConfig, DataTableRow, ProductsTableResponse, TableTemplate } from '@/models/chiTableTypes';
import {
    MYAPPS_TABLE_CONFIG,
    MONTHS,
    MYAPPS_TABLE_TEMPLATES,
    MYAPPS_TABLE_COLUMNS,
    APPS_TABLE_CONFIG,
    APPS_TABLE_COLUMNS,
    AppListTableRow,
    APPS_TABLE_TEMPLATES,
    AlertObj,
} from '@/modules/myapps/_constants/list/apiChiTable';
import { MODAL_TITLES, MODAL_MESSAGE_FUNC, MODAL_APPLY_BUTTONS } from '@/utils/messages';
import MyAppsStore, { STORE_KEY } from '../../_store';
import ActionLayout from './ActionLayout.vue';
import AppLayout from '@/modules/common/_components/AppLayout.vue';
@Component({
    components: { AppLayout, ActionLayout, Modal },
    data() {
        return {
            MYAPPS_TABLE_TEMPLATES,
            MYAPPS_TABLE_COLUMNS,
            APPS_TABLE_COLUMNS,
            APPS_TABLE_TEMPLATES,
            DataTableUtils,
        };
    },
})
export default class MyAppLayout extends Vue {
    private delAppDetails: any = [];
    private APIarr: ProductsTableResponse[] = [];
    private chiInstance = (window as Window).chi;
    private subscription: any;
    appStore!: MyAppsStore;
    numRecord: number = 0;
    numRecText: string = '';
    failureAlert: boolean = false;
    modal: any;
    recPerPage: any = MYAPPS_TABLE_CONFIG.resultsPerPage;
    config: DataTableConfig = MYAPPS_TABLE_CONFIG;
    config1: DataTableConfig = APPS_TABLE_CONFIG;
    deleteAPIModal: CustomModal = new CustomModal('', '', () => '');
    alertObj!: AlertObj;
    featureFlag;

    async created() {
        this.featureFlag = this.$store.state.userContext.flags.apienable_apihub_menu_active;
        const isModuleRegistered = Object.keys(this.$store.state).includes(STORE_KEY);
        if (!isModuleRegistered) {
            this.$store.registerModule(STORE_KEY, MyAppsStore);
        }
        this.appStore = getModule(MyAppsStore, this.$store);

        this.appStore.loadAppData();
        this.appStore.loadProductDetailsAndEnvironments();
        this.loadInitialStateForAlerts();
    }

    async mounted(): Promise<void> {
        this.modal = this.chiInstance.modal(document.getElementById('delete-api-modal-trigger'));
        this.subscription = this.$store.subscribe((mutation, state) => {
            const currentMutation = mutation.type.split('/')[1];
            const currentStore = state[STORE_KEY];
            if (currentMutation === 'setAppData') {
                this.APIarr = currentStore.appData;
                this.numRecord = currentStore.appData.length;
            }
            if (currentMutation === 'setAlertObj') {
                this.toogleAlert(true, currentStore.alertObj);
            }
        });
    }

    get table(): any {
        if (this.fetchDataCount == 1) {
            MYAPPS_TABLE_COLUMNS.name.sortable = false;
            MYAPPS_TABLE_COLUMNS.environment.sortable = false;
            MYAPPS_TABLE_COLUMNS.api_product.sortable = false;
            MYAPPS_TABLE_COLUMNS.created.sortable = false;
        }
        return {
            head: MYAPPS_TABLE_COLUMNS,
            body: this.filteredListApps,
        };
    }

    get filteredListApps(): DataTableRow[] {
        this.numRecord = this.fetchDataCount;
        const resTxt = this.numRecord < 2 ? 'result' : 'results';
        this.numRecText = this.numRecord.toString().concat(' ', resTxt);
        const localTableData: DataTableRow[] = [];
        this.APIarr.forEach((element: any) => {
            const row: any = {
                id: element.id.toString(),
                active: false,
                data: this.templateRow(element, MYAPPS_TABLE_TEMPLATES),
                nestedContent: {
                    template: 'accordionContent',
                    payload: {
                        consumerkey: element.consumerkey,
                        element: {
                            id: element.id.toString(),
                            data: {
                                config: APPS_TABLE_CONFIG,
                                table: {
                                    head: APPS_TABLE_COLUMNS,
                                    body: this.templateRowChild(element.apiProduct),
                                },
                            },
                        },
                    },
                },
            };
            localTableData.push(row);
        });
        return localTableData;
    }

    get fetchDataCount(): number {
        return Object.keys(this.APIarr).length;
    }

    private loadInitialStateForAlerts(): void {
        if (this.appStore.getAlertObj) {
            this.toogleAlert(true, this.appStore.getAlertObj);
        }
    }

    templateRow(element: AppListTableRow, tableTEMPLATES: Record<string, string>): (string | TableTemplate)[] {
        const row: (string | TableTemplate)[] = [];
        for (const key in tableTEMPLATES) {
            const tempName = tableTEMPLATES[key];
            const template: TableTemplate = {
                template: tempName,
                payload: {
                    [tempName]: element[tempName],
                    element,
                },
            };
            row.push(template);
        }
        return row;
    }

    templateRowChild(data: any[]): DataTableRow[] {
        const localTableData: DataTableRow[] = [];
        data.forEach((element: any) => {
            const row: any = {
                active: false,
                data: this.templateRow(element, APPS_TABLE_TEMPLATES),
            };
            localTableData.push(row);
        });
        return localTableData;
    }

    getFormatedDate(InputDate: string): string {
        const expDate = new Date(InputDate);
        return `${expDate.getDate()} ${MONTHS[expDate.getMonth()]} ${expDate.getFullYear()} ${expDate.toLocaleString(
            'en-US',
            { hour: 'numeric', minute: 'numeric', hour12: true }
        )}`;
    }

    copyClip(_event: object, code: string) {
        navigator.clipboard.writeText(code);
    }

    deleteSelectedApp(delObj: any): any {
        MODAL_TITLES.DELETE_CLIENT = 'Delete Credentials';
        this.delAppDetails = delObj;
        const targetArea = document.querySelector('.chi-modal__content');
        const elem = document.querySelectorAll('.icon_child');
        if (!elem.length && targetArea) {
            const itag = document.createElement('i');
            itag.className = 'chi-icon icon-circle-x -icon--danger -mr--1 icon_child';
            itag.setAttribute('aria-hidden', 'true');
            itag.setAttribute('data-cy', 'cy-client__modal');
            const snippet = document.createTextNode('');
            itag.appendChild(snippet);
            targetArea.append(itag);
        }
        document.getElementById('delete-api-modal-trigger')?.click();
    }

    deleteClick() {
        const applyFunc = async () => {
            this.appStore.deleteApp({
                name: this.delAppDetails.name,
                appName: this.delAppDetails.appName,
            });
        };
        const deleteClientModal = new CustomModal(
            MODAL_TITLES.DELETE_CLIENT,
            MODAL_MESSAGE_FUNC.deleteClient(this.delAppDetails.name.concat(' ?')),
            applyFunc.bind(this),
            {
                acceptText: MODAL_APPLY_BUTTONS.DELETE_CLIENT,
                acceptTag: 'cy-delete-api-modal__accept__button',
                cancelTag: 'cy-delete-api-modal__cancel__button',
            }
        );
        this.deleteAPIModal = deleteClientModal;
    }

    toogleAlert(show: boolean, alertObj?: AlertObj): void {
        this.failureAlert = show;
        if (show && alertObj) {
            this.alertObj = alertObj;
        }
    }

    beforeDestroy() {
        this.appStore.setAlertObj(undefined!);
        this.modal.dispose();
        this.subscription();
    }
}
</script>
<style>
.chi-data-table__row-child {
    background-color: #fff !important;
}
.chi .chi-data-table.-portal .sub_chi_tbl .chi-data-table__head .chi-data-table__row {
    background-color: #f8f9f9;
}
.chi .chi-data-table.-portal .sub_chi_tbl .chi-data-table__body .chi-data-table__row {
    background-color: #fff;
}
[data-label~='Created'] {
    padding-left: 6rem !important;
}
.chi-table-footer {
    padding-top: 0.75rem !important;
    padding-bottom: 0.75rem !important;
}

.text_20 {
    font-size: 1.25rem !important;
    line-height: normal !important;
}

.chi-modal__footer {
    margin: 1rem !important;
}

.chi-modal__content p {
    display: contents;
    float: right;
}

.icon_child {
    float: left;
    margin-top: 2px;
}

.chi-modal__footer [data-cy~='cy-delete-api-modal__accept__button'] {
    margin-left: 0.5rem !important;
}
</style>
