<template>
    <div v-if="featureFlag" class="chi-dropdown chi-dropdown__hover">
        <i class="chi-icon icon-more-vert" data-cy="cy-actions__iconbtn" aria-hidden="true"></i>
        <div class="chi-dropdown__menu" data-cy="cy-actionsDropdown__icn">
            <router-link
                class="edit_menu_item"
                data-cy="cy-edit__appbtn"
                :to="{ name: 'editapp', params: { appName: data.appName } }"
            >
                <a class="chi-dropdown__menu-item" href="#">Edit</a>
            </router-link>
            <a
                class="chi-dropdown__menu-item"
                data-cy="cy-overview_delete__button"
                href="#"
                @click="delAppDetails({ appName: data.appName, name: data.element.name })"
                >Delete</a
            >
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
@Component
export default class ActionLayout extends Vue {
    @Prop({ default: '' }) data: any;
    featureFlag;

    created() {
        this.featureFlag = this.$store.state.userContext.flags.apienable_apihub_menu_active;
    }

    delAppDetails(obj) {
        this.$emit('childAppDetails', obj);
    }
}
</script>
<style>
.edit_menu_item {
    text-decoration: none !important;
}
</style>
