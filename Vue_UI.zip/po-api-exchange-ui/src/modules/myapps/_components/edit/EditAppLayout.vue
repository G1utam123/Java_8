<template>
    <div class="editapp chi" data-ut="ut-editapp">
        <div class="chi-app -w--95">
            <div class="wrapper -bg--white">
                <div class="chi-grid -mx--3 -mt--3">
                    <div class="chi-col -w--12">
                        <div class="chi-main__header-start" id="details_link">
                            <router-link
                                v-if="firstBlock"
                                data-cy="cy-myapp__back"
                                :to="{
                                    name: 'Credentials',
                                    params: {
                                        page: 'credentials',
                                        alert: '',
                                        alertmsg: '',
                                    },
                                }"
                            >
                                <div class="chi-link__content">
                                    <i class="chi-icon icon-chevron-left -xs" aria-hidden="true"></i>
                                    <span class="-text--md">Credentials</span>
                                </div>
                            </router-link>

                            <a class="chi-link" @click="backlink" v-else>
                                <div class="chi-link__content">
                                    <i class="chi-icon icon-chevron-left -xs" aria-hidden="true"></i>
                                    <span class="-text--md">Details</span>
                                </div>
                            </a>
                            <div class="chi-main__title">
                                <h3
                                    class="chi-epanel__title -text--navy -text--boldest -br--1 -pr--2"
                                    data-cy="cy-my-app__title"
                                    id="h3_header"
                                >
                                    Edit
                                </h3>
                                <div class="-text--md -pl--2" data-cy="cy-app__name">{{ apiOldName }}</div>
                            </div>
                        </div>
                    </div>
                    <div class="chi-col -w--12 block_1 -px--0" data-cy="cy-block_1" v-if="firstBlock">
                        <div class="chi-col -w--12">
                            <h3 class="-text--boldest text_20 -mb--1" data-cy="cy-manage__label">Details</h3>
                        </div>

                        <div class="chi-col -w--12">
                            <div class="-bg--muted-lighter -px--2 -py--2">
                                <div class="chi-grid">
                                    <div class="chi-col -w--3 -py--1">
                                        <div class="chi-form__item">
                                            <label for="appName" class="chi-label" data-cy="cy-appName__lbl">
                                                Credential Name</label
                                            >
                                            <input
                                                type="text"
                                                class="chi-input"
                                                id="appName"
                                                v-model="prodAppName"
                                                placeholder="Enter App Name"
                                                @keyup="onInputChanged"
                                                v-bind:class="{ ' -danger': !isBlank }"
                                                data-cy="cy-appName__tbx"
                                            />
                                        </div>
                                    </div>
                                    <div class="chi-col -w--9 -py--1">
                                        <label for="appEnv" class="chi-label" data-cy="cy-appEnv__lbl">
                                            Environment</label
                                        >
                                        <p class="-text--normal -mt--0" data-cy="cy-appEnv__name">
                                            {{ prodEnvironment }}
                                        </p>
                                    </div>
                                </div>
                                <div class="chi-grid" data-cy="cy-name__required">
                                    <div class="chi-col -w--12 -py--1">
                                        <div
                                            v-if="!isBlank"
                                            class="chi-label -status -danger"
                                            data-cy="cy-name__required__error"
                                        >
                                            <i class="chi-icon icon-circle-warning" aria-hidden="true"></i>
                                            Please enter a name.
                                        </div>
                                        <div
                                            v-if="noUnique"
                                            class="chi-label -status -danger"
                                            data-cy="cy-name__unique__error"
                                        >
                                            <i class="chi-icon icon-circle-warning" aria-hidden="true"></i>
                                            An App with this name already exists. Please try another name.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="chi-col -w-sm-12 -mt--3">
                            <div class="chi-grid">
                                <div class="chi-col -w--4">
                                    <h3 class="-text--boldest text_20 -mb--1" data-cy="cy-apiProducts__lbl">
                                        <span class="-br--1 -pr--2">API Products</span>
                                        <span class="-text--normal -text--md -pl--2" data-cy="cy-productsCount__lbl">
                                            {{ recordCount }}
                                        </span>
                                    </h3>
                                </div>
                                <div class="chi-col -w--6 -px--0"></div>
                                <div class="chi-col -w--2 -text-xl--right">
                                    <button
                                        type="button"
                                        class="chi-button -xs -mt--2"
                                        data-cy="cy-manage__btn"
                                        @click="btnManageSelectedApi()"
                                    >
                                        Manage Selected APIs
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="chi-col -w--12" data-cy="cy-apiProducts__table">
                            <div class="chi-grid">
                                <div class="chi-col -w--12 -pb--2">
                                    <ChiDataTable
                                        :config="config"
                                        :data="table"
                                        @chiRowSelected="(e) => rowSelected(e)"
                                    >
                                        <template #productDisplayName="payload">
                                            {{ payload.productDisplayName }}
                                        </template>
                                        <template #prodDescription="payload">
                                            <div class="description_class">
                                                {{ payload.prodDescription }}
                                            </div>
                                        </template>
                                        <template #productName="payload">
                                            <div class="chi" style="resize: both">
                                                <ChiTooltip message="Remove" position="top">
                                                    <button
                                                        type="button"
                                                        id="16abcc68d1cd66f8c2d3a0a39de53807"
                                                        class="chi-button -icon -flat"
                                                        @click="removeProduct(payload.element.id)"
                                                        data-cy="cy-removeProduct__btn"
                                                    >
                                                        <div class="chi-button__content">
                                                            <i class="chi-icon icon-x" aria-hidden="true"></i>
                                                        </div>
                                                    </button>
                                                </ChiTooltip>
                                            </div>
                                        </template>
                                    </ChiDataTable>
                                    <div class="chi-grid">
                                        <div
                                            class="chi-col -w--12 -pb--2 -mx--0 -mt--2 -mb--0"
                                            v-if="recordCount == 0"
                                            data-cy="cy-minProdErr__lbl"
                                        >
                                            <chi-alert color="danger" icon="circle-warning" size="sm">
                                                You must select at least one product.
                                            </chi-alert>
                                        </div>
                                    </div>
                                    <div class="chi-col -w--12 -bb--1" />
                                </div>
                            </div>
                        </div>
                        <div class="chi-col -w--12 -mt--2">
                            <div class="chi-grid">
                                <div class="chi-col -w--8"></div>
                                <div class="chi-col -w--4 -text-xl--right">
                                    <router-link :to="{ name: 'Credentials', params: {} }">
                                        <button
                                            class="chi-button -primary -outline -uppercase -mr--1"
                                            data-cy="cy-cancel__btn"
                                        >
                                            Cancel
                                        </button>
                                    </router-link>

                                    <chi-button
                                        color="primary"
                                        data-cy="cy-save__btn"
                                        @chiClick="() => updateAppData()"
                                    >
                                        Save Changes</chi-button
                                    >
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="chi-col -w--12 block_2 -px--0" data-cy="cy-block_2" v-if="firstBlock == false">
                        <div class="chi-col -w--12">
                            <h3 class="-text--boldest text_20 -mb--1" data-cy="cy-manageSelected__label">
                                Select Products
                            </h3>

                            <div class="chi-col -w--12 -px--0" data-cy="cy-minProdErr__lbl">
                                <p class="-text--normal -mb--1">Please select at least one product</p>
                            </div>
                            <div class="chi-col -w-sm--12">
                                <div class="chi-grid -bg--muted-lighter">
                                    <div class="chi-col -w--3 -py--1">
                                        <div class="chi-form__item -py--2">
                                            <div class="chi-form__item">
                                                <div class="chi-input__wrapper -icon--right">
                                                    <input
                                                        class="chi-input chi-search__input"
                                                        type="search"
                                                        placeholder="Search"
                                                        aria-label="search input"
                                                        v-model="searchProduct"
                                                        data-cy="cy-search__tbx"
                                                        @keyup="onSearchProduct"
                                                    />
                                                    <button
                                                        class="chi-button -icon -flat -bg--none"
                                                        aria-label="Search"
                                                    >
                                                        <div class="chi-button__content">
                                                            <i class="chi-icon icon-search" aria-hidden="true"></i>
                                                        </div>
                                                    </button>
                                                    <button
                                                        class="chi-button -icon -close -sm search_close"
                                                        aria-label="Close"
                                                        @click="closeSearch"
                                                    >
                                                        <div class="chi-button__content">
                                                            <i class="chi-icon icon-x" aria-hidden="true"></i>
                                                        </div>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="chi-col -w--9 -pt--3">
                                        <div class="chi-col -bl--1">
                                            <label for="appEnv" class="chi-label" data-cy="cy-appEnv__lbl">
                                                Environment</label
                                            >
                                            <p class="-text--normal -mt--0" data-cy="cy-appEnv__name">
                                                {{ prodEnvironment }}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="chi-grid">
                                    <div class="chi-col -w--12">
                                        <div class="chi-grid -bg--secondary">
                                            <div class="chi-col -w--2">
                                                <p class="-text--bold" data-cy="cy-manageSelProdCount__lbl">
                                                    {{ selectedAppCount }} Selected
                                                </p>
                                            </div>
                                            <div class="chi-col -w--10">
                                                <div class="chi-form__item">
                                                    <p class="chi-checkbox">
                                                        <input
                                                            type="checkbox"
                                                            class="chi-checkbox__input"
                                                            id="showSelectedOnly"
                                                            v-model="showSelected"
                                                            @change="check($event)"
                                                            data-cy="cy-showSelectedOnly__cbx"
                                                        />
                                                        <label
                                                            class="chi-checkbox__label"
                                                            for="showSelectedOnly"
                                                            data-cy="cy-showSelectedOnly__lbl"
                                                            >Show Selected Only</label
                                                        >
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="chi-grid">
                                    <div class="chi-col -w--12 -px--0" data-cy="cy-manageSelAPIProducts__table">
                                        <ChiDataTable
                                            :config="configProd"
                                            :data="prodTable"
                                            @chiRowSelected="(e) => rowSelected(e)"
                                            @chiRowDeselected="(e) => rowSelected(e)"
                                            @chiSelectAll="(e) => rowSelectedAll(e, 1)"
                                            @chiDeselectAll="(e) => rowSelectedAll(e, 0)"
                                        >
                                            <template #productDisplayName="payload">
                                                <div
                                                    :class="{
                                                        disable_text: payload.element.isdisabled,
                                                    }"
                                                >
                                                    {{ payload.productDisplayName }}
                                                </div>
                                            </template>
                                            <template #prodDescription="payload">
                                                <div
                                                    class="description_class"
                                                    :class="{
                                                        disable_text: payload.element.isdisabled,
                                                    }"
                                                >
                                                    {{
                                                        payload.element.isdisabled
                                                            ? 'Product currently unavailable in selected environment.'
                                                            : payload.prodDescription
                                                    }}
                                                </div>
                                            </template>
                                        </ChiDataTable>
                                        <div class="chi-grid" v-if="!selectedAppCount">
                                            <div
                                                class="chi-col -w--12 -pb--2 -mx--0 -mt--2 -mb--0"
                                                data-cy="cy-manageSelectedProdsError__lbl"
                                            >
                                                <chi-alert color="danger" icon="circle-warning" size="sm">
                                                    You must select at least one product.
                                                </chi-alert>
                                            </div>
                                        </div>
                                        <div class="chi-col -w--12 -bb--1" />
                                    </div>
                                </div>
                                <div class="chi-grid">
                                    <div class="chi-col -w--12 -mt--2">
                                        <div class="chi-grid">
                                            <div class="chi-col -w--9"></div>
                                            <div class="chi-col -w--3 -text-xl--right -px--0">
                                                <button
                                                    class="chi-button -primary -outline -uppercase -mr--1"
                                                    data-cy="cy-manageSelectedBack__btn"
                                                    @click="backlink"
                                                >
                                                    Back
                                                </button>
                                                <button
                                                    class="chi-button -primary -uppercase"
                                                    data-cy="cy-manageSelectedUpdate__btn"
                                                    @click="updateProduct"
                                                >
                                                    Update
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <Footer />
    </div>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { DataTableUtils } from '@/modules/myapps/_global/utils/dataTableUtils';
import { getModule } from 'vuex-module-decorators';
import { DataTableConfig, DataTableRow } from '@/models/chiTableTypes';
import {
    APPS_TABLE_CONFIG,
    APP_TABLE_TEMPLATES,
    APP_TABLE_COLUMNS,
    PRODUCT_TABLE_CONFIG,
    PRODUCT_TABLE_TEMPLATES,
    PRODUCT_TABLE_COLUMNS,
    APIProductDataTableRow,
    EditInputType,
    AppListResponse,
} from '@/modules/myapps/_global/apiChiTable';
import MyAppsStore from '@/modules/myapps/_store';
import Footer from '@/modules/common/_components/Footer.vue';
@Component({
    components: { Footer },
    data() {
        return {
            APPS_TABLE_CONFIG,
            APP_TABLE_TEMPLATES,
            APP_TABLE_COLUMNS,
            PRODUCT_TABLE_CONFIG,
            PRODUCT_TABLE_TEMPLATES,
            PRODUCT_TABLE_COLUMNS,
        };
    },
})
export default class EditAppLayout extends Vue {
    public config: DataTableConfig = APPS_TABLE_CONFIG;
    public configProd: DataTableConfig = PRODUCT_TABLE_CONFIG;
    public prodAppName: string = '';
    public searchProduct: string = '';
    public apiOldName: string = '';
    private uniqueId: any;
    private appStore!: MyAppsStore;
    public prodEnvironment: string = '';
    public noUnique: boolean = false;
    private minProduct: boolean = false;
    private timer: number = 1;
    private appNames: string[] = [];
    private APIarr: AppListResponse[] = [];
    private linkedProducts: any[] = [];
    private tempAPIarr: any[] = [];
    public showSelected: boolean = false;
    public firstBlock: boolean = true;
    private apiProducts: APIProductDataTableRow[] = [];
    private apiTempProducts: APIProductDataTableRow[] = [];
    private appConsumerKey: string = '';
    private appStatus: string = '';
    get table(): any {
        if (this.recordCount == 1) {
            APP_TABLE_COLUMNS.productDisplayName.sortable = false;
        } else {
            APP_TABLE_COLUMNS.productDisplayName.sortable = true;
        }
        return {
            head: APP_TABLE_COLUMNS,
            body: this.filteredTableBody,
        };
    }

    get prodTable(): any {
        if (this.apiProducts.length == 1) {
            PRODUCT_TABLE_COLUMNS.productDisplayName.sortable = false;
        } else {
            PRODUCT_TABLE_COLUMNS.productDisplayName.sortable = true;
        }

        return {
            head: PRODUCT_TABLE_COLUMNS,
            body: this.filteredTableAllProduct,
        };
    }

    created() {
        this.uniqueId = this.$route.params.appName;
        if (!this.appStore) {
            this.appStore = getModule(MyAppsStore, this.$store);
        }
    }
    beforeMount() {
        this.apiTempProducts = this.apiProducts = JSON.parse(JSON.stringify(this.appStore.getAllProducts));
        let applist = this.appStore.getAppData;
        this.appNames = this.appStore.getUniqueAppName;
        let selList = applist.find((o) => o.appName === this.uniqueId);
        this.prodAppName = this.apiOldName = selList.name;
        this.appConsumerKey = selList.consumerkey;
        this.appStatus = selList.status;
        this.appNames = this.appNames.filter((obj) => obj !== selList.appName);
        this.prodEnvironment = selList.environment;

        let prodNames: string[] = [...selList.apiProduct.map((obj) => obj.apiproduct)];
        this.APIarr = this.apiTempProducts
            .filter((obj) => prodNames.indexOf(obj.productName) > -1)
            .map((obj) => ({
                id: obj.id,
                productDisplayName: obj.productDisplayName,
                prodDescription: obj.prodDescription,
                productName: obj.productName,
            }));

        this.addedProductsList();
        this.linkedProductList();
    }
    onSearchProduct(): void {
        this.showSelected = false;
        let re = new RegExp(`.*${this.searchProduct.toLowerCase()}.*`, 'g');
        clearTimeout(this.timer);
        this.timer = setTimeout(() => {
            this.apiProducts = [
                ...this.apiTempProducts.filter(
                    (o) => o.productDisplayName.toLowerCase().match(re) || o.prodDescription.toLowerCase().match(re)
                ),
            ];
        }, 500);
    }
    closeSearch(): void {
        this.showSelected = false;
        this.searchProduct = '';
        this.apiProducts = [...this.apiTempProducts];
    }
    onInputChanged(): void {
        clearTimeout(this.timer);
        this.timer = setTimeout(() => {
            let appprodName = this.prodAppName.replace(/[^A-Z0-9]/gi, '_').toLowerCase();
            if (this.appNames.includes(appprodName)) {
                this.noUnique = true;
            } else {
                this.noUnique = false;
            }
        }, 250);
    }
    btnManageSelectedApi() {
        this.firstBlock = false;
        this.tempAPIarr = [...this.linkedProducts];
        this.closeSearch();
    }
    addedProductsList(): void {
        this.tempAPIarr = [
            ...this.APIarr.map((obj) => ({
                id: obj.id,
            })),
        ];
    }
    linkedProductList(): void {
        this.linkedProducts = [
            ...this.APIarr.map((obj) => ({
                id: obj.id,
            })),
        ];
    }
    removeProduct(id: number): void {
        this.APIarr = this.APIarr.filter((o) => o.id != id);
        this.addedProductsList();
        if (this.recordCount == 0) {
            this.minProduct = true;
        }
        this.linkedProductList();
    }
    backlink() {
        this.firstBlock = true;
    }

    updateProduct() {
        if (this.selectedAppCount == 0) {
            document.getElementById('details_link')!.scrollIntoView();
        } else {
            let addedProdId: number[] = [...this.tempAPIarr.map((obj) => obj.id)];
            this.APIarr = [
                ...this.apiTempProducts
                    .filter((o) => addedProdId.indexOf(o.id) > -1)
                    .map((obj) => ({
                        id: obj.id,
                        productDisplayName: obj.productDisplayName,
                        productName: obj.productName,
                        prodDescription: obj.prodDescription,
                    })),
            ];
            this.linkedProductList();
            this.firstBlock = true;
        }
    }

    updateAppData() {
        let selectedProducts = [...this.APIarr.map((obj) => ({ apiproduct: obj.productName }))];
        if (
            selectedProducts.length == 0 ||
            this.appConsumerKey.length == 0 ||
            this.uniqueId.length == 0 ||
            this.appStatus.length == 0 ||
            this.prodEnvironment.length == 0 ||
            this.prodAppName.length == 0 ||
            this.noUnique
        ) {
            document.getElementById('details_link')!.scrollIntoView();
            return 0;
        }
        const formData: EditInputType = {
            credentials: [
                {
                    apiProducts: selectedProducts,
                    consumerKey: this.appConsumerKey,
                    expiresAt: -1,
                },
            ],
            name: this.uniqueId,
            keyExpiresIn: -1,
            status: this.appStatus,
            attributes: [
                {
                    name: 'environment',
                    value: this.prodEnvironment,
                },
                {
                    name: 'DisplayName',
                    value: this.prodAppName,
                },
            ],
        };
        this.updateApp(this, formData);
    }
    async updateApp(me: any, formData: EditInputType) {
        await me.appStore.updateApp({
            appName: me.prodAppName,
            formData: formData,
        });

        this.$router.push({
            path: '/credentials',
            name: 'Credentials',
        });
    }

    get isBlank(): number {
        return this.prodAppName.replace(/\s/g, '').length;
    }
    get recordCount(): number {
        return this.APIarr.length;
    }

    get filteredTableBody(): DataTableRow[] {
        const tableDataBody = DataTableUtils.getTableBody(this.APIarr, APP_TABLE_TEMPLATES);
        return [...tableDataBody];
    }

    get selectedAppCount(): number {
        return this.tempAPIarr.length;
    }

    get filteredTableAllProduct(): DataTableRow[] {
        const localTableData: DataTableRow[] = [];
        let selectedProds: number[] = this.getSelectedProducts;
        this.apiProducts.forEach((element: any) => {
            let selected = selectedProds.indexOf(element.id) > -1 ? true : false;
            let disabled = element.envirments.indexOf(this.prodEnvironment) == -1;
            element.isdisabled = disabled;
            const row: DataTableRow = {
                id: element.id.toString(),
                active: false,
                selected: selected,
                selectionDisabled: disabled,
                data: DataTableUtils.templateRow(element, PRODUCT_TABLE_TEMPLATES),
            };
            localTableData.push(row);
        });
        return localTableData;
    }

    public rowSelected(selectedRow: DataTableRow): void {
        if (selectedRow.selected) {
            this.tempAPIarr.push({ id: parseInt(selectedRow.id) });
        } else {
            this.tempAPIarr = this.tempAPIarr.filter((o) => o.id != parseInt(selectedRow.id));
        }
    }
    public rowSelectedAll(selectedRow: DataTableRow[], _type: number): void {
        if (_type) {
            this.tempAPIarr = selectedRow
                .filter((obj) => !obj.selectionDisabled)
                .map((obj) => ({
                    id: parseInt(obj.id),
                }));
        } else {
            this.tempAPIarr = [];
        }
    }

    get getSelectedProducts(): number[] {
        return [...this.tempAPIarr.map((obj) => obj.id)];
    }

    check(e) {
        this.searchProduct = '';
        this.$nextTick(() => {
            if (e.target.checked) {
                let selectedProds: number[] = this.getSelectedProducts;
                this.apiProducts = [
                    ...this.apiTempProducts.filter((product) => selectedProds.indexOf(product.id) > -1),
                ];
            } else {
                this.apiProducts = [...this.apiTempProducts];
            }
        });
    }
}
</script>
<style scoped>
.disable_text {
    color: #8e9399;
    cursor: default;
}
.description_class {
    white-space: normal;
}
button.search_close div i {
    line-height: 0.5rem !important;
}
.text_20 {
    font-size: 1.25rem !important;
    line-height: normal;
}
</style>
