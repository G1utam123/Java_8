<template>
    <div class="CreateApp chi" data-ut="ut-createapps">
        <div class="chi-app -w--95">
            <div class="wrapper -bg--white" v-if="step === 1">
                <!-- start -->

                <div class="chi-grid -mx--3 -mt--3">
                    <div class="chi-col -w--6 -o--3">
                        <ul class="chi-steps" data-cy="cy-createPageStep__lbl">
                            <li class="chi-steps__item -active">
                                <div class="chi-steps__icon">
                                    <div class="chi-steps__content">
                                        <a class="chi-steps__item-title" href="#">Create</a>
                                    </div>
                                </div>
                                <div class="chi-steps__line"></div>
                            </li>
                            <li class="chi-steps__item">
                                <div class="chi-steps__icon">
                                    <div class="chi-steps__content">
                                        <a class="chi-steps__item-title" href="#">Review</a>
                                    </div>
                                </div>
                                <div class="chi-steps__line"></div>
                            </li>
                            <li class="chi-steps__item">
                                <div class="chi-steps__icon">
                                    <div class="chi-steps__content">
                                        <a class="chi-steps__item-title" href="#">Complete</a>
                                    </div>
                                </div>
                                <div class="chi-steps__line"></div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="chi-grid -px--3 -mt--3 -mx--3">
                    <div class="chi-col -w-sm--10 -pl--0">
                        <div class="chi-main__header-start -mt--1">
                            <router-link
                                data-cy="cy-myAppsBack__lnk"
                                :to="{
                                    name: 'Credentials',
                                    params: {
                                        page: 'credentials',
                                        alert: '',
                                        alertmsg: '',
                                    },
                                }"
                            >
                                <div class="chi-link__content" id="details_link">
                                    <i class="chi-icon icon-chevron-left -xs" aria-hidden="true"></i>
                                    <span class="-text--md">Credentials</span>
                                </div>
                            </router-link>
                            <div class="chi-main__title">
                                <div
                                    class="-text--h3 -text--boldest -text--navy -m--0 -br--1 -pr--2"
                                    data-cy="cy-create_apptitle"
                                >
                                    Create
                                </div>
                                <div class="-text--md -pl--2">New Credential</div>
                            </div>
                        </div>
                    </div>
                    <div class="chi-col -w-sm--9 -pl--0 -mt--3">
                        <h3 class="-text--boldest text_20 -mb--1" data-cy="cy-details__lbl">Details</h3>
                    </div>
                    <div class="-bg--muted-lighter chi-col -w--12 -px--4 -py--2">
                        <div class="chi-grid">
                            <div class="chi-col -w--6 -py--2">
                                <div class="chi-form__item">
                                    <label class="chi-label">Credential Name</label>
                                    <input
                                        type="text"
                                        class="chi-input"
                                        id="appName"
                                        v-model="apiName"
                                        placeholder="Enter Credential Name"
                                        @keyup="onInputChanged"
                                        v-bind:class="{ [emptyClass]: !isBlank }"
                                        data-cy="cy-appName__tbx"
                                    />
                                </div>
                                <div class="chi-grid" :class="[isEmptyMessage]" data-cy="cy-name__required">
                                    <div class="chi-col -w--12 -py--1">
                                        <div
                                            v-if="!isBlank"
                                            class="chi-label -status -danger -text--semi-bold error_text"
                                            data-cy="cy-name__required__error"
                                        >
                                            <i class="chi-icon icon-circle-warning" aria-hidden="true"></i>
                                            You must enter a name
                                        </div>
                                        <div
                                            v-if="noUnique"
                                            class="chi-label -status -danger"
                                            data-cy="cy-name__unique__error"
                                        >
                                            <i class="chi-icon icon-circle-warning" aria-hidden="true"></i>
                                            An App with this name already exists. Please try another name.
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="chi-col -w--12 -py--1">
                                <fieldset>
                                    <legend></legend>
                                    <label class="chi-label">Environment</label>
                                    <div class="chi-picker-group" data-cy="cy-environment__picker">
                                        <div class="chi-picker-group__content">
                                            <div v-for="(item, key) in environmentList" :key="key">
                                                <input
                                                    class="chi-picker__input"
                                                    type="radio"
                                                    name="unique-name-Env"
                                                    :id="'unique-id-env' + key"
                                                    :value="item.value"
                                                    v-model="prodEnvironment"
                                                    @change="environmentValue($event)"
                                                />
                                                <label :for="'unique-id-env' + key" class="radioPickerGroupLabel">{{
                                                    item.value
                                                }}</label>
                                            </div>
                                        </div>
                                    </div>
                                </fieldset>
                            </div>
                        </div>
                    </div>
                    <div class="chi-col -w-sm--9 -pl--0 -mt--4">
                        <h3 class="-text--boldest text_20 -mb--1" data-cy="cy-selectProducts__lbl">Select Products</h3>
                        <p v-if="productErrorMessage || selectedAppCount" class="-text--normal -mt--1 -mb--1">
                            Please select at least one product
                        </p>
                    </div>
                    <div class="chi-col -w-sm--12">
                        <div class="chi-grid -bg--muted-lighter">
                            <div class="chi-col -w--4 -py--2 -ml--3 -pl--0">
                                <div class="chi-form__item -py--2">
                                    <div class="chi-form__item">
                                        <div class="chi-input__wrapper -icon--right">
                                            <input
                                                class="chi-input chi-search__input"
                                                type="search"
                                                placeholder="Search"
                                                aria-label="search input"
                                                v-model="searchProduct"
                                                @keyup="onSearchProductData"
                                                data-cy="cy-search__tbx"
                                            />
                                            <button
                                                class="chi-button -icon -flat -bg--none"
                                                aria-label="Search"
                                                @click="onSearchProductData"
                                            >
                                                <div class="chi-button__content">
                                                    <i class="chi-icon icon-search" aria-hidden="true"></i>
                                                </div>
                                            </button>
                                            <button
                                                class="chi-button -icon -close -sm searchCloseButton"
                                                aria-label="Close"
                                                @click="closeSearchButton"
                                            >
                                                <div class="chi-button__content">
                                                    <i class="chi-icon icon-x" aria-hidden="true"></i>
                                                </div>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="chi-col -w-sm--12 -bg--muted-lighter">
                        <div class="chi-grid">
                            <div class="chi-col -w--12">
                                <div class="chi-grid -bg--secondary">
                                    <div class="chi-col -w--2">
                                        <p class="-text--bold" data-cy="cy-selProdCount__lbl">
                                            {{ selectedAppCount }} Selected
                                        </p>
                                    </div>
                                    <div class="chi-col -w--10">
                                        <div class="chi-form__item">
                                            <p class="chi-checkbox">
                                                <input
                                                    type="checkbox"
                                                    class="chi-checkbox__input"
                                                    id="showSelectedOnly"
                                                    v-model="showSelected"
                                                    @change="check($event)"
                                                    data-cy="cy-showSelectedOnly__cbx"
                                                />
                                                <label
                                                    class="chi-checkbox__label"
                                                    for="showSelectedOnly"
                                                    data-cy="cy-showSelectedOnly__lbl"
                                                    >Show Selected Only</label
                                                >
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <section class="chi-table -fixed--header -pt--0 -bg--muted-lighter" style="height: 250px">
                            <div class="chi-col -w--12 -px--0" data-cy="cy-selectProducts__tbl">
                                <ChiDataTable
                                    :config="configProd"
                                    :data="prodAppTable"
                                    @chiRowSelected="(e) => rowSelectedList(e)"
                                    @chiRowDeselected="(e) => rowSelectedList(e)"
                                    @chiSelectAll="(e) => rowSelectedAllList(e, 1)"
                                    @chiDeselectAll="(e) => rowSelectedAllList(e, 0)"
                                >
                                    <template #productDisplayName="payload">
                                        <div
                                            :class="{
                                                disable_text: payload.element.envirments.indexOf(prodEnvironment) == -1,
                                            }"
                                        >
                                            {{ payload.productDisplayName }}
                                        </div>
                                    </template>
                                    <template #prodDescription="payload">
                                        <div
                                            class="disable_text"
                                            style="white-space: normal"
                                            v-if="payload.element.envirments.indexOf(prodEnvironment) == -1"
                                        >
                                            Product currently unavailable in selected environment.
                                        </div>
                                        <div
                                            style="white-space: normal"
                                            v-if="payload.element.envirments.indexOf(prodEnvironment) !== -1"
                                        >
                                            {{ payload.prodDescription }}
                                        </div>
                                    </template>
                                </ChiDataTable>
                            </div>
                        </section>
                    </div>
                </div>
                <div :class="[productErrorMessage]" class="chi-grid">
                    <div
                        class="chi-col -w--12 -ml--3 -mt--2 -mr--6 -mb--0"
                        v-if="selectedAppCount == 0"
                        data-cy="cy-minProdErr__lbl"
                    >
                        <chi-alert color="danger" icon="circle-warning" size="sm">
                            You must select at least one product.
                        </chi-alert>
                    </div>
                </div>
                <div class="-d--flex -align-items--center -justify-content--end -py--3 -my--2 -bt--1 -mx--6">
                    <router-link
                        :to="{
                            name: 'Credentials',
                            params: {
                                page: 'credentials',
                                alert: '',
                                alertmsg: '',
                            },
                        }"
                    >
                        <button class="chi-button -primary -outline -bg--white" data-cy="cy-step1Cancel__btn">
                            CANCEL
                        </button>
                    </router-link>
                    <button class="chi-button -primary -ml--1" data-cy="cy-next__btn" @click.prevent="next()">
                        NEXT
                    </button>
                </div>
            </div>
            <div class="wrapper -bg--white" v-if="step === 2">
                <div class="chi-grid -px--3 -mt--3 -mx--3">
                    <div class="chi-col -w--6 -o--3">
                        <ul class="chi-steps" data-cy="cy-reviewPageSteps__lbl">
                            <li class="chi-steps__item -completed">
                                <div class="chi-steps__icon">
                                    <div class="chi-steps__content">
                                        <a class="chi-steps__item-title" href="#">Create</a>
                                    </div>
                                </div>
                                <div class="chi-steps__line"></div>
                            </li>
                            <li class="chi-steps__item -active">
                                <div class="chi-steps__icon">
                                    <div class="chi-steps__content">
                                        <a class="chi-steps__item-title" href="#">Review</a>
                                    </div>
                                </div>
                                <div class="chi-steps__line"></div>
                            </li>
                            <li class="chi-steps__item">
                                <div class="chi-steps__icon">
                                    <div class="chi-steps__content">
                                        <a class="chi-steps__item-title" href="#">Complete</a>
                                    </div>
                                </div>
                                <div class="chi-steps__line"></div>
                            </li>
                        </ul>
                    </div>
                    <div class="chi-col -w-sm--10 -p--0" id="review_link">
                        <div class="chi-main__header-start -mt--1">
                            <a class="chi-link" @click.prevent="prev()" data-cy="cy-createBack__lnk">
                                <div class="chi-link__content">
                                    <i class="chi-icon icon-chevron-left -xs" aria-hidden="true"></i>
                                    <span class="-text--md">Create</span>
                                </div>
                            </a>
                            <div class="chi-main__title">
                                <div
                                    class="-text--h3 -text--boldest -text--navy -m--0 -br--1 -pr--2"
                                    data-cy="cy-review_apptitle"
                                >
                                    Review
                                </div>
                                <div class="-text--md -pl--2">New Credential</div>
                            </div>
                        </div>
                    </div>
                    <div class="chi-col -w-sm--9 -mt--2 -p--0">
                        <h3 class="-text--boldest text_20 -mb--1" data-cy="cy-manage__label">Details</h3>
                    </div>
                    <div class="-bg--muted-lighter chi-col -w-sm--12 -d-md--flex -px--2 -py--4">
                        <span>
                            <div class="chi-form__item">
                                <chi-label for="example__readonly"> Credential Name </chi-label>
                                <p class="-text--normal -mt--0" data-cy="cy-reviewAppName__tbx">
                                    {{ apiName }}
                                </p>
                            </div>
                        </span>
                        <span class="-ml--5">
                            <div class="chi-form__item">
                                <chi-label for="example__readonly">Environment</chi-label>
                                <p class="-text--normal -mt--0" data-cy="cy-appEnv__name">
                                    {{ prodEnvironment }}
                                </p>
                            </div>
                        </span>
                    </div>
                    <div class="chi-main__title -ml--0 -p--0 -mt--4 -mb--1" data-cy="cy-apiProducts__lbl">
                        <h3 class="-text--boldest -m--0 -br--1 -pr--2 text_20">API Products</h3>
                        <div class="-text--md -pl--2">{{ recordCountData }}</div>
                    </div>
                    <div class="chi-col -w-sm--12 -bg--muted-lighter">
                        <section class="chi-table -fixed--header" style="height: 150px">
                            <ChiDataTable
                                :config="config"
                                :data="appTable"
                                @chiRowSelected="(e) => rowSelectedList(e)"
                                data-cy="cy-apiProducts__tbl"
                            >
                                <template #productDisplayName="payload">
                                    {{ payload.productDisplayName }}
                                </template>
                                <template #prodDescription="payload">
                                    <div style="white-space: normal">
                                        {{ payload.prodDescription }}
                                    </div>
                                </template>
                                <template #productName="payload">
                                    <div class="chi" style="resize: both">
                                        <ChiTooltip message="Remove" position="top">
                                            <button
                                                type="button"
                                                id="16abcc68d1cd66f8c2d3a0a39de53807"
                                                class="chi-button -icon -flat"
                                                @click="removeProduct(payload.element.id)"
                                                data-cy="cy-removeProduct__btn"
                                            >
                                                <div class="chi-button__content">
                                                    <i class="chi-icon icon-x" aria-hidden="true"></i>
                                                </div>
                                            </button>
                                        </ChiTooltip>
                                    </div>
                                </template>
                            </ChiDataTable>
                        </section>
                    </div>
                </div>
                <div class="-d--flex -align-items--center -justify-content--end -py--3 -my--2 -bt--1 -mx--6">
                    <button
                        class="chi-button -primary -outline -bg--white -mr--1"
                        @click.prevent="prev()"
                        data-cy="cy-reviewBack__btn"
                    >
                        BACK
                    </button>
                    <div class="chi-divider -vertical" style="height: 45px"></div>
                    <router-link
                        data-cy="cy-cancelApp__btn"
                        :to="{
                            name: 'Credentials',
                            params: {
                                page: 'credentials',
                                alert: '',
                                alertmsg: '',
                            },
                        }"
                    >
                        <button class="chi-button -primary -outline -bg--white -ml--1">CANCEL</button>
                    </router-link>
                    <div class="chi-col -w--2 -pr--0 -pl--2">
                        <chi-button color="primary" data-cy="cy-createApp__btn" @chiClick="() => createAppData()">
                            CREATE</chi-button
                        >
                    </div>
                </div>
            </div>
            <div class="wrapper -bg--white" v-if="step === 3">
                <div class="chi-grid -px--3 -mt--3 -mx--3">
                    <div class="chi-col -w--6 -o--3 -mb--2">
                        <ul class="chi-steps" data-cy="cy-completePageSteps__lbl">
                            <li class="chi-steps__item -completed">
                                <div class="chi-steps__icon">
                                    <div class="chi-steps__content">
                                        <a class="chi-steps__item-title" href="#">Create</a>
                                    </div>
                                </div>
                                <div class="chi-steps__line"></div>
                            </li>
                            <li class="chi-steps__item -completed">
                                <div class="chi-steps__icon">
                                    <div class="chi-steps__content">
                                        <a class="chi-steps__item-title" href="#">Review</a>
                                    </div>
                                </div>
                                <div class="chi-steps__line"></div>
                            </li>
                            <li class="chi-steps__item -active">
                                <div class="chi-steps__icon">
                                    <div class="chi-steps__content">
                                        <a class="chi-steps__item-title" href="#">Complete</a>
                                    </div>
                                </div>
                                <div class="chi-steps__line"></div>
                            </li>
                        </ul>
                    </div>
                    <div class="chi-col -w-sm--10 -pl--0">
                        <div class="chi-main__header-start -mt--1">
                            <div class="chi-main__title" data-cy="cy-completeApp__title">
                                <div class="-text--h3 -text--boldest -text--navy -m--0 -br--1 -pr--2">Complete</div>
                                <div class="-text--md -pl--2">New Credential</div>
                            </div>
                        </div>
                    </div>
                    <div class="chi-col -w-sm--12 -my--2 -p--0">
                        <div class="chi-alert -success -lg" role="alert" data-cy="cy-createSuccess__alert">
                            <i class="chi-alert__icon chi-icon icon-circle-check" aria-hidden="true"></i>
                            <div class="chi-alert__content">
                                <p class="chi-alert__title">Success</p>
                                <p class="chi-alert__text">
                                    {{ appTitle }} Credential has been created. Go to My Credentials to view your new
                                    credential.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="chi-col -w-sm--9 -pl--0 -mt--1">
                        <h4 class="-text--boldest" data-cy="cy-credentials__label">Your Credentials</h4>
                    </div>
                    <div class="-bg--muted-lighter chi-col -w-sm--12 -px--2 -py--2">
                        <div class="chi-alert -warning -lg -ml--2" role="alert" data-cy="cy-note__lbl">
                            <i class="chi-alert__icon chi-icon icon-warning" aria-hidden="true"></i>
                            <div class="chi-alert__content">
                                <p class="chi-alert__title">Important</p>
                                <p class="chi-alert__text">
                                    Note: Please store your Credentials in a safe place.You will not be able to view
                                    your API Proxy Secret after this step.
                                </p>
                            </div>
                        </div>
                        <div class="chi-form__item chi-col -w-sm--10 -p--2">
                            <label class="chi-label" for="example__icon-left-right-aligned">Consumer Key</label>
                            <div class="chi-input__wrapper -icon--right">
                                <input
                                    type="text"
                                    class="chi-input -bg--white"
                                    v-model="consumerKey"
                                    id="example__icon-left-right-aligned"
                                    disabled="disabled"
                                />
                                <a
                                    id="details_link"
                                    class="chi-link chi-icon -w-sm--auto"
                                    v-on:click="(e) => copyClip(consumerKey)"
                                >
                                    <i
                                        class="chi-icon icon-copy -icon--primary -sm -d--table-cell"
                                        aria-hidden="true"
                                    ></i
                                    >&nbsp;
                                    <span class="-text--md -pl--1 -d--table-cell">Copy</span>
                                </a>
                            </div>
                        </div>
                        <div class="chi-form__item chi-col -w-sm--10 -p--2">
                            <label class="chi-label" for="example__icon-left-right-aligned">Consumer Secret</label>
                            <div class="chi-input__wrapper -icon--right">
                                <input
                                    type="text"
                                    class="chi-input -bg--white"
                                    v-model="consumerSecret"
                                    id="example__icon-left-right-aligned"
                                    disabled="disabled"
                                />
                                <a
                                    id="details_link"
                                    class="chi-link chi-icon -w-sm--auto"
                                    v-on:click="(e) => copyClip(consumerSecret)"
                                >
                                    <i
                                        class="chi-icon icon-copy -icon--primary -sm -d--table-cell"
                                        aria-hidden="true"
                                    ></i
                                    >&nbsp;
                                    <span class="-text--md -pl--1 -d--table-cell">Copy</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="-d--flex -align-items--center -justify-content--end -py--3 -my--2 -bt--1 -mx--6">
                    <router-link
                        data-cy="cy-done__btn"
                        :to="{
                            name: 'Credentials',
                            params: {
                                page: 'credentials',
                                alert: '',
                                alertmsg: '',
                            },
                        }"
                    >
                        <button class="chi-button -primary -ml--1">DONE</button>
                    </router-link>
                </div>
            </div>
        </div>
        <Footer />
    </div>
</template>
<script lang="ts">
import Footer from '@/modules/common/_components/Footer.vue';
import { Component, Vue } from 'vue-property-decorator';
import { DataTableUtils } from '@/modules/myapps/_global/utils/dataTableUtils';
import { getModule } from 'vuex-module-decorators';
import { DataTableConfig, DataTableRow, FilterType } from '@/models/chiTableTypes';
import {
    APPS_TABLE_CONFIG,
    APP_TABLE_TEMPLATES,
    APP_TABLE_COLUMNS,
    PRODUCT_TABLE_CONFIG,
    PRODUCT_TABLE_TEMPLATES,
    PRODUCT_TABLE_COLUMNS,
    APIProductDataTableRow,
    CreateInputType,
} from '@/modules/myapps/_global/apiChiTable';
import MyAppsStore from '@/modules/myapps/_store';
@Component({
    components: { Footer },
    data() {
        return {
            step: 1,
            prodEnvironment: 'dev',
            PRODUCT_TABLE_CONFIG,
            PRODUCT_TABLE_TEMPLATES,
            PRODUCT_TABLE_COLUMNS,
            APPS_TABLE_CONFIG,
            APP_TABLE_TEMPLATES,
            APP_TABLE_COLUMNS,
        };
    },
    methods: {},
})
export default class CreateNewApp extends Vue {
    config: DataTableConfig = APPS_TABLE_CONFIG;
    step: number = 1;
    emptyClass: string = '';
    isEmptyMessage: string = ' -d--none';
    productErrorMessage: string = ' -d--none';
    configProd: DataTableConfig = PRODUCT_TABLE_CONFIG;
    apiName: string = '';
    searchProduct: string = '';
    apiOldName: string = '';
    uniqueId: any;
    appStore!: MyAppsStore;
    prodEnvironment: string = 'dev';
    consumerKey: any = '';
    consumerSecret: any = '';
    noUnique: boolean = false;
    minProduct: boolean = false;
    timer: number = 1;
    appNames: string[] = [];
    currentFilters: FilterType[] = [];
    APIarr: any[] = [];
    linkedProducts: any[] = [];
    tempAPIarr: any[] = [];
    showSelected: boolean = false;
    firstBlock: boolean = true;
    apiProducts: APIProductDataTableRow[] = [];
    apiTempProducts: APIProductDataTableRow[] = [];
    appStatus: string = 'approved';
    environmentList: any[] = [];
    appTitle: any;

    get appTable(): any {
        if (this.recordCountData == 1) {
            APP_TABLE_COLUMNS.productDisplayName.sortable = false;
        } else {
            APP_TABLE_COLUMNS.productDisplayName.sortable = true;
        }
        return {
            head: APP_TABLE_COLUMNS,
            body: this.filteredTableAppBody,
        };
    }
    get prodAppTable(): any {
        if (this.apiProducts.length == 1) {
            PRODUCT_TABLE_COLUMNS.productDisplayName.sortable = false;
        } else {
            PRODUCT_TABLE_COLUMNS.productDisplayName.sortable = true;
        }

        return {
            head: PRODUCT_TABLE_COLUMNS,
            body: this.filteredTableAllAppProduct,
        };
    }
    created() {
        if (!this.appStore) {
            this.appStore = getModule(MyAppsStore, this.$store);
        }
    }
    onInputChanged(): void {
        if (!this.isBlank) {
            this.emptyClass = '-danger';
            this.isEmptyMessage = '';
        }
        clearTimeout(this.timer);
        this.timer = setTimeout(() => {
            let appprodName = this.apiName.replace(/[^A-Z0-9]/gi, '_').toLowerCase();
            this.uniqueId = this.apiName.replace(/[^A-Z0-9]/gi, '_').toLowerCase();
            if (this.appNames.includes(appprodName)) {
                this.noUnique = true;
            } else {
                this.noUnique = false;
            }
            if (this.noUnique) {
                this.emptyClass = '-danger';
                this.isEmptyMessage = '';
            }
        }, 250);
    }
    beforeMount() {
        this.apiTempProducts = this.apiProducts = JSON.parse(JSON.stringify(this.appStore.getAllProducts));
        this.environmentList = JSON.parse(JSON.stringify(this.appStore.getAllEnvironments));
        let applist = this.appStore.getAppData;
        this.appNames = this.appStore.getUniqueAppName;
        let selList = applist.find((o) => o.appName === this.uniqueId);
        if (selList) {
            this.apiName = this.apiOldName = selList.name;
            this.appNames = this.appNames.filter((obj) => obj !== selList.appName);
            this.prodEnvironment = selList.environment;
            let prodNames: string[] = [...selList.apiProduct.map((obj) => obj.apiproduct)];
            this.APIarr = this.apiTempProducts
                .filter((obj) => prodNames.indexOf(obj.productName) > -1)
                .map((obj) => ({
                    id: obj.id,
                    productDisplayName: obj.productDisplayName,
                    prodDescription: obj.prodDescription,
                    productName: obj.productName,
                }));

            this.addedAppProductsListData();
            this.linkedProductListData();
        }
    }
    onSearchProductData(): void {
        this.showSelected = false;
        let re = new RegExp(`.*${this.searchProduct.toLowerCase()}.*`, 'g');
        this.apiProducts = [
            ...this.apiTempProducts.filter(
                (o) => o.productDisplayName.toLowerCase().match(re) || o.prodDescription.toLowerCase().match(re)
            ),
        ];
    }

    closeSearchButton(): void {
        this.showSelected = false;
        this.searchProduct = '';
        this.apiProducts = [...this.apiTempProducts];
    }
    addedAppProductsListData(): void {
        this.tempAPIarr = [
            ...this.APIarr.map((obj) => ({
                id: obj.id,
            })),
        ];
    }
    linkedProductListData(): void {
        this.linkedProducts = [
            ...this.APIarr.map((obj) => ({
                id: obj.id,
            })),
        ];
    }
    removeProduct(id: number): void {
        this.APIarr = this.APIarr.filter((o) => o.id != id);
        this.addedAppProductsListData();
        if (this.recordCountData == 0) {
            this.minProduct = true;
        }
        this.linkedProductListData();
        if (this.selectedAppCount == 0) {
            document.getElementById('review_link')!.scrollIntoView();
            this.productErrorMessage = '';
        }
    }
    prev() {
        this.step--;
        document.getElementsByClassName('CreateApp')[0].scrollIntoView();
    }
    next() {
        this.productErrorMessage = '';
        this.emptyClass = '-danger';
        this.isEmptyMessage = '';
        if (this.selectedAppCount == 0) {
            document.getElementById('details_link')!.scrollIntoView();
        } else if (!this.isBlank) {
            document.getElementById('details_link')!.scrollIntoView();
        } else if (this.noUnique) {
            document.getElementById('details_link')!.scrollIntoView();
        } else {
            this.step++;
            let addedProdId: number[] = [...this.tempAPIarr.map((obj) => obj.id)];
            this.APIarr = [
                ...this.apiTempProducts
                    .filter((o) => addedProdId.indexOf(o.id) > -1)
                    .map((obj) => ({
                        id: obj.id,
                        productDisplayName: obj.productDisplayName,
                        productName: obj.productName,
                        prodDescription: obj.prodDescription,
                    })),
            ];
            this.linkedProductListData();
            this.firstBlock = true;
        }
        document.getElementsByClassName('CreateApp')[0].scrollIntoView();
    }
    copyClip(code: string) {
        navigator.clipboard.writeText(code);
    }
    environmentValue(event) {
        this.prodEnvironment = event.target.value;
        this.getSelectedProducts.forEach((element: any) => {
            this.APIarr = this.APIarr.filter((o) => o.id != element.id);
            this.addedAppProductsListData();
            if (this.recordCountData == 0) {
                this.minProduct = true;
            }
            this.linkedProductListData();
        });
    }

    get selectedAppCount(): number {
        return this.tempAPIarr.length;
    }
    get isBlank(): number {
        return this.apiName.replace(/\s/g, '').length;
    }
    get recordCountData(): number {
        return this.APIarr.length;
    }
    get filteredTableAppBody(): DataTableRow[] {
        const tableDataBody = DataTableUtils.getTableBody(this.APIarr, APP_TABLE_TEMPLATES);
        return [...tableDataBody];
    }
    get filteredTableAllAppProduct(): DataTableRow[] {
        const localTableData: DataTableRow[] = [];
        let selectedProds: number[] = this.getSelectedProducts;
        this.apiProducts.forEach((element: any) => {
            let selected = selectedProds.indexOf(element.id) > -1 ? true : false;
            let disabled = element.envirments.indexOf(this.prodEnvironment) == -1;
            const row: DataTableRow = {
                id: element.id.toString(),
                active: false,
                selected: selected,
                selectionDisabled: disabled,
                data: DataTableUtils.templateRow(element, PRODUCT_TABLE_TEMPLATES),
            };
            localTableData.push(row);
        });
        return localTableData;
    }

    rowSelectedList(selectedRow: DataTableRow): void {
        if (selectedRow.selected) {
            this.tempAPIarr.push({ id: parseInt(selectedRow.id) });
        } else {
            this.tempAPIarr = this.tempAPIarr.filter((o) => o.id != parseInt(selectedRow.id));
        }
    }
    rowSelectedAllList(selectedRow: DataTableRow[], _type: number): void {
        if (_type) {
            this.tempAPIarr = selectedRow
                .filter((obj) => !obj.selectionDisabled)
                .map((obj) => ({
                    id: parseInt(obj.id),
                }));
        } else {
            this.tempAPIarr = [];
        }
    }

    get getSelectedProducts(): number[] {
        return [...this.tempAPIarr.map((obj) => obj.id)];
    }
    check(e) {
        this.searchProduct = '';
        this.$nextTick(() => {
            if (e.target.checked) {
                let selectedProds: number[] = this.getSelectedProducts;
                this.apiProducts = [
                    ...this.apiTempProducts.filter((product) => selectedProds.indexOf(product.id) > -1),
                ];
            } else {
                this.apiProducts = [...this.apiTempProducts];
            }
        });
    }
    createAppData() {
        let selectedProducts = [...this.APIarr.map((obj) => ({ apiproduct: obj.productName }))];
        if (
            selectedProducts.length == 0 ||
            this.uniqueId.length == 0 ||
            this.prodEnvironment.length == 0 ||
            this.apiName.length == 0 ||
            this.noUnique
        ) {
            document.getElementById('details_link')!.scrollIntoView();
            return 0;
        }
        const formData: CreateInputType = {
            credentials: [
                {
                    apiProducts: selectedProducts,
                    expiresAt: -1,
                },
            ],
            name: this.uniqueId,
            keyExpiresIn: -1,
            status: this.appStatus,
            attributes: [
                {
                    name: 'environment',
                    value: this.prodEnvironment,
                },
                {
                    name: 'DisplayName',
                    value: this.apiName,
                },
            ],
        };
        this.createApp(this, formData);
    }
    async createApp(me: any, formData: CreateInputType) {
        await me.appStore.createApp({
            appName: me.apiName,
            formData: formData,
        });

        if (this.appStore.getAlertObj?.navigateTo) {
            this.$router.push({
                path: this.appStore.getAlertObj.navigateTo.path,
                name: this.appStore.getAlertObj.navigateTo.name,
            });
        }

        if (this.appStore.getResponseData?.appDetails?.credentials[0].consumerKey) {
            this.step++;
            const credentials = this.appStore.getResponseData.appDetails.credentials[0];
            this.consumerKey = credentials.consumerKey;
            this.consumerSecret = credentials.consumerSecret;
            this.appTitle = this.appStore.getResponseData.appDetails.attributes[1].value;
        }
    }
}
</script>
<style>
.chi .chi-table.-fixed--header:before {
    background-color: #f8f9f9;
}
.searchCloseButton {
    right: 2rem !important;
    top: 0.2rem !important;
}
.disable_text {
    color: #8e9399;
    cursor: default;
}
.error_text {
    color: #d62015;
}
.text_20 {
    font-size: 1.25rem !important;
    line-height: normal;
}
.radioPickerGroupLabel {
    border-radius: unset !important;
}
.chi-picker-group__content > div:first-child .radioPickerGroupLabel {
    border-bottom-left-radius: 0.25rem !important;
    border-top-left-radius: 0.25rem !important;
}
.chi-picker-group__content > div:last-child .radioPickerGroupLabel {
    border-bottom-right-radius: 0.25rem !important;
    border-top-right-radius: 0.25rem !important;
}
.chi .chi-alert {
    margin-left: 24px;
}
</style>
