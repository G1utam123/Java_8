<template>
    <CreateNewApp />
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component({
    components: {
        CreateNewApp: () =>
            import(/* webpackChunkName: "apiexchange-home-layout" */ '../../_components/create/CreateNewApp.vue'),
    },
})
export default class Index extends Vue {}
</script>
