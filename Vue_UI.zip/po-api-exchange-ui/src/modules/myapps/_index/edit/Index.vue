<template>
    <EditAppLayout />
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component({
    components: {
        EditAppLayout: () =>
            import(/* webpackChunkName: "apiexchange-home-layout" */ '../../_components/edit/EditAppLayout.vue'),
    },
})
export default class Index extends Vue {}
</script>
