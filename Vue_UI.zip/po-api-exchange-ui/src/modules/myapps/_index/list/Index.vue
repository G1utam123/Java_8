<template>
    <MyAppLayout />
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import MyAppsStore from '@/modules/myapps/_store';

@Component({
    components: {
        MyAppLayout: () =>
            import(/* webpackChunkName: "apiexchange-home-layout" */ '../../_components/list/MyAppLayout.vue'),
    },
})
export default class Index extends Vue {
    created() {
        MyAppsStore.register(this.$store);
    }
}
</script>
