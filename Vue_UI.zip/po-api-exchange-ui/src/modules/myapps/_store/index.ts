import { Module, VuexModule, Action, Mutation } from 'vuex-module-decorators';
import { Store } from 'vuex';
import { ProductsTableResponse } from '@/models/chiTableTypes';
import { APIProductDataTableRow, EditInputType, CreateInputType } from '@/modules/myapps/_global/apiChiTable';
import { myappsApi } from '@/modules/myapps/_api/myappsApi';
import { AlertObj } from '../_constants/list/apiChiTable';
import { OrderUtils } from '@/utils/orderUtils';
export const STORE_KEY = '$_api_exchange_myapps';
@Module({
    namespaced: true,
    name: STORE_KEY,
})
export default class MyAppsStore extends VuexModule {
    // register and unregister should be called in a parent component (src/modules/myapps/Index.vue)
    static register($store: Store<any>) {
        if (!$store.state[STORE_KEY]) {
            $store.registerModule(STORE_KEY, this);
        }
    }
    static unregister($store: Store<any>) {
        if ($store.state[STORE_KEY]) {
            $store.unregisterModule(STORE_KEY);
        }
    }

    //#region states
    appData: any[] = [];
    allProducts: APIProductDataTableRow[] = [];
    responseData: any;
    allEnvironmentsArray: any[] = [];
    alertObj!: AlertObj;
    //#endregion

    //#region getters
    get getAppData(): any[] {
        return this.appData;
    }

    get getUniqueAppName(): string[] {
        return this.appData.map((item) => item['appName']);
    }

    get getAllProducts(): APIProductDataTableRow[] {
        return this.allProducts;
    }

    get getAllEnvironments(): any[] {
        return this.allEnvironmentsArray;
    }

    get getAlertObj(): AlertObj {
        return this.alertObj;
    }

    get getResponseData(): any {
        return this.responseData;
    }
    //#endregion

    //#region mutations
    @Mutation
    setAppData(appData: ProductsTableResponse[]) {
        this.appData = [...appData];
    }

    @Mutation
    setAllProducts(allProducts: APIProductDataTableRow[]) {
        this.allProducts = [...allProducts];
    }

    @Mutation
    setAllEnvironments(allEnvironmentsArray: any[]) {
        this.allEnvironmentsArray = [...allEnvironmentsArray];
    }

    @Mutation
    setAlertObj(alertObj: AlertObj) {
        this.alertObj = alertObj;
    }

    @Mutation
    setResponseData(responseData: any) {
        this.responseData = responseData;
    }
    //#endregion

    //#region actions
    @Action
    async loadAppData(): Promise<void> {
        await myappsApi
            .loadAppDetails()
            .then((response: any) => {
                const appData: any[] = response.data.app.map((obj, index) => ({
                    id: index,
                    appName: obj.name,
                    name: obj.displayName,
                    environment: obj.environment,
                    api_product: obj.apiProdCount,
                    status: obj.status,
                    created: obj.createdAt,
                    consumerkey: obj.consumerKey,
                    consumersecret: obj.consumerSecret,
                    apiProduct: obj.apiProducts,
                }));
                this.context.commit('setAppData', appData);
            })
            .catch((error) => {
                this.context.commit('setAlertObj', {
                    dyclass: '-danger',
                    icon: 'icon-circle-warning',
                    message: error.message.includes('DeveloperDoesNotExist')
                        ? error.message.substring(
                              error.message.lastIndexOf('message') + 18,
                              error.message.indexOf('contexts') - 14
                          )
                        : error.message,
                });
            });
    }

    @Action
    async loadProductDetailsAndEnvironments(): Promise<void> {
        await myappsApi
            .loadProductDetails()
            .then((response: any) => {
                const allProducts: APIProductDataTableRow[] = response.data.apiProduct.map((obj, index) => ({
                    id: index,
                    productName: obj.name,
                    productDisplayName: obj.displayName,
                    envirments: obj.environments,
                    prodDescription: obj.description.length ? obj.description : '-',
                }));
                this.context.commit('setAllProducts', allProducts);
                let allEnvironmentsArrayAsString: string[] = [];
                response.data.apiProduct.map((obj) => {
                    if (obj.environments?.length > 0) {
                        obj.environments.forEach((environment) => {
                            if (!allEnvironmentsArrayAsString.includes(environment)) {
                                allEnvironmentsArrayAsString.push(environment);
                            }
                        });
                    }
                });
                allEnvironmentsArrayAsString = OrderUtils.orderEnvironments(allEnvironmentsArrayAsString);
                const allEnvironmentsArray: any[] = [];
                allEnvironmentsArrayAsString.forEach((element) => {
                    allEnvironmentsArray.push({ value: element });
                });
                this.context.commit('setAllEnvironments', allEnvironmentsArray);
            })
            .catch((error) => {
                this.context.commit('setAlertObj', {
                    dyclass: '-danger',
                    icon: 'icon-circle-warning',
                    message: error,
                });
            });
    }

    @Action
    async deleteApp(payload: { name: string; appName: string }) {
        await myappsApi
            .deleteApp(payload.appName)
            .then((_response) => {
                this.context.commit('setAlertObj', {
                    dyclass: '-success',
                    icon: 'icon-circle-check',
                    message: `${payload.name} has been deleted.`,
                });
                this.loadAppData();
                this.loadProductDetailsAndEnvironments();
            })
            .catch((_error) => {
                this.context.commit('setAlertObj', {
                    dyclass: '-danger',
                    icon: 'icon-circle-warning',
                    message: 'App not found',
                });
            });
    }

    @Action
    async updateApp(payload: { appName: string; formData: EditInputType }) {
        await myappsApi
            .updateApp(payload.formData)
            .then((_response) => {
                this.context.commit('setAlertObj', {
                    dyclass: '-success',
                    icon: 'icon-circle-check',
                    message: `${payload.appName} changes have been saved.`,
                });
            })
            .catch((_error) => {
                this.context.commit('setAlertObj', {
                    dyclass: '-danger',
                    icon: 'icon-circle-warning',
                    message: 'Internal server error',
                });
            });
    }

    @Action
    async createApp(payload: { appName: string; formData: CreateInputType }) {
        await myappsApi
            .createApp(payload.formData)
            .then((_response) => {
                if (_response.data) {
                    this.context.commit('setResponseData', { appDetails: _response.data });
                } else {
                    this.context.commit('setAlertObj', {
                        dyclass: '-danger',
                        icon: 'icon-circle-warning',
                        message: 'Internal server error: No data',
                    });
                }
            })
            .catch((_error) => {
                this.context.commit('setAlertObj', {
                    dyclass: '-danger',
                    icon: 'icon-circle-warning',
                    message: 'Internal server error',
                    navigateTo: {
                        path: '/credentials',
                        name: 'Credentials',
                    },
                });
            });
    }
    //#endregion
}
