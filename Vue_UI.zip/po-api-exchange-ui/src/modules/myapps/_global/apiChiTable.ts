import { DataTableConfig, HeadItem } from '@/models/chiTableTypes';
export const APPS_TABLE_CONFIG: DataTableConfig = {
    columnResize: false,
    noResultsMessage: 'No API Product(s).',
    activePage: 1,
    style: { portal: true, noBorder: false, bordered: false, hover: false, size: 'md', striped: true },
    pagination: { hideOnSinglePage: true, compact: true, firstLast: false, pageJumper: false },
    selectable: true,
    columnSizes: {
        xs: [20, 60, 5],
        sm: [20, 60, 5],
        md: [20, 60, 5],
        lg: [20, 60, 5],
        xl: [20, 60, 5],
    },
    resultsPerPage: 9999,
    defaultSort: {
        key: 'productDisplayName',
        sortBy: 'productDisplayName',
        direction: 'ascending',
    },
};

export const APP_TABLE_TEMPLATES = {
    PRODUCTDISPLAYNAME: 'productDisplayName',
    PRODUCTDESC: 'prodDescription',
    PRODUCTNAME: 'productName',
};
export const APP_TABLE_COLUMNS: Record<string, HeadItem> = {
    productDisplayName: {
        label: 'API Name',
        sortable: true,
        sortDataType: 'string',
    },
    prodDescription: { label: 'Description', sortable: false },
    productName: { label: ' ', sortable: false, align: 'right' },
};

export const PRODUCT_TABLE_CONFIG: DataTableConfig = {
    columnResize: false,
    noResultsMessage: 'No API Product(s).',
    activePage: 1,
    style: { portal: true, noBorder: false, bordered: false, hover: false, size: 'md', striped: true },
    pagination: { hideOnSinglePage: true, compact: true, firstLast: false, pageJumper: false },
    selectable: true,
    columnSizes: {
        xs: [20, 60],
        sm: [20, 60],
        md: [20, 60],
        lg: [20, 60],
        xl: [20, 60],
    },
    resultsPerPage: 9999,
    defaultSort: {
        key: 'productDisplayName',
        sortBy: 'productDisplayName',
        direction: 'ascending',
    },
};

export const PRODUCT_TABLE_TEMPLATES = {
    PRODUCTDISPLAYNAME: 'productDisplayName',
    PRODUCTDESC: 'prodDescription',
};

export const PRODUCT_TABLE_COLUMNS: Record<string, HeadItem> = {
    productDisplayName: {
        label: 'API Name',
        sortable: true,
        sortDataType: 'string',
    },
    prodDescription: { label: 'Description', sortable: false },
};

export interface APIProductDataTableRow {
    id: number;
    productName: string;
    productDisplayName: string;
    envirments: string[];
    prodDescription: string;
}

export interface ApiProductsList {
    apiproduct: string;
}

export interface AppListResponse {
    id: number;
    productDisplayName: string;
    prodDescription: string;
    productName: string;
}

export interface CreateInputType {
    credentials: CreateAppCredentialsInput[];
    name: string;
    keyExpiresIn: number;
    status: string;
    attributes: InputTypeAttr[];
}

export interface InputTypeAttr {
    name: string;
    value: string;
}

export interface CreateAppCredentialsInput {
    apiProducts: ApiProductsList[];
    expiresAt: number;
}

export interface EditInputType {
    credentials: CredentialsInput[];
    name: string;
    keyExpiresIn: number;
    status: string;
    attributes: InputTypeAttr[];
}

export interface CredentialsInput {
    apiProducts: ApiProductsList[];
    consumerKey: string;
    expiresAt: number;
}
