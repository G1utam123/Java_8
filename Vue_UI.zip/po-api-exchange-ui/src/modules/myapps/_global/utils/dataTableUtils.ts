import { AppListResponse, APIProductDataTableRow } from '@/modules/myapps/_global/apiChiTable';
import { DataTableRow, TableTemplate } from '@/models/chiTableTypes';
export class DataTableUtils {
    static getTableBody(data: AppListResponse[], tableTemplates: Record<string, string>): DataTableRow[] {
        const localTableData: DataTableRow[] = [];
        const localData: AppListResponse[] = [...data];
        localData.forEach((element: AppListResponse) => {
            const row: DataTableRow = {
                id: element.id.toString(),
                active: false,
                data: this.getRowData(localData, element.id.toString(), tableTemplates),
            };
            localTableData.push(row);
        });
        return localTableData;
    }

    static getRowData(
        data: AppListResponse[],
        id: string,
        tableTemplates: Record<string, string>
    ): (string | TableTemplate)[] {
        const row: (string | TableTemplate)[] = [];
        for (const key in tableTemplates) {
            const value = tableTemplates[key];
            const dataIndex = data.findIndex((element: AppListResponse) => element.id.toString() === id.toString());
            const template: TableTemplate = {
                template: value,
                payload: { [value]: data[dataIndex][value as keyof AppListResponse], element: data[dataIndex] },
            };
            row.push(template);
        }
        return row;
    }

    static templateRow(
        element: APIProductDataTableRow,
        tableTemplates: Record<string, string>
    ): (string | TableTemplate)[] {
        const row: (string | TableTemplate)[] = [];
        for (const key in tableTemplates) {
            const tempName = tableTemplates[key];
            const template: TableTemplate = {
                template: tempName,
                payload: {
                    [tempName]: element[tempName],
                    element,
                },
            };
            row.push(template);
        }
        return row;
    }
}
