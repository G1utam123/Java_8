import * as fetch from '../../../wrappers/fetch';

export const myappsApi = {
    loadAppDetails: async () => fetch.get('/v1/userapps'),
    loadProductDetails: async () => fetch.get('/v1/apiproducts'),
    deleteApp: async (appName: string) => fetch.delete('/v1/deleteuserapp/' + appName),
    updateApp: async (formData: any) => fetch.post('/v1/updateuserapps', formData),
    createApp: async (formData: any) => fetch.post('/v1/createuserapps', formData),
};
