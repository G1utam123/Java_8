<template>
    <AppLayout data-cy="cy-community_name">
        <template v-slot:community>
            <div class="-text--center">
                <div class="chi-card -highlight heroimage">
                    <div class="chi-card__content heroimagecontent">
                        <div class="-w--30">
                            <h2 class="-text--left -text--white" data-cy="cy-Welcome-text">Community</h2>
                        </div>
                    </div>
                </div>
                <div>
                    <img
                        src="../../../assets/Automated-operations-robot-arm.png"
                        alt="community_logo"
                        class="image"
                        data-cy="cy-community_logo"
                    />
                </div>
                <div data-cy="cy-community_text">
                    <div class="-text--boldest -mt--8 sub_title">COMING SOON</div>
                    <div class="-text--bold -text--lg">We are busy building.</div>
                    <div class="-text--bold -text--lg -mt--2">
                        In the meantime, please visit our
                        <a
                            href="https://teams.microsoft.com/l/channel/19%3a956740acab654c4eaa726cc1e3920675%40thread.skype/General?groupId=456f475c-6aaf-46a4-a9fb-ce8874ff02c8&tenantId=72b17115-9915-42c0-9f1b-4f98e5a4bcd2"
                            target="_blank"
                            rel="noopener"
                            >Community of Practice site in MS Teams</a
                        >
                    </div>
                </div>
            </div>
        </template>
    </AppLayout>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import AppLayout from '@/modules/common/_components/AppLayout.vue';

@Component({
    components: {
        AppLayout,
    },
})
export default class Community extends Vue {}
</script>
<style scoped>
.sub_title {
    font-size: 2.875rem;
    height: 3.125rem;
}
.image {
    width: 8rem;
    height: 8.313rem;
    margin-top: 4rem;
}
.heroimage {
    background-image: url('../../../assets/community-kra.jpg');
    max-width: 100rem !important;
    height: 184px;
    margin-left: auto;
    margin-right: auto;
}
.chi-main {
    padding-top: 2rem !important;
}
.heroimagecontent {
    margin-top: 0.25rem;
    margin-left: 0.5rem;
}
</style>
