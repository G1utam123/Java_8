<template>
    <div class="chi-main">
        <div class="chi-main__header" style="margin: 0% 0% 0% 1%">
            <div class="chi-main__header-start">
                <a class="chi-link" href="#">
                    <div class="chi-link__content" data-cy="cy-back_link">
                        <chi-icon icon="chevron-left"></chi-icon>
                        <span class="-text--md">
                            <router-link v-if="!addSections" :to="{ name: 'exchange' }" class="-text--sm -ml-md--1"
                                >Exchange
                            </router-link>
                            <router-link
                                v-if="addSections"
                                :to="{ name: 'overview', params: { apiid: api.id, apiname: api.name } }"
                                class="-text--sm -ml-md--1"
                                >Overview
                            </router-link></span
                        >
                    </div>
                </a>
            </div>
        </div>
        <div class="chi-main__content" id="editapiPage">
            <div class="chi-grid" v-if="isAlert" data-cy="cy-success_alert">
                <div class="chi-col -w--12 -ml--4 -mt--4 -mr--6">
                    <AlertComponent :alertObject="alertObject" @dismissAlert="alertCloseclicked()" />
                </div>
            </div>

            <div class="chi-grid">
                <div class="chi-col -w--12 -ml--4 -mt--4 -mr--6">
                    <div class="chi-form__item">
                        <label class="chi-label" for="example__base" data-cy="cy-api-title__label"
                            >Component Name
                            <abbr class="chi-label__required" title="Required field">*</abbr>
                        </label>
                        <input
                            type="text"
                            class="chi-input"
                            id="example__base"
                            data-cy="cy-api-title__input"
                            v-model="apiName"
                            maxlength="40"
                        />
                        <div class="chi-label -status -danger" data-cy="cy-api-title__err" v-if="title">
                            Please provide a Component Name
                        </div>
                    </div>
                </div>
                <div class="chi-col -w--12 -ml--4 -mt--4 -mr--6">
                    <div class="chi-form__item">
                        <label class="chi-label" for="example__base" data-cy="cy-api-description__label"
                            >Component Description
                            <abbr class="chi-label__required" title="Required field">*</abbr>
                        </label>

                        <div class="chi-form__item" id="tag_check">
                            <textarea
                                class="chi-input"
                                id="example__required"
                                data-cy="cy-api-description__textarea"
                                required
                                v-model="content"
                                minlength="40"
                                maxlength="1000"
                                aria-multiline="true"
                                style="resize: vertical"
                            ></textarea>
                            <div class="chi-label -status -danger" data-cy="cy-api-description__err" v-if="description">
                                Please provide a Component Description
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="chi-grid">
                <div class="chi-col -ml--4 -mt--4 -mr--6">
                    <div class="chi-form__item">
                        <label class="chi-label" for="example-ba1" data-cy="cy-category__label">Category</label>
                        <select class="chi-select" id="example-ba1" data-cy="cy-api-category__select">
                            <option value="">Select</option>
                            <option>Option 1</option>
                            <option>Option 2</option>
                            <option>Option 3</option>
                        </select>
                    </div>
                </div>
                <div class="chi-col -mt--4 -mr--6">
                    <div class="chi-form__item">
                        <label class="chi-label" for="example-ba1" data-cy="cy-type__label"
                            >Type
                            <abbr class="chi-label__required" title="Required field">*</abbr>
                        </label>
                        <select
                            class="chi-select"
                            id="example-ba1"
                            data-cy="cy-api-type__select"
                            @change="onType($event)"
                            v-model="type"
                            required
                        >
                            <option value="">Select</option>
                            <option value="RESTful">RESTful</option>
                            <option value="GraphQL">GraphQL</option>
                            <option value="SOAP">SOAP</option>
                        </select>
                        <div class="chi-label -status -danger" data-cy="cy-api-type__err" v-if="typeError">
                            Please provide a Type
                        </div>
                    </div>
                </div>
                <div class="chi-col -mt--4 -mr--6">
                    <div class="chi-form__item">
                        <label class="chi-label" for="example-ba1" data-cy="cy-status__label"
                            >Status
                            <abbr class="chi-label__required" title="Required field">*</abbr>
                        </label>
                        <select
                            class="chi-select"
                            id="example-ba1"
                            data-cy="cy-api-status__select"
                            @change="onStatusType($event)"
                            v-model="status"
                            required
                        >
                            <option value="">Select</option>
                            <option value="Development">Development</option>
                            <option value="Beta">Beta</option>
                            <option value="Production">Production</option>
                            <option value="Retired">Retired</option>
                        </select>
                        <div class="chi-label -status -danger" data-cy="cy-api-status__err" v-if="statusError">
                            Please provide a Status
                        </div>
                    </div>
                </div>
                <div class="chi-col -mt--4 -mr--6">
                    <div class="chi-form__item">
                        <chi-label for="example__base" data-cy="cy-version__label"
                            >Version
                            <abbr class="chi-label__required" title="Required field">*</abbr>
                        </chi-label>
                        <chi-text-input
                            id="example__base"
                            data-cy="cy-api-version__input"
                            @change="onVersion($event)"
                            :value="version"
                            required
                        ></chi-text-input>
                        <div class="chi-label -status -danger" data-cy="cy-api-version__err" v-if="versionError">
                            Please provide a Version
                        </div>
                    </div>
                </div>
            </div>
            <div class="chi-grid">
                <div class="chi-col -ml--4 -mt--4 -mr--6">
                    <div class="chi-form__item">
                        <chi-label for="example__base" data-cy="cy-link-to-oas__label">Link to OAS</chi-label>
                        <chi-text-input
                            id="example__base"
                            data-cy="cy-api-link-to-oas__input"
                            @change="onOASlink($event)"
                            :value="oasUrl"
                        ></chi-text-input>
                    </div>
                </div>
                <div class="chi-col -mt--4 -mr--6">
                    <div class="chi-form__item">
                        <chi-label for="example__base" data-cy="cy-link-to-api-source-code__label"
                            >Link to API Source Code</chi-label
                        >
                        <chi-text-input
                            id="example__base"
                            data-cy="cy-api-link-to-api-source-code__input"
                            @change="onSourceCodelink($event)"
                            :value="sourceCodeUrl"
                        ></chi-text-input>
                    </div>
                </div>
            </div>

            <div class="chi-grid">
                <div class="chi-col -w--12 -mt--4 -pl--2 -mr--6">
                    <div v-if="addSections" style="float: right">
                        <router-link :to="{ name: 'overview', params: { apiid: api.id, apiname: api.name } }">
                            <chi-button class="-mr--2">Cancel</chi-button>
                        </router-link>
                        <chi-button color="primary" v-on:click="apiSave()" data-cy="cy-save-api-details__button">
                            Save</chi-button
                        >
                    </div>
                    <div v-else style="float: right">
                        <chi-button color="primary" v-on:click="apiSave()" data-cy="cy-save-api-details__button">
                            Save</chi-button
                        >
                    </div>
                </div>
            </div>
            <div class="chi-grid">
                <div class="chi-col -w--12 -ml--4 -mt--4 -mr--6">
                    <div class="chi-card -highlight">
                        <div class="chi-card__header">
                            <div class="chi-card__title" v-if="addSections">Documentation</div>
                        </div>

                        <div class="chi-card__content" v-if="apiSections.length === 0 && addSections">
                            <div class="chi-card__caption" data-cy="cy-chi-card-api-sections">
                                Use the below option to add new text or swagger section and get its details in table
                                view.
                            </div>
                        </div>
                    </div>

                    <div class="sectionTable" v-if="addSections && apiSections.length > 0" data-cy="cy-section-table">
                        <CommonTable
                            :headerColumns="headerColumns"
                            :rowData="apiSections"
                            @removeSectionEvent="(sectionId) => remove(sectionId)"
                            @editSectionEvent="(sectionData) => edit(sectionData)"
                            @moveSectionEvent="(sectionInfo) => moveSectionOrder(sectionInfo)"
                        />
                    </div>
                </div>
            </div>

            <div class="chi-grid" v-if="addSections">
                <div class="chi-col -w--12 -mt--4 -pl--2 -mr--6">
                    <div style="float: right">
                        <router-link :to="{ name: 'EditSwagger' }">
                            <chi-button color="primary" class="-mr--1" data-cy="cy-new-swagger__button">
                                New Swagger Section
                            </chi-button>
                        </router-link>
                        &nbsp;
                        <router-link :to="{ name: 'EditTextSection' }">
                            <chi-button color="primary" data-cy="cy-new-text__button">New Text Section</chi-button>
                        </router-link>
                    </div>
                </div>
            </div>
            <div class="chi-grid" id="proxyAlert" v-if="addSections">
                <div class="chi-col -w--12 -ml--4 -mt--4 -mr--6">
                    <div class="chi-card -highlight">
                        <div class="chi-card__header">
                            <div class="chi-card__title" data-cy="cy-proxies__section"></div>
                        </div>
                    </div>
                    <div v-if="showProxyAlert" data-cy="cy-proxy-save-alert">
                        <AlertComponent :alertObject="alertObject" @dismissAlert="alertCloseclicked()" />
                    </div>
                    <Proxies @proxydataSave="(saveresponse) => proxyDataSaveMsg(saveresponse)" :saveApiId="proxyId" />
                </div>
            </div>
        </div>
        <Footer />
    </div>
</template>
<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import { Alert } from '@/models/alert';
import AlertComponent from '@/modules/common/_components/AlertComponent.vue';
import { ALERTMSG } from '@/modules/exchange/_constants/messages';
import CommonTable from '@/modules/common/_components/commonTable.vue';
import { ALERT_DISPLAY_TIME } from '@/utils/constants';
import { Compare } from '@/utils/compare';
import Footer from '@/modules/common/_components/Footer.vue';
import store, { STORE_KEY } from '@/modules/exchange/_store';
import { getModule } from 'vuex-module-decorators';
import Proxies from '@/modules/exchange/_components/Proxies.vue';
@Component({
    components: { AlertComponent, CommonTable, Footer, Proxies },
})
export default class EditAPIDocumentation extends Vue {
    @Prop() saveApiId: any;
    apiSections: any[] = [];
    progress: number = 0;

    title: boolean = false;
    description: boolean = false;

    page: string = 'create';
    content: string = '';
    apiName: string = '';
    addSections: boolean = false;

    API: any = {};
    alertHide: boolean = false;
    type: string = '';
    status: string = '';
    version: string = '';
    oasUrl: string = '';
    sourceCodeUrl: string = '';
    typeError: boolean = false;
    statusError: boolean = false;
    versionError: boolean = false;
    alertObject!: Alert;
    isAlert: boolean = false;
    proxyId!: number;
    api: any;
    showProxyAlert: boolean = false;
    headerColumns = ['Name', 'Section Type', 'Action'];
    private _homeStore!: any;
    created() {
        const isModuleRegistered = Object.keys(this.$store.state).includes(STORE_KEY);
        if (!isModuleRegistered) {
            this.$store.registerModule(STORE_KEY, store);
        }
        this._homeStore = getModule(store, this.$store);
    }

    mounted() {
        this.page = this.$route.params.page;
        this.api = this._homeStore.apiData;
        this.isAlert = this.$route.params.alert === 'true';
        this.alertObject = new Alert(this.$route.params.alertmsg);
        if (this.page == 'edit') {
            this.addSections = true;
            this.getAPITextSection();
            this.apiName = this.api.name;
            this.content = this.api.description;
            this.type = this.api.type;
            this.status = this.api.status;
            this.version = this.api.version;
            this.oasUrl = this.api.oasUrl;
            this.sourceCodeUrl = this.api.sourceCodeUrl;
            this.API = this.api;
            this.proxyId = this.api.id;
        } else {
            Vue.prototype.apiId = '';
            this.addSections = false;
            this.content = '';
            this.apiName = '';
            this.type = '';
            this.status = '';
            this.version = '';
            this.oasUrl = '';
            this.sourceCodeUrl = '';
        }
    }

    compare(apidetail1, apidetail2) {
        if (apidetail1.sectionOrder < apidetail2.sectionOrder) {
            return -1;
        }
        if (apidetail1.sectionOrder > apidetail2.sectionOrder) {
            return 1;
        }
        return 0;
    }
    proxyDataSaveMsg(response: string) {
        this.showProxyAlert = true;
        document.getElementById('proxyAlert')?.scrollIntoView();
        if (response === 'ok') {
            this.alertObject = new Alert('Proxy data saved successfully');
        } else {
            this.alertObject = new Alert(ALERTMSG.failureMessage, { color: 'danger', icon: 'circle-warning' });
        }
        if (this.showProxyAlert) {
            setTimeout(() => {
                this.showProxyAlert = false;
            }, ALERT_DISPLAY_TIME);
        }
    }

    onType(event) {
        this.type = event.target.value;
    }
    onStatusType(event) {
        this.status = event.target.value;
    }
    onVersion(event) {
        this.version = event.target.value;
    }
    onOASlink(event) {
        this.oasUrl = event.target.value;
    }
    onSourceCodelink(event) {
        this.sourceCodeUrl = event.target.value;
    }
    async remove(documentId: number) {
        this.isAlert = true;
        await this._homeStore.deleteDocuments(documentId);
        if (this._homeStore.successResponse.deleteSuccess) {
            this.alertObject = new Alert('API section ' + ALERTMSG.successMessageOnDelete);
            this.getAPITextSection();
        } else if (this._homeStore.errorDetails.deleteError) {
            this.alertObject = new Alert(ALERTMSG.failureMessage, { color: 'danger', icon: 'circle-warning' });
        }
    }

    edit(sec: any) {
        if (sec.sectionType == 'text') {
            this.$router.push({ name: 'EditTextSection', params: { section: sec } });
        } else if (sec.sectionType == 'swagger') {
            this.$router.push({ name: 'EditSwagger', params: { section: sec } });
        }
    }
    async getAPITextSection() {
        await this._homeStore.getDocumentData(this.api.id);
        this.apiSections = JSON.parse(this._homeStore.documentData);
        // Check why this.apiSections.sort is not showing as a function
        this.apiSections.sort(this.compare);
    }

    async saveApiDetails() {
        const formData = {
            apiName: this.apiName,
            description: this.content,
            type: this.type,
            version: this.version,
            status: this.status,
            oasUrl: this.oasUrl,
            sourceCodeUrl: this.sourceCodeUrl,
        };
        this.title = !this.apiName;
        this.description = !this.content;
        this.typeError = !this.type;
        this.statusError = !this.status;
        this.versionError = !this.version;
        if (Compare.checkElementsHaveValues([this.apiName, this.content, this.type, this.version, this.status])) {
            this.title = false;
            this.description = false;
            this.typeError = false;
            this.statusError = false;
            this.versionError = false;
            await this._homeStore.addApi(formData);
            if (this._homeStore.successResponse.addSuccess) {
                this.alertObject = new Alert('API details ' + ALERTMSG.successMessageOnSave);
                this.proxyId = this._homeStore.apiData.id;
                this.api = this._homeStore.apiData;
                this.addSections = true;
            } else if (this._homeStore.errorDetails.addError) {
                this.alertObject = new Alert(ALERTMSG.failureMessage, { color: 'danger', icon: 'circle-warning' });
            }

            this.isAlert = true;
        }
    }

    apiSave() {
        if (!this.addSections) {
            this.saveApiDetails();
        }
    }
    alertCloseclicked() {
        this.isAlert = false;
        this.showProxyAlert = false;
    }
    @Watch('isAlert')
    hideAlertOnTimeOut() {
        setTimeout(() => (this.isAlert = false), ALERT_DISPLAY_TIME);
    }
    moveSectionOrder(data: any) {
        if (data.direction == 'up') {
            this.apiSections.splice(data.index - 1, 0, this.apiSections.splice(data.index, 1)[0]);
        }
        if (data.direction == 'down') {
            this.apiSections.splice(data.index + 1, 0, this.apiSections.splice(data.index, 1)[0]);
        }
        this.apiSections.forEach(function (section, index) {
            section.sectionOrder = index;
        });
    }
}
</script>
<style scoped>
.chi-button {
    float: right;
}
.chi .chi-input {
    height: 2rem;
}
.chi textarea.chi-input {
    min-height: 4.5rem;
}

.chi-grid {
    margin: 0;
}
.slide-leave-active,
.slide-enter-active {
    transition: 1s;
}
.slide-enter {
    transform: translate(0, 100%);
}
.slide-leave-to {
    transform: translate(0, -100%);
}
.slide-move {
    transition: 1s;
}
.chi .-pb--4 {
    padding-bottom: 0rem !important;
}
.chi .-pt--2 {
    padding-top: 0rem !important;
}
#editapiPage {
    margin: 0 0rem 1rem;
}

.chi .chi-main {
    margin-top: 1rem;
}
.chi .chi-col.-w--11 {
    padding-right: 45px;
}
</style>
