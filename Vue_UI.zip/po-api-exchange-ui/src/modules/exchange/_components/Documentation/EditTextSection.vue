<template>
    <div id="page">
        <div class="chi-grid">
            <div class="chi-col -w--11 -mt--2 -pl--6" v-if="failureAlert">
                <AlertComponent :alertObject="alertObject" @dismissAlert="alertCloseclicked()" />
            </div>
            <div class="chi-col -w--9 -ml--4 -mt--4">
                <div class="chi-form__item">
                    <label class="chi-label" required for="title" data-cy="cy-section-title__label"
                        >Title
                        <abbr class="chi-label__required" title="Required field">*</abbr>
                    </label>
                    <input
                        type="text"
                        class="chi-input"
                        maxlength="40"
                        data-cy="cy-section-title__input"
                        id="title"
                        v-model="title"
                    />
                    <div class="chi-label -status -danger" v-if="isTextTitle" data-cy="cy-general-error_text_title">
                        Please provide a title
                    </div>
                </div>
            </div>
            <div class="chi-col -w--9 -ml--4 -mt--4">
                <label class="chi-label" for="content" data-cy="cy-section-content__label">Content</label>
                <quill-editor ref="myQuillEditor" data-cy="cy-section-content__quill-editor" v-model="content" />
            </div>

            <div class="chi-col -w--9 -ml--4 -mt--4">
                <chi-button color="primary" style="float: right" data-cy="cy-section-save__button" @click="saveData">
                    Save</chi-button
                >
                <router-link
                    :to="{
                        name: 'EditAPIDocumentation',
                        params: { page: 'edit', alert: '', alertmsg: '' },
                    }"
                >
                    <chi-button style="float: right; margin-right: 2%" data-cy="cy-section-cancle__button"
                        >Cancel</chi-button
                    >
                </router-link>
            </div>
        </div>
        <br />
        <Footer />
    </div>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

import { quillEditor } from 'vue-quill-editor';
import { Compare } from '@/utils/compare';
import 'quill/dist/quill.core.css';
import 'quill/dist/quill.snow.css';
import 'quill/dist/quill.bubble.css';
import { Alert } from '@/models/alert';
import AlertComponent from '@/modules/common/_components/AlertComponent.vue';
import ExchangeModule from '@/modules/exchange/ExchangeModule.vue';
import Footer from '@/modules/common/_components/Footer.vue';
import store, { STORE_KEY } from '@/modules/exchange/_store';
import { getModule } from 'vuex-module-decorators';

@Component({
    components: {
        quillEditor,
        AlertComponent,
        Footer,
        ExchangeModule,
    },
})
export default class EditTextSection extends Vue {
    exchangeModule: ExchangeModule = new ExchangeModule();
    content = '';
    title: any = '';
    section: any;
    failureAlert: boolean = false;
    isTextTitle: boolean = false;
    alertObject!: Alert;
    private _homeStore!: any;

    created() {
        const isModuleRegistered = Object.keys(this.$store.state).includes(STORE_KEY);
        if (!isModuleRegistered) {
            this.$store.registerModule(STORE_KEY, store);
        }
        this._homeStore = getModule(store, this.$store);
    }

    async saveData() {
        this.isTextTitle = Compare.isElementEmpty(this.title);
        if (!this.isTextTitle) {
            this.exchangeModule.checkAddTextSuccuess(this, 'text');
        }
    }

    mounted() {
        document.getElementById('page')?.scrollIntoView();
        if (this.$route.params.section) {
            this.section = this.$route.params.section;
            this.title = this.section.apiName;
            this.content = this.section.documentation;
        }
    }
    alertCloseclicked() {
        this.failureAlert = false;
    }
}
</script>
<style>
.ql-editor {
    height: 40vh !important;
    overflow-y: scroll !important;
}
#page {
    overflow-x: hidden !important;
}
.chi .chi-col.-w--9 {
    flex: 0 1 87%;
}
</style>
