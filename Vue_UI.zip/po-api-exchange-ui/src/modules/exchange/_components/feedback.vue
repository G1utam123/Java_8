<template>
    <AppLayout title="Feedback" data-cy="cy-feedback__title">
        <template v-slot:feedback>
            <div class="chi-epanel">
                <div class="chi-card">
                    <div class="chi-card__content -d--flex -mb--3">
                        <div class="chi-card__caption -mb--3" data-cy="cy-share-feedback">
                            Thank you for taking the time to share your feedback. When you click submit, an email will
                            be sent to the <br />API Hub Experience Team and someone will get back to you shortly.
                        </div>
                        <div class="-d--flex -mb--3">
                            <div class="chi-form__item -mb--3 -inline size">
                                <label class="chi-label" for="firstName" data-cy="cy-firstName_lbl"
                                    >First Name
                                    <abbr class="chi-label__required" title="Required field">*</abbr>
                                </label>
                                <input
                                    class="chi-input"
                                    type="text"
                                    disabled
                                    data-cy="cy-firstname__tbx"
                                    id="firstName"
                                    v-model="firstName"
                                />
                            </div>
                            <div class="chi-form__item -mr--10 -pr--10 -inline size">
                                <label class="chi-label" for="lastName" data-cy="cy-lastName_lbl"
                                    >Last Name
                                    <abbr class="chi-label__required" title="Required field">*</abbr>
                                </label>
                                <input
                                    class="chi-input"
                                    type="text"
                                    disabled
                                    data-cy="cy-lastname__tbx"
                                    id="lastName"
                                    v-model="lastName"
                                />
                            </div>
                        </div>

                        <div class="-d--flex -mb--3">
                            <div class="chi-form__item -mb--3 -inline size">
                                <label class="chi-label" for="emailAddress" data-cy="cy-email_lbl"
                                    >Email
                                    <abbr class="chi-label__required" title="Required field">*</abbr>
                                </label>
                                <input
                                    class="chi-input"
                                    type="text"
                                    disabled
                                    data-cy="cy-email__tbx"
                                    id="emailAddress1"
                                    v-model="emailAddress"
                                />
                            </div>
                            <div class="chi-form__item -mr--10 -pr--10 -inline size">
                                <label class="chi-label" for="phoneNumber" data-cy="cy-phone_lbl">Phone Number</label>
                                <input
                                    class="chi-input"
                                    type="text"
                                    data-cy="cy-phone__tbx"
                                    id="phoneNumber"
                                    v-model="phoneNumber"
                                />
                            </div>
                        </div>

                        <div class="chi-form__item_ feedBack_container">
                            <label class="chi-label" for="feedBack" data-cy="cy-feedback_lbl">
                                Feedback
                                <abbr class="chi-label__required" title="Required field">*</abbr>
                            </label>
                            <textarea
                                class="chi-input"
                                :maxlength="maxFeedback"
                                data-cy="cy-feedback__tbx"
                                id="feedBack"
                                required
                                v-model="feedBack"
                            ></textarea>
                            <div
                                class="chi-input-addon chi-label -status -danger"
                                v-if="maxFeedback - feedBack.length == 0"
                            >
                                <i class="chi-icon icon-circle-warning" aria-hidden="true"></i>
                                {{ feedbackLimit }}
                            </div>

                            <div
                                class="chi-label -status -danger"
                                data-cy="cy-feedback__required__error"
                                v-if="!isFeedback && feedBack.trim().length <= 0"
                            >
                                <i class="chi-icon icon-circle-warning" aria-hidden="true"></i>
                                {{ feedbackWarning }}
                            </div>
                            <h6>The remaining characters : {{ 3800 - feedBack.length }}</h6>
                        </div>
                    </div>
                </div>
                <div class="chi-divider -mb--3"></div>
                <div style="float: right">
                    <chi-button class="-mr--1" data-cy="cy-button-cancel" @chiClick="cancelClick()">CANCEL</chi-button>
                    <chi-button color="primary" data-cy="cy-button-submit" @chiClick="submitClick()">SUBMIT</chi-button>
                    <button id="modal-trigger-alert" data-target="#modal-alert" style="display: none"></button>
                </div>
                <div class="chi-backdrop -closed">
                    <div class="chi-backdrop__wrapper">
                        <section
                            id="modal-alert"
                            class="chi-modal -portal"
                            role="dialog"
                            aria-label="Modal description"
                            aria-modal="true"
                        >
                            <header class="chi-modal__header">
                                <h2 class="chi-modal__title">Error</h2>
                                <button class="chi-button -icon -close" data-dismiss="modal" aria-label="Close">
                                    <div class="chi-button__content">
                                        <i class="chi-icon icon-x" aria-hidden="true"></i>
                                    </div>
                                </button>
                            </header>
                            <div class="chi-modal__content">
                                <div class="-d--flex">
                                    <i
                                        class="chi-icon icon-circle-x -sm--2 -icon--danger -mr--1"
                                        aria-hidden="true"
                                    ></i>
                                    <div class="-w--100">
                                        <p class="-text--bold -m--0">Something went wrong. Please try again later.</p>
                                    </div>
                                </div>
                            </div>
                            <footer class="chi-modal__footer">
                                <button class="chi-button -primary" @click.prevent="cancelClick()">OK</button>
                            </footer>
                        </section>
                    </div>
                </div>
                <br /><br />
            </div>
        </template>
    </AppLayout>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { apiLibraryApi } from '../_api/apiLibrary';
import { FeedbackFormRequest } from '@/modules/exchange/_constants/proxy';
import { ALERTMSG } from '@/modules/exchange/_constants/messages';
import AppLayout from '@/modules/common/_components/AppLayout.vue';
import { UserContext } from '@/utils/entities/userContext';
declare const chi: any;

@Component({
    components: {
        AppLayout,
    },
})
export default class Feedback extends Vue {
    public firstName = '';
    public lastName = '';
    public emailAddress = '';
    public phoneNumber = '';
    public feedBack = '';
    public isFeedback = true;
    public maxFeedback = 3800;
    feedbackLimit = ALERTMSG.maxFeedbackLimit;
    feedbackWarning = ALERTMSG.feedbackAlert;
    token: any;
    modal: any;

    mounted() {
        this.modal = chi.modal(document.getElementById('modal-trigger-alert'));
        this.token = localStorage.getItem('token');
        const jwt = UserContext.parseJwt(this.token);
        this.emailAddress = jwt.email;
        this.firstName = jwt.name.split(' ')[0];
        this.lastName = jwt.name.split(' ')[1];
    }
    beforeDestroy() {
        this.modal.dispose();
    }
    cancelClick() {
        this.$router.push('/home');
    }
    getFeedbackFormRequest(): FeedbackFormRequest {
        return {
            firstName: this.firstName,
            lastName: this.lastName,
            email: this.emailAddress,
            phoneNumber: this.phoneNumber,
            message: this.feedBack,
        };
    }
    async submitClick() {
        if (this.submitValidation()) {
            await apiLibraryApi
                .submitFeedbackForm(this.getFeedbackFormRequest())
                .then(() => {
                    this.$router.push('/home');
                })
                .catch((error) => {
                    this.modal.show();
                });
        }
    }
    submitValidation(): boolean {
        this.isFeedback = this.feedBack?.trim().length > 0;
        return this.isFeedback;
    }
}
</script>
<style scoped>
.size {
    max-width: 300px;
    max-height: 40px;
}

.feedBack_container {
    max-width: 744px;
    max-height: 136px;
}

.chi .chi-modal {
    left: 21rem;
    top: 7.9rem;
    max-width: 30rem;
    height: 11.4375rem;
}

.chi-modal__content {
    padding-bottom: 0.5rem;
}

.chi i.icon-x {
    font-size: 1rem !important;
}

.chi .chi-modal__header .chi-modal__title {
    font-size: 1.12rem;
}
</style>
