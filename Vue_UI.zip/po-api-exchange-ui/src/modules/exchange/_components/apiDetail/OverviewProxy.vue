<template>
    <div>
        <div class="chi-card -portal -highlight -my--2 -mb--2 -ml--3">
            <div class="chi-card__header -sm -pl--0">
                <div class="chi-card__caption -text--h4 -text--bolder" data-cy="cy-environment">Environments</div>
            </div>
            <div class="chi-card__content">
                <div class="chi-grid -ml--2">
                    <div class="chi-col -w--4 -p--0">
                        <span class="-text--2xs -mb--0 -text--bold" data-cy="cy-text-dev">DEVELOPMENT</span>
                        <div class="chi-divider -bt--2" style="margin-right: -24px"></div>
                    </div>
                    <div class="chi-col -w--4 -p--0 -ml--10 -mr--2">
                        <span class="-text--2xs -mb--0 -text--bold" data-cy="cy-text-test">TEST</span>
                        <div class="chi-divider -bt--2" style="margin-right: -24px"></div>
                    </div>

                    <div class="chi-col -ml--8 -p--0" style="margin-right: -24px">
                        <span class="-text--2xs -text--bold -mb--0" data-cy="cy-text-prod">PRODUCTION</span>
                        <div class="chi-divider -bt--2 -mr--4"></div>
                    </div>
                </div>
                <div class="chi-grid -ml--2" v-if="loadProxyEnv">
                    <div v-for="env in development" class="chi-col -w--1 -p--0 -mr--1 -mt--1" :key="env.id">
                        <div class="chi-card -w-sm--2 -b--0 -b-sm--1 -b-md--1 -align--center" id="environment-box">
                            <a
                                v-if="checkEnvPresent(env.id)"
                                class="-p--0 -pt--1 -pb--1 chi-card__content -mb--1 -mt--2"
                                :data-cy="`cy-chi-card__content__${env.id}`"
                                @click="loadEnvData(env.id)"
                            >
                                <div
                                    class="chi-card__title success_card -text--normal -mb--1"
                                    :data-cy="`cy-card__content__${env.id}`"
                                >
                                    {{ env.value }}
                                </div>
                                <chi-icon icon="circle-check" size="xs" color="success"> </chi-icon>
                            </a>
                            <div
                                v-else
                                class="-p--0 -pt--1 -pb--1 chi-card__content -mb--1 -mt--2"
                                :data-cy="`cy-chi-card__content__${env.id}`"
                            >
                                <div
                                    class="chi-card__title muted_card -text--normal -mb--1"
                                    :data-cy="`cy-card__content__${env.id}`"
                                >
                                    {{ env.value }}
                                </div>
                                <chi-icon icon="minus" size="xs" color="muted"> </chi-icon>
                            </div>
                        </div>
                    </div>
                    <div class="-mr--6"></div>
                    <div v-for="env in test" class="chi-col -w--1 -p--0 -mr--1 -mt--1" :key="env.id">
                        <div class="chi-card -w-sm--2 -b--0 -b-sm--1 -b-md--1 -align--center" id="environment-box">
                            <a
                                v-if="checkEnvPresent(env.id)"
                                class="-p--0 -pt--1 -pb--1 chi-card__content -mb--1 -mt--2"
                                :data-cy="`cy-chi-card__content__${env.id}`"
                                @click="loadEnvData(env.id)"
                            >
                                <div
                                    class="chi-card__title success_card -text--normal -mb--1"
                                    :data-cy="`cy-card__content__${env.id}`"
                                >
                                    {{ env.value }}
                                </div>
                                <chi-icon icon="circle-check" size="xs" color="success"> </chi-icon>
                            </a>
                            <div
                                v-else
                                class="-p--0 -pt--1 -pb--1 chi-card__content -mb--1 -mt--2"
                                :data-cy="`cy-chi-card__content__${env.id}`"
                            >
                                <div
                                    class="chi-card__title muted_card -text--normal -mb--1"
                                    :data-cy="`cy-card__content__${env.id}`"
                                >
                                    {{ env.value }}
                                </div>
                                <chi-icon icon="minus" size="xs" color="muted"> </chi-icon>
                            </div>
                        </div>
                    </div>
                    <div class="-mr--6"></div>
                    <div v-for="env in production" class="chi-col -w--1 -p--0 -mt--1" :key="env.id">
                        <div class="chi-card -w-sm--2 -b--0 -b-sm--1 -b-md--1 -align--center" id="environment-box">
                            <a
                                v-if="checkEnvPresent(env.id)"
                                class="-p--0 -pt--1 -pb--1 chi-card__content -mb--1 -mt--2"
                                :data-cy="`cy-chi-card__content__${env.id}`"
                                @click="loadEnvData(env.id)"
                            >
                                <div
                                    class="chi-card__title success_card -text--normal -mb--1"
                                    :data-cy="`cy-card__content__${env.id}`"
                                >
                                    {{ env.value }}
                                </div>
                                <chi-icon icon="circle-check" size="xs" color="success"> </chi-icon>
                            </a>
                            <div
                                v-else
                                class="-p--0 -pt--1 -pb--1 chi-card__content -mb--1 -mt--2"
                                :data-cy="`cy-chi-card__content__${env.id}`"
                            >
                                <div
                                    class="chi-card__title muted_card -text--normal -mb--1"
                                    :data-cy="`cy-card__content__${env.id}`"
                                >
                                    {{ env.value }}
                                </div>
                                <chi-icon icon="minus" size="xs" color="muted"> </chi-icon>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="chi-card -portal -my--2 -ml--3">
            <div class="chi-card__content">
                <div class="chi-grid">
                    <div class="chi-col -ml--2 -mr--2">
                        <div class="chi-form__item">
                            <chi-label for="example__taxononmy" data-cy="cy-proxy-taxonomy_label">Taxonomy </chi-label>
                            <input
                                type="text"
                                class="chi-input"
                                id="example__taxonomy"
                                data-cy="cy-proxy-taxonomy_text"
                                :value="taxonomy"
                                disabled
                            />
                        </div>
                    </div>
                    <div class="chi-col -mr--2">
                        <div class="chi-form__item">
                            <chi-label for="example__resourceName" data-cy="cy-proxy-resourceName_label"
                                >Resource Name
                            </chi-label>
                            <input
                                type="text"
                                class="chi-input"
                                id="example__resourceName"
                                data-cy="cy-proxy-resourceName_text"
                                :value="resourceName"
                                disabled
                            />
                        </div>
                    </div>
                    <div class="chi-col -mr--2">
                        <div class="chi-form__item">
                            <chi-label for="example__version" data-cy="cy-proxy-version_label">Version </chi-label>
                            <input
                                type="text"
                                class="chi-input"
                                id="example__version"
                                data-cy="cy-proxy-version_text"
                                :value="version"
                                disabled
                            />
                        </div>
                    </div>
                    <div class="chi-col -mr--2">
                        <div class="chi-form__item">
                            <chi-label for="example__appId" data-cy="cy-proxy-appId_label">App ID </chi-label>
                            <input
                                type="text"
                                class="chi-input"
                                id="example__appId"
                                data-cy="cy-proxy-appId_text"
                                :value="appId"
                                disabled
                            />
                        </div>
                    </div>
                </div>
                <div class="chi-grid">
                    <div class="chi-col -ml--2 -mt--4 -mr--2">
                        <div class="chi-form__item">
                            <chi-label for="example__routing" data-cy="cy-proxy-routing_label">Routing </chi-label>
                            <input
                                type="text"
                                class="chi-input"
                                id="example__routing"
                                data-cy="cy-proxy-routing_text"
                                :value="routing"
                                disabled
                            />
                        </div>
                    </div>
                </div>
                <div class="chi-grid">
                    <div class="chi-col -ml--2 -mt--4 -mr--2">
                        <div class="chi-form__item">
                            <chi-label for="example__endUrl" data-cy="cy-proxy-endUrl_label">Endpoint URL </chi-label>
                            <input
                                type="text"
                                class="chi-input"
                                id="example__endUrl"
                                data-cy="cy-proxy-endUrl_text"
                                :value="endUrl"
                                disabled
                            />
                        </div>
                    </div>
                </div>
                <div class="chi-grid">
                    <div class="chi-col -ml--2 -mt--4 -mr--2 -w-md--3">
                        <div class="chi-form__item">
                            <chi-label for="example__throttle" data-cy="cy-proxy-throttle_label"
                                >Timeout Throttle
                            </chi-label>
                            <input
                                type="text"
                                class="chi-input"
                                id="example__throttle"
                                data-cy="cy-proxy-throttle_text"
                                :value="throttle"
                                disabled
                            />
                        </div>
                    </div>
                    <div class="chi-col -mt--4 -mr--2 -w-md--1">
                        <fieldset>
                            <legend class="chi-label" data-cy="cy-proxy-active_label">Act</legend>
                            <div class="chi-form__item">
                                <div class="chi-radio">
                                    <input
                                        class="chi-radio__input"
                                        type="radio"
                                        data-cy="cy-proxy-active_radio_yes"
                                        name="actRadios"
                                        id="radio - act1"
                                        :checked="activated === true"
                                    />
                                    <label
                                        class="chi-radio__label"
                                        data-cy="cy-proxy-active_yes_label"
                                        for="radio - act1"
                                        >Yes</label
                                    >
                                </div>
                            </div>
                            <div class="chi-form__item">
                                <div class="chi-radio">
                                    <input
                                        class="chi-radio__input"
                                        type="radio"
                                        data-cy="cy-proxy-active_radio_no"
                                        name="actRadios"
                                        id="radio - act2"
                                        :checked="activated === false"
                                    />
                                    <label
                                        class="chi-radio__label"
                                        data-cy="cy-proxy-active_no_label"
                                        for="radio - act2"
                                        >No</label
                                    >
                                </div>
                            </div>
                        </fieldset>
                    </div>
                    <div class="chi-col -mt--4 -mr--2 -w-md--1">
                        <fieldset>
                            <legend class="chi-label" data-cy="cy-proxy-int_label">Int</legend>
                            <div class="chi-form__item">
                                <div class="chi-radio">
                                    <input
                                        class="chi-radio__input"
                                        type="radio"
                                        data-cy="cy-proxy-int_radio_yes"
                                        name="intRadios"
                                        id="radio - int1"
                                        :checked="internalAvail === true"
                                    />
                                    <label class="chi-radio__label" data-cy="cy-proxy-int_yes_label" for="radio - int1"
                                        >Yes</label
                                    >
                                </div>
                            </div>
                            <div class="chi-form__item">
                                <div class="chi-radio">
                                    <input
                                        class="chi-radio__input"
                                        type="radio"
                                        data-cy="cy-proxy-int_radio_no"
                                        name="intRadios"
                                        id="radio - int2"
                                        :checked="internalAvail === false"
                                    />
                                    <label class="chi-radio__label" data-cy="cy-proxy-int_no_label" for="radio - int2"
                                        >No</label
                                    >
                                </div>
                            </div>
                        </fieldset>
                    </div>
                    <div class="chi-col -mt--4 -mr--2 -w-md--1">
                        <fieldset>
                            <legend class="chi-label" data-cy="cy-proxy-ext_label">Ext</legend>
                            <div class="chi-form__item">
                                <div class="chi-radio">
                                    <input
                                        class="chi-radio__input"
                                        type="radio"
                                        data-cy="cy-proxy-ext_radio_yes"
                                        name="extRadios"
                                        id="radio - ext1"
                                        :checked="externalAvail === true"
                                    />
                                    <label class="chi-radio__label" data-cy="cy-proxy-ext_yes_label" for="radio - ext1"
                                        >Yes</label
                                    >
                                </div>
                            </div>
                            <div class="chi-form__item">
                                <div class="chi-radio">
                                    <input
                                        class="chi-radio__input"
                                        type="radio"
                                        data-cy="cy-proxy-ext_radio_no"
                                        name="extRadios"
                                        id="radio - ext2"
                                        :checked="externalAvail === false"
                                    />
                                    <label class="chi-radio__label" data-cy="cy-proxy-ext_no_label" for="radio - ext2"
                                        >No</label
                                    >
                                </div>
                            </div>
                        </fieldset>
                    </div>
                    <div class="chi-col -mt--4 -mr--2 -w-md--2">
                        <div class="chi-form__item">
                            <chi-label for="example__sync" data-cy="cy-proxy-sync_label">Sync </chi-label>
                            <input
                                type="text"
                                class="chi-input"
                                id="example__sync"
                                data-cy="cy-proxy-sync_text"
                                :value="sync"
                                disabled
                            />
                        </div>
                    </div>
                    <div class="chi-col -mt--4 -mr--2"></div>
                </div>
                <div class="chi-grid">
                    <div class="chi-col -ml--2 -mt--4 -mr--2">
                        <div class="chi-form__item">
                            <chi-label for="example__apigeeServer" data-cy="cy-proxy-apigeeServer_label"
                                >Apigee Servers
                            </chi-label>
                            <textarea
                                class="chi-input"
                                id="example__apigeeServer"
                                data-cy="cy-proxy-apigeeServer__textarea"
                                :value="apigeeServer"
                                minlength="40"
                                maxlength="1000"
                                aria-multiline="true"
                                style="resize: vertical"
                                disabled
                            ></textarea>
                        </div>
                    </div>
                </div>
                <div class="chi-grid">
                    <div class="chi-col -ml--2 -mt--4 -w-sm--5">
                        <div class="chi-form__item">
                            <chi-label for="example__producerAppKey" data-cy="cy-proxy-producerAppKey_label"
                                >API Producer App Application Key
                            </chi-label>
                            <input
                                type="text"
                                class="chi-input"
                                id="example__producerAppKey"
                                data-cy="cy-proxy-producerAppKey_text"
                                :value="producerAppKey"
                                disabled
                            />
                        </div>
                    </div>
                    <div class="chi-col -mt--4 -w-sm--3">
                        <div class="chi-form__item">
                            <chi-label for="example__assetTag" data-cy="cy-proxy-assetTag_label"
                                >CMS Asset Tag/ID #
                            </chi-label>
                            <input
                                type="text"
                                class="chi-input"
                                id="example__assetTag"
                                data-cy="cy-proxy-assetTag_text"
                                :value="assetTagId"
                                disabled
                            />
                        </div>
                    </div>
                    <div class="chi-col -mt--4 -w-sm--2">
                        <fieldset>
                            <legend class="chi-label">Endpoint Type</legend>
                            <div class="chi-form__item">
                                <div class="chi-radio">
                                    <input
                                        class="chi-radio__input"
                                        type="radio"
                                        name="endTypeRadios"
                                        id="radio - endType1"
                                        :checked="routingType === 'Inbound'"
                                        disabled
                                    />
                                    <label class="chi-radio__label" for="radio - endType1">Inbound</label>
                                </div>
                            </div>
                            <div class="chi-form__item">
                                <div class="chi-radio">
                                    <input
                                        class="chi-radio__input"
                                        type="radio"
                                        name="endTypeRadios"
                                        id="radio - endType2"
                                        :checked="routingType === 'outbound'"
                                        disabled
                                    />
                                    <label class="chi-radio__label" for="radio - endType2">Outbound</label>
                                </div>
                            </div>
                        </fieldset>
                    </div>
                </div>
                <div class="chi-grid">
                    <div class="chi-col -ml--2 -mt--4 -mr--2 -w-sm--3">
                        <div class="chi-form__item">
                            <chi-label for="example__createdBy" data-cy="cy-proxy-createdBy_label"
                                >Created By
                            </chi-label>
                            <input
                                type="text"
                                class="chi-input"
                                id="example__createdBy"
                                data-cy="cy-proxy-createdBy_text"
                                :value="createdBy"
                                disabled
                            />
                        </div>
                    </div>
                    <div class="chi-col -mt--4 -mr--2 -w-sm--3">
                        <div class="chi-form__item">
                            <chi-label for="example__createdTs" data-cy="cy-proxy-createdTs_label"
                                >Created At
                            </chi-label>
                            <input
                                type="text"
                                class="chi-input"
                                id="example__createdTs"
                                data-cy="cy-proxy-createdTs_text"
                                :value="createdDate"
                                disabled
                            />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import { DocumentationData } from '@/models/chiTableTypes';
import { getModule } from 'vuex-module-decorators';
import store, { STORE_KEY } from '@/modules/exchange/_store';
@Component({
    components: {},
})
export default class OverviewProxy extends Vue {
    @Prop() proxyData!: any;
    private _homeStore!: any;
    taxonomy = '';
    resourceName = '';
    version = '';
    appId: any = '';
    activated = false;
    internalAvail = false;
    externalAvail = false;
    routing = '';
    endUrl = '';
    throttle = '';
    sync = '';
    routingType = '';
    apigeeServer = '';
    producerAppKey = '';
    assetTagId = '';
    createdBy = '';
    createdDate = '';
    development: any = [
        { id: 'dev1', value: 'Dev 1' },
        { id: 'dev2', value: 'Dev 2' },
        { id: 'dev3', value: 'Dev 3' },
        { id: 'dev4', value: 'Dev 4' },
    ];
    test: any = [
        { id: 'test1', value: 'Test 1' },
        { id: 'test2', value: 'Test 2' },
        { id: 'test3', value: 'Test 3' },
        { id: 'test4', value: 'Test 4' },
    ];
    production: any = [{ id: 'prod', value: 'Prod' }];
    private proxyEnv: string[] = [];
    private proxyIndex = 0;
    private documentIndex = 0;

    created() {
        const isModuleRegistered = Object.keys(this.$store.state).includes(STORE_KEY);
        if (!isModuleRegistered) {
            this.$store.registerModule(STORE_KEY, store);
        }
        this._homeStore = getModule(store, this.$store);
    }

    mounted() {
        this.setProxyData(this.proxyIndex);
    }

    updated() {
        this.setProxyData(this.proxyIndex, this.documentIndex);
    }

    //#region getters
    get loadProxyEnv(): boolean {
        this.proxyEnv = [];
        this.proxyIndex = this._homeStore?.proxyIndex;
        const documentationData: DocumentationData[] = this.proxyData[this.proxyIndex].documentation;

        documentationData.forEach((documentation) => {
            this.proxyEnv.push(documentation['environment']);
        });
        this.documentIndex = documentationData.findIndex((doc) => doc['environment'] === this.proxyEnv[0]);
        return !!this.proxyEnv;
    }
    //#endregion

    //#region Private functions
    setProxyData(proxyIndex: number, docIndex: number = 0): void {
        this.taxonomy = this.proxyData[proxyIndex].documentation[docIndex]?.resourceTaxonomy;
        this.resourceName = this.proxyData[proxyIndex].documentation[docIndex]?.resourceName;
        this.version = this.proxyData[proxyIndex].documentation[docIndex]?.version;
        this.appId = this.proxyData[proxyIndex].documentation[docIndex]?.mediatedResourceId;
        this.routing = this.proxyData[proxyIndex].documentation[docIndex]?.routingExpression;
        this.endUrl = this.proxyData[proxyIndex].documentation[docIndex]?.endPointUrl;
        this.throttle = this.proxyData[proxyIndex].documentation[docIndex]?.timeoutSecs;
        this.producerAppKey = this.proxyData[proxyIndex].documentation[docIndex]?.owningApplicationKey;
        this.assetTagId = this.proxyData[proxyIndex].documentation[docIndex]?.owningApplicationId;
        this.createdBy = this.proxyData[proxyIndex].documentation[docIndex]?.createdBy;
        this.createdDate = this.proxyData[proxyIndex].documentation[docIndex]?.createdDate;
        this.activated = this.proxyData[proxyIndex].documentation[docIndex]?.active;
        this.internalAvail = this.proxyData[proxyIndex].documentation[docIndex]?.internallyAvailable;
        this.externalAvail = this.proxyData[proxyIndex].documentation[docIndex]?.externallyAvailable;
        this.routingType = this.proxyData[proxyIndex].documentation[docIndex]?.routingType;
    }

    checkEnvPresent(env: string): boolean {
        let foundEnv: boolean = false;
        this.proxyEnv.forEach((proxy) => {
            if (proxy === env) {
                foundEnv = true;
            }
        });
        return foundEnv;
    }

    loadEnvData(environment: string): void {
        this.documentIndex = this.proxyData[this.proxyIndex].documentation.findIndex(
            (element) => element.environment === environment
        );
        this.setProxyData(this.proxyIndex, this.documentIndex);
    }
    //#endregion
}
</script>
<style scoped>
.chi .chi-input {
    height: 2rem;
}
.chi textarea.chi-input {
    min-height: 4.5rem;
}
.success_card {
    color: green;
    font-size: 14px !important;
}
.muted_card {
    color: black;
    font-size: 14px !important;
}
</style>
