<template>
    <div>
        <Loader v-if="dataLoading" />
        <div class="chi-main" id="overviewPage" v-else>
            <div class="chi-grid">
                <div class="chi-col -w--4">
                    <div class="chi-main__header" style="margin: 0% 0% 0% 1%">
                        <div class="chi-main__header-start">
                            <a class="chi-link" href="/exchange">
                                <div class="chi-link__content" data-cy="cy-back_link">
                                    <chi-icon icon="chevron-left"></chi-icon>
                                    <span class="chi-main__title-heading -text--boldest -text--navy -text--900"
                                        >Exchange</span
                                    >
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="chi-main__title chi-col -w--12 -h--50">
                    <div class="chi-col -text--boldest -text--navy -pr--2">
                        <div data-cy="cy-selected_apiname" class="-mt--2">
                            <h4>{{ api.name }}</h4>
                        </div>
                    </div>

                    <div class="chi-col">
                        <div style="float: right">
                            <chi-button
                                class="-mt--1 -pr--1 -pl--0"
                                data-target="#delete-api-modal"
                                id="delete-api-modal-trigger"
                                data-cy="cy-overview_delete__button"
                                @click="deleteClientClick()"
                            >
                                <span>Delete API</span>
                            </chi-button>
                            <router-link
                                :to="{
                                    name: 'EditAPIDocumentation',
                                    params: { page: 'edit', alert: '', alertmsg: '', apiid: api.id },
                                }"
                            >
                                <chi-button color="primary" data-cy="cy-overview_edit__button" class="-my--1 -mt--2"
                                    >Edit</chi-button
                                >
                            </router-link>
                        </div>
                    </div>
                </div>
            </div>
            <div class="chi-main__content">
                <div class="chi-grid -pr--6" style="margin-top: 4%; margin-right: -115px">
                    <div class="chi-col -w--2 -pl--3 sticky-scroll" id="sections" data-cy="cy-sections">
                        <ul class="chi-tabs -vertical -icons" id="example-vertical-base">
                            <li
                                class=""
                                v-bind:class="{
                                    '': !isFolderOpen && !apisectAvail,
                                    '-active': isFolderOpen && apisectAvail,
                                }"
                                data-cy="cy-document-sections"
                            >
                                <a href="#" @click="switchApiSections('DOCUMENT')">
                                    <i
                                        class="chi-icon"
                                        v-bind:class="{
                                            'icon-folder': !isFolderOpen,
                                            'icon-folder-open': isFolderOpen,
                                        }"
                                        aria-hidden="true"
                                    ></i>
                                    <span>Documentation</span>
                                </a>
                                <ul class="chi-tabs__subtabs" data-cy="cy-document-subsection" v-if="isFolderOpen">
                                    <li
                                        v-for="(API, index) in documents"
                                        :key="API.id"
                                        :class="{ '-active': index === activeDocIndex }"
                                    >
                                        <a
                                            :id="'section' + `${API.id}`"
                                            role="tab"
                                            :aria-selected="index === activeDocIndex"
                                            @click="changeIndex(index)"
                                            tabindex="-1"
                                            :aria-controls="'section' + `${API.id}`"
                                            >{{ API.apiName }}</a
                                        >
                                    </li>
                                </ul>
                            </li>
                            <li
                                class=""
                                v-bind:class="{
                                    '': isFolderOpen,
                                    '-active': !isFolderOpen,
                                }"
                                data-cy="cy-proxy-sections"
                            >
                                <a href="#" @click="switchApiSections('PROXY')">
                                    <i
                                        class="chi-icon"
                                        v-bind:class="{
                                            'icon-folder': isFolderOpen,
                                            'icon-folder-open': !isFolderOpen,
                                        }"
                                        aria-hidden="true"
                                    ></i>

                                    <span>Proxies</span>
                                </a>
                                <ul v-if="!isFolderOpen" class="chi-tabs__subtabs" data-cy="cy-proxy-subsection">
                                    <li
                                        v-for="(proxyData, index) in proxySection"
                                        :key="proxyData.id"
                                        :class="{ '-active': index === activeProxyIndex }"
                                    >
                                        <a
                                            :data-cy="`proxies-section-${proxyData.id}`"
                                            :id="`proxies-section-${index}`"
                                            role="tab"
                                            tabindex="-1"
                                            :aria-selected="index === activeProxyIndex"
                                            @click="changeProxyIndex(index)"
                                            :aria-controls="'section' + `${proxyData.id}`"
                                            :data-target="`#proxysection-${index}`"
                                            ref="popoverTrigger"
                                            data-popover-trigger
                                            style="overflow: hidden; text-overflow: ellipsis"
                                            >{{ proxyData.apiName }}</a
                                        >
                                        <section
                                            class="chi-popover chi-popover--top -animated"
                                            :id="`proxysection-${index}`"
                                            aria-modal="true"
                                            role="dialog"
                                            aria-hidden="true"
                                            x-placement="top"
                                        >
                                            <div class="chi-popover__content -p--1">
                                                <p
                                                    class="chi-popover__text min-width -text--xs"
                                                    data-cy="cy-proxy-popover_content"
                                                >
                                                    {{ proxyData.apiName }}
                                                </p>
                                            </div>
                                        </section>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <div
                        class="chi-col -w--10 -w-sm--12"
                        v-if="apisectAvail && isFolderOpen"
                        style="margin-top: -1.5%; max-width: 85%"
                    >
                        <div class="chi-card -portal -my--2" data-cy="cy-document-content-sections">
                            <div
                                v-for="(API, index) in documents"
                                :key="API.id"
                                class="chi-tabs-panel"
                                :class="{ '-active': index === activeDocIndex }"
                                :id="'section' + `${API.id}`"
                                role="tabpanel"
                            >
                                <div class="chi-card__header -sm">
                                    <div class="chi-card__title">
                                        {{ API.apiName }}
                                    </div>
                                </div>
                                <div class="chi-card__content" id="sectionContent" data-cy="cy-document-content">
                                    <div v-if="API.sectionType === 'text'">{{ API.documentation }}</div>

                                    <div v-if="API.sectionType === 'swagger'">
                                        <div class="swagger" :id="'swagger' + `${API.id}`"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div
                        class="chi-col -w-md--10 -w-sm--12 -mw--85 -mt--1"
                        v-if="!apisectAvail && isFolderOpen && proxysectAvail"
                        data-cy="no_doc_alert"
                    >
                        <chi-alert color="info" icon="circle-info" size="md">
                            Currently no <u>Documentation</u> available!
                        </chi-alert>
                    </div>
                    <div
                        class="chi-col -w-md--10 -w-sm--12"
                        v-if="proxysectAvail && !isFolderOpen"
                        style="margin-top: -1.5%; max-width: 85%"
                    >
                        <OverviewProxy :proxyData="proxySection" />
                    </div>

                    <div
                        class="chi-col -w-md--10 -w-sm--12 -mw--85 -mt--1"
                        v-if="apisectAvail && !proxysectAvail && !isFolderOpen"
                        data-cy="no_proxy_alert"
                    >
                        <chi-alert color="info" icon="circle-info" size="md">
                            Currently no <u>Proxies</u> available!
                        </chi-alert>
                    </div>

                    <div v-if="!apisectAvail && !proxysectAvail" class="chi-col -o--0 -w--10" data-cy="cy-no_data">
                        <AlertComponent :alertObject="alertObject" />
                    </div>
                </div>
            </div>
        </div>
        <Modal :modalObject="deleteAPIModal" :id="`delete-api-modal`" />
        <Footer />
    </div>
</template>
<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import Modal from '@/modules/common/_components/Modal.vue';
import { getModule } from 'vuex-module-decorators';
import { MODAL_TITLES, MODAL_MESSAGE_FUNC, MODAL_APPLY_BUTTONS } from '@/utils/messages';
import SwaggerUI from 'swagger-ui';
import 'swagger-ui/dist/swagger-ui.css';
import { CustomModal } from '@/models/custom-modal';
import Footer from '@/modules/common/_components/Footer.vue';
import { Alert } from '@/models/alert';
import AlertComponent from '@/modules/common/_components/AlertComponent.vue';
import store, { STORE_KEY } from '@/modules/exchange/_store';
import { DocumentationData, ProxieData, Proxies } from '@/models/chiTableTypes';
import { Compare } from '@/utils/compare';
import OverviewProxy from './OverviewProxy.vue';
import Loader from '@/modules/common/_components/Loader.vue';
import { CHI_WAIT_TIME } from '@/utils/constants';
import { mapState } from 'vuex';
window.Vue = require('vue');
declare let chi: any;
@Component({
    components: {
        Modal,
        Footer,
        AlertComponent,
        OverviewProxy,
        Loader,
    },
    computed: {
        ...mapState('$_api_exchange_home', { storeLoader: 'loader' }),
    },
})
export default class Overview extends Vue {
    windowTop: any = 0;
    apiSections: any[] = [];
    proxySection: Proxies[] = [];
    url: any = '';
    overviewInfo: any = '';
    api: any;
    apiName: any;
    showSwagger = true;
    swaggerFile: any = [];
    apisectAvail = false;
    proxysectAvail = false;
    activeDocIndex: number = 0;
    activeProxyIndex: number = 0;
    successAlertData: string = '';
    isFolderOpen = true;
    chiInstance = (window as Window).chi;
    alertObject: Alert = new Alert('Currently no data available! ', {
        color: 'info',
        icon: 'circle-info',
        closable: false,
    });
    deleteAPIModal: CustomModal = new CustomModal('', '', () => '');
    failureAlertMsg: string = '';
    _homeStore!: any;
    splittedStr: string[] = [];
    resource: string = '';
    rtaxonomy: string = '';
    proxyName: string = '';
    documents: DocumentationData[] = [];
    proxies: ProxieData[] = [];
    dataLoading = false;
    popovers: any[] = [];
    modal: any;
    tab: any;
    created() {
        const isModuleRegistered = Object.keys(this.$store.state).includes(STORE_KEY);
        if (!isModuleRegistered) {
            this.$store.registerModule(STORE_KEY, store);
        }
        this._homeStore = getModule(store, this.$store);
        this.api = this._homeStore.apiData;
        this._homeStore.setLoadingProp(true);
    }

    async mounted(): Promise<void> {
        this.api.id = this.$route.params.apiid;
        this.api.name = this.$route.params.apiname;

        await this._homeStore.loadOverviewData(this.api.name);
        this.documents = [...this._homeStore.apiOverview.documentations];
        this.proxies = [...this._homeStore.apiOverview.proxies];
        this.documents.sort(this.compare);
        this.apisectAvail = !Compare.isEmptyArray(this.documents) ? true : false;
        this.documents.forEach((section) => {
            if (section.sectionType == 'swagger') {
                this.swaggerFile.push(section.id);
            }
        });
        await this.proxySectionDetails();
        await this._homeStore.setLoadingProp(false);
        this.modal = this.chiInstance.modal(document.getElementById('delete-api-modal-trigger'));
        window.addEventListener('scroll', this.onScroll);
        this.tab = chi?.tab(document.getElementById('example-vertical-base'));
    }

    private initSectionUrls() {
        this.documents.forEach((section) => {
            const doc = document.getElementById(`section${section.id}`);
            if (doc) {
                doc.setAttribute('href', '#section' + `${section.id}`);
            } else {
                console.error('(initSectionUrls) Could not set href property for section: ', section.id);
            }
        });
    }

    private initProxySectionUrls() {
        this.proxySection.forEach((proxySection) => {
            const doc = document.getElementById(`proxies-section-${proxySection.id}`);
            if (doc) {
                doc.setAttribute('href', '#proxysection' + `${proxySection.id}`);
            } else {
                console.error('(initProxySectionUrls) Could not set href property for proxySection: ', proxySection.id);
            }
        });
    }

    beforeDestroy() {
        this.popovers.forEach(function (popover) {
            popover.dispose();
        });
        this.modal.dispose();
        this.tab.dispose();
        this.windowTop.dispose();
    }

    private initPopovers(): void {
        this.popovers = this.chiInstance.popover(document.querySelectorAll('[data-popover-trigger]'));
        for (let popup = 0; popup < this.popovers.length; popup = popup + 1) {
            const data = document?.getElementById(`proxies-section-${popup}`);
            const popover = this.chiInstance?.popover(data);
            let hoverAnimationTimeout: number;
            if (data) {
                data.addEventListener('mouseenter', () => {
                    hoverAnimationTimeout = window.setTimeout(() => {
                        popover.show();
                    }, CHI_WAIT_TIME);
                });
                data.addEventListener('mouseleave', () => {
                    if (hoverAnimationTimeout) {
                        clearTimeout(hoverAnimationTimeout);
                    }
                    popover.hide();
                });
            }
        }
    }
    beforeUpdate() {
        if (this.isFolderOpen) {
            setTimeout(() => {
                this.swaggerFile.forEach((element) => {
                    this.initializeSwagger(element);
                });
            }, 100);
        }
    }
    updated(): void {
        this.initPopovers();
        this.initSectionUrls();
        this.initProxySectionUrls();
    }

    compare(apidetail1, apidetail2) {
        if (apidetail1.sectionOrder < apidetail2.sectionOrder) {
            return -1;
        }
        if (apidetail1.sectionOrder > apidetail2.sectionOrder) {
            return 1;
        }
        return 0;
    }

    onScroll(e) {
        this.windowTop = e.target.documentElement.scrollTop;
    }

    initializeSwagger(sectId: any) {
        SwaggerUI({
            url: Vue.prototype.$config.base_url + '/v1/docFile/' + sectId,
            dom_id: '#swagger' + sectId,
        });
    }

    deleteClientClick() {
        const apiName: string = this.api.name;
        const applyFunc = async () => {
            await this._homeStore.deleteApi({ apiId: this.api.id, apiName: apiName });
            if (this._homeStore.successResponse.deleteSuccess) {
                await this._homeStore.loadProducts();
                this.$router.push({
                    name: 'Home',
                });
            } else if (this._homeStore.errorDetails.deleteError) {
                this.failureAlertMsg = "API didn't get deleted";
            }
        };
        const deleteClientModal = new CustomModal(
            MODAL_TITLES.DELETE_CLIENT,
            MODAL_MESSAGE_FUNC.deleteClient(apiName),
            applyFunc.bind(this),
            {
                acceptText: MODAL_APPLY_BUTTONS.DELETE_CLIENT,
                acceptTag: 'cy-delete-api-modal__accept__button',
                cancelTag: 'cy-delete-api-modal__cancel__button',
            }
        );
        this.deleteAPIModal = deleteClientModal;
    }

    //#region Private functions
    changeIndex(docIndex: number): void {
        this.activeDocIndex = docIndex;
    }

    changeProxyIndex(proxyIndex: number): void {
        this._homeStore.updateProxyIndex(proxyIndex);
        this.activeProxyIndex = proxyIndex;
    }

    switchApiSections(folder: string) {
        if (folder === 'DOCUMENT') {
            this.isFolderOpen = true;
        } else {
            this.isFolderOpen = false;
        }
    }

    private async proxySectionDetails(): Promise<void> {
        if (!Compare.isEmptyArray(this.proxies)) {
            for (const element of this.proxies) {
                const obj = {
                    apiId: this.api.id,
                    apiName: this.getProxyName(
                        element.environments[0]?.resourceTaxonomy,
                        element.environments[0]?.version,
                        element.environments[0]?.resourceName
                    ),
                    documentation: element.environments,
                    id: this.getRandomNumber(),
                    sectionOrder: '',
                    sectionType: 'PROXY',
                };
                this.proxySection.push(obj);
            }
            this.proxysectAvail = true;
        }
    }

    private getProxyName(resourceTaxonomy: string, version: string, resourceName: string): string {
        this.splittedStr = resourceTaxonomy?.split('/');
        if (this.splittedStr) {
            this.resource = this.splittedStr[0];
            if (this.splittedStr.length >= 2) {
                this.rtaxonomy = this.splittedStr[1];
                this.proxyName = this.resource + '/' + version + '/' + this.rtaxonomy + '/' + resourceName;
            } else {
                this.proxyName = this.resource + '/' + version + '/' + resourceName;
            }
        }

        return this.proxyName;
    }

    private getRandomNumber(): number {
        const array = new Uint32Array(1);
        window.crypto.getRandomValues(array);
        return array[0];
    }
    @Watch('storeLoader')
    setLoader() {
        this.dataLoading = !this.dataLoading;
    }
    //#endregion
}
</script>
<style scoped>
.chi-button {
    float: right;
}
#sections {
    margin-left: -3.5%;
    flex: 0%;
}
#sectionContent {
    height: 80vh;
    overflow-y: scroll;
    overflow-x: hidden !important;
}
.chi-col.-w--3.sticky-scroll ul {
    position: fixed;
    max-width: 310px;
}

.chi h2 {
    margin: 0rem 0;
}

.sticky-scroll {
    padding: 0 !important;
}
#overviewPage {
    width: 93%;
    min-height: 380px;
}
.chi .chi-main {
    margin-top: 1rem;
    margin-left: 2rem;
}
#delete-api-modal-trigger {
    padding: 10px 5px 10px 5px;
}
.loader {
    height: 64vh;
}
.chi .chi-popover .chi-popover__content {
    overflow: hidden;
}
.chi .chi-popover .chi-popover__content .chi-popover__text,
.chi .chi-popover .chi-popover__content p {
    word-break: break-all;
}
</style>
