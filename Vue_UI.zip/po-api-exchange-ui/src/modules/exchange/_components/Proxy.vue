<template>
    <div>
        <chi-spinner v-if="isDataMigrating" color="primary" backdrop="inverse"></chi-spinner>
        <Loader v-if="isDataLoading" />
        <div v-else>
            <a class="chi-link" href="#">
                <div class="chi-link__content -ml--4 -pt--4">
                    <chi-icon icon="chevron-left"></chi-icon>
                    <span class="-text--md" data-cy="cy-back_link">
                        <router-link to="/exchange" class="-text--sm,-m--60 -p--60">Exchange</router-link></span
                    >
                </div>
            </a>

            <div class="chi-main -base sc-chi-main">
                <div class="chi-main__header sc-chi-main -ml--4">
                    <div class="chi-main__header-start sc-chi-main">
                        <div class="chi-main__title sc-chi-main">
                            <div
                                class="-text--h3 -text--boldest -text--navy -m--0 -pr--2 sc-chi-main"
                                data-cy="cy-proxy-migrate"
                            >
                                Proxy Migration
                            </div>
                            <div class="-text--md -pl--2 -bl--1 sc-chi-main" data-cy="cy-network-audit">
                                {{ getResourceName() }}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="chi-main__content sc-chi-main sc-chi-main-s"></div>
            </div>

            <div class="chi-card__header -my--2 -mb--2 -ml--4">
                <div class="chi-card__caption -text--h4 -text--bolder" data-cy="cy-environment">Environments</div>
            </div>
            <div class="chi-card chi-lb-background-color -ml--4 -mr--4">
                <div class="chi-card__content">
                    <div class="chi-grid -ml--3">
                        <div class="chi-col -w--4 -p--0">
                            <span class="-text--2xs -mb--0 -text--bold" data-cy="cy-text-dev">DEVELOPMENT</span>
                            <div class="chi-divider -bt--2" style="margin-right: -9px"></div>
                        </div>
                        <div class="chi-col -w--4 -p--0 -ml--2">
                            <span class="-text--2xs -mb--0 -text--bold" data-cy="cy-text-test">TEST</span>
                            <div class="chi-divider -bt--2" style="margin-right: -10px"></div>
                        </div>

                        <div class="chi-col -w--3 -ml--1">
                            <span class="-text--2xs -mb--0 -text--bold" data-cy="cy-text-prod">PRODUCTION</span>
                            <div class="chi-divider -bt--2" style="margin-right: -27px"></div>
                        </div>
                    </div>

                    <div class="chi-grid -ml--3 -mr--4" data-cy="cy-box-environment">
                        <div class="chi-col -w--1 -p--0 -mr--1" v-for="(env, index) in envArray" :key="index">
                            <div
                                class="chi-card chi-w-background-color -w-sm--2 -b--0 -b-sm--1 -b-md--2 -align--center"
                            >
                                <div class="-p--0 -pt--1 -pb--1 chi-card__content -mb--1 -mt--1">
                                    <div
                                        class="chi-card__title success_card -text--normal -mb--1"
                                        :data-cy="`cy-card__content__${env}`"
                                    >
                                        {{ env }}
                                    </div>
                                    <chi-icon :icon="checkIcon(env)" :color="checkColor(env)"> </chi-icon>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="chi-card__header -my--2 -ml--4 -text--h4 -text--bolder" data-cy="cy-endpoint-promo">
                Endpoint Promotion
            </div>
            <div class="chi-card -ml--4 -mr--4">
                <div class="-ml--5 -align--left">
                    <div class="-text--h5 -text--bold" data-cy="cy-select-source">
                        <span class="chi-col -text--h4 -text--bold">1.</span><span>Select Source</span>
                    </div>

                    <div class="chi-grid">
                        <div class="chi-col -w--2 -ml--4">
                            <div class="chi-form__item">
                                <select
                                    class="chi-select -text--capitalize"
                                    id="example-ba1"
                                    data-cy="cy-select-dropdown"
                                    @change="selectedEnv($event.target.value)"
                                >
                                    <option v-for="(envs, index) in availableEnvs" :key="index">
                                        {{ envs }}
                                    </option>
                                </select>
                            </div>
                        </div>
                        <div class="chi-col">
                            <div class="chi-form__item" data-cy="cy-endpoint">
                                <chi-label>Endpoint</chi-label>
                                <p data-cy="cy-source-endpoint" class="-m--0 -mb--1">{{ getEndPoint() }}</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="chi-grid">
                    <div class="chi-col -text--h5 -ml--5 -text--bold" data-cy="cy-sel-endpoint-label">
                        <span class="chi-col -text--h4 -text--bold">2.</span><span>Select Endpoint</span>
                    </div>
                </div>
                <div class="chi-grid">
                    <div class="-mt--1 -text--2xs -align--right -ml--10 -text--bold" data-cy="cy-label-dev">
                        DEVELOPMENT
                    </div>
                </div>
                <div class="chi-divider -ml--8 -mr--3"></div>
                <div class="chi-form__item">
                    <div class="chi-grid -ml--4">
                        <div class="-mt--1 display_flex_50 -pr--4">
                            <label class="-mt--1 -ml--4 -mr--2 -text--semi-bold"> Dev1 </label>
                            <div class="chi-form__item -w--100">
                                <input
                                    type="text"
                                    class="chi-input"
                                    id="textEndpoint1"
                                    data-cy="cy-text-endpoint1"
                                    v-model="endPointStrDev1"
                                    :disabled="isDisabledInput('dev1')"
                                />
                                <div
                                    class="chi-label -status -danger"
                                    v-if="!isDisabledInput('dev1') && !isEmptyInput('dev1') && !isValidInput('dev1')"
                                >
                                    <chi-icon icon="circle-warning" data-cy="cy-error-text-endpoint1"></chi-icon>
                                    Invalid syntax: start with {{ http_string }} or {{ https_string }}
                                </div>
                            </div>
                            <chi-icon
                                v-if="showSuccess('dev1')"
                                class="-ml--1"
                                icon="check"
                                color="success"
                                size="sm--3"
                                data-cy="cy-check-text-endpoint1"
                            ></chi-icon>
                        </div>
                        <div class="-mt--1 display_flex_50 -pr--4">
                            <label class="-mt--1 -ml--4 -mr--2 -text--semi-bold"> Dev3 </label>
                            <div class="chi-form__item -w--100">
                                <input
                                    type="text"
                                    class="chi-input"
                                    id="textEndpoint3"
                                    data-cy="cy-text-endpoint3"
                                    v-model="endPointStrDev3"
                                    :disabled="isDisabledInput('dev3')"
                                />
                                <div
                                    class="chi-label -status -danger"
                                    v-if="!isDisabledInput('dev3') && !isEmptyInput('dev3') && !isValidInput('dev3')"
                                >
                                    <chi-icon icon="circle-warning" data-cy="cy-error-text-endpoint3"></chi-icon>
                                    Invalid syntax: start with {{ http_string }} or {{ https_string }}
                                </div>
                            </div>
                            <chi-icon
                                v-if="showSuccess('dev3')"
                                class="-ml--1"
                                icon="check"
                                color="success"
                                size="sm--3"
                                data-cy="cy-check-text-endpoint3"
                            ></chi-icon>
                        </div>
                    </div>
                    <div class="chi-grid -ml--4">
                        <div class="-mt--2 display_flex_50 -pr--4">
                            <label class="-mt--1 -ml--4 -mr--2 -text--semi-bold"> Dev2 </label>
                            <div class="chi-form__item -w--100">
                                <input
                                    type="text"
                                    class="chi-input"
                                    id="textEndpoint2"
                                    data-cy="cy-text-endpoint2"
                                    v-model="endPointStrDev2"
                                    :disabled="isDisabledInput('dev2')"
                                />
                                <div
                                    class="chi-label -status -danger"
                                    v-if="!isDisabledInput('dev2') && !isEmptyInput('dev2') && !isValidInput('dev2')"
                                >
                                    <chi-icon icon="circle-warning" data-cy="cy-error-text-endpoint2"></chi-icon>
                                    Invalid syntax: start with {{ http_string }} or {{ https_string }}
                                </div>
                            </div>
                            <chi-icon
                                v-if="showSuccess('dev2')"
                                class="-ml--1"
                                icon="check"
                                color="success"
                                size="sm--3"
                                data-cy="cy-check-text-endpoint2"
                            ></chi-icon>
                        </div>

                        <div class="-mt--2 display_flex_50 -pr--4">
                            <label class="-mt--1 -ml--4 -mr--2 -text--semi-bold"> Dev4 </label>
                            <div class="chi-form__item -w--100">
                                <input
                                    type="text"
                                    class="chi-input"
                                    id="textEndpoint4"
                                    data-cy="cy-text-endpoint4"
                                    v-model="endPointStrDev4"
                                    :disabled="isDisabledInput('dev4')"
                                />
                                <div
                                    class="chi-label -status -danger"
                                    v-if="!isDisabledInput('dev4') && !isEmptyInput('dev4') && !isValidInput('dev4')"
                                >
                                    <chi-icon icon="circle-warning" data-cy="cy-error-text-endpoint4"></chi-icon>
                                    Invalid syntax: start with {{ http_string }} or {{ https_string }}
                                </div>
                            </div>
                            <chi-icon
                                v-if="showSuccess('dev4')"
                                class="-ml--1"
                                icon="check"
                                color="success"
                                size="sm--3"
                                data-cy="cy-check-text-endpoint4"
                            ></chi-icon>
                        </div>
                    </div>
                    <div class="chi-grid">
                        <div class="-mt--4 -text--2xs -align--right -ml--10 -text--bold" data-cy="cy-label-test">
                            TEST
                        </div>
                    </div>
                    <div class="chi-divider -ml--8 -mr--3"></div>
                    <div class="chi-grid -ml--4">
                        <div class="-mt--1 display_flex_50 -pr--4">
                            <label class="-mt--1 -ml--4 -mr--2 -text--semi-bold"> Test1 </label>
                            <div class="chi-form__item -w--100">
                                <input
                                    type="text"
                                    class="chi-input"
                                    id="textEndpointt1"
                                    data-cy="cy-text-endpointt1"
                                    v-model="endPointStrTest1"
                                    :disabled="isDisabledInput('test1')"
                                />
                                <div
                                    class="chi-label -status -danger"
                                    v-if="!isDisabledInput('test1') && !isEmptyInput('test1') && !isValidInput('test1')"
                                >
                                    <chi-icon icon="circle-warning" data-cy="cy-error-text-endpointt1"></chi-icon>
                                    Invalid syntax: start with {{ http_string }} or {{ https_string }}
                                </div>
                            </div>
                            <chi-icon
                                v-if="showSuccess('test1')"
                                class="-ml--1"
                                icon="check"
                                color="success"
                                size="sm--3"
                                data-cy="cy-check-text-endpointt1"
                            ></chi-icon>
                        </div>

                        <div class="-mt--1 display_flex_50 -pr--4">
                            <label class="-mt--1 -ml--4 -mr--2 -text--semi-bold"> Test3 </label>
                            <div class="chi-form__item -w--100">
                                <input
                                    type="text"
                                    class="chi-input"
                                    id="textEndpointt3"
                                    data-cy="cy-text-endpointt3"
                                    v-model="endPointStrTest3"
                                    :disabled="isDisabledInput('test3')"
                                />
                                <div
                                    class="chi-label -status -danger"
                                    v-if="!isDisabledInput('test3') && !isEmptyInput('test3') && !isValidInput('test3')"
                                >
                                    <chi-icon icon="circle-warning" data-cy="cy-error-text-endpointt3"></chi-icon>
                                    Invalid syntax: start with {{ http_string }} or {{ https_string }}
                                </div>
                            </div>
                            <chi-icon
                                v-if="showSuccess('test3')"
                                class="-ml--1"
                                icon="check"
                                color="success"
                                size="sm--3"
                                data-cy="cy-check-text-endpointt3"
                            ></chi-icon>
                        </div>
                    </div>
                    <div class="chi-grid -ml--4">
                        <div class="-mt--1 display_flex_50 -pr--4">
                            <label class="-mt--1 -ml--4 -mr--2 -text--semi-bold"> Test2 </label>
                            <div class="chi-form__item -w--100">
                                <input
                                    type="text"
                                    class="chi-input"
                                    id="textEndpointt2"
                                    data-cy="cy-text-endpointt2"
                                    v-model="endPointStrTest2"
                                    :disabled="isDisabledInput('test2')"
                                />
                                <div
                                    class="chi-label -status -danger"
                                    v-if="!isDisabledInput('test2') && !isEmptyInput('test2') && !isValidInput('test2')"
                                >
                                    <chi-icon icon="circle-warning" data-cy="cy-error-text-endpointt2"></chi-icon>
                                    Invalid syntax: start with {{ http_string }} or {{ https_string }}
                                </div>
                            </div>
                            <chi-icon
                                v-if="showSuccess('test2')"
                                class="-ml--1"
                                icon="check"
                                color="success"
                                size="sm--3"
                                data-cy="cy-check-text-endpointt2"
                            ></chi-icon>
                        </div>

                        <div class="-mt--1 display_flex_50 -pr--4">
                            <label class="-mt--1 -ml--4 -mr--2 -text--semi-bold"> Test4 </label>
                            <div class="chi-form__item -w--100">
                                <input
                                    type="text"
                                    class="chi-input"
                                    id="textEndpointt4"
                                    data-cy="cy-text-endpointt4"
                                    v-model="endPointStrTest4"
                                    :disabled="isDisabledInput('test4')"
                                />
                                <div
                                    class="chi-label -status -danger"
                                    v-if="!isDisabledInput('test4') && !isEmptyInput('test4') && !isValidInput('test4')"
                                >
                                    <chi-icon icon="circle-warning" data-cy="cy-error-text-endpointt4"></chi-icon>
                                    Invalid syntax: start with {{ http_string }} or {{ https_string }}
                                </div>
                            </div>
                            <chi-icon
                                v-if="showSuccess('test4')"
                                class="-ml--1"
                                icon="check"
                                color="success"
                                size="sm--3"
                                data-cy="cy-check-text-endpointt4"
                            ></chi-icon>
                        </div>
                    </div>
                    <div class="chi-grid">
                        <div class="-mt--4 -text--2xs -align--right -ml--10 -text--bold" data-cy="cy-label-prod">
                            PRODUCTION
                        </div>
                    </div>
                    <div class="chi-divider -ml--8 -mr--3"></div>
                    <div class="chi-grid -ml--4">
                        <div class="-mt--1 display_flex_50 -pr--4">
                            <label class="-mt--1 -ml--4 -mr--2 -text--semi-bold"> Mock </label>
                            <div class="chi-form__item -w--100">
                                <input
                                    type="text"
                                    class="chi-input"
                                    id="textEndpointm"
                                    data-cy="cy-text-endpointm"
                                    v-model="endPointStrMock"
                                    :disabled="isDisabledInput('mock')"
                                />
                                <div
                                    class="chi-label -status -danger"
                                    v-if="!isDisabledInput('mock') && !isEmptyInput('mock') && !isValidInput('mock')"
                                >
                                    <chi-icon icon="circle-warning" data-cy="cy-error-text-mock"></chi-icon>
                                    Invalid syntax: start with {{ http_string }} or {{ https_string }}
                                </div>
                            </div>
                            <chi-icon
                                v-if="showSuccess('mock')"
                                class="-ml--1"
                                icon="check"
                                color="success"
                                size="sm--3"
                                data-cy="cy-check-text-mock"
                            ></chi-icon>
                        </div>

                        <div class="-mt--1 display_flex_50 -pr--4">
                            <label class="-mt--1 -ml--4 -mr--2 -text--semi-bold"> Sandbox </label>
                            <div class="chi-form__item -w--100">
                                <input
                                    type="text"
                                    class="chi-input"
                                    id="textEndpoints"
                                    data-cy="cy-text-endpoints"
                                    v-model="endPointStrSandBox"
                                    :disabled="isDisabledInput('sandbox')"
                                />
                                <div
                                    class="chi-label -status -danger"
                                    v-if="
                                        !isDisabledInput('sandbox') &&
                                        !isEmptyInput('sandbox') &&
                                        !isValidInput('sandbox')
                                    "
                                >
                                    <chi-icon icon="circle-warning" data-cy="cy-error-text-sandbox"></chi-icon>
                                    Invalid syntax: start with {{ http_string }} or {{ https_string }}
                                </div>
                            </div>
                            <chi-icon
                                v-if="showSuccess('sandbox')"
                                class="-ml--1"
                                icon="check"
                                color="success"
                                size="sm--3"
                                data-cy="cy-check-text-sandbox"
                            ></chi-icon>
                        </div>
                    </div>
                    <div class="chi-grid -ml--4 -mb--2">
                        <div class="-mt--1 display_flex_50 -pr--4">
                            <label class="-mt--1 -ml--4 -mr--2 -text--semi-bold"> Prod </label>
                            <div class="chi-form__item -w--100 -ml--1">
                                <input
                                    type="text"
                                    class="chi-input"
                                    id="textEndpointp"
                                    data-cy="cy-text-endpointp"
                                    disabled="true"
                                    v-model="endPointStrProd"
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div v-if="showProxyAlert" class="chi-grid" id="proxyAlert">
                <div class="chi-col -w--12 -ml--4 -mt--2 -mr--4 -mb--1">
                    <div data-cy="cy-proxy-save-alert">
                        <AlertComponent :alertObject="alertObject" @dismissAlert="alertCloseclicked()" size="sm" />
                    </div>
                </div>
            </div>
            <div class="chi-divider -ml--4 -my--1 -mr--4"></div>
            <div class="chi-grid -mb--4">
                <div class="chi-col -ml--4 -my--2 -mr--4">
                    <div style="float: right">
                        <chi-button class="-mr--1" data-cy="cy-button-cancel" @chiClick="cancelClick()"
                            >Cancel</chi-button
                        >
                        <chi-button color="primary" data-cy="cy-button-submit" @chiClick="submitClick()"
                            >Migrate</chi-button
                        >
                    </div>
                </div>
            </div>
        </div>
        <Footer />
    </div>
</template>
<script lang="ts">
import Footer from '@/modules/common/_components/Footer.vue';
import { Component, Vue } from 'vue-property-decorator';
import {
    HTTP_STRING,
    HTTPS_STRING,
    T_env,
    ApiProxyMigration,
    ApiProxyMigrationResponse,
} from '@/modules/exchange/_constants/proxy';
import Loader from '@/modules/common/_components/Loader.vue';
import AlertComponent from '@/modules/common/_components/AlertComponent.vue';
import { Alert } from '@/models/alert';
import { ALERTMSG } from '@/modules/exchange/_constants/messages';
import { ALERT_DISPLAY_TIME } from '@/utils/constants';
import { Validate } from '@/utils/validate';
import { apiLibraryApi } from '../_api/apiLibrary';
import { Environments } from '@/utils/entities/environments';
@Component({
    components: {
        AlertComponent,
        Loader,
        Footer,
    },
})
export default class Proxy extends Vue {
    public proxies: any[] = [];
    public endPointStrDev1 = '';
    public endPointStrDev2 = '';
    public endPointStrDev3 = '';
    public endPointStrDev4 = '';
    public endPointStrTest1 = '';
    public endPointStrTest2 = '';
    public endPointStrTest3 = '';
    public endPointStrTest4 = '';
    public endPointStrProd = '';
    public endPointStrMock = '';
    public endPointStrSandBox = '';
    availableEnvs: any = [];
    selectedIndex = 0;
    isDataLoading = true;
    isDataMigrating = false;
    envArray = ['Dev1', 'Dev2', 'Dev3', 'Dev4', 'Test1', 'Test2', 'Test3', 'Test4', 'Prod', 'Sandbox', 'Mock'];
    http_string = HTTP_STRING;
    https_string = HTTPS_STRING;
    alertObject!: Alert;
    alert: any;
    alertMessage: any;
    showProxyAlert = false;
    resourceGuid = '';

    mounted() {
        this.loadParameters();
        this.loadProxies();
        this.checkAlert();
    }

    selectedEnv(value) {
        this.selectedIndex = this.proxies.findIndex((x) => x.environment == value);
    }

    loadParameters(): void {
        this.resourceGuid = this.$route.params.ID;
        this.alert = this.$route.params.alert ? this.$route.params.alert : undefined;
        this.alertMessage = this.$route.params.message ? this.$route.params.message : undefined;
    }

    loadProxies(): void {
        const selId: any = { params: { resourceGuid: this.resourceGuid } };
        apiLibraryApi.getApiEnvironments(selId).then((response: any) => {
            this.proxies = response.data;
            this.availableEnvs = this.proxies.map((x) => x.environment);
            this.proxies.forEach((p) => {
                this.setEndpointByEnv(p.environment);
            });

            this.isDataLoading = false;
        });
    }

    checkAlert(): void {
        if (this.alert) {
            this.showAlert(this.alert, this.alertMessage, this.alert === 'success');
        }
    }

    showAlert(alert: string, message: string, isAutoClosed: boolean): void {
        this.showProxyAlert = true;

        let alertConfig;
        if (alert === 'success') {
            alertConfig = { color: 'success', icon: 'circle-check' };
        } else {
            if (message === ALERTMSG.failureAPIProxyMigrationIncorrectSyntax) {
                alertConfig = { color: 'danger', icon: 'circle-x' };
            } else if (message === ALERTMSG.failureAPIProxyMigrationNoEndpoints) {
                alertConfig = { color: 'danger', icon: 'circle-x' };
            } else {
                message += ALERTMSG.failureAPIProxyMigrationContact;
                alertConfig = { color: 'danger', icon: 'circle-x' };
            }
        }
        this.alertObject = new Alert(message, alertConfig);
        if (isAutoClosed) {
            setTimeout(() => {
                this.showProxyAlert = false;
            }, ALERT_DISPLAY_TIME);
        }
    }

    checkIcon(env): string {
        const checkEnv = this.checkEnvExist(env);
        if (checkEnv.length) {
            return 'circle-check';
        } else {
            return 'minus';
        }
    }
    checkColor(env) {
        const checkEnv = this.checkEnvExist(env);
        if (checkEnv.length) {
            return 'success';
        } else {
            return 'grey';
        }
    }

    getResourceName(): string {
        return this.proxies[this.selectedIndex].resourceName;
    }

    getEnvironment(): string {
        return this.proxies[this.selectedIndex].environment;
    }

    getEndPoint(): string {
        return this.proxies[this.selectedIndex].endPointUrl;
    }

    checkEnvExist(env): any[] {
        return this.proxies.filter((proxy) => proxy.environment === env.toLowerCase().trim());
    }

    getValueFromProxy(sEnv: string): string {
        return this.proxies
            .filter((proxy) => proxy.environment === sEnv.toLowerCase().trim())
            .map((obj) => obj.endPointUrl)[0];
    }

    setEndpointByEnv(env: T_env): void {
        const valueFromProxy = this.getValueFromProxy(env);
        switch (env) {
            case 'dev1':
                this.endPointStrDev1 = valueFromProxy;
                break;
            case 'dev2':
                this.endPointStrDev2 = valueFromProxy;
                break;
            case 'dev3':
                this.endPointStrDev3 = valueFromProxy;
                break;
            case 'dev4':
                this.endPointStrDev4 = valueFromProxy;
                break;
            case 'test1':
                this.endPointStrTest1 = valueFromProxy;
                break;
            case 'test2':
                this.endPointStrTest2 = valueFromProxy;
                break;
            case 'test3':
                this.endPointStrTest3 = valueFromProxy;
                break;
            case 'test4':
                this.endPointStrTest4 = valueFromProxy;
                break;
            case 'mock':
                this.endPointStrMock = valueFromProxy;
                break;
            case 'sandbox':
                this.endPointStrSandBox = valueFromProxy;
                break;
            case 'prod':
                this.endPointStrProd = valueFromProxy;
                break;
        }
    }
    isEmptyInput(env: T_env): boolean {
        switch (env) {
            case 'dev1':
                return this.endPointStrDev1?.length === 0;
            case 'dev2':
                return this.endPointStrDev2?.length === 0;
            case 'dev3':
                return this.endPointStrDev3?.length === 0;
            case 'dev4':
                return this.endPointStrDev4?.length === 0;
            case 'test1':
                return this.endPointStrTest1?.length === 0;
            case 'test2':
                return this.endPointStrTest2?.length === 0;
            case 'test3':
                return this.endPointStrTest3?.length === 0;
            case 'test4':
                return this.endPointStrTest4?.length === 0;
            case 'mock':
                return this.endPointStrMock?.length === 0;
            case 'sandbox':
                return this.endPointStrSandBox?.length === 0;
            case 'prod':
                return this.endPointStrProd?.length === 0;
        }
    }

    isValidInput(env: T_env): boolean {
        switch (env) {
            case 'dev1':
                return Validate.validateHostname(this.endPointStrDev1);
            case 'dev2':
                return Validate.validateHostname(this.endPointStrDev2);
            case 'dev3':
                return Validate.validateHostname(this.endPointStrDev3);
            case 'dev4':
                return Validate.validateHostname(this.endPointStrDev4);
            case 'test1':
                return Validate.validateHostname(this.endPointStrTest1);
            case 'test2':
                return Validate.validateHostname(this.endPointStrTest2);
            case 'test3':
                return Validate.validateHostname(this.endPointStrTest3);
            case 'test4':
                return Validate.validateHostname(this.endPointStrTest4);
            case 'mock':
                return Validate.validateHostname(this.endPointStrMock);
            case 'sandbox':
                return Validate.validateHostname(this.endPointStrSandBox);
            case 'prod':
                return Validate.validateHostname(this.endPointStrProd);
        }
    }

    isDisabledInput(env: T_env): boolean {
        return this.proxies.findIndex((p) => p.environment === env) !== -1;
    }

    submitValidation(): boolean {
        return (
            this.submitValidationByEnv('dev1') &&
            this.submitValidationByEnv('dev3') &&
            this.submitValidationByEnv('dev2') &&
            this.submitValidationByEnv('dev4') &&
            this.submitValidationByEnv('test1') &&
            this.submitValidationByEnv('test2') &&
            this.submitValidationByEnv('test3') &&
            this.submitValidationByEnv('test4') &&
            this.submitValidationByEnv('mock') &&
            this.submitValidationByEnv('sandbox') &&
            this.submitValidationByEnv('prod') &&
            this.showSuccessForAtLeastOne()
        );
    }
    private showSuccessForAtLeastOne(): boolean {
        return (
            this.showSuccess('dev1') ||
            this.showSuccess('dev3') ||
            this.showSuccess('dev2') ||
            this.showSuccess('dev4') ||
            this.showSuccess('test1') ||
            this.showSuccess('test2') ||
            this.showSuccess('test3') ||
            this.showSuccess('test4') ||
            this.showSuccess('mock') ||
            this.showSuccess('sandbox') ||
            this.showSuccess('prod')
        );
    }

    private showAtLeastOnePopulated(): boolean {
        return (
            this.showPopulated('dev1') ||
            this.showPopulated('dev3') ||
            this.showPopulated('dev2') ||
            this.showPopulated('dev4') ||
            this.showPopulated('test1') ||
            this.showPopulated('test2') ||
            this.showPopulated('test3') ||
            this.showPopulated('test4') ||
            this.showPopulated('mock') ||
            this.showPopulated('sandbox') ||
            this.showPopulated('prod')
        );
    }

    showPopulated(env: T_env): boolean {
        return !this.isDisabledInput(env) && !this.isEmptyInput(env);
    }

    showSuccess(env: T_env): boolean {
        return !this.isDisabledInput(env) && this.isValidInput(env);
    }

    private submitValidationByEnv(env: T_env): boolean {
        return (
            this.isDisabledInput(env) ||
            (!this.isDisabledInput(env) && this.isValidInput(env)) ||
            (!this.isDisabledInput(env) && this.isEmptyInput(env))
        );
    }

    cancelClick() {
        this.$router.push('/exchange');
    }

    getApiProxyMigration(): ApiProxyMigration {
        return {
            mirrorEnvironment: this.getEnvironment(),
            dev1EndpointHostname: this.showSuccess('dev1') ? this.endPointStrDev1 : '',
            dev2EndpointHostname: this.showSuccess('dev2') ? this.endPointStrDev2 : '',
            dev3EndpointHostname: this.showSuccess('dev3') ? this.endPointStrDev3 : '',
            dev4EndpointHostname: this.showSuccess('dev4') ? this.endPointStrDev4 : '',
            test1EndpointHostname: this.showSuccess('test1') ? this.endPointStrTest1 : '',
            test2EndpointHostname: this.showSuccess('test2') ? this.endPointStrTest2 : '',
            test3EndpointHostname: this.showSuccess('test3') ? this.endPointStrTest3 : '',
            test4EndpointHostname: this.showSuccess('test4') ? this.endPointStrTest4 : '',
            mockEndpointHostname: this.showSuccess('mock') ? this.endPointStrMock : '',
            sandboxEndpointHostname: this.showSuccess('sandbox') ? this.endPointStrSandBox : '',
            guid: this.resourceGuid,
            requestorEmail: this.$store.state.userContext.email,
        };
    }

    onSubmitMigrateApiProxies(alert: 'success' | 'error', message: string) {
        const params: Record<string, string> = {
            ID: this.resourceGuid,
            alert: alert,
            message: message,
        };
        this.$router.replace({ name: 'migrate-params', params: params });
        setTimeout(() => {
            this.$router.go(0);
        }, 0);
    }

    async submitClick() {
        this.showProxyAlert = false;
        if (!this.showAtLeastOnePopulated()) {
            this.showAlert('error', ALERTMSG.failureAPIProxyMigrationNoEndpoints, false);
        } else if (!this.submitValidation()) {
            this.showAlert('error', ALERTMSG.failureAPIProxyMigrationIncorrectSyntax, false);
        } else {
            this.isDataMigrating = true;
            const apiProxyMigration: ApiProxyMigration = this.getApiProxyMigration();
            console.log('> apiProxyMigration: ', apiProxyMigration);
            await apiLibraryApi
                .submitMigrateApiProxies(apiProxyMigration)
                .then((resp) => {
                    this.onSubmitMigrateApiProxies(
                        'success',
                        resp?.data ? this.setAlertMessage(resp?.data) : ALERTMSG.successAPIProxyMigration
                    );
                })
                .catch((err) => {
                    let errorMessage;
                    try {
                        errorMessage = JSON.parse(err.message);
                    } catch (e) {
                        errorMessage = err.message;
                    } finally {
                        errorMessage = errorMessage?.routingExpression
                            ? this.setAlertMessage(errorMessage)
                            : ALERTMSG.failureAPIProxyMigration;
                        this.onSubmitMigrateApiProxies('error', errorMessage);
                    }
                });
        }
    }

    alertCloseclicked() {
        this.showProxyAlert = false;
    }

    private setAlertMessage(resp: ApiProxyMigrationResponse): string {
        let message = resp.routingExpression;
        if (resp.migratedEnv?.length > 0) {
            message += ALERTMSG.successAPIProxyMigrationOk;
            message += Environments.parseListOfEnvironmentsToString(resp.migratedEnv);
            if (resp.notMigratedEnv?.length > 0) {
                message += ALERTMSG.failureAPIProxyMigrationNotOk;
                message += Environments.parseListOfEnvironmentsToString(resp.notMigratedEnv);
            }
        } else {
            message += ALERTMSG.failureAPIProxyMigrationNotOk2;
            message += Environments.parseListOfEnvironmentsToString(resp.notMigratedEnv);
        }
        return message;
    }
}
</script>
<style scoped>
.chi-button {
    float: right;
}
#sections {
    margin-left: -3.5%;
}
#sectionContent {
    height: 80vh;
    overflow-y: scroll;
    overflow-x: hidden !important;
}
.chi h2 {
    margin: 0rem 0;
}
.chi .chi-input {
    height: 2.5rem;
}
.chi-w-background-color {
    background-color: #ffffff;
}
.chi-lb-background-color {
    background-color: #f5f8fc;
}
.chi-main {
    margin-top: 0 !important;
}
.chi-card__title {
    font-size: 1rem !important;
    font-weight: 400;
}
.display_flex_50 {
    display: flex;
    flex: 0 50%;
}
</style>
