<template>
    <div>
        <div id="pageWrapper" v-bind:class="{ 'wrapper-parent': !showApiClientPage }">
            <div class="-w--100 min-height">
                <div class="chi-card">
                    <div class="chi-card__header">
                        <div class="chi-card__title" data-cy="cy-display_header">Products</div>
                    </div>
                </div>
                <div v-if="isAlert" class="-mb--2">
                    <AlertComponent :alertObject="homeAlert" />
                </div>
                <ChiDataTable data-cy="cy-product-chi-data-table" :data="tableData" :config="config">
                    <template #toolbar>
                        <ChiDataTableToolbar>
                            <template v-slot:start>
                                <ChiSearchInput
                                    @chiInput="(e) => search(e)"
                                    @chiClean="() => search('')"
                                    :value="getSearchedInput()"
                                    placeholder="Search"
                                    :dataTableSearch="true"
                                    data-cy="cy-product__search-input"
                                    class="input-width input-left-margin"
                                />
                            </template>
                        </ChiDataTableToolbar>
                    </template>
                    <template v-if="envFeatureFlag" #displayName="payload">
                        {{ payload.displayName }}
                    </template>
                    <template v-else #displayName="payload">
                        {{ payload.displayName }}
                    </template>
                    <template #description="payload">
                        <p style="white-space: pre-line">
                            <strong>Description</strong>
                            <br />
                            {{ payload.description }}
                        </p>
                    </template>

                    <template #createdBy="payload">
                        {{ payload.createdBy }}
                    </template>

                    <template #createdAt="payload">
                        {{ getCreatedAt(payload.createdAt) }}
                    </template>

                    <template #lastModifiedBy="payload">
                        {{ payload.lastModifiedBy }}
                    </template>

                    <template #lastModifiedAt="payload">
                        {{ getLastModifiedAt(payload.lastModifiedAt) }}
                    </template>
                </ChiDataTable>
                <Footer v-if="!isExchange()" />
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import {
    PRODUCTS_DATATABLE_COLUMNS,
    PRODUCTS_DATATABLE_CONFIG,
    PRODUCTS_DATATABLE_TEMPLATES,
    MONTHS,
} from '@/modules/exchange/_constants/productsTable';
import { DataTableUtils } from '@/utils/dataTableUtils';
import { SearchUtils } from '@/utils/searchUtils';
import { DataTableConfig, DataTableData, DataTableRow, FilterType } from '@/models/chiTableTypes';
import { getModule } from 'vuex-module-decorators';
import { ALERT_DISPLAY_TIME } from '@/utils/constants';
import { Alert } from '@/models/alert';
import AlertComponent from '@/modules/common/_components/AlertComponent.vue';
import Footer from '@/modules/common/_components/Footer.vue';
import store, { STORE_KEY } from '@/modules/exchange/_store';

@Component({
    data() {
        return {
            PRODUCTS_DATATABLE_TEMPLATES,
            PRODUCTS_DATATABLE_COLUMNS,
            DataTableUtils,
        };
    },
    components: {
        AlertComponent,
        Footer,
    },
})
export default class Products extends Vue {
    _homeStore!: any;
    backgroundImage = require('@/assets/desktop-hero-image.jpg');
    page: string = 'Home';
    config: DataTableConfig = PRODUCTS_DATATABLE_CONFIG;
    currentFilters: FilterType[] = [];
    searchInput: string = '';
    searchedValue: string = '';
    chiInstance = (window as Window).chi;
    isAlert = false;
    wrapper: HTMLElement | null = null;
    showApiClientPage = false;
    successAlertData: string = '';
    homeAlert!: Alert;
    envFeatureFlag: any = '';

    created() {
        this.envFeatureFlag = this.$store.state.userContext.flags.apienable_apihub_menu_active;
        this.config.defaultSort = {
            key: 'displayName',
            sortBy: 'displayName',
            direction: 'ascending',
        };
        const isModuleRegistered = Object.keys(this.$store.state).includes(STORE_KEY);
        if (!isModuleRegistered) {
            this.$store.registerModule(STORE_KEY, store);
        }
        this._homeStore = getModule(store, this.$store);
    }
    beforeMount() {
        if (this._homeStore.successResponse.deleteSuccess) {
            this.isAlert = true;
            this.homeAlert = new Alert(this._homeStore.successResponse.deleteSuccess, {
                tag: 'cy-api__deletion-success__alert',
            });
        }
        this.config.defaultSort = {
            key: 'displayName',
            sortBy: 'displayName',
            direction: 'ascending',
        };
    }

    mounted() {
        this.isExchange();
        this._homeStore.loadProducts();
    }

    isExchange() {
        let exchangeCheck = this.$route.name === 'exchange';
        if (exchangeCheck) {
            this.showApiClientPage = true;
        }
        return exchangeCheck;
    }

    get tableData(): DataTableData {
        return {
            head: PRODUCTS_DATATABLE_COLUMNS,
            body: this.filteredTableBody,
        };
    }

    filtersChange(filters: FilterType[] = []): void {
        this.currentFilters = [...filters];
    }

    search(searchInputValue: string): void {
        this.searchedValue = searchInputValue;
        this.searchInput = searchInputValue;
    }

    getSearchedInput(): string {
        this.searchInput = !!this.searchedValue ? this.searchedValue : '';
        return this.searchInput;
    }

    getCreatedAt(createdAt: string): string {
        const expDate = new Date(createdAt);
        return `${expDate.getDate()} ${MONTHS[expDate.getMonth()]} ${expDate.getFullYear()}`;
    }

    getLastModifiedAt(lastModifiedAt: string): string {
        const expDate = new Date(lastModifiedAt);
        return `${expDate.getDate()} ${MONTHS[expDate.getMonth()]} ${expDate.getFullYear()}`;
    }

    get filteredTableBody(): DataTableRow[] {
        const tableDataBody = DataTableUtils.getProductsTableBody(
            this._homeStore.Products,
            PRODUCTS_DATATABLE_TEMPLATES,
            this.currentFilters
        );
        let rows: DataTableRow[] = [...tableDataBody];
        const searchValue = this.searchInput.trim().toLowerCase();
        if (rows.length > 0 && !!this.searchInput) {
            rows = rows.filter((__: any, index: number) => {
                const searchValueString = SearchUtils.formSearchValueString(tableDataBody);
                return searchValueString[index]?.indexOf(searchValue) > -1;
            });
        }
        return rows;
    }
    @Watch('isAlert')
    hideAlertOnTimeOut() {
        setTimeout(() => (this.isAlert = false), ALERT_DISPLAY_TIME);
    }
}
</script>

<style lang="scss" scoped>
.wrapper-parent {
    margin: 0 5rem;
    padding: 2rem 0;
}
.wrapper-child {
    margin: 0 2rem;
}
.min-height {
    min-height: 320px;
}
#button-header {
    padding: 0px 0px;
}
#create-api-button {
    float: right;
}
.searchbar-tabledata {
    background-color: white;
}
#alertStyle {
    width: 100%;
}
.input-width {
    width: 408px;
}
.input-left-margin {
    margin-left: -8px;
}
</style>
