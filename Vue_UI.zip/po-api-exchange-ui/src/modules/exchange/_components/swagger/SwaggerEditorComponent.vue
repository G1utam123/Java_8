<template>
    <div class="main-content">
        <div class="chi-grid -no-gutter">
            <div class="chi-col -w--11 -mt--2 -pl--6" v-if="failureAlert">
                <AlertComponent :alertObject="alertObject" @dismissAlert="alertCloseclicked()" />
            </div>
            <div class="" style="padding-top: 1%">
                <label class="chi-label" required for="title" data-cy="cy-swagger-title__label"
                    >Title
                    <abbr class="chi-label__required" title="Required field">*</abbr>
                </label>
            </div>
            <div class="chi-col -w--8" style="padding-top: 0.7%">
                <div class="chi-form__item -ml--1 -mr--3">
                    <input
                        type="text"
                        class="chi-input"
                        id="title"
                        maxlength="40"
                        v-model="title"
                        data-cy="cy-swagger-title__input"
                    />
                    <div
                        class="chi-label -status -danger"
                        v-if="isSwaggerTitle"
                        data-cy="cy-general-error_swagger_title"
                    >
                        Please provide a title
                    </div>
                </div>
            </div>
            <div class="chi-col -mr--4">
                <div class="chi-grid -no-gutter">
                    <div class="chi-col">
                        <div style="float: right">
                            <chi-button
                                color="primary"
                                class="-my--1 -ml--1 -mr--2"
                                @click="onUploadFile"
                                data-cy="cy-swagger-save__button"
                                >Save</chi-button
                            >
                            <router-link
                                :to="{
                                    name: 'EditAPIDocumentation',
                                    params: { page: 'edit', alert: '', alertmsg: '' },
                                }"
                            >
                                <chi-button class="-my--1" data-cy="cy-cancel_button">Cancel</chi-button>
                            </router-link>
                        </div>
                    </div>
                </div>
            </div>
            <input type="hidden" v-model="newYaml" />
        </div>
        <br />
        <div class="swagger" data-cy="cy-swagger_div" id="swagger"></div>
        <br />
    </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import 'swagger-ui/dist/swagger-ui.css';
import SwaggerEditor from 'swagger-editor';
import 'swagger-editor/dist/swagger-editor.css';
import { Compare } from '@/utils/compare';
import store, { STORE_KEY } from '@/modules/exchange/_store';
import { getModule } from 'vuex-module-decorators';
import { Alert } from '@/models/alert';
import ExchangeModule from '@/modules/exchange/ExchangeModule.vue';
@Component({
    components: {
        ExchangeModule,
    },
})
export default class SwaggerEditorComponent extends Vue {
    exchangeModule: ExchangeModule = new ExchangeModule();
    editor: SwaggerEditor;
    yaml: string = '';
    newYaml: string = '';
    id: any;
    content: any;
    selectedFile = '';
    progress: number = 0;
    fileName: any;
    yamlURL: any;
    title: any = '';
    apiSection: any;
    isSwaggerTitle: boolean = false;
    failureAlert: boolean = false;
    failureAlertMsg: any = '';
    private _homeStore!: any;
    alertObject!: Alert;
    created() {
        const isModuleRegistered = Object.keys(this.$store.state).includes(STORE_KEY);
        if (!isModuleRegistered) {
            this.$store.registerModule(STORE_KEY, store);
        }
        this._homeStore = getModule(store, this.$store);
    }
    mounted() {
        window.scrollTo();
        this.apiSection = this.$route.params.section;
        if (this.apiSection) {
            this.id = this.apiSection.id;
            this.title = this.apiSection.apiName;
        }
        this.progress = 0;
        this.editor = this.getSwaggerEditor();
    }

    getSwaggerEditor(): SwaggerEditor {
        let self = this;
        const SpecUpdateListenerPlugin = () => {
            return {
                statePlugins: {
                    spec: {
                        wrapActions: {
                            updateSpec: (oriAction) => (args) => {
                                self.yaml = this.newYaml;

                                return oriAction(args);
                            },
                        },
                    },
                },
            };
        };

        return SwaggerEditor({
            dom_id: '#swagger',
            layout: 'EditorLayout',
            plugins: [SpecUpdateListenerPlugin],
        });
    }

    async onUploadFile() {
        this.isSwaggerTitle = Compare.isElementEmpty(this.title);
        if (!this.isSwaggerTitle) {
            this.progress = 0;
            this.content = window.localStorage.getItem('swagger-editor-content');
            this.exchangeModule.checkAddTextSuccuess(this, 'swagger');
        }
    }
    alertCloseclicked() {
        this.failureAlert = false;
    }
}
</script>

<style lang="scss">
.main-content {
    margin: 0% 0% 0% 3%;
    width: 96%;
}

#swagger-editor {
    font-size: 1.3em;
}
.container {
    max-width: 100%;
    margin-left: auto;
    margin-right: auto;
}

#editor-wrapper {
    border: 1em solid #000;
    border: none;
}

.Pane2 {
    overflow-y: scroll;
}

.chi-grid {
    margin: 0;
}

.ace_scrollbar-v {
    overflow-y: scroll !important;
}
</style>
