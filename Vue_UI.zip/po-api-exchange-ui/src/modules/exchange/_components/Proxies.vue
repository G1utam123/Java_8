<template>
    <div class="chi-card" data-cy="cy-parent-router__element">
        <div class="chi-card__header">
            <div class="chi-card__title" data-cy="cy-display_header">Proxies</div>
        </div>
        <div class="chi-card__header chi-note" v-if="tableData.body.length > 0"></div>
        <chi-spinner v-if="dataSearching" color="primary" backdrop="inverse"></chi-spinner>
        <Loader v-if="dataLoading" />
        <div v-else class="chi-card">
            <template>
                <!-- Vue component -->
                <ChiDataTable
                    data-cy="cy-api-chi-data-table"
                    :config="config"
                    :data="tableData"
                    v-if="!dataLoading"
                    @chiRowSelected="(e) => rowSelected(e)"
                    @chiRowDeselected="(e) => rowSelected(e)"
                >
                    <template #toolbar>
                        <ChiDataTableToolbar>
                            <template v-slot:start>
                                <ChiSearchInput
                                    @chiSearch="(e) => search(e)"
                                    @chiClean="() => search('')"
                                    placeholder="Search"
                                    :dataTableSearch="true"
                                    data-cy="cy-api__search-input"
                                    class="input-width input-left-margin"
                                ></ChiSearchInput>
                                <div class="chi-divider -vertical"></div>
                                <ChiDataTableFilters
                                    :portal="true"
                                    :filtersData="toolbarFilters"
                                    @chiFiltersChange="(e) => filtersChange(e)"
                                    data-cy="cy-api__filter"
                                />
                            </template>
                        </ChiDataTableToolbar>
                    </template>
                    <template #resourceTaxonomy="payload">
                        {{ payload.resourceTaxonomy }}
                    </template>

                    <template #resourceName="payload">
                        {{ payload.resourceName }}
                    </template>

                    <template #version="payload">
                        {{ payload.version }}
                    </template>

                    <template #owningApplicationId="payload">
                        <a
                            @click="openCmsViewerUrl(payload.owningApplicationId)"
                            class="chi-link"
                            rel="noreferrer noopener"
                            data-cy="cy-api-chi-data-table-owningApplicationId"
                            >{{ payload.owningApplicationId }}</a
                        >
                    </template>

                    <template #routingExpression="payload">
                        {{ payload.routingExpression }}
                    </template>

                    <template #actions="payload">
                        <router-link
                            v-if="payload.allowMigration"
                            class="link"
                            :to="{
                                name: 'migrate',
                                params: { ID: payload.id },
                            }"
                            >Migrate</router-link
                        >
                    </template>
                </ChiDataTable>
            </template>
        </div>
        <div style="float: right">
            <chi-button
                color="primary"
                class="-mt--1"
                style="float: right"
                data-cy="cy-api-proxy_save_button"
                @click="saveApiproxies()"
                v-if="!isExchange()"
                >Save</chi-button
            >
        </div>
    </div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import {
    PROXIES_TOOLBAR_FILTERS,
    PROXIES_DATATABLE_COLUMNS,
    PROXIES_DATATABLE_CONFIG,
    PROXIES_DATATABLE_TEMPLATES,
    Proxy,
} from '@/modules/exchange/_constants/proxiesTable';

import { DataTableConfig, DataTableRow, FilterType } from '@/models/chiTableTypes';
import { SearchUtils } from '@/utils/searchUtils';
import Loader from '@/modules/common/_components/Loader.vue';
import store, { STORE_KEY } from '@/modules/exchange/_store';
import { getModule } from 'vuex-module-decorators';
import { DataTableUtils } from '@/utils/dataTableUtils';
import { ALERTMSG } from '@/modules/exchange/_constants/messages';
@Component({
    data() {
        return {
            PROXIES_DATATABLE_TEMPLATES,
            PROXIES_DATATABLE_COLUMNS,
            DataTableUtils,
        };
    },
    components: {
        Loader,
    },
})
export default class Proxies extends Vue {
    @Prop() saveApiId: any;
    @Prop() InventoryEnv: any;
    toolbarFilters: any = PROXIES_TOOLBAR_FILTERS;
    config: DataTableConfig = PROXIES_DATATABLE_CONFIG;
    displayNote = ALERTMSG.proxiesNote;
    hasCapabilities = false;
    dataLoading = true;
    dataSearching = false;
    proxies: Proxy[] = [];
    private _homeStore!: any;
    private searchInput: string = '';
    private searchedValue: string = '';
    private saveProxyData: any = {};
    private proxyArrayFinal: any[] = [];
    private currentEnv: string = 'dev1';

    created() {
        const isModuleRegistered = Object.keys(this.$store.state).includes(STORE_KEY);
        if (!isModuleRegistered) {
            this.$store.registerModule(STORE_KEY, store);
        }
        this._homeStore = getModule(store, this.$store);

        this.config.defaultSort = {
            key: 'resourceTaxonomy',
            sortBy: 'resourceTaxonomy',
            direction: 'ascending',
        };
    }

    mounted() {
        this.loadProxies();
    }

    get tableData(): any {
        return {
            head: PROXIES_DATATABLE_COLUMNS,
            body: this.filteredTableBody,
        };
    }

    filtersChange(filters: FilterType[] = []): void {
        this.dataSearching = true;
        this.currentEnv = filters[0].value;
        localStorage.setItem('InvEnv', this.currentEnv);
        this.loadProxies();
    }

    search(searchInputValue: string): void {
        this.dataSearching = true;
        setTimeout(() => {
            this.searchedValue = searchInputValue;
            this.searchInput = searchInputValue;
        }, 1000);
    }

    loadProxies(): void {
        let options: any = { params: { env: this.currentEnv } };
        try {
            this._homeStore.loadProxiesDetails(options);
        } catch (err) {
            this.config.noResultsMessage = 'Failed to load proxies from ' + this.currentEnv + '.';
        } finally {
            this.proxies = this._homeStore.ProxiesDetails;
            this.dataLoading = false;
            this.dataSearching = false;
        }
    }
    get filteredTableBody(): DataTableRow[] {
        const tableDataBody = DataTableUtils.getProxyTableBody(
            this._homeStore.ProxiesDetails,
            PROXIES_DATATABLE_TEMPLATES,
            this.toolbarFilters
        );
        let rows: DataTableRow[] = [...tableDataBody];
        const searchValue = this.searchInput.trim().toLowerCase();
        if (rows.length > 0 && !!this.searchInput) {
            rows = rows.filter((__: any, index: number) => {
                const searchValueString = SearchUtils.formSearchValueString(tableDataBody);
                return searchValueString[index]?.indexOf(searchValue) > -1;
            });
        }
        this.dataLoading = false;
        this.dataSearching = false;
        this.hasCapabilities = rows.length > 0 && rows.findIndex((p) => p.allowMigration) > -1;
        return rows;
    }

    getSearchedInput(): string {
        this.searchInput = !!this.searchedValue ? this.searchedValue : '';
        return this.searchInput;
    }
    rowSelected(selectedRow: DataTableRow): void {
        if (selectedRow.selected) {
            this.proxyArrayFinal.push({ apiid: this.saveApiId, resourceGuuid: selectedRow.id });
        } else {
            this.proxyArrayFinal.forEach(() => {
                const findIndex = this.proxyArrayFinal.findIndex((proxy) => proxy.resourceGuuid === selectedRow.id);
                if (findIndex !== -1) {
                    this.proxyArrayFinal.splice(findIndex, 1);
                }
            });
        }
    }
    async saveApiproxies() {
        try {
            if (this.proxyArrayFinal.length != 0) {
                this.saveProxyData = { proxyResponse: this.proxyArrayFinal };
                await this._homeStore.saveProxySection(this.saveProxyData).then(() => {
                    this.$emit('proxydataSave', this._homeStore.successResponse.proxysaveSuccess);
                });
            }
        } catch {
            this.$emit('proxydataSave', this._homeStore.errorDetails.proxysaveError);
        }
    }
    isExchange() {
        this.config.selectable = false;
        let exchangeCheck = this.$route.name === 'exchange';
        if (!exchangeCheck) {
            this.config.selectable = true;
        }
        return exchangeCheck;
    }
    openCmsViewerUrl(id: string) {
        window.open(Vue.prototype.$config.cms_viewer_url + '/index.html?s=' + id, '_blank');
    }
}
</script>
<style lang="scss" scoped>
.input-width {
    width: 408px;
}
.input-left-margin {
    margin-left: -8px;
}
.chi-note {
    padding: 0 0 0.2rem 0;
}
</style>
