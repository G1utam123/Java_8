import Vue from 'vue';
import { Module, VuexModule, Action, Mutation, MutationAction } from 'vuex-module-decorators';
import { Store } from 'vuex';
import { homeApi } from '@/modules/exchange/_api/home';
import { OverviewData } from '@/models/chiTableTypes';
export const STORE_KEY = '$_api_exchange_home';

@Module({
    namespaced: true,
    name: STORE_KEY,
    store: Vue.prototype.$store,
})
export default class HomeStore extends VuexModule {
    static register($store: Store<any>) {
        if (!$store.state[STORE_KEY]) {
            $store.registerModule(STORE_KEY, this);
        }
    }
    static unregister($store: Store<any>) {
        if ($store.state[STORE_KEY]) {
            $store.unregisterModule(STORE_KEY);
        }
    }

    proxiesArr: any = [];
    apiProxiesArr: any = [];
    apiArr: any = [];
    errorDetails: any = {};
    successResponse: any = {};
    documentData: any = {};
    apiData: any = {};
    apiOverview: OverviewData = new OverviewData();
    loader: boolean = false;
    proxyIndex: number = 0;
    get Products(): any {
        return this.apiArr;
    }

    get ProxiesDetails(): any {
        return this.proxiesArr;
    }

    //#region Actions
    @Action
    async loadProducts(): Promise<void> {
        let apiArr: any = [];
        await homeApi.loadProducts().then((response: any) => {
            apiArr = response.data.apiProduct;
        });
        this.context.commit('setProducts', apiArr);
    }

    @Action
    async loadProxiesDetails(options: any): Promise<void> {
        let proxiesArr: any = [];
        await homeApi
            .loadProxiesDetails(options)
            .then((response: any) => {
                proxiesArr = response.data;
            })
            .catch((err: any) => {
                console.error(err);
                proxiesArr = [];
            });
        this.context.commit('setProxiesDetails', proxiesArr);
    }

    @MutationAction
    async loadOverviewData(apiId: string) {
        const apiOverviewData: OverviewData = new OverviewData();
        const response: any = await homeApi.getApiData(apiId);
        apiOverviewData.documentations = [...response.data.documentations];
        apiOverviewData.proxies = [...response.data.proxies];
        return { apiOverview: apiOverviewData };
    }
    @Mutation
    setLoadingProp(payload: boolean) {
        this.loader = payload;
    }

    @Action
    async deleteApi(payload: { apiId: string; apiName: string }) {
        try {
            await homeApi.deleteApi(payload.apiId);
            this.setSuccessMessage({ deleteSuccess: `${payload.apiName} deleted successfully` });
        } catch (error) {
            const dataError = { deleteError: error };
            this.setErrorAlert(dataError);
        }
    }

    @Action
    async deleteDocuments(documentId: number) {
        try {
            await homeApi.deleteDocument(documentId);
            this.setSuccessMessage({ deleteSuccess: 'ok' });
        } catch (error) {
            const dataError = { deleteError: error };
            this.setErrorAlert(dataError);
        }
    }

    @Action
    async addApi(formData: any) {
        try {
            const response = await homeApi.addApi(formData);
            this.setSuccessMessage({ addSuccess: 'ok' });
            this.setApiData(response.data);
        } catch (error) {
            const dataError = { addError: error };
            this.setErrorAlert(dataError);
        }
    }

    @Action
    async addTextSection(payload: { data: any; type: string }) {
        try {
            if (payload.type == 'add') {
                await homeApi.addTextSection(payload.data);
            }

            this.setSuccessMessage({ addTextSuccess: 'ok' });
        } catch (error) {
            const dataError = { addTextError: error };
            this.setErrorAlert(dataError);
        }
    }

    @Action
    async saveProxySection(saveProxyData: any) {
        try {
            await homeApi.saveApiProxies(saveProxyData);
            this.setSuccessMessage({ proxysaveSuccess: 'ok' });
        } catch (error) {
            const dataError = { proxysaveError: error };
            this.setErrorAlert(dataError);
        }
    }
    @Action
    async getDocumentData(apiId: string) {
        try {
            const response = await homeApi.getDocuments(apiId);
            this.setDocumentData(response);
        } catch (error) {
            const dataError = { documentError: error };
            this.setErrorAlert(dataError);
        }
    }
    //#endregion

    //#region Mutation
    @Mutation
    updateProxyIndex(index: number) {
        this.proxyIndex = index;
    }

    @Mutation
    setProducts(apiArr: any[]) {
        this.apiArr = [...apiArr];
    }

    @Mutation
    setProxiesDetails(proxiesArr: any[]) {
        this.proxiesArr = [...proxiesArr];
    }

    @Mutation
    getApiProxiesDetails(apiProxiesArr: any[]) {
        this.apiProxiesArr = [...apiProxiesArr];
    }
    //#endregion

    //#region MutationActions
    @MutationAction
    async setDocumentData(response: any) {
        return { documentData: JSON.stringify(response.data) };
    }

    @MutationAction
    async setSuccessMessage(payload: any) {
        return { successResponse: payload };
    }

    @MutationAction
    async setErrorAlert(payload: any) {
        return { errorDetails: payload };
    }

    @MutationAction
    async setApiData(payload: any) {
        return { apiData: payload };
    }

    //#endregion
}
