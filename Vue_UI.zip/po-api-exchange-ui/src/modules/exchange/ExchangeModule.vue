<template>
    <AppLayout class="-pt--4">
        <template v-slot:exchange>
            <div class="chi-grid">
                <div class="chi-card -highlight -position--relative heroimage">
                    <div class="chi-card__content -position--absolute -pt--4 heroimagecontent">
                        <div class="-text--left -text--boldest -text--white -w--12" data-cy="cy-exchange_main">
                            Exchange
                        </div>
                        <p class="-text--left -text--h4 -w--12 -text--semi-bold -text--white -text--light">
                            Explore our inventory of internal and external Lumen APIs
                        </p>
                    </div>
                </div>
                <div class="chi-col -w-md--9 -w-sm--0 -w-lg--9 -w-xl--9 -w-xs--0"></div>
                <div
                    class="chi-col -mt--4 -text-xl--right -w-md--3 -w-sm--12 -w-lg--3 -w-xl--3 -w-xs--12"
                    v-if="envFeatureFlag"
                >
                    <router-link
                        v-if="isProxy"
                        class="link"
                        :to="{
                            name: 'proxy',
                        }"
                        ><chi-button
                            color="primary"
                            class="-lg -uppercase -px--1"
                            id="create-api-button"
                            data-cy="cy-create-new-proxy__button"
                            >CREATE NEW PROXY</chi-button
                        >
                    </router-link>

                    <router-link
                        v-else
                        :to="{
                            name: 'EditAPIDocumentation',
                            params: {
                                page: 'create',
                                alert: '',
                                alertmsg: '',
                            },
                        }"
                    >
                        <chi-button
                            color="primary"
                            class="-lg -uppercase -px--1"
                            id="create-api-button"
                            v-if="isProxy"
                            data-cy="cy-create-new-proxy__button"
                            >CREATE NEW PROXY</chi-button
                        >
                        <chi-button
                            color="primary"
                            class="-lg -uppercase -px--1"
                            id="create-api-button"
                            v-else
                            data-cy="cy-create-new-product__button"
                            >CREATE NEW PRODUCT</chi-button
                        >
                    </router-link>
                </div>
                <div class="chi-col -w-sm--12 -pt--1">
                    <ul class="chi-tabs -solid -lg -border" ref="tabs" role="tablist" aria-label="chi-tabs-horizontal">
                        <li class="-active">
                            <a
                                href="#proxies"
                                role="tab"
                                aria-selected="true"
                                aria-controls="proxies"
                                @click="toogleIsProxy(true)"
                                data-cy="cy-proxies_tab"
                                >Proxies</a
                            >
                        </li>
                        <li role="tab">
                            <a
                                href="#products"
                                aria-selected="false"
                                tabindex="-1"
                                aria-controls="products"
                                @click="toogleIsProxy(false)"
                                data-cy="cy-products_tab"
                                >Products</a
                            >
                        </li>
                    </ul>
                    <div class="chi-tabs-panel -py--6" id="products" role="tabpanel">
                        <Products />
                    </div>
                    <div class="chi-tabs-panel -active -py--6" id="proxies" role="tabpanel">
                        <Proxies />
                    </div>
                </div>
            </div>
        </template>
    </AppLayout>
</template>
<script lang="ts">
import { Alert } from '@/models/alert';
import { Section } from '@/models/section';
import { ALERTMSG } from '@/modules/exchange/_constants/messages';
import { UUID } from '@/utils/uuid';
import { Component, Vue } from 'vue-property-decorator';
import Products from './_components/Products.vue';
import Proxies from './_components/Proxies.vue';
import AppLayout from '@/modules/common/_components/AppLayout.vue';
declare const chi: any;

@Component({
    components: {
        Products,
        Proxies,
        AppLayout,
    },
})
export default class ExchangeModule extends Vue {
    tabs: any;
    isProxy = true;
    envFeatureFlag: any = '';

    mounted() {
        this.tabs = chi.tab(this.$refs.tabs as HTMLElement);
        this.envFeatureFlag = this.$store.state.userContext.flags.apienable_apihub_menu_active;
    }

    beforeDestroy() {
        this.tabs.dispose();
    }
    toogleIsProxy(isProxy: boolean): void {
        this.isProxy = isProxy;
    }
    async checkAddTextSuccuess(object: any, area: string) {
        let sectionId = 0;
        let msgType = 'added';
        if (object.section) {
            sectionId = object.section.id;
            msgType = 'updated';
        }
        const sect: Section = {
            id: sectionId,
            apiId: new UUID(object._homeStore.apiData.id).toString(),
            apiName: object.title,
            documentation: object.content,
            sectionType: area,
            filecontent: '',
        };
        const serviceFunction = async () => {
            if (object.section) {
                await object._homeStore.addTextSection({ data: sect, type: 'update' });
            } else {
                await object._homeStore.addTextSection({ data: sect, type: 'add' });
            }
        };
        await serviceFunction();

        if (object._homeStore.successResponse.addTextSuccess) {
            object.$router.push({
                name: 'EditAPIDocumentation',
                params: { page: 'edit', alert: 'true', alertmsg: area + ' section ' + msgType + ' successfully' },
            });
        } else if (object._homeStore.errorDetails.addTextError) {
            document.getElementById('page')?.scrollIntoView();
            object.failureAlert = true;
            object.alertObject = new Alert(ALERTMSG.failureMessage, {
                color: 'danger',
                icon: 'circle-warning',
            });
        }
    }
}
</script>
<style>
.exchange {
    width: 108rem;
}

.heroimage {
    background-image: url('../../assets/exchange-kra.jpg');
    max-width: 100rem !important;
    height: 184px;
    width: 100% !important;
    margin-left: auto;
    margin-right: auto;
}

.heroimagecontent {
    top: 25%;
    font-size: 2.25rem !important;
    padding-left: 2.5rem !important;
}

.title-height {
    height: 24px;
}
</style>
