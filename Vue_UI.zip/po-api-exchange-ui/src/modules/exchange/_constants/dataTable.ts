import { DataTableConfig } from '@/models/chiTableTypes';

export const DATATABLE_CONFIG: DataTableConfig = {
    columnResize: true,
    selectable: true,
    noResultsMessage: 'No matches found. Please revise search criteria and try again.',
    style: {
        portal: true,
        noBorder: false,
        bordered: false,
        hover: false,
        size: 'md',
        striped: true,
    },
    pagination: {
        activePage: 1,
        compact: false,
        firstLast: true,
        pageJumper: true,
        hideOnSinglePage: true,
    },
    columnSizes: {
        xs: [5, 5, 5, 5, 5, 5, 5, 5, 5],
        sm: [5, 5, 5, 5, 5, 5, 5, 5, 5],
        md: [5, 5, 5, 5, 5, 5, 5, 5, 5],
        lg: [5, 5, 5, 5, 5, 5, 5, 5, 5],
        xl: [5, 5, 5, 5, 5, 5, 5, 5, 5],
    },
    resultsPerPage: 20,
    reserveExpansionSlot: false,
};
