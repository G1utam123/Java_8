export const ALERTMSG = {
    failureAPIProxyMigration: 'Proxy Migration error',
    failureAPIProxyMigrationContact:
        '. Please try again later or contact APIEnablementTeam@lumen.com with the details of the error.',
    failureAPIProxyMigrationIncorrectSyntax: 'Please correct syntax for endpoint data',
    failureAPIProxyMigrationNoEndpoints: 'You have not entered any new endpoint data',
    failureAPIProxyMigrationNotOk: ', but was not migrated to ',
    failureAPIProxyMigrationNotOk2: ' was not migrated to ',
    failureMessage: 'something went wrong',
    feedbackAlert: 'Feedback required',
    maxFeedbackLimit: 'You have reached your maximum characters limit',
    orderUpdate: 'API section order updated successfully',
    proxiesNote: 'Note: The Migrate option will display for any proxy that you originally created.',
    successAPIProxyMigration: 'Every proxy has been migrated to the selected environments',
    successAPIProxyMigrationOk: ' has been successfully migrated to ',
    successMessageOnDelete: ' deleted successfully',
    successMessageOnSave: 'saved successfully',
    successMessageOnUpdate: ' updated successfully',
};
