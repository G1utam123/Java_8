export const HTTP_STRING: string = 'http://';
export const HTTPS_STRING: string = 'https://';

export type T_env =
    | 'dev1'
    | 'dev2'
    | 'dev3'
    | 'dev4'
    | 'test1'
    | 'test2'
    | 'test3'
    | 'test4'
    | 'mock'
    | 'sandbox'
    | 'prod';

export interface ApiProxyMigration {
    mirrorEnvironment: string;
    dev1EndpointHostname: string;
    dev2EndpointHostname: string;
    dev3EndpointHostname: string;
    dev4EndpointHostname: string;
    test1EndpointHostname: string;
    test2EndpointHostname: string;
    test3EndpointHostname: string;
    test4EndpointHostname: string;
    mockEndpointHostname: string;
    sandboxEndpointHostname: string;
    guid: string;
    requestorEmail: string;
}

export interface ApiProxyMigrationResponse {
    routingExpression: string;
    migratedEnv: string[];
    notMigratedEnv: string[];
}

export interface FeedbackFormRequest {
    firstName: string;
    lastName: string;
    email: string;
    phoneNumber: string;
    message: string;
}
