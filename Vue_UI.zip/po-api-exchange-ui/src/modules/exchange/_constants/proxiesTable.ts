import { DataTableConfig } from '@/models/chiTableTypes';
import { DATATABLE_CONFIG } from '@/modules/exchange/_constants/dataTable';

export const PROXIES_TOOLBAR_FILTERS = [
    {
        name: 'environment',
        type: 'select',
        id: 'environment-filter',
        label: 'Selector',
        options: [
            {
                label: 'Dev 1',
                value: 'dev1',
            },
            {
                label: 'Dev 2',
                value: 'dev2',
            },
            {
                label: 'Dev 3',
                value: 'dev3',
            },
            {
                label: 'Dev 4',
                value: 'dev4',
            },
            {
                label: 'Test 1',
                value: 'test1',
            },
            {
                label: 'Test 2',
                value: 'test2',
            },
            {
                label: 'Test 3',
                value: 'test3',
            },
            {
                label: 'Test 4',
                value: 'test4',
            },
            {
                label: 'Prod',
                value: 'prod',
            },
        ],
        value: 'dev1',
    },
];

export const PROXIES_DATATABLE_CONFIG: DataTableConfig = DATATABLE_CONFIG;

PROXIES_DATATABLE_CONFIG.defaultSort = {
    key: 'resourceTaxonomy',
    sortBy: 'resourceTaxonomy',
    direction: 'ascending',
};

export const PROXIES_DATATABLE_TEMPLATES = {
    TAXONAMY: 'resourceTaxonomy',
    RESOURCE_NAME: 'resourceName',
    VERSION: 'version',
    OWNING_APPLICATION_ID: 'owningApplicationId',
    ROUTING_EXPRESSION: 'routingExpression',
};

export const PROXIES_DATATABLE_COLUMNS = {
    Taxonomy: {
        label: 'Taxonomy',
        sortable: true,
        sortBy: PROXIES_DATATABLE_TEMPLATES.TAXONAMY,
        sortDataType: 'string',
    },
    ResourceName: {
        label: 'Resource Name',
        sortable: true,
        sortBy: PROXIES_DATATABLE_TEMPLATES.RESOURCE_NAME,
        sortDataType: 'string',
    },
    Version: { label: 'Version', sortable: true, sortBy: PROXIES_DATATABLE_TEMPLATES.VERSION, sortDataType: 'string' },
    AppID: {
        label: 'App ID',
        sortable: true,
        sortBy: PROXIES_DATATABLE_TEMPLATES.OWNING_APPLICATION_ID,
        sortDataType: 'string',
    },
    RoutingExpression: {
        label: 'Routing Expression',
        sortable: true,
        sortBy: PROXIES_DATATABLE_TEMPLATES.ROUTING_EXPRESSION,
        sortDataType: 'string',
    },
    Actions: { label: 'Actions', sortable: false, sortBy: 'resourceGuid', align: 'right', allowOverflow: true },
};
export interface Proxy {
    resourceTaxonomy: string;
    resourceName: string;
    version: string;
    owningApplicationId: string;
    routingExpression: string;
    resourceGuid: string;
    allowMigration: boolean;
}

export interface ProxyEnv {
    environment: string;
    endPointUrl: string;
    replaceUrlToValue: string;
}
