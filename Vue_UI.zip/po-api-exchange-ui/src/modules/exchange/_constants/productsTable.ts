import { DataTableConfig, HeadItem } from '@/models/chiTableTypes';
import { DATATABLE_CONFIG } from '@/modules/exchange/_constants/dataTable';

export const MONTHS: string[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export const PRODUCTS_DATATABLE_CONFIG: DataTableConfig = DATATABLE_CONFIG;

PRODUCTS_DATATABLE_CONFIG.defaultSort = {
    key: 'displayName',
    sortBy: 'displayName',
    direction: 'ascending',
};

export const PRODUCTS_DATATABLE_TEMPLATES = {
    DISPLAYNAME: 'displayName',
    CREATED_BY: 'createdBy',
    CREATED_DATE: 'createdAt',
    UPDATED_BY: 'lastModifiedBy',
    LAST_UPDATED_DATE: 'lastModifiedAt',
};

export const PRODUCTS_DATATABLE_COLUMNS: Record<string, HeadItem> = {
    displayName: {
        label: 'Name',
        sortable: true,
        sortBy: PRODUCTS_DATATABLE_TEMPLATES.DISPLAYNAME,
        sortDataType: 'string',
        allowOverflow: false,
    },
    createdBy: {
        label: 'Create By',
        sortable: true,
        sortBy: PRODUCTS_DATATABLE_TEMPLATES.CREATED_BY,
        sortDataType: 'string',
        allowOverflow: false,
    },
    createdDate: {
        label: 'Created Date',
        sortable: true,
        sortBy: PRODUCTS_DATATABLE_TEMPLATES.CREATED_DATE,
        sortDataType: 'date',
        allowOverflow: false,
    },
    updatedBy: {
        label: 'Updated By',
        sortable: true,
        sortBy: PRODUCTS_DATATABLE_TEMPLATES.UPDATED_BY,
        sortDataType: 'string',
        allowOverflow: false,
    },
    lastUpdatedDate: {
        label: 'Last Updated Date',
        sortable: true,
        sortBy: PRODUCTS_DATATABLE_TEMPLATES.LAST_UPDATED_DATE,
        sortDataType: 'date',
        allowOverflow: false,
    },
};
