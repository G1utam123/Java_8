export class Apis {
    id: string = '';
    secret: string = '';
    name: string = '';
    description: string = '';
    category: string = '';
    type: string = '';
    status: number = 0;
    version: string = '';
    author: string = '';
    createdDate: string = '';
    lastUpdatedDate: string = '';
    oasUrl: string = '';
    sourceCodeUrl: string = '';
}
