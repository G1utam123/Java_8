export interface MicroappDataType {
    id: string;
    data1: string;
    data2: string;
}
