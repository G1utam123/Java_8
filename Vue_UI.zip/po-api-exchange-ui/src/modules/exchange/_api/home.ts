import * as fetch from '../../../wrappers/fetch';

export const homeApi = {
    loadProducts: async () =>
        fetch.get('/v1/products/apigee?planet=PROD&internalExternal=EXTERNAL', {
            headers: { Authorization: 'Bearer ' + localStorage.getItem('accessToken') },
        }),
    loadProxiesDetails: async (options: any) => fetch.get('/v1/apiProxyDetails', options),
    saveApiProxies: async (proxiesData: any) => fetch.post('/v1/saveApiProxies', proxiesData),
    deleteApi: async (apiId: string) => fetch.delete('/v1/deleteapi/' + apiId),
    getDocuments: async (apiId: string) => fetch.get('/v1/documentation/' + apiId),
    deleteDocument: async (documentId: number) => fetch.delete('/v1/documentation/' + documentId),
    addApi: async (formData: any) => fetch.post('/v1/addnewapi', formData),
    addTextSection: async (sectionData: any) => fetch.post('/v1/newdoc', sectionData),
    getApiData: async (apiId: string) => fetch.get('/v1/documentationwithproxy/' + apiId),
};
