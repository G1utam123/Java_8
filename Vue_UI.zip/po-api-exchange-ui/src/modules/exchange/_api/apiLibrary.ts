import * as fetch from '../../../wrappers/fetch';
import { FeedbackFormRequest } from '../_constants/proxy';

export const apiLibraryApi = {
    getApiEnvironments: async (env: string) => fetch.get('/v1/apiEnvironments', env),
    submitMigrateApiProxies: async (json: any) => fetch.post('/v1/migrateApiProxies', json),
    submitFeedbackForm: async (json: FeedbackFormRequest) => fetch.post('/v1/feedback', json),
};
