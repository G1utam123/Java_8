<template>
    <AppLayout data-cy="cy-playbook_name">
        <template v-slot:playbook>
            <div class="-text--center">
                <div class="chi-card -highlight heroimage">
                    <div class="chi-card__content heroimagecontent">
                        <div class="-w--30">
                            <h2 class="-text--left -text--white" data-cy="cy-Welcome-text">Playbook</h2>
                        </div>
                    </div>
                </div>
                <div>
                    <img
                        src="../../../assets/Automated-operations-robot-arm.png"
                        alt="playbook_logo"
                        class="image"
                        data-cy="cy-playbook_logo"
                    />
                </div>
                <div data-cy="cy-playbook_text">
                    <div class="-text--boldest -mt--8 sub_title">COMING SOON</div>
                    <div class="-text--bold -text--lg">
                        We are busy building. <br />In the meantime, please visit our Community of Practice.
                    </div>
                </div>
                <form
                    target="_blank"
                    action="https://centurylink.sharepoint.com/sites/SPTAPICoP/SitePages/APIs-101.aspx"
                >
                    <chi-button class="-mt--8" data-cy="cy-playbook_button" color="primary">
                        API COMMUNITY OF PRACTICE
                    </chi-button>
                </form>
            </div>
        </template>
    </AppLayout>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import AppLayout from '@/modules/common/_components/AppLayout.vue';

@Component({
    components: {
        AppLayout,
    },
})
export default class Playbook extends Vue {}
</script>

<style scoped>
.sub_title {
    font-size: 2.875rem;
    height: 3.125rem;
}
.image {
    width: 8rem;
    height: 8.313rem;
    margin-top: 4rem;
}
.heroimage {
    background-image: url('../../../assets/playbook-kra.jpg');
    max-width: 100rem !important;
    height: 184px;
    margin-left: auto;
    margin-right: auto;
}
.chi-main {
    padding-top: 2rem !important;
}
.heroimagecontent {
    margin-top: 0.25rem;
    margin-left: 0.5rem;
}
</style>
