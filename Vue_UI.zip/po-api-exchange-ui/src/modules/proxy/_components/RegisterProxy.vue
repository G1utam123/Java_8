<template>
    <AppLayout title="API Proxy Builder" data-cy="cy-title-api-proxy-builder">
        <template v-slot:proxy>
            <Loader v-if="dataLoading" :height="apbHeight" />
            <div v-else>
                <div v-if="isAPBAvailable" class="chi-card -mr--4">
                    <!-- 1 -->
                    <General />

                    <!-- 2 -->
                    <GatewayEndpoint />

                    <!-- 3 -->
                    <TargetEndpoint />

                    <!-- 4 -->
                    <InternalGatewayAuthentication v-if="internalAvailability" />

                    <!-- 5 -->
                    <ExternalGatewayAuthentication
                        v-if="externalAvailability"
                        :step="externalGatewayAuthenticationStep"
                    />

                    <!-- 6 -->
                    <EndpointAuthentication
                        :internalAvailability="internalAvailability"
                        :externalAvailability="externalAvailability"
                        :isManagementRights="isManagementRights"
                        :step="endpointAuthenticationStep"
                        @clickLastPanelFinish="submitRequest()"
                    />

                    <!-- 7 -->
                    <ManagementRights
                        v-if="isManagementRights"
                        :internalAvailability="internalAvailability"
                        :externalAvailability="externalAvailability"
                        :step="managementRightsStep"
                        @clickLastPanelFinish="submitRequest()"
                    />

                    <div class="chi-backdrop -center" v-if="finalAlert">
                        <div class="chi-backdrop__wrapper">
                            <section
                                id="modal-1"
                                class="chi-modal"
                                role="dialog"
                                aria-label="Modal description"
                                aria-modal="true"
                            >
                                <header class="chi-modal__header">
                                    <h2 class="chi-modal__title">Proxy Request Submitted</h2>
                                    <button class="chi-button -icon -close" data-dismiss="modal" aria-label="Close">
                                        <div class="chi-button__content">
                                            <i class="chi-icon icon-x" aria-hidden="true" @click="closeModal()"></i>
                                        </div>
                                    </button>
                                </header>

                                <div class="chi-modal__content">
                                    <div class="-d--flex -mb--2" data-cy="proxyBuilderSuccessAlert">
                                        <i
                                            class="chi-icon icon-circle-check -sm--3 -icon--success -mr--2"
                                            aria-hidden="true"
                                        ></i>
                                        <div class="-w--100">
                                            <p class="-text -m--0">{{ successMessageFinalAlert1 }}</p>
                                            <p class="-text -m--0">{{ successMessageFinalAlert2 }}</p>
                                        </div>
                                    </div>
                                    <div v-if="isManagementRights" data-cy="groupRequestAlert">
                                        <div class="-d--flex -mt--1" v-if="failureGroupRequestAlert">
                                            <i
                                                class="chi-icon icon-warning -sm--3 -icon--warning -mr--2"
                                                aria-hidden="true"
                                            ></i>
                                            <div class="-w--100">
                                                <p class="-text -m--0">{{ failureGroupRequestAlert }}</p>
                                            </div>
                                        </div>
                                        <div class="-mt--1 -pl--4" v-else>
                                            <AlertComponent :alertObject="alertGroupRequest"></AlertComponent>
                                        </div>
                                    </div>
                                </div>
                                <footer class="chi-modal__footer">
                                    <button class="chi-button -primary" @click="closeModal()">OK</button>
                                </footer>
                            </section>
                        </div>
                    </div>

                    <div class="chi-backdrop -center" v-if="finalFailureAlert">
                        <div class="chi-backdrop__wrapper">
                            <section
                                id="modal-1"
                                class="chi-modal"
                                role="dialog"
                                aria-label="Modal description"
                                aria-modal="true"
                            >
                                <header class="chi-modal__header">
                                    <h2 class="chi-modal__title">Proxy Request Failed</h2>
                                    <button class="chi-button -icon -close" data-dismiss="modal" aria-label="Close">
                                        <div class="chi-button__content">
                                            <i
                                                class="chi-icon icon-x"
                                                aria-hidden="true"
                                                @click="closeModalFailure()"
                                            ></i>
                                        </div>
                                    </button>
                                </header>
                                <div class="chi-modal__content">
                                    <div class="-d--flex">
                                        <i
                                            class="chi-icon icon-circle-x -sm--3 -icon--danger -mr--2"
                                            aria-hidden="true"
                                        ></i>
                                        <div class="-w--100">
                                            <p class="-text -m--0">{{ failureMessageFinalAlert1 }}</p>
                                            <p class="-text -m--0">{{ failureMessageFinalAlert2 }}</p>
                                            <p class="-text -mt--1 -m--0">{{ failureMessageFinalAlert3 }}</p>
                                        </div>
                                    </div>
                                </div>
                                <footer class="chi-modal__footer">
                                    <button class="chi-button -primary" @click="closeModalFailure()">OK</button>
                                </footer>
                            </section>
                        </div>
                    </div>
                </div>
                <div v-else>
                    <AlertComponent
                        :alertObject="alertAPBAvailability"
                        :height="apbHeight"
                        :paddingTop="4"
                        :spinner="true"
                        :spinnerMessage="spinnerMessage"
                    ></AlertComponent>
                </div>
            </div>
        </template>
    </AppLayout>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { getModule } from 'vuex-module-decorators';
import ProxyModule, { STORE_KEY } from '@/modules/proxy/_store';
import General from '@/modules/proxy/common/_components/General.vue';
import GatewayEndpoint from '@/modules/proxy/common/_components/GatewayEndpoint.vue';
import TargetEndpoint from '@/modules/proxy/common/_components/TargetEndpoint.vue';
import InternalGatewayAuthentication from '@/modules/proxy/common/_components/InternalGatewayAuthentication.vue';
import ExternalGatewayAuthentication from '@/modules/proxy/common/_components/ExternalGatewayAuthentication.vue';
import EndpointAuthentication from '@/modules/proxy/common/_components/EndpointAuthentication.vue';
import ManagementRights from '@/modules/proxy/common/_components/ManagementRights.vue';
import AppLayout from '@/modules/common/_components/AppLayout.vue';
import { ApiProxyBuilderResponse, CHECK_APB_AVAILABILITY_TIME } from '@/modules/proxy/_constants/proxy';
import { ALERTMSGAPB } from '@/modules/proxy/_constants/AlertMessages';
import Loader from '@/modules/common/_components/Loader.vue';
import { OwnershipDetails } from '../_models/proxiesOwnership';
import { Alert } from '@/models/alert';
import AlertComponent from '@/modules/common/_components/AlertComponent.vue';
import { Environments } from '@/utils/entities/environments';
declare let chi: any;

@Component({
    components: {
        General,
        GatewayEndpoint,
        TargetEndpoint,
        InternalGatewayAuthentication,
        ExternalGatewayAuthentication,
        EndpointAuthentication,
        ManagementRights,
        AppLayout,
        Loader,
        AlertComponent,
    },
})
export default class RegisterProxy extends Vue {
    private subscription: any;
    proxyStore!: ProxyModule;
    internalAvailability = false;
    externalAvailability = false;
    loggedInUser: any = '';
    finalAlert: boolean = false;
    finalFailureAlert: boolean = false;
    expansionPanelsArray: any[] = [];
    successMessageFinalAlert1 = '';
    successMessageFinalAlert2 = '';
    failureMessageFinalAlert1 = '';
    failureMessageFinalAlert2 = '';
    failureMessageFinalAlert3 = '';
    failureGroupRequestAlert = '';
    dataLoading = true;
    isManagementRights = false;
    externalGatewayAuthenticationStep = 3;
    endpointAuthenticationStep = 3;
    managementRightsStep = 4;
    apbHeight = '50.125rem';
    //#region alertAPB availability variables
    isAPBAvailable = false;
    isCheckAvailabilityInProgress = false;
    alertAPBAvailability = new Alert(ALERTMSGAPB.apbAvailabilityMessage, {
        color: 'warning',
        icon: 'warning',
        closable: false,
        size: 'lg',
        title: ALERTMSGAPB.apbAvailabilityTitle,
        custom: 'apb',
        tag: 'alert-apb-available',
    });
    spinnerMessage = ALERTMSGAPB.apbAvailabilitySpinner;
    //#endregion
    //#region check availability variables
    control = 0;
    interval = 0;
    speed = CHECK_APB_AVAILABILITY_TIME;
    //#endregion
    alertGroupRequest = {};

    //#region Lifecycle hooks
    created() {
        if (!this.proxyStore) {
            this.proxyStore = getModule(ProxyModule, this.$store);
        }
        this.loadHealthESP();
        this.loggedInUser = this.$store.state.userContext.email;
        this.proxyStore.setLoggedInUser(this.loggedInUser);

        this.subscription = this.$store.subscribe((mutation, state) => {
            const currentMutation = mutation.type.split('/')[1];
            const currentStore = state[STORE_KEY];
            if (
                this.$store.state.userContext.flags.apienable_apihub_api_ownership &&
                currentMutation === 'setProxiesOwnership'
            ) {
                this.isManagementRights =
                    OwnershipDetails.getOwnershipDetailsByOwnershipId(
                        currentStore.proxiesOwnership,
                        currentStore.cmsAssetTag
                    )?.ownershipDetails === undefined;
            }
            this.internalAvailability = currentStore.availabilityInternal;
            this.externalAvailability = currentStore.availabilityExternal;
            this.loadSteps();
            this.isAPBAvailable = currentStore.healthESP;
            if (currentMutation === 'setHealthESP') {
                this.dataLoading = false;
                if (!this.isCheckAvailabilityInProgress && !this.isAPBAvailable) {
                    this.checkAvailability();
                }
            }
        });
    }
    mounted() {
        this.expansionPanelsArray = chi.expansionPanel(
            document.querySelectorAll('[data-chi-epanel-group="proxy_chi__epanel"]')
        );
    }
    beforeDestroy() {
        this.expansionPanelsArray.forEach(function (expansionPanel) {
            expansionPanel.dispose();
        });
        this.subscription();
    }
    //#endregion

    private loadSteps(): void {
        this.externalGatewayAuthenticationStep = this.internalAvailability ? 4 : 3;
        if (this.internalAvailability && this.externalAvailability) {
            this.endpointAuthenticationStep = 5;
            this.managementRightsStep = 6;
        } else if (this.internalAvailability || this.externalAvailability) {
            this.endpointAuthenticationStep = 4;
            this.managementRightsStep = 5;
        } else {
            this.endpointAuthenticationStep = 3;
            this.managementRightsStep = 4;
        }
    }

    private loadHealthESP() {
        console.log('Checking APB availability...');
        this.proxyStore.loadHealthESP();
    }

    private checkAvailability(): void {
        this.isCheckAvailabilityInProgress = true;
        this.interval = setInterval(() => {
            if (!this.isAPBAvailable) {
                this.loadHealthESP();
            } else {
                clearInterval(this.interval);
            }
        }, this.speed);
    }

    async submitRequest(): Promise<void> {
        this.dataLoading = true;
        await this.proxyStore.loadProxyData();
        if (this.proxyStore.successResponse.successValue) {
            if (this.proxyStore.getGroupRequest) {
                this.proxyStore
                    .loadGroupRequest(this.proxyStore.getGroupRequest)
                    .then(() => {
                        if (this.proxyStore.groupRequestResponse) {
                            this.alertGroupRequest = new Alert('', {
                                color: 'info',
                                icon: 'circle-info',
                                closable: false,
                                size: 'lg',
                                title: 'Next Steps',
                                tag: 'alert-apb-group-request',
                                custom: 'groupRequest',
                                customParameters: {
                                    requestNumber: this.proxyStore.groupRequestResponse,
                                    successGroupRequestAlert1: ALERTMSGAPB.successGroupRequestAlert1(
                                        this.proxyStore.groupRequestResponse
                                    ),
                                    successGroupRequestAlert2: ALERTMSGAPB.successGroupRequestAlert2,
                                    successGroupRequestAlert3: ALERTMSGAPB.successGroupRequestAlert3,
                                    successGroupRequestAlertLink1: ALERTMSGAPB.successGroupRequestAlertLink1,
                                    successGroupRequestAlertLink2: ALERTMSGAPB.successGroupRequestAlertLink2,
                                    successGroupRequestAlertLink3: ALERTMSGAPB.successGroupRequestAlertLink3,
                                },
                            });
                        } else {
                            console.error(`No valid RITM -${this.proxyStore.getGroupRequestResponse}-.`);
                            this.failureGroupRequestAlert = ALERTMSGAPB.errorGroupRequest;
                        }
                    })
                    .catch(() => {
                        this.failureGroupRequestAlert = ALERTMSGAPB.errorGroupRequest;
                    })
                    .finally(() => {
                        this.setSuccessMessage();
                    });
            } else {
                this.setSuccessMessage();
            }
        } else if (this.proxyStore.errorDetails.proxyErr) {
            this.setErrorMessage();
        }
    }

    private setSuccessMessage(): void {
        this.dataLoading = false;
        this.successMessageFinalAlert1 = ALERTMSGAPB.successAPIProxyBuilderOk1;
        this.successMessageFinalAlert2 = this.getSuccessMessage(this.proxyStore.successResponse.successValue.data);
        this.finalAlert = true;
    }

    private setErrorMessage(): void {
        this.dataLoading = false;
        this.failureMessageFinalAlert1 = ALERTMSGAPB.proxyErrAPIProxyBuilderNotOk1;
        this.failureMessageFinalAlert2 = this.getErrorMessage(this.proxyStore.errorDetails.proxyErr);
        this.failureMessageFinalAlert3 = ALERTMSGAPB.proxyErrAPIProxyBuilderNotOk2;
        this.finalFailureAlert = true;
    }

    private getSuccessMessage(resp: ApiProxyBuilderResponse): string {
        return (
            resp.proxy +
            ALERTMSGAPB.successAPIProxyBuilderOk2 +
            Environments.parseListOfEnvironmentsToString(resp.proxyBuiltInEnvironments) +
            ALERTMSGAPB.successAPIProxyBuilderOk3
        );
    }

    private getErrorMessage(error: string): string {
        return error;
    }

    closeModal() {
        this.finalAlert = false;
        window.location.reload();
    }

    closeModalFailure() {
        this.finalFailureAlert = false;
        window.location.reload();
    }
}
</script>

<style>
.main-content {
    margin: 1% 10% 1% 10%;
}

#checkbox-ch3 {
    vertical-align: middle;
}
#thirdContinueButton {
    margin-right: -15px;
}
.chi .chi-checkbox .chi-checkbox__input:checked + .chi-checkbox__label #l2:after {
    margin-top: -6px;
}
.sc__filtered-items {
    background-color: white !important;
    height: 300px;
    z-index: 1 !important;
    position: relative !important;
}

.chi .chi-epanel > .chi-epanel__header > .chi-epanel__number {
    width: 48px;
    margin-left: 24px;
}

.chi .chi-epanel:not(.-bordered) > .chi-epanel__header + .chi-epanel__collapse {
    margin-left: 72px;
    margin-right: 24px;
}

.chi-form__item > .sc__container > input:hover {
    border-color: #acb0b5;
}
.chi-form__item > .sc__container > input:focus {
    border-color: #0c9ed9;
    box-shadow: 0 0 0 1px #0c9ed9;
}
.chi-form__item > .sc__container {
    position: relative;
    display: block;
    grid-template-columns: auto;
    justify-content: start;
}

.chi i[class*=' icon-'] {
    font-size: 0.8rem;
}

#ldapUserFlex {
    flex: auto;
}
.chi .chi-card__content {
    padding: 0rem;
}
.chi-data-table__cell {
    border-bottom: hidden;
    max-width: 85%;
    padding: 0.6rem 0.75rem;
}
#chi-col-1 {
    border-bottom: hidden;
    max-width: 85%;
    padding: 0.6rem 0.75rem;
}
#chi-col-2 {
    border-bottom: hidden;
    max-width: 15%;
    padding: 0.6rem 0.75rem;
}
body {
    overflow: hidden;
}
.title-height {
    height: 48px;
}
</style>
