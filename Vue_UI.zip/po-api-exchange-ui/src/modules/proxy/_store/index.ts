import Vue from 'vue';
import { Module, VuexModule, Action, Mutation, MutationAction } from 'vuex-module-decorators';
import { Store } from 'vuex';
import { registerProxy } from '@/modules/proxy/_api/proxy';
import { ApplicationKeyData } from '@/models/proxy';
import { Compare } from '@/utils/compare';
import { ProxyOwnership, OwnershipDetails } from '../_models/proxiesOwnership';
import { GroupRequest } from '../_models/groupRequest';
import { checkHealthESP } from '../_constants/proxy';
export const STORE_KEY = '$_api_exchange_proxy';

@Module({
    namespaced: true,
    name: STORE_KEY,
    store: Vue.prototype.$store,
})
export default class ProxyStore extends VuexModule {
    static register($store: Store<any>) {
        if (!$store.state[STORE_KEY]) {
            $store.registerModule(STORE_KEY, this);
        }
    }
    static unregister($store: Store<any>) {
        if ($store.state[STORE_KEY]) {
            $store.unregisterModule(STORE_KEY);
        }
    }

    //#region states
    targetEndpointValidation = false;
    internalGatewayAuthenticationValidation = false;
    externalGatewayAuthenticationValidation = false;
    appData: ApplicationKeyData[] = [];
    taxonomyData: string[] = [];
    errorDetails: any = {};
    successResponse: any = {};
    endpointAuthenticationData: any = {};
    loggedInUserEmail: string = '';
    basicAuthGroups: Record<string, string> = {};
    basicLpdapUsers: Record<string, string> = {};
    appKey: string = '';
    cmsAssetTag: string = '';
    serviceCategory: string = '';
    soap: any = '';
    availabilityInternal = false;
    availabilityExternal = false;
    resourceName: string = '';
    type: string = '';
    version: string = '';
    dev1EndpointHostname = '';
    dev2EndpointHostname = '';
    dev3EndpointHostname = '';
    dev4EndpointHostname = '';
    test1EndpointHostname = '';
    test2EndpointHostname = '';
    test3EndpointHostname = '';
    test4EndpointHostname = '';
    endpointPath = '';
    intGatewayArr: string[] = [];
    extGatewayArr: string[] = [];
    enforceDigest = false;
    enforceTaxonomy = false;
    isLegacyOAuth = true;
    isLiamOAuth = false;
    proxiesOwnership: ProxyOwnership[] = [];
    groupRequest: GroupRequest | undefined;
    groupRequestResponse = '';
    currentStep = 0;
    currentStepCollapse = false;
    healthESP = false;
    //#endregion

    //#region getters
    get getVersion(): string {
        return this.version;
    }

    get getType(): string {
        return this.type;
    }

    get getIsLegacyOAuth(): boolean {
        return this.isLegacyOAuth;
    }

    get getIsLiamOAuth(): boolean {
        return this.isLiamOAuth;
    }

    get getAppData(): ApplicationKeyData[] {
        return this.appData;
    }

    get getTaxonomyData(): string[] {
        return this.taxonomyData;
    }

    get getAppKey(): string {
        return this.appKey;
    }

    get getMalId(): string {
        return this.cmsAssetTag;
    }

    get getServiceCategory(): string {
        return this.serviceCategory;
    }

    get getAvailabilityInternal(): boolean {
        return this.availabilityInternal;
    }

    get getAvailabilityExternal(): boolean {
        return this.availabilityExternal;
    }

    get getResourceName(): string {
        return this.resourceName;
    }

    get getTargetEndpointValidation(): boolean {
        return this.targetEndpointValidation;
    }

    get getInternalGatewayAuthenticationValidation(): boolean {
        return this.internalGatewayAuthenticationValidation;
    }

    get getExternalGatewayAuthenticationValidation(): boolean {
        return this.externalGatewayAuthenticationValidation;
    }

    get getProxiesOwnership(): ProxyOwnership[] {
        return this.proxiesOwnership;
    }

    get getGroupRequest(): GroupRequest | undefined {
        return this.groupRequest;
    }

    get getGroupRequestResponse(): string {
        return this.groupRequestResponse;
    }

    get getCurrentStep(): number {
        return this.currentStep;
    }
    //#endregion

    //#region Actions
    @Action
    async loadVersion(version: string): Promise<void> {
        this.context.commit('setVersion', version);
    }

    @Action
    async loadType(type: string): Promise<void> {
        this.context.commit('setType', type);
    }

    @Action
    async loadTargetEndpointValidation(targetEndpointValidation: boolean): Promise<void> {
        this.context.commit('setTargetEndpointValidation', targetEndpointValidation);
    }

    @Action
    async loadInternalGatewayAuthenticationValidation(internalGatewayAuthenticationValidation: boolean): Promise<void> {
        this.context.commit('setInternalGatewayAuthenticationValidation', internalGatewayAuthenticationValidation);
    }

    @Action
    async loadExternalGatewayAuthenticationValidation(externalGatewayAuthenticationValidation: boolean): Promise<void> {
        this.context.commit('setExternalGatewayAuthenticationValidation', externalGatewayAuthenticationValidation);
    }

    @Action
    async loadResourceName(resourceName: string): Promise<void> {
        this.context.commit('setResourceName', resourceName);
    }

    @Action
    async loadServiceCategory(serviceCategory: string): Promise<void> {
        this.context.commit('setServiceCategory', serviceCategory);
    }

    @Action
    async loadSoap(soap: any): Promise<void> {
        this.context.commit('setSoap', soap);
    }

    @Action
    async loadAvailabilityInternal(availabilityInternal: boolean): Promise<void> {
        this.context.commit('setAvailabilityInternal', availabilityInternal);
    }

    @Action
    async loadAvailabilityExternal(availabilityExternal: boolean): Promise<void> {
        this.context.commit('setAvailabilityExternal', availabilityExternal);
    }

    @Action
    async loadMalID(malId: string): Promise<void> {
        this.context.commit('setMalID', malId);
    }

    @Action
    async loadAppKey(appKey: string): Promise<void> {
        this.context.commit('setAppKey', appKey);
    }

    @Action
    async loadApplicationKeyData(): Promise<void> {
        let appData: ApplicationKeyData[] = [];
        await registerProxy.loadApplicationKey().then((response: any) => {
            appData = response.data;
        });
        this.context.commit('setApplicationKey', appData);
    }

    @Action
    async loadTaxonomies(): Promise<void> {
        let taxonomyData: string[] = [];
        await registerProxy.loadTaxonomies().then((response: any) => {
            taxonomyData = response.data;
        });
        this.context.commit('setTaxonomy', taxonomyData);
    }

    @Action
    async loadIntGatewayArr(intGatewayArr: string[]): Promise<void> {
        this.context.commit('setIntGatewayArr', intGatewayArr);
    }

    @Action
    async loadExtGatewayArr(extGatewayArr: string[]): Promise<void> {
        this.context.commit('setExtGatewayArr', extGatewayArr);
    }

    @Action
    async loadIsLegacyOAuth(isLegacyOAuth: boolean): Promise<void> {
        this.context.commit('setIsLegacyOAuth', isLegacyOAuth);
    }

    @Action
    async loadIsLiamOAuth(isLiamOAuth: boolean): Promise<void> {
        this.context.commit('setIsLiamOAuth', isLiamOAuth);
    }

    @Action
    async loadProxiesOwnership(ownershipId: string): Promise<void> {
        await registerProxy
            .getOwnershipDetails(ownershipId)
            .then((response: any) => {
                this.context.commit(
                    'setProxiesOwnership',
                    new ProxyOwnership(
                        ownershipId,
                        new OwnershipDetails(
                            response.data.type,
                            response.data.id,
                            response.data.status,
                            response.data.request,
                            response.data.requester
                        )
                    )
                );
            })
            .catch((error) => {
                console.error('loadProxiesOwnership.getOwnershipDetails: ', error);
                this.context.commit('setProxiesOwnership', new ProxyOwnership(ownershipId, undefined));
            });
    }

    @Action
    async loadProxyData() {
        let dataError: any = {};
        let successDetail: Record<string, string> = {};
        let response: any;
        try {
            // General data
            const generalData = {
                owningAppAppkey: this.appKey,
                malId: this.cmsAssetTag,
                type: this.type,
                soap: this.soap,
                internal: this.availabilityInternal,
                external: this.availabilityExternal,
            };
            // GatewayEndpoint data
            const gatewayEndPointData = {
                taxonomy: this.serviceCategory,
                resourceName: this.resourceName,
                version: this.version,
            };
            // TargetEndpoint data
            const targetEndPointData = {
                dev1EndpointHostname: this.dev1EndpointHostname,
                dev2EndpointHostname: this.dev2EndpointHostname,
                dev3EndpointHostname: this.dev3EndpointHostname,
                dev4EndpointHostname: this.dev4EndpointHostname,
                test1EndpointHostname: this.test1EndpointHostname,
                test2EndpointHostname: this.test2EndpointHostname,
                test3EndpointHostname: this.test3EndpointHostname,
                test4EndpointHostname: this.test4EndpointHostname,
                endpointPath: this.endpointPath,
            };
            // InternalGatewayAuthentication data
            const internalGatewayData = this.availabilityInternal
                ? {
                      proxyAuthInternal: this.intGatewayArr.toString(),
                      appkeyEnforceDigest: this.enforceDigest,
                      appkeyEnforceTaxonomy: this.enforceTaxonomy,
                  }
                : {
                      proxyAuthInternal: '',
                      appkeyEnforceDigest: false,
                      appkeyEnforceTaxonomy: false,
                  };
            // ExternalGatewayAuthentication data
            let externalGatewayData = { proxyAuthExternal: '' };
            if (this.availabilityExternal) {
                externalGatewayData = { proxyAuthExternal: this.extGatewayArr.toString() };
                if (this.extGatewayArr.toString().includes('oAuth')) {
                    if (this.isLiamOAuth) {
                        externalGatewayData = {
                            proxyAuthExternal: this.extGatewayArr.toString().replace('oAuth', 'LIAMOAuth'),
                        };
                    }
                }
            }
            // User data
            let users = '';
            let groups = '';
            if (this.availabilityInternal && this.availabilityExternal) {
                users = Compare.concatenateElements(this.basicLpdapUsers.internal, this.basicLpdapUsers.external);
                groups = Compare.concatenateElements(this.basicAuthGroups.internal, this.basicAuthGroups.external);
            } else {
                if (this.availabilityInternal) {
                    users = this.basicLpdapUsers.internal;
                    groups = this.basicAuthGroups.internal;
                } else if (this.availabilityExternal) {
                    users = this.basicLpdapUsers.external;
                    groups = this.basicAuthGroups.external;
                }
            }
            const userData = {
                requestorEmail: this.loggedInUserEmail,
                basicAuthGroups: groups.toString(),
                basicAuthUsers: users.toString(),
            };

            const finalObject = {
                ...generalData,
                ...gatewayEndPointData,
                ...targetEndPointData,
                ...internalGatewayData,
                ...externalGatewayData,
                ...this.endpointAuthenticationData,
                ...userData,
            };
            response = await registerProxy.loadProxyData(finalObject);
            successDetail = { successValue: response };
            this.setSuccessMessage(successDetail);
        } catch (error) {
            dataError = { proxyErr: error };
        }
        if (dataError.proxyErr) {
            this.setErrorAlert(dataError);
        }
    }

    @Action
    async loadGroupRequest(groupRequest: GroupRequest): Promise<void> {
        await registerProxy
            .loadGroupRequest(groupRequest)
            .then((response: any) => {
                this.context.commit('setGroupRequestResponse', response.data);
            })
            .catch((error) => {
                console.error('loadGroupRequest: ', error);
                this.context.commit('setGroupRequestResponse', '');
                this.setErrorAlert({ proxyErr: error });
            });
    }

    @Action
    async loadbasicAuthGroups(basicAuthGroup: Record<string, any>) {
        this.context.commit('setbasicAuthGroups', basicAuthGroup);
    }

    @Action
    async loadbasicAuthUsers(basicAuthUser: Record<string, any>) {
        this.context.commit('setbasicAuthUsers', basicAuthUser);
    }

    @Action
    async loadHealthESP(): Promise<void> {
        await registerProxy
            .healthESP()
            .then((response: any) => {
                this.context.commit('setHealthESP', checkHealthESP(response.data));
            })
            .catch((error) => {
                console.error('loadHealthESP: ', error);
                this.context.commit('setHealthESP', false);
            });
    }
    //#endregion

    //#region Mutations
    @Mutation
    setVersion(version: string) {
        this.version = version;
    }

    @Mutation
    setType(type: string) {
        this.type = type;
    }

    @Mutation
    setTargetEndpointValidation(targetEndpointValidation: boolean) {
        this.targetEndpointValidation = targetEndpointValidation;
    }

    @Mutation
    setInternalGatewayAuthenticationValidation(internalGatewayAuthenticationValidation: boolean) {
        this.internalGatewayAuthenticationValidation = internalGatewayAuthenticationValidation;
    }

    @Mutation
    setExternalGatewayAuthenticationValidation(externalGatewayAuthenticationValidation: boolean) {
        this.externalGatewayAuthenticationValidation = externalGatewayAuthenticationValidation;
    }

    @Mutation
    setResourceName(resourceName: string) {
        this.resourceName = resourceName;
    }

    @Mutation
    setServiceCategory(serviceCategory: string) {
        this.serviceCategory = serviceCategory;
    }

    @Mutation
    setSoap(soap: any) {
        this.soap = soap;
    }

    @Mutation
    setAvailabilityInternal(availabilityInternal: boolean) {
        this.availabilityInternal = availabilityInternal;
    }

    @Mutation
    setAvailabilityExternal(availabilityExternal: boolean) {
        this.availabilityExternal = availabilityExternal;
    }

    @Mutation
    setMalID(cmsAssetTag: string) {
        this.cmsAssetTag = cmsAssetTag;
    }

    @Mutation
    setAppKey(appKey: string) {
        this.appKey = appKey;
    }

    @Mutation
    setApplicationKey(appData: ApplicationKeyData[]) {
        this.appData = [...appData];
    }

    @Mutation
    setTaxonomy(taxonomyData: []) {
        this.taxonomyData = [...taxonomyData];
    }

    @Mutation
    setIntGatewayArr(intGatewayArr: string[]) {
        this.intGatewayArr = [...intGatewayArr];
    }

    @Mutation
    setExtGatewayArr(extGatewayArr: string[]) {
        this.extGatewayArr = [...extGatewayArr];
    }

    @Mutation
    setbasicAuthUsers(basicAuthUser: Record<string, any>) {
        const index: number = Object.keys(this.basicLpdapUsers).findIndex((item) => item === basicAuthUser.property);
        const basicAuthUsers: Record<string, string> = { ...this.basicLpdapUsers };
        if (index !== -1) {
            delete basicAuthUsers[basicAuthUser.property];
        }
        Object.assign(basicAuthUsers, {
            [basicAuthUser.property]: basicAuthUser.users,
        });
        this.basicLpdapUsers = basicAuthUsers;
    }

    @Mutation
    setbasicAuthGroups(basicAuthGroup: Record<string, any>) {
        const index: number = Object.keys(this.basicAuthGroups).findIndex((item) => item === basicAuthGroup.property);
        const basicAuthGroups: Record<string, string> = { ...this.basicAuthGroups };
        if (index !== -1) {
            delete basicAuthGroups[basicAuthGroup.property];
        }
        Object.assign(basicAuthGroups, {
            [basicAuthGroup.property]: basicAuthGroup.groups,
        });
        this.basicAuthGroups = basicAuthGroups;
    }

    @Mutation
    setProxiesOwnership(proxyOwnership: ProxyOwnership) {
        const proxyOwnershipFound = OwnershipDetails.getOwnershipDetailsByOwnershipId(
            this.proxiesOwnership,
            proxyOwnership.ownershipId
        );
        if (proxyOwnershipFound) {
            const index = OwnershipDetails.getIndexByOwnershipId(this.proxiesOwnership, proxyOwnership.ownershipId);
            this.proxiesOwnership[index].ownershipDetails = proxyOwnership.ownershipDetails;
        } else {
            this.proxiesOwnership.push(proxyOwnership);
        }
    }

    @Mutation
    setIsLegacyOAuth(IsLegacyOAuth: boolean) {
        this.isLegacyOAuth = IsLegacyOAuth;
    }

    @Mutation
    setIsLiamOAuth(isLiamOAuth: boolean) {
        this.isLiamOAuth = isLiamOAuth;
    }

    @Mutation
    setGroupRequestResponse(groupRequestResponse: string) {
        this.groupRequestResponse = groupRequestResponse;
    }

    @Mutation
    setHealthESP(healthESP: boolean) {
        this.healthESP = healthESP;
    }
    //#endregion

    //#region MutationActions
    @MutationAction
    async setEndpointAuthenticationData(endpointAuthenticationData: any) {
        return { endpointAuthenticationData: endpointAuthenticationData };
    }
    @MutationAction
    async setDev1EndpointHostname(dev1EndpointHostname: string) {
        return { dev1EndpointHostname: dev1EndpointHostname };
    }
    @MutationAction
    async setDev2EndpointHostname(dev2EndpointHostname: string) {
        return { dev2EndpointHostname: dev2EndpointHostname };
    }
    @MutationAction
    async setDev3EndpointHostname(dev3EndpointHostname: string) {
        return { dev3EndpointHostname: dev3EndpointHostname };
    }
    @MutationAction
    async setDev4EndpointHostname(dev4EndpointHostname: string) {
        return { dev4EndpointHostname: dev4EndpointHostname };
    }
    @MutationAction
    async setTest1EndpointHostname(test1EndpointHostname: string) {
        return { test1EndpointHostname: test1EndpointHostname };
    }
    @MutationAction
    async setTest2EndpointHostname(test2EndpointHostname: string) {
        return { test2EndpointHostname: test2EndpointHostname };
    }
    @MutationAction
    async setTest3EndpointHostname(test3EndpointHostname: string) {
        return { test3EndpointHostname: test3EndpointHostname };
    }
    @MutationAction
    async setTest4EndpointHostname(test4EndpointHostname: string) {
        return { test4EndpointHostname: test4EndpointHostname };
    }
    @MutationAction
    async setEndpointPath(endpointPath: string) {
        return { endpointPath: endpointPath };
    }
    @MutationAction
    async setEnforceDigest(enforceDigest: boolean) {
        return { enforceDigest: enforceDigest };
    }
    @MutationAction
    async setEnforceTaxonomy(enforceTaxonomy: boolean) {
        return { enforceTaxonomy: enforceTaxonomy };
    }
    @MutationAction
    async setLoggedInUser(loggedInUser: any) {
        return { loggedInUserEmail: loggedInUser };
    }
    @MutationAction
    async setSuccessMessage(successMessage: any) {
        return { successResponse: successMessage };
    }
    @MutationAction
    async setErrorAlert(errorAlert: any) {
        return { errorDetails: errorAlert };
    }
    @MutationAction
    async setGroupRequest(groupRequest: any) {
        return { groupRequest: groupRequest };
    }
    @MutationAction
    async setCurrentStep(currentStep: number) {
        return { currentStep: currentStep };
    }
    @MutationAction
    async setCurrentStepCollapse(currentStepCollapse: boolean) {
        return { currentStepCollapse: currentStepCollapse };
    }
    //#endregion
}
