<template>
    <Proxy />
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import ProxyStore from '@/modules/proxy/_store';

@Component({
    components: {
        Proxy: () => import(/* webpackChunkName: "apiexchange-proxy" */ './_components/RegisterProxy.vue'),
    },
})
export default class ProxyModule extends Vue {
    created() {
        ProxyStore.register(this.$store);
    }

    destroyed() {
        ProxyStore.unregister(this.$store);
    }
}
</script>
