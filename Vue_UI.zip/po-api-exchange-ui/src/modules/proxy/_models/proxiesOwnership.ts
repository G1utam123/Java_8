enum StatusTypes {
    Provisioning = 'PROVISIONING',
    Provisioned = 'PROVISIONED',
}

export class ProxyOwnership {
    ownershipId: string = '';
    ownershipDetails?: OwnershipDetails;

    constructor(ownershipId: string, ownershipDetails?: OwnershipDetails) {
        this.ownershipId = ownershipId;
        this.ownershipDetails = ownershipDetails;
    }
}

export class OwnershipDetails {
    type: string = '';
    id: string = '';
    status: StatusTypes = StatusTypes.Provisioning;
    request: string = '';
    requester: string = '';

    constructor(type, id, status, request, requester) {
        this.type = type;
        this.id = id;
        this.status = status;
        this.request = request;
        this.requester = requester;
    }

    static getOwnershipDetailsByOwnershipId(proxiesOwnership: ProxyOwnership[], ownershipId: string): any {
        return proxiesOwnership?.find((proxyOwnership) => proxyOwnership.ownershipId === ownershipId);
    }

    static getIndexByOwnershipId(proxiesOwnership: ProxyOwnership[], ownershipId: string): number {
        return proxiesOwnership
            ? proxiesOwnership.findIndex((proxyOwnership) => proxyOwnership.ownershipId === ownershipId)
            : -1;
    }
}
