export enum ElementTypes {
    Proxy = 'proxy',
    Product = 'product',
}

export class GroupRequest {
    element_type: ElementTypes;
    element_name: string;
    admins: string[];
    owners: string[];
    requester: string;

    constructor(
        element_type: ElementTypes,
        element_name: string,
        admins: string[],
        owners: string[],
        requester: string
    ) {
        this.element_type = element_type;
        this.element_name = element_name;
        this.admins = admins;
        this.owners = owners;
        this.requester = requester;
    }
}
