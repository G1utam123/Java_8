<template>
    <div
        :class="'chi-epanel -' + currentState"
        data-chi-epanel-group="proxy_chi__epanel"
        data-cy="cy-extActive__epanel"
    >
        <div class="chi-epanel__header">
            <div class="chi-epanel__number">{{ step + 1 }}.</div>
            <div class="chi-epanel__title">External Gateway Authentication</div>
            <div class="chi-epanel__content">
                <div class="chi-epanel__collapse">
                    <div class="-done--only"></div>
                </div>
            </div>
            <div class="chi-epanel__action -done--only">
                <button class="chi-button -primary -flat" data-chi-epanel-action="active" @click="clickExtChange">
                    Change
                </button>
            </div>
        </div>
        <div class="chi-epanel__collapse">
            <div class="-active--only">
                <div class="chi-epanel__body">
                    <div class="chi-epanel__content">
                        <div class="chi-form__item">
                            <div class="chi-checkbox" data-cy="cy-applicationKey__checkbox">
                                <div class="flex items-center">
                                    <input
                                        type="checkbox"
                                        value="appkey"
                                        class="chi-checkbox__input --xs flex items-center"
                                        id="checkbox-ch7"
                                        @change="changeExtApplicationKeyEvent($event)"
                                    />

                                    <label
                                        class="chi-checkbox__label -text--xs -text--primary -text--muted"
                                        for="checkbox-ch7"
                                        >Application Key – Consumers are issued an application key and secret. A Unix
                                        timestamp is encrypted using the secret, this digest,
                                    </label>
                                </div>
                            </div>
                            <label class="chi-checkbox__label -text--xs -text--primary -text--muted"
                                >the timestamp and application key are included as headers in the request</label
                            >
                            <br />
                            <div class="chi-alert -warning -sm" role="alert">
                                <i class="chi-alert__icon chi-icon icon-warning" aria-hidden="true"></i>
                                <div class="chi-alert__content" data-cy="cy-extauthenticationwarning">
                                    <p class="chi-alert__text">
                                        WARNING!: The value above is deprecated for EXTERNAL access. You may be required
                                        to make changes in the near future. Please consider an OAUTH based model to
                                        avoid future rework.
                                    </p>
                                </div>
                            </div>

                            <br />
                            <div class="chi-checkbox" data-cy="cy-basicAuthExternal__checkbox">
                                <input
                                    type="checkbox"
                                    value="basicAuth"
                                    @change="changeExtAuthenticationEvent($event)"
                                    class="chi-checkbox__input"
                                    id="checkbox-ch8"
                                />
                                <label
                                    class="chi-checkbox__label -text--xs -text--primary -text--muted"
                                    for="checkbox-ch8"
                                    >Basic Authentication – Lumen employees can provide their LDAP credentials in a
                                    basic authentication header. Access can be granted to
                                </label>
                            </div>
                            <label class="chi-checkbox__label -text--xs -text--primary -text--muted"
                                >LDAP users and/or groups.</label
                            >
                            <div class="chi-grid" v-if="authExt">
                                <div class="chi-col -w--6">
                                    <div class="chi-form__item">
                                        <label class="chi-label" for="ldap_users" data-cy="cy-LdapUserExt"
                                            >LDAP Users</label
                                        >
                                        <div class="chi-grid">
                                            <div class="chi-col -w--6" id="ldapUserFlex">
                                                <chi-text-input
                                                    id="ldap_users"
                                                    name="ldap_user"
                                                    ref="users2"
                                                    data-cy="cy-extLdapUser_textInput"
                                                    :state="isLDAPPanel ? 'danger' : ''"
                                                ></chi-text-input>
                                            </div>
                                            <div class="chi-col -w--3">
                                                <chi-button
                                                    color="primary"
                                                    data-cy="cy-extLdapUser_button"
                                                    @click="saveUsersExt()"
                                                    >Add</chi-button
                                                >
                                            </div>
                                        </div>
                                        <div class="chi-grid" v-if="extLdapUserList" data-cy="cy-extldapUserlist_grid">
                                            <div class="chi-col -w--9">
                                                <div class="chi-card">
                                                    <div class="chi-card__content">
                                                        <div class="chi-data-table">
                                                            <div class="chi-data-table__body">
                                                                <transition-group>
                                                                    <div
                                                                        class="chi-data-table__row"
                                                                        v-for="a in user2"
                                                                        :key="a"
                                                                        id="ldapusers"
                                                                    >
                                                                        <div
                                                                            class="chi-data-table__cell"
                                                                            id="chi-col-1"
                                                                        >
                                                                            <div>{{ a }}</div>
                                                                        </div>
                                                                        <div
                                                                            class="chi-data-table__cell"
                                                                            id="chi-col-2"
                                                                        >
                                                                            <div>
                                                                                <i
                                                                                    class="chi-icon icon-delete"
                                                                                    size="xs"
                                                                                    aria-hidden="true"
                                                                                    @click="deleteExtLdapUser(a)"
                                                                                    data-cy="cy-extLdapUser_delbutton"
                                                                                ></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </transition-group>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="chi-col -w--6">
                                    <div class="chi-form__item">
                                        <chi-label for="ldap_group" name="ldap_groups" data-cy="cy-LdapGroupExt"
                                            >LDAP Groups</chi-label
                                        >
                                        <div class="chi-grid">
                                            <div class="chi-col -w--9">
                                                <chi-text-input
                                                    id="ldap_group"
                                                    ref="groups2"
                                                    data-cy="cy-extLdapGroup_textInput"
                                                    :state="isLDAPPanel ? 'danger' : ''"
                                                ></chi-text-input>
                                            </div>
                                            <div class="chi-col -w--3">
                                                <chi-button
                                                    color="primary"
                                                    @click="saveGroupsExt()"
                                                    data-cy="cy-extLdapGroup_button"
                                                    >Add</chi-button
                                                >
                                            </div>
                                        </div>
                                        <div
                                            class="chi-grid"
                                            v-if="extLdapGroupList"
                                            data-cy="cy-extldapGrouplist_grid"
                                        >
                                            <div class="chi-col -w--9">
                                                <div class="chi-card">
                                                    <div class="chi-card__content">
                                                        <div class="chi-data-table">
                                                            <div class="chi-data-table__body">
                                                                <transition-group>
                                                                    <div
                                                                        class="chi-data-table__row"
                                                                        v-for="a in group2"
                                                                        :key="a"
                                                                        id="ldapgroup"
                                                                    >
                                                                        <div
                                                                            class="chi-data-table__cell"
                                                                            id="chi-col-1"
                                                                        >
                                                                            <div>{{ a }}</div>
                                                                        </div>
                                                                        <div
                                                                            class="chi-data-table__cell"
                                                                            id="chi-col-2"
                                                                        >
                                                                            <div>
                                                                                <i
                                                                                    class="chi-icon icon-delete"
                                                                                    size="xs"
                                                                                    aria-hidden="true"
                                                                                    @click="deleteExtLdapGroup(a)"
                                                                                    data-cy="cy-extLdapGroup_delbutton"
                                                                                ></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </transition-group>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="chi-grid" v-if="authExt">
                                <div
                                    class="chi-col chi-label -status -danger"
                                    v-if="isLDAPPanel"
                                    data-cy="cy-extLdapUser&Group-enforce"
                                >
                                    <chi-icon icon="circle-warning"></chi-icon>
                                    Please add LDAP Users and/or LDAP Groups to proceed.
                                </div>
                                <br />
                            </div>
                            <div class="chi-alert -warning -sm" role="alert">
                                <i class="chi-alert__icon chi-icon icon-warning" aria-hidden="true"></i>
                                <div class="chi-alert__content" data-cy="cy-extbasicauthwarning">
                                    <p class="chi-alert__text">
                                        WARNING!: The value above is deprecated for EXTERNAL access. You may be required
                                        to make changes in the near future. Please consider an OAUTH based model to
                                        avoid future rework.
                                    </p>
                                </div>
                            </div>
                            <br />
                            <div class="chi-checkbox" data-cy="cy-extoAuth__checkbox">
                                <input
                                    type="checkbox"
                                    class="chi-checkbox__input"
                                    value="oAuth"
                                    id="checkbox-ch5"
                                    @change="extoAuth($event)"
                                    v-model="extOauth"
                                    data-cy="cy-extoAuth"
                                />
                                <label
                                    class="chi-checkbox__label -text--xs -text--primary -text--muted"
                                    for="checkbox-ch5"
                                    >OAuth – Consumers are issued and clientId and secret that are used to request a
                                    token for access to endpoints (OAuth client credentials flow)</label
                                >
                            </div>
                            <div v-if="isLIAMPanel">
                                <fieldset>
                                    <legend></legend>
                                    <div class="chi-picker-group -fluid -mt--2">
                                        <div class="chi-picker-group__content">
                                            <input
                                                class="chi-picker__input"
                                                type="radio"
                                                name="OAuthName"
                                                id="legacyOAuthId"
                                                @click="clickIsLegacyOAuth($event)"
                                                checked
                                            />
                                            <label class="chi-picker-label__wrapper" for="legacyOAuthId">
                                                <div class="chi-picker-label">Legacy OAuth</div>
                                                <div class="chi-picker-label">Apigee or AzureB2C Only</div>
                                            </label>
                                            <input
                                                class="chi-picker__input"
                                                type="radio"
                                                name="OAuthName"
                                                id="liamJwtId"
                                                @click="clickIsLiamOAuth($event)"
                                            />
                                            <label class="chi-picker-label__wrapper" for="liamJwtId">
                                                <div class="chi-picker-label" required="isLIAMJWT">LIAM OAuth</div>
                                                <div class="chi-picker-label">
                                                    Apigee or Azure B2C with LIAM JWT Token Authorization
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </fieldset>
                            </div>
                            <div class="chi-checkbox -mt--2" data-cy="cy-extportalJwt__checkbox">
                                <input
                                    type="checkbox"
                                    class="chi-checkbox__input"
                                    id="checkbox-ch6"
                                    value="jwt"
                                    v-model="portalJwt"
                                    @change="portalJWT($event)"
                                    data-cy="cy-portalJwt"
                                />
                                <label
                                    class="chi-checkbox__label -text--xs -text--primary -text--muted"
                                    for="checkbox-ch6"
                                    >Portal Framework JWT – Consumers provide a Portal Framework JWT for access to
                                    endpoints</label
                                >
                            </div>
                        </div>
                        <div class="chi-label -status -danger" v-if="isCheckboxPanel5" data-cy="cy-ext-error__checkbox">
                            <chi-icon icon="circle-warning"></chi-icon>
                            Please check at least one checkbox
                        </div>
                    </div>
                    <div class="chi-epanel__footer -justify-content--end">
                        <button
                            class="chi-button -lg"
                            data-chi-epanel-action="previous"
                            @click="clickExtPrevious"
                            data-cy="cy-ext-previous__button"
                        >
                            Previous
                        </button>
                        <button
                            class="chi-button -lg -primary"
                            @click="clickExtContinue"
                            data-cy="cy-ext-continue__button"
                        >
                            Continue
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import { getModule } from 'vuex-module-decorators';
import ProxyModule, { STORE_KEY } from '@/modules/proxy/_store';
import { Compare } from '@/utils/compare';
import { ExpansionPanelStates, ExpansionPanels } from '../../_constants/proxy';

@Component
export default class ExternalGatewayAuthentication extends Vue {
    @Prop({ default: 3 }) step;
    private proxyStore!: ProxyModule;
    extAppkChkBx: boolean = false;
    extGatewayArr: string[] = [];
    extBasicAuthBx: boolean = false;
    extOAuthBx: boolean = false;
    extJWTBx: boolean = false;
    authExt: boolean = false;
    user2: string[] = [];
    extLdapUserList: boolean = false;
    group2: string[] = [];
    extLdapGroupList: boolean = false;
    isCheckboxPanel5: boolean = false;
    extOauth: any = '';
    portalJwt: any = '';
    isLIAMPanel = false;
    isLegacyOAuth = true;
    isLiamOAuth = false;
    checkIsLDAPErrorPanel: boolean = false;
    currentState = ExpansionPanelStates.Pending;
    isValidatedAtLeastOnce = false;

    get isLDAPPanel(): boolean {
        return this.checkIsLDAPErrorPanel && this.user2?.length === 0 && this.group2?.length === 0;
    }

    get isExternalGatewayAuthenticationValid(): boolean {
        return (
            !this.isCheckboxPanel5 &&
            (this.extAppkChkBx ||
                this.extJWTBx ||
                this.extOAuthBx ||
                (this.extBasicAuthBx && (this.extLdapUserList || this.extLdapGroupList))) &&
            !(this.extBasicAuthBx && !(this.extLdapUserList || this.extLdapGroupList))
        );
    }

    created() {
        const isModuleRegistered = Object.keys(this.$store.state).includes(STORE_KEY);
        if (!isModuleRegistered) {
            this.$store.registerModule(STORE_KEY, ProxyModule);
        }
        if (!this.proxyStore) {
            this.proxyStore = getModule(ProxyModule, this.$store);
        }
        this.$store.subscribe((mutation) => {
            const currentMutation = mutation.type.split('/')[1];
            if (currentMutation === 'setCurrentStep' || currentMutation === 'setCurrentStepCollapse') {
                this.setCurrentState(currentMutation);
            }
        });
    }

    changeExtApplicationKeyEvent(event): void {
        if (!this.extAppkChkBx) {
            this.extAppkChkBx = true;
            this.extGatewayArr?.push(event.target.value);
            this.isCheckboxPanel5 = false;
        } else {
            this.extAppkChkBx = false;
            const index = this.extGatewayArr.indexOf(event.target.value);
            if (index > -1) {
                this.extGatewayArr.splice(index, 1);
            }
        }
        this.checkCheckboxSelection();
        this.setDataInStore('authType', this.extGatewayArr);
    }

    changeExtAuthenticationEvent(event): void {
        if (!this.extBasicAuthBx) {
            this.extBasicAuthBx = true;
            this.extGatewayArr?.push(event.target.value);
            this.isCheckboxPanel5 = false;
        } else {
            this.extBasicAuthBx = false;
            const index = this.extGatewayArr.indexOf(event.target.value);
            if (index > -1) {
                this.extGatewayArr.splice(index, 1);
            }
        }
        this.checkCheckboxSelection();
        this.loadOAuthProperties();
        this.authExt = !this.authExt;
        this.setDataInStore('authType', this.extGatewayArr);
    }

    private loadOAuthProperties(): void {
        this.proxyStore.loadIsLegacyOAuth(this.isLegacyOAuth);
        this.proxyStore.loadIsLiamOAuth(this.isLiamOAuth);
    }

    extoAuth(event): void {
        if (!this.extOAuthBx) {
            this.extOAuthBx = true;
            this.extGatewayArr?.push(event.target.value);
            this.isCheckboxPanel5 = false;
            this.isLIAMPanel = true;
        } else {
            this.extOAuthBx = false;
            this.isLIAMPanel = false;
            const index = this.extGatewayArr.indexOf(event.target.value);
            if (index > -1) {
                this.extGatewayArr.splice(index, 1);
            }
        }
        this.checkCheckboxSelection();
        this.setDataInStore('authType', this.extGatewayArr);
    }

    portalJWT(event): void {
        if (!this.extJWTBx) {
            this.extJWTBx = true;
            this.extGatewayArr?.push(event.target.value);
            this.isCheckboxPanel5 = false;
        } else {
            this.extJWTBx = false;
            const index = this.extGatewayArr.indexOf(event.target.value);
            if (index > -1) {
                this.extGatewayArr.splice(index, 1);
            }
        }
        this.checkCheckboxSelection();
        this.setDataInStore('authType', this.extGatewayArr);
    }

    clickIsLegacyOAuth(event): void {
        this.isLegacyOAuth = event.target.value === 'on';
        this.isLiamOAuth = !this.isLegacyOAuth;
        this.loadOAuthProperties();
    }

    clickIsLiamOAuth(event): void {
        this.isLiamOAuth = event.target.value === 'on';
        this.isLegacyOAuth = !this.isLiamOAuth;
        this.loadOAuthProperties();
    }

    saveUsersExt(): void {
        let v = (this.$refs.users2 as HTMLInputElement).getElementsByTagName('input')[0].value;
        if (this.user2.includes(v) === false && v != '') {
            this.user2.push(v);
        }
        if (this.user2[0] != undefined) {
            this.extLdapUserList = true;
        } else {
            this.extLdapUserList = false;
        }
        (this.$refs.users2 as HTMLInputElement).getElementsByTagName('input')[0].value = '';
        this.setDataInStore('extLdapUserList', this.user2);
    }

    deleteExtLdapUser(a): void {
        const index = this.user2.indexOf(a);
        if (index > -1) {
            this.user2.splice(index, 1);
        }
        this.extLdapUserList = !Compare.isEmptyArray(this.user2);
        this.setDataInStore('extLdapUserList', this.user2);
    }

    saveGroupsExt(): void {
        let v = (this.$refs.groups2 as HTMLInputElement).getElementsByTagName('input')[0].value;

        if (this.group2.includes(v) === false && v != '') {
            this.group2.push(v);
        }
        if (this.group2[0] != undefined) {
            this.extLdapGroupList = true;
        } else {
            this.extLdapGroupList = false;
        }
        (this.$refs.groups2 as HTMLInputElement).getElementsByTagName('input')[0].value = '';
        this.setDataInStore('extLdapGroupList', this.group2);
    }

    deleteExtLdapGroup(a): void {
        const index = this.group2.indexOf(a);
        if (index > -1) {
            this.group2.splice(index, 1);
        }
        this.extLdapGroupList = !Compare.isEmptyArray(this.group2);
        this.setDataInStore('extLdapGroupList', this.group2);
    }

    checkCheckboxSelection() {
        if (!this.extOAuthBx && !this.extJWTBx && !this.extBasicAuthBx && !this.extAppkChkBx) {
            this.isCheckboxPanel5 = true;
        } else {
            this.isCheckboxPanel5 = false;
        }
    }

    private setDataInStore(key: string, value: any): void {
        this.proxyStore.loadExternalGatewayAuthenticationValidation(this.isExternalGatewayAuthenticationValid);
        switch (key) {
            case 'authType':
                this.proxyStore.loadExtGatewayArr(value);
                const isBasicAuthAdded = value?.length > 0 && value.includes('basicAuth');
                const listOfUsers = isBasicAuthAdded ? this.user2.toString() : [].toString();
                const listOfGroups = isBasicAuthAdded ? this.group2.toString() : [].toString();
                this.proxyStore.loadbasicAuthUsers({ property: 'external', users: listOfUsers });
                this.proxyStore.loadbasicAuthGroups({ property: 'external', groups: listOfGroups });
                break;
            case 'extLdapUserList':
                this.proxyStore.loadbasicAuthUsers({ property: 'external', users: value.toString() });
                break;
            case 'extLdapGroupList':
                this.proxyStore.loadbasicAuthGroups({ property: 'external', groups: value.toString() });
                break;
        }
    }

    private submitValidation(): boolean {
        this.checkIsLDAPErrorPanel = true;
        this.checkCheckboxSelection();
        return this.isExternalGatewayAuthenticationValid;
    }

    private setCurrentState(mutation: string): void {
        if (this.proxyStore.getCurrentStep === this.step) {
            if (mutation === 'setCurrentStep') {
                this.currentState = ExpansionPanelStates.Active;
            } else {
                this.currentState = this.isValidatedAtLeastOnce
                    ? ExpansionPanels.getStateByCollapse(this.submitValidation())
                    : ExpansionPanelStates.Pending;
            }
        }
    }

    clickExtChange(): void {
        ExpansionPanels.setChangeAction(this.proxyStore, this.step);
    }

    clickExtContinue(): void {
        if (this.submitValidation()) {
            this.isValidatedAtLeastOnce = true;
            this.currentState = ExpansionPanels.getContinueAction(this.proxyStore, this.step);
        }
    }

    clickExtPrevious(): void {
        this.currentState = this.isValidatedAtLeastOnce
            ? ExpansionPanels.getStateByCollapse(this.submitValidation())
            : ExpansionPanelStates.Pending;
        ExpansionPanels.setPreviousAction(this.proxyStore, this.step);
    }
}
</script>
