<template>
    <div :class="'chi-epanel -' + currentState" data-chi-epanel-group="proxy_chi__epanel" data-cy="cy-general__epanel">
        <div class="chi-epanel__header">
            <div class="chi-epanel__number">{{ step + 1 }}.</div>
            <div class="chi-epanel__title">General</div>
            <div class="chi-epanel__content">
                <div class="chi-epanel__collapse">
                    <div class="-done--only">
                        {{ consolidatedHeaderValue }}
                    </div>
                </div>
            </div>
            <div class="chi-epanel__action -done--only">
                <button class="chi-button -primary -flat" data-chi-epanel-action="active" @click="clickGenChange">
                    Change
                </button>
            </div>
        </div>
        <div class="chi-epanel__collapse">
            <div class="-active--only">
                <div class="chi-epanel__body">
                    <div class="chi-epanel__content">
                        <div class="chi-grid">
                            <div class="chi-col">
                                <div class="chi-form__item" id="vueSimple1">
                                    <label class="chi-label" for="example-baselect1">
                                        API Producer’s Application Key
                                        <abbr class="chi-label__required" title="Required field">*</abbr>
                                    </label>
                                    <vue-simple-suggest
                                        ref="suggest"
                                        mode="select"
                                        :list="items"
                                        @select="onAppKeySelect($event)"
                                        @input="onAppKeyInputChanged"
                                        :styles="autoCompleteStyle"
                                        :destyled="true"
                                        :filter-by-query="true"
                                    >
                                        <div class="chi-form__item">
                                            <div class="chi-input__wrapper -icon--right">
                                                <input
                                                    class="chi-input chi-search__input"
                                                    type="search"
                                                    aria-label="search input"
                                                    data-cy="cy-app-key__input"
                                                    placeholder="Start typing…"
                                                    v-model="selAppkey"
                                                    :id="isApplication ? 'simpledanger' : 'simple'"
                                                    :disabled="isAppKeyClearVisible"
                                                />
                                                <button class="chi-button -icon -flat -bg--none" aria-label="Search">
                                                    <div class="chi-button__content">
                                                        <i
                                                            class="chi-icon icon-search remove_effect"
                                                            aria-hidden="true"
                                                        ></i>
                                                    </div>
                                                </button>

                                                <button
                                                    v-if="isAppKeyClearVisible"
                                                    class="chi-button -icon -close -sm"
                                                    aria-label="Close"
                                                >
                                                    <div class="chi-button__content">
                                                        <i
                                                            class="chi-icon icon-x remove_color"
                                                            aria-hidden="true"
                                                            @click="clearValue"
                                                        ></i>
                                                    </div>
                                                </button>
                                            </div>
                                        </div>
                                    </vue-simple-suggest>
                                    <p
                                        class="card_categories -text--xs -text--primary -text--muted"
                                        data-cy="cy-appkeydesc_paragraph"
                                    >
                                        <a
                                            class="chi-link"
                                            href="https://serviceportalprod.corp.global.level3.com/#/ESP/ApplicationKeyRequest"
                                            rel="noreferrer noopener"
                                            onclick="window.open(this.href,'_blank');return false;"
                                            >Request an Application Key</a
                                        >
                                    </p>
                                    <div
                                        class="chi-label -status -danger"
                                        v-if="isApplication"
                                        data-cy="cy-general-error_Applicationkey"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Please select an Application Key from the list
                                    </div>
                                </div>
                            </div>
                            <div class="chi-col">
                                <div class="chi-form__item">
                                    <label class="chi-label" for="example-baInputmal"
                                        >CMS Asset Tag / ID #
                                        <abbr class="chi-label__required" title="Required field">*</abbr>
                                    </label>
                                    <input
                                        type="text"
                                        @input="onAssetInputChanged"
                                        placeholder="SYSGEN123456789"
                                        :class="[!isMalId ? 'chi-input' : 'chi-input -danger']"
                                        id="example-baInputmal"
                                        v-model="malId"
                                        data-cy="cy-app-key__select"
                                    />
                                    <p
                                        class="card_categories -text--xs -text--primary -text--muted"
                                        data-cy="cy-malIddesc_paragraph"
                                    >
                                        An entry in the Master Application List is required to expose an endpoint
                                        through the gateway,
                                        <a
                                            class="chi-link"
                                            href="https://directory.corp.intranet/cmsviewer/login.html?page=/cmsviewer/index.html"
                                            rel="noreferrer noopener"
                                            onclick="window.open(this.href,'_blank');return false;"
                                            >click here to request a CMS Asset Tag / ID #</a
                                        >
                                    </p>

                                    <div
                                        class="chi-label -status -danger"
                                        v-if="isMalId"
                                        data-cy="cy-general-error_MalId"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Please provide CMS Asset Tag / ID #
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br />
                        <div class="chi-grid">
                            <div class="chi-col">
                                <div class="chi-form__item">
                                    <div class="chi-checkbox" data-cy="cy-SOAP-checkbox">
                                        <input
                                            type="checkbox"
                                            @click="soap()"
                                            class="chi-checkbox__input"
                                            id="checkbox-ba1"
                                        />
                                        <label class="chi-checkbox__label" for="checkbox-ba1"
                                            ><strong>SOAP</strong></label
                                        >
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br />
                        <div class="chi-grid">
                            <div class="chi-col">
                                <div class="chi-form__item">
                                    <label class="chi-label" for="example-ba3">
                                        Type
                                        <abbr class="chi-label__required" title="Required field">*</abbr>
                                    </label>
                                    <select
                                        :class="[!isServType ? 'chi-select' : 'chi-select -danger']"
                                        id="example-ba3"
                                        @change="onServiceType($event)"
                                        data-cy="cy-service-type__select"
                                    >
                                        <option value="" selected>Select</option>
                                        <option value="Inbound">Inbound</option>
                                        <option value="Outbound">Outbound</option>
                                    </select>
                                    <div
                                        class="chi-label -status -danger"
                                        v-if="isServType"
                                        data-cy="cy-general-error_Service"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Please select a Service Type
                                    </div>
                                </div>
                            </div>
                            <div class="chi-col">
                                <div class="chi-form__item">
                                    <br />
                                    <label
                                        class="card_categories -text--xs -text--primary -text--muted"
                                        data-cy="cy-service-type__inbound"
                                    >
                                        Inbound - Endpoint service is inside the Lumen network
                                    </label>
                                    <label
                                        class="card_categories -text--xs -text--primary -text--muted"
                                        data-cy="cy-service-type__outbound"
                                    >
                                        Outbound - Endpoint service is outside the Lumen network
                                    </label>
                                </div>
                            </div>
                        </div>
                        <p>
                            <label class="chi-label" for="example-ba1">
                                Availability
                                <abbr class="chi-label__required" title="Required field">*</abbr>
                            </label>
                        </p>
                        <div class="chi-form__item">
                            <div class="chi-checkbox" data-cy="cy-internal-checkbox__div">
                                <input
                                    @change="availabitity($event, 'internal')"
                                    type="checkbox"
                                    class="chi-checkbox__input"
                                    id="checkbox-ch1"
                                    data-cy="cy-internal__checkbox"
                                />
                                <label
                                    class="chi-checkbox__label -text--xs -text--primary -text--muted"
                                    for="checkbox-ch1"
                                    >Internal - Consumers will access this endpoint from inside the Lumen
                                    firewall</label
                                >
                            </div>
                            <div class="chi-checkbox" data-cy="cy-external__checkbox_div">
                                <input
                                    @change="availabitity($event, 'external')"
                                    type="checkbox"
                                    class="chi-checkbox__input"
                                    id="checkbox-ch2"
                                    data-cy="cy-external__checkbox"
                                />
                                <label
                                    class="chi-checkbox__label -text--xs -text--primary -text--muted"
                                    for="checkbox-ch2"
                                    >External - Consumers will access this endpoint from outside the Lumen
                                    firewall</label
                                >
                            </div>
                        </div>
                        <div class="chi-label -status -danger" v-if="isCheckboxPanel1">
                            <chi-icon icon="circle-warning"></chi-icon>
                            Please select at least one checkbox
                        </div>
                    </div>
                    <div class="chi-epanel__footer -justify-content--end">
                        <button
                            class="chi-button -lg -primary"
                            @click="clickGenContinue()"
                            data-cy="cy-general-continue__button"
                        >
                            Continue
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import VueSimpleSuggest from 'vue-simple-suggest';
import { getModule } from 'vuex-module-decorators';
import ProxyModule, { STORE_KEY } from '@/modules/proxy/_store';
import { Compare } from '@/utils/compare';
Vue.component('vue-simple-suggest', VueSimpleSuggest);
import 'vue-simple-suggest/dist/styles.css';
import { ExpansionPanelStates, ExpansionPanels } from '../../_constants/proxy';

@Component
export default class General extends Vue {
    private proxyStore!: ProxyModule;
    changedInput: any = '';
    selAppkey: any = '';
    appKey: any[] = [];
    malId: string = '';
    isApplication: boolean = false;
    isMalId: boolean = false;
    soapType: any = '';
    selSerType: any;
    isServType: boolean = false;
    internalAvailability = false;
    externalAvailability = false;
    items: any[] = [];
    isCheckboxPanel1: boolean = false;
    autoCompleteStyle: any;
    $refs: any;
    step = 0;
    currentState = ExpansionPanelStates.Active;
    isAppKeyClearVisible = false;

    data() {
        return {
            autoCompleteStyle: {
                vueSimpleSuggest: 'position-relative',
                inputWrapper: '',
                defaultInput: 'form-control',
                suggestions: 'position-absolute list-group z-1000',
                suggestItem: 'list-group-item',
            },
        };
    }

    get consolidatedHeaderValue() {
        return this.proxyStore.getAppKey + ', ' + this.proxyStore.getMalId + ', ' + this.proxyStore.getType;
    }

    created() {
        if (!this.proxyStore) {
            this.proxyStore = getModule(ProxyModule, this.$store);
        }
        this.proxyStore.loadApplicationKeyData();
        this.$store.subscribe((mutation, state) => {
            const currentMutation = mutation.type.split('/')[1];
            const currentStore = state[STORE_KEY];
            if (currentMutation === 'setApplicationKey') {
                currentStore.appData.forEach((apky) => {
                    this.items.push(apky.applicationKeyID);
                });
            }
            if (currentMutation === 'setCurrentStep' || currentMutation === 'setCurrentStepCollapse') {
                this.setCurrentState(currentMutation);
            }
        });
    }

    clearValue() {
        this.selAppkey = '';
        this.isAppKeyClearVisible = false;
        this.malId = '';
        this.isApplication = true;
        this.onSetNewMalId(this.malId);
    }

    onAppKeyInputChanged(value): void {
        this.changedInput = value;
        this.selAppkey = value;
        this.proxyStore.loadAppKey(this.selAppkey);
        this.isApplication = Compare.isElementEmpty(this.changedInput);
        if (!this.isApplication) {
            this.proxyStore.getAppData.forEach((apky) => {
                if (this.changedInput == apky.applicationKeyID) {
                    this.malId = apky.itpkmServiceId;
                    this.isApplication = false;
                    this.isAppKeyClearVisible = true;
                    this.onSetNewMalId(this.malId);
                }
            });
        }
    }

    onAppKeySelect(event): void {
        if (event) {
            // needed timeout to delay the hide of the suggestions
            setTimeout(() => {
                this.$refs.suggest.hideList();
            }, 0);
        }
    }

    onAssetInputChanged(value): void {
        this.isMalId = Compare.isElementEmpty(this.malId);
        this.onSetNewMalId(this.malId);
    }

    private onSetNewMalId(malId: string) {
        this.proxyStore.loadMalID(malId);
        this.proxyStore.loadProxiesOwnership(malId);
    }

    onServiceType(event): void {
        this.selSerType = event.target.value;
        this.proxyStore.loadType(this.selSerType);
        this.isServType = !this.selSerType;
    }

    soap(): void {
        if (this.soapType === '') {
            this.soapType = true;
        } else {
            this.soapType = '';
        }
        this.proxyStore.loadSoap(this.soapType);
    }

    private submitValidation(): boolean {
        this.isApplication = Compare.isElementEmpty(this.changedInput);
        this.isMalId = Compare.isElementEmpty(this.malId);
        this.isServType = Compare.isElementEmpty(this.selSerType);
        this.checkAvailabilitySelection();
        if (!this.isAppKeyClearVisible) {
            this.isApplication = true;
        }
        return (
            !this.isApplication &&
            !this.isMalId &&
            !this.isServType &&
            !this.isCheckboxPanel1 &&
            this.isAppKeyClearVisible
        );
    }

    checkAvailabilitySelection(): void {
        if (!this.internalAvailability && !this.externalAvailability) {
            this.isCheckboxPanel1 = true;
        } else {
            this.isCheckboxPanel1 = false;
        }
    }

    private saveAvailabilityInStore(internalAvailability: boolean, externalAvailability: boolean): void {
        this.proxyStore.loadAvailabilityInternal(internalAvailability);
        this.proxyStore.loadAvailabilityExternal(externalAvailability);
    }

    availabitity($event, type: string): void {
        if (type === 'internal') {
            this.internalAvailability = $event.target.checked;
        }
        if (type === 'external') {
            this.externalAvailability = $event.target.checked;
        }
        this.checkAvailabilitySelection();
        this.saveAvailabilityInStore(this.internalAvailability, this.externalAvailability);
        if (!this.internalAvailability) {
            this.proxyStore.loadbasicAuthUsers({ property: 'internal', users: [] });
            this.proxyStore.loadbasicAuthGroups({ property: 'internal', groups: [] });
        }
        if (!this.externalAvailability) {
            this.proxyStore.loadbasicAuthUsers({ property: 'external', users: [] });
            this.proxyStore.loadbasicAuthGroups({ property: 'external', groups: [] });
        }
    }

    private setCurrentState(mutation: string): void {
        if (this.proxyStore.getCurrentStep === this.step) {
            this.currentState =
                mutation === 'setCurrentStep'
                    ? ExpansionPanelStates.Active
                    : ExpansionPanels.getStateByCollapse(this.submitValidation());
        }
    }

    clickGenChange(): void {
        ExpansionPanels.setChangeAction(this.proxyStore, this.step);
    }

    clickGenContinue(): void {
        if (this.submitValidation()) {
            this.currentState = ExpansionPanels.getContinueAction(this.proxyStore, this.step);
        }
    }
}
</script>
<style>
#simple {
    width: 100% !important;
    border: 0.0625rem solid #dadee2;
    border-radius: 0.25rem;
    color: #242526;
    display: block;
    font-size: 0.875rem;
    height: 2.5rem;
    line-height: 1.25rem;
    outline: none;
    padding: 0.5625rem 0.75rem;
    -webkit-transition: all 0.15s ease-in-out;
    transition: all 0.15s ease-in-out;
}
#simpledanger {
    width: 100% !important;
    border: 0.0625rem solid #dadee2;
    border-color: #ee3026;
    border-radius: 0.25rem;
    color: #242526;
    display: block;
    font-size: 0.875rem;
    height: 2.5rem;
    line-height: 1.25rem;
    outline: none;
    padding: 0.5625rem 0.75rem;
    -webkit-transition: all 0.15s ease-in-out;
    transition: all 0.15s ease-in-out;
}
.z-1000 {
    z-index: 1000;
}
.hover {
    background-color: #007bff;
    color: #fff;
}
.suggestions {
    opacity: 1;
}

.vue-simple-suggest-enter-active.suggestions,
.vue-simple-suggest-leave-active.suggestions {
    transition: opacity 0.2s;
}

.vue-simple-suggest-enter.suggestions,
.vue-simple-suggest-leave-to.suggestions {
    opacity: 0;
}

.remove_effect {
    color: #313336 !important;
    cursor: auto;
}

.remove_color {
    color: #313336 !important;
}
</style>
