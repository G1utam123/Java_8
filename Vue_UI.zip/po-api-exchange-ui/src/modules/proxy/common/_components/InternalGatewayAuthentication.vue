<template>
    <div
        :class="'chi-epanel -' + currentState"
        data-chi-epanel-group="proxy_chi__epanel"
        data-cy="cy-intActive__epanel"
    >
        <div class="chi-epanel__header">
            <div class="chi-epanel__number">{{ step + 1 }}.</div>
            <div class="chi-epanel__title">
                Internal Gateway<br />
                Authentication
            </div>
            <div class="chi-epanel__content">
                <div class="chi-epanel__collapse">
                    <div class="-done--only"></div>
                </div>
            </div>
            <div class="chi-epanel__action -done--only">
                <button class="chi-button -primary -flat" data-chi-epanel-action="active" @click="clickIntChange">
                    Change
                </button>
            </div>
        </div>
        <div class="chi-epanel__collapse">
            <div class="-active--only">
                <div class="chi-epanel__body">
                    <div class="chi-epanel__content">
                        <div class="chi-epanel__subtitle"></div>

                        <div class="chi-form__item">
                            <div class="chi-checkbox" data-cy="cy-appln-key__checkbox">
                                <div class="flex items-center">
                                    <input
                                        type="checkbox"
                                        value="appkey"
                                        class="chi-checkbox__input --xs flex items-center"
                                        id="checkbox-ch3"
                                        @change="changeApplicationKeyEvent($event)"
                                    />

                                    <label
                                        class="chi-checkbox__label -text--xs -text--primary -text--muted"
                                        for="checkbox-ch3"
                                        data-cy="cy-int-appln-key_label"
                                        >Application Key – Consumers are issued an application key and secret. A Unix
                                        timestamp is encrypted using the secret, this digest,
                                    </label>
                                </div>
                            </div>
                            <label class="chi-checkbox__label -text--xs -text--primary -text--muted"
                                >the timestamp and application key are included as headers in the request</label
                            >

                            <div class="chi-grid" v-if="applicationKeyCheckbox">
                                <div class="chi-col -o--2">
                                    <div class="chi-form__item -mr--30">
                                        <div class="chi-checkbox -mr--30" data-cy="cy-checkbox-enforceTaxonamy">
                                            <input
                                                type="checkbox"
                                                class="chi-checkbox__input"
                                                id="checkbox-enforce-ba1"
                                                v-model="enforceTaxonomy"
                                                @change="changeTaxonomy()"
                                            />
                                            <label class="chi-checkbox__label -text--xs" for="checkbox-enforce-ba1"
                                                ><strong>Enforce Taxonomy</strong></label
                                            >
                                        </div>
                                        <div class="chi-checkbox" data-cy="cy-checkbox-enforceDigest">
                                            <input
                                                type="checkbox"
                                                class="chi-checkbox__input"
                                                id="checkbox-enforce-ba2"
                                                v-model="enforceDigest"
                                                @change="changeEnforceDigest()"
                                            />
                                            <label class="chi-checkbox__label -text--xs" for="checkbox-enforce-ba2"
                                                ><strong>Enforce Digest</strong></label
                                            >
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="chi-checkbox" data-cy="cy-basicAuth__checkbox">
                                <input
                                    type="checkbox"
                                    value="basicAuth"
                                    @change="changeAuthenticationEvent($event)"
                                    class="chi-checkbox__input"
                                    id="checkbox-ch4"
                                />
                                <label
                                    class="chi-checkbox__label -text--xs -text--primary -text--muted"
                                    for="checkbox-ch4"
                                    data-cy="cy-int-basAuth_label"
                                    >Basic Authentication – Lumen employees can provide their LDAP credentials in a
                                    basic authentication header. Access can be granted to
                                </label>
                            </div>
                            <label class="chi-checkbox__label -text--xs -text--primary -text--muted"
                                >LDAP users and/or groups.</label
                            >
                        </div>
                        <div
                            class="chi-label -status -danger"
                            v-if="isCheckboxPanel4"
                            data-cy="cy-internal-error__checkbox"
                        >
                            <chi-icon icon="circle-warning"></chi-icon>
                            Please check at least one checkbox
                        </div>
                        <br />
                        <div class="chi-grid" v-if="authAct">
                            <div class="chi-col -w--6">
                                <div class="chi-form__item" data-cy="cy-LdapUser">
                                    <label class="chi-label" for="ldap_users_1">LDAP Users</label>
                                    <div class="chi-grid">
                                        <div class="chi-col -w--9">
                                            <chi-text-input
                                                id="ldap_users_1"
                                                name="ldap_user"
                                                ref="users1"
                                                data-cy="cy-intLdapUser_textInput"
                                                :state="isLDAPPanel ? 'danger' : ''"
                                            ></chi-text-input>
                                        </div>
                                        <div class="chi-col -w--3">
                                            <chi-button
                                                color="primary"
                                                @click="saveUsers()"
                                                data-cy="cy-intLdapUser_button"
                                                >Add</chi-button
                                            >
                                        </div>
                                    </div>
                                    <div class="chi-grid" v-if="ldapuserlist" data-cy="cy-intldapUserlist_grid">
                                        <div class="chi-col -w--9">
                                            <div class="chi-card">
                                                <div class="chi-card__content">
                                                    <div class="chi-data-table">
                                                        <div class="chi-data-table__body">
                                                            <transition-group>
                                                                <div
                                                                    class="chi-data-table__row"
                                                                    v-for="a in user1"
                                                                    :key="a"
                                                                    id="ldapusers_1"
                                                                >
                                                                    <div class="chi-data-table__cell" id="chi-col-1">
                                                                        <div data-cy="cy-intldapuserow_tablerow">
                                                                            {{ a }}
                                                                        </div>
                                                                    </div>
                                                                    <div class="chi-data-table__cell" id="chi-col-2">
                                                                        <div>
                                                                            <i
                                                                                class="chi-icon icon-delete"
                                                                                size="xs"
                                                                                aria-hidden="true"
                                                                                @click="deleteIntLdapUser(a)"
                                                                                data-cy="cy-intLdapUser_delbutton"
                                                                            ></i>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </transition-group>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="chi-col -w--6">
                                <div class="chi-form__item" data-cy="cy-LdapGroup">
                                    <chi-label for="ldap_group" name="ldap_groups">LDAP Groups</chi-label>
                                    <div class="chi-grid">
                                        <div class="chi-col -w--9">
                                            <chi-text-input
                                                id="ldap_group"
                                                ref="groups1"
                                                data-cy="cy-intLdapGroup_textInput"
                                                :state="isLDAPPanel ? 'danger' : ''"
                                            ></chi-text-input>
                                        </div>
                                        <div class="chi-col -w--3">
                                            <chi-button
                                                color="primary"
                                                @click="saveGroups()"
                                                data-cy="cy-intLdapGroup_button"
                                                >Add</chi-button
                                            >
                                        </div>
                                    </div>

                                    <div class="chi-grid" v-if="ldapgrouplist" data-cy="cy-intldapGrouplist_grid">
                                        <div class="chi-col -w--9">
                                            <div class="chi-card">
                                                <div class="chi-card__content">
                                                    <div class="chi-data-table">
                                                        <div class="chi-data-table__body">
                                                            <transition-group>
                                                                <div
                                                                    class="chi-data-table__row"
                                                                    v-for="a in group1"
                                                                    :key="a"
                                                                    id="ldapgroup"
                                                                >
                                                                    <div class="chi-data-table__cell" id="chi-col-1">
                                                                        <div>{{ a }}</div>
                                                                    </div>
                                                                    <div class="chi-data-table__cell" id="chi-col-2">
                                                                        <div>
                                                                            <i
                                                                                class="chi-icon icon-delete"
                                                                                size="xs"
                                                                                aria-hidden="true"
                                                                                @click="deleteIntLdapGroup(a)"
                                                                                data-cy="cy-intLdapGroup_delbutton"
                                                                            ></i>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </transition-group>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div
                                class="chi-col -w--6 chi-label -status -danger"
                                v-if="isLDAPPanel"
                                data-cy="cy-intLdapUser&Group-enforce"
                            >
                                <chi-icon icon="circle-warning"></chi-icon>
                                Please add LDAP Users and/or LDAP Groups to proceed.
                            </div>
                            <br />
                        </div>
                    </div>
                    <div class="chi-epanel__footer -justify-content--end">
                        <button class="chi-button -lg" data-chi-epanel-action="previous" @click="clickIntPrevious">
                            Previous
                        </button>
                        <button
                            class="chi-button -lg -primary"
                            @click="clickIntContinue"
                            data-cy="cy-internal-continue__button"
                        >
                            Continue
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { getModule } from 'vuex-module-decorators';
import ProxyModule from '@/modules/proxy/_store';
import { ExpansionPanelStates, ExpansionPanels } from '../../_constants/proxy';

@Component
export default class InternalGatewayAuthentication extends Vue {
    private proxyStore!: ProxyModule;
    enforceDigest: boolean = false;
    enforceTaxonomy: boolean = false;
    isAppkey: boolean = false;
    intGatewayArr: string[] = [];
    applicationKeyCheckbox: boolean = false;
    isBasAuth: boolean = false;
    authAct: boolean = false;
    user1: string[] = [];
    ldapuserlist: boolean = false;
    group1: string[] = [];
    ldapgrouplist: boolean = false;
    isCheckboxPanel4: boolean = false;
    checkIsLDAPErrorPanel: boolean = false;
    step = 3;
    currentState = ExpansionPanelStates.Pending;
    isValidatedAtLeastOnce = false;

    get isLDAPPanel(): boolean {
        return this.checkIsLDAPErrorPanel && this.user1?.length === 0 && this.group1?.length === 0;
    }

    get isInternalGatewayAuthenticationValid(): boolean {
        return (
            !this.isCheckboxPanel4 &&
            (this.isAppkey || (this.isBasAuth && (this.ldapuserlist || this.ldapgrouplist))) &&
            !(this.isBasAuth && !(this.ldapuserlist || this.ldapgrouplist))
        );
    }

    created() {
        if (!this.proxyStore) {
            this.proxyStore = getModule(ProxyModule, this.$store);
        }
        this.$store.subscribe((mutation) => {
            const currentMutation = mutation.type.split('/')[1];
            if (currentMutation === 'setCurrentStep' || currentMutation === 'setCurrentStepCollapse') {
                this.setCurrentState(currentMutation);
            }
        });
    }

    changeApplicationKeyEvent(event): void {
        if (!this.isAppkey) {
            this.isAppkey = true;
            this.intGatewayArr?.push(event.target.value);
            this.applicationKeyCheckbox = true;
            this.isCheckboxPanel4 = false;
        } else {
            this.isAppkey = false;
            this.applicationKeyCheckbox = false;
            const index = this.intGatewayArr.indexOf(event.target.value);
            if (index > -1) {
                this.intGatewayArr.splice(index, 1);
            }
        }
        this.checkCheckboxSelection();
        this.setDataInStore('intGatewayArr', this.intGatewayArr);
    }

    changeEnforceDigest(): void {
        this.proxyStore.setEnforceDigest(this.enforceDigest);
    }

    changeTaxonomy(): void {
        this.proxyStore.setEnforceTaxonomy(this.enforceTaxonomy);
    }

    private setDataInStore(key: string, value: any): void {
        this.proxyStore.loadInternalGatewayAuthenticationValidation(this.isInternalGatewayAuthenticationValid);
        switch (key) {
            case 'intGatewayArr':
                this.proxyStore.loadIntGatewayArr(value);
                let isAddAppKey = false;
                let isAddBasicAuth = false;
                if (value?.length > 0) {
                    value.forEach((element) => {
                        switch (element) {
                            case 'appkey':
                                isAddAppKey = true;
                                this.proxyStore.setEnforceDigest(this.enforceDigest);
                                this.proxyStore.setEnforceTaxonomy(this.enforceTaxonomy);
                                break;
                            case 'basicAuth':
                                isAddBasicAuth = true;
                                this.proxyStore.loadbasicAuthUsers({
                                    property: 'internal',
                                    users: this.user1.toString(),
                                });
                                this.proxyStore.loadbasicAuthGroups({
                                    property: 'internal',
                                    groups: this.group1.toString(),
                                });
                                break;
                        }
                    });
                }
                if (!isAddAppKey) {
                    this.proxyStore.setEnforceDigest(false);
                    this.proxyStore.setEnforceTaxonomy(false);
                }
                if (!isAddBasicAuth) {
                    this.proxyStore.loadbasicAuthUsers({ property: 'internal', users: [].toString() });
                    this.proxyStore.loadbasicAuthGroups({ property: 'internal', groups: [].toString() });
                }
                break;
            case 'ldapuserlist':
                this.proxyStore.loadbasicAuthUsers({ property: 'internal', users: value.toString() });
                break;
            case 'ldapgrouplist':
                this.proxyStore.loadbasicAuthGroups({ property: 'internal', groups: value.toString() });
                break;
        }
    }

    changeAuthenticationEvent(event: any): void {
        if (!this.isBasAuth) {
            this.isBasAuth = true;
            this.intGatewayArr?.push(event.target.value);
        } else {
            this.isBasAuth = false;
            const index = this.intGatewayArr.indexOf(event.target.value);
            if (index > -1) {
                this.intGatewayArr.splice(index, 1);
            }
        }
        this.checkCheckboxSelection();
        this.authAct = !this.authAct;
        this.setDataInStore('intGatewayArr', this.intGatewayArr);
    }

    saveUsers(): void {
        let v = (this.$refs.users1 as HTMLInputElement).getElementsByTagName('input')[0].value;

        if (this.user1.includes(v) === false && v != '') {
            this.user1.push(v);
        }
        if (this.user1[0] != undefined) {
            this.ldapuserlist = true;
        } else {
            this.ldapuserlist = false;
        }
        (this.$refs.users1 as HTMLInputElement).getElementsByTagName('input')[0].value = '';
        this.setDataInStore('ldapuserlist', this.user1);
    }

    deleteIntLdapUser(a): void {
        const index = this.user1.indexOf(a);
        if (index > -1) {
            this.user1.splice(index, 1);
        }

        if (this.user1.length == 0) {
            this.ldapuserlist = false;
        }
        this.setDataInStore('ldapuserlist', this.user1);
    }

    saveGroups(): void {
        let v = (this.$refs.groups1 as HTMLInputElement).getElementsByTagName('input')[0].value;

        if (this.group1.includes(v) === false && v != '') {
            this.group1.push(v);
        }
        if (this.group1[0] != undefined) {
            this.ldapgrouplist = true;
        } else {
            this.ldapgrouplist = false;
        }
        (this.$refs.groups1 as HTMLInputElement).getElementsByTagName('input')[0].value = '';
        this.setDataInStore('ldapgrouplist', this.group1);
    }

    deleteIntLdapGroup(a): void {
        const index = this.group1.indexOf(a);
        if (index > -1) {
            this.group1.splice(index, 1);
        }

        if (this.group1.length == 0) {
            this.ldapgrouplist = false;
        }
        this.setDataInStore('ldapgrouplist', this.group1);
    }

    checkCheckboxSelection() {
        if (!this.isAppkey && !this.isBasAuth) {
            this.isCheckboxPanel4 = true;
        } else {
            this.isCheckboxPanel4 = false;
        }
    }

    private submitValidation(): boolean {
        this.checkIsLDAPErrorPanel = true;
        this.checkCheckboxSelection();
        return this.isInternalGatewayAuthenticationValid;
    }

    private setCurrentState(mutation: string): void {
        if (this.proxyStore.getCurrentStep === this.step) {
            if (mutation === 'setCurrentStep') {
                this.currentState = ExpansionPanelStates.Active;
            } else {
                this.currentState = this.isValidatedAtLeastOnce
                    ? ExpansionPanels.getStateByCollapse(this.submitValidation())
                    : ExpansionPanelStates.Pending;
            }
        }
    }

    clickIntChange(): void {
        ExpansionPanels.setChangeAction(this.proxyStore, this.step);
    }

    clickIntContinue(): void {
        if (this.submitValidation()) {
            this.isValidatedAtLeastOnce = true;
            this.currentState = ExpansionPanels.getContinueAction(this.proxyStore, this.step);
        }
    }

    clickIntPrevious(): void {
        this.currentState = this.isValidatedAtLeastOnce
            ? ExpansionPanels.getStateByCollapse(this.submitValidation())
            : ExpansionPanelStates.Pending;
        ExpansionPanels.setPreviousAction(this.proxyStore, this.step);
    }
}
</script>
