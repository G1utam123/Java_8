<template>
    <div
        :class="'chi-epanel -' + currentState"
        data-chi-epanel-group="proxy_chi__epanel"
        data-cy="cy-targetEndpoint__epanel"
    >
        <div class="chi-epanel__header">
            <div class="chi-epanel__number">{{ step + 1 }}.</div>
            <div class="chi-epanel__title">Target Endpoint</div>
            <div class="chi-epanel__content">
                <div class="chi-epanel__collapse">
                    <div class="-done--only">
                        {{ consolidatedHeaderValue }}
                    </div>
                </div>
            </div>
            <div class="chi-epanel__action -done--only">
                <button class="chi-button -primary -flat" data-chi-epanel-action="active" @click="clickTEChange">
                    Change
                </button>
            </div>
        </div>
        <div class="chi-epanel__collapse">
            <div class="-active--only">
                <div class="chi-epanel__body">
                    <div class="chi-epanel__content">
                        <p class="card_categories -text--xs -text--primary -text--muted">
                            The target endpoint is the URL on your servers that the gateway will proxy to, the path is
                            made up of two parts: <br /><br /><strong>1. Environment Host</strong> - The host of your
                            server for each environment that you support(dev1, dev2, etc), for example
                            https://myserver-dev1.corp.intranet <br /><br /><strong>2. Path</strong> - The path on the
                            host where your resource is located, for example /path/to/my/resource. <br /><br />The two
                            attributes are combined to form the final URL: <br /><br /><u
                                >https://myserver-dev1.corp.intranet/path/to/my/resource</u
                            >
                        </p>
                        <br />
                        <div class="chi-grid">
                            <div class="chi-col">
                                <div class="chi-form__item">
                                    <label class="chi-label" for="dev1-host-id" data-cy="cy-dev1_label"
                                        >Dev1 Host</label
                                    >
                                    <input
                                        type="url"
                                        :class="[validHostnameDev1 && validEndDev1 ? activeClass : errorClass]"
                                        placeholder="http://mocktarget.apigee.net"
                                        id="dev1-host-id"
                                        v-model="dev1"
                                        @change="
                                            (validHostnameDev1 = isValidInput(dev1)), (validEndDev1 = isValidEnd(dev1))
                                        "
                                        @input="setDataInStore('dev1', dev1)"
                                        data-cy="cy-dev1-host__input"
                                    />
                                    <div
                                        class="chi-label -status -danger"
                                        style="margin-bottom: -2px"
                                        v-if="!validHostnameDev1"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Invalid syntax: start with {{ http_string }} or {{ https_string }}
                                    </div>
                                    <div
                                        class="chi-label -status -danger"
                                        style="margin-bottom: -2px"
                                        v-if="!validEndDev1"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Hostname cannot end in special characters like " / ? * , " etc
                                    </div>
                                </div>
                            </div>
                            <div class="chi-col">
                                <div class="chi-form__item">
                                    <label class="chi-label" for="dev2-host-id" data-cy="cy-dev2_label"
                                        >Dev2 Host</label
                                    >
                                    <input
                                        type="url"
                                        :class="[validHostnameDev2 && validEndDev2 ? activeClass : errorClass]"
                                        placeholder="http://mocktarget.apigee.net"
                                        id="dev2-host-id"
                                        v-model="dev2"
                                        @change="
                                            (validHostnameDev2 = isValidInput(dev2)), (validEndDev2 = isValidEnd(dev2))
                                        "
                                        @input="setDataInStore('dev2', dev2)"
                                        data-cy="cy-dev2-host__input"
                                    />
                                    <div
                                        class="chi-label -status -danger"
                                        style="margin-bottom: -2px"
                                        v-if="!validHostnameDev2"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Invalid syntax: start with {{ http_string }} or {{ https_string }}
                                    </div>
                                    <div
                                        class="chi-label -status -danger"
                                        style="margin-bottom: -2px"
                                        v-if="!validEndDev2"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Hostname cannot end in special characters like " / ? * , " etc
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br />
                        <div class="chi-grid">
                            <div class="chi-col">
                                <div class="chi-form__item">
                                    <label class="chi-label" for="dev3-host-id" data-cy="cy-dev3_label"
                                        >Dev3 Host</label
                                    >
                                    <input
                                        type="url"
                                        :class="[validHostnameDev3 && validEndDev3 ? activeClass : errorClass]"
                                        placeholder="http://mocktarget.apigee.net"
                                        id="dev3-host-id"
                                        v-model="dev3"
                                        @change="
                                            (validHostnameDev3 = isValidInput(dev3)), (validEndDev3 = isValidEnd(dev3))
                                        "
                                        @input="setDataInStore('dev3', dev3)"
                                        data-cy="cy-dev3-host__input"
                                    />
                                    <div
                                        class="chi-label -status -danger"
                                        style="margin-bottom: -2px"
                                        v-if="!validHostnameDev3"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Invalid syntax: start with {{ http_string }} or {{ https_string }}
                                    </div>
                                    <div
                                        class="chi-label -status -danger"
                                        style="margin-bottom: -2px"
                                        v-if="!validEndDev3"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Hostname cannot end in special characters like " / ? * , " etc
                                    </div>
                                </div>
                            </div>
                            <div class="chi-col">
                                <div class="chi-form__item">
                                    <label class="chi-label" for="dev4-host-id" data-cy="cy-dev4_label"
                                        >Dev4 Host</label
                                    >
                                    <input
                                        type="url"
                                        :class="[validHostnameDev4 && validEndDev4 ? activeClass : errorClass]"
                                        placeholder="http://mocktarget.apigee.net"
                                        id="dev4-host-id"
                                        v-model="dev4"
                                        @change="
                                            (validHostnameDev4 = isValidInput(dev4)), (validEndDev4 = isValidEnd(dev4))
                                        "
                                        @input="setDataInStore('dev4', dev4)"
                                        data-cy="cy-dev4-host__input"
                                    />
                                    <div
                                        class="chi-label -status -danger"
                                        style="margin-bottom: -2px"
                                        v-if="!validHostnameDev4"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Invalid syntax: start with {{ http_string }} or {{ https_string }}
                                    </div>
                                    <div
                                        class="chi-label -status -danger"
                                        style="margin-bottom: -2px"
                                        v-if="!validEndDev4"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Hostname cannot end in special characters like " / ? * , " etc
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br />
                        <div class="chi-grid">
                            <div class="chi-col">
                                <div class="chi-form__item">
                                    <label class="chi-label" for="test1-host-id" data-cy="cy-test1_label"
                                        >Test1 Host</label
                                    >
                                    <input
                                        type="url"
                                        :class="[validHostnameTest1 && validEndTest1 ? activeClass : errorClass]"
                                        placeholder="http://mocktarget.apigee.net"
                                        id="test1-host-id"
                                        v-model="test1"
                                        @change="
                                            (validHostnameTest1 = isValidInput(test1)),
                                                (validEndTest1 = isValidEnd(test1))
                                        "
                                        @input="setDataInStore('test1', test1)"
                                        data-cy="cy-test1-host__input"
                                    />
                                    <div
                                        class="chi-label -status -danger"
                                        style="margin-bottom: -2px"
                                        v-if="!validHostnameTest1"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Invalid syntax: start with {{ http_string }} or {{ https_string }}
                                    </div>
                                    <div
                                        class="chi-label -status -danger"
                                        style="margin-bottom: -2px"
                                        v-if="!validEndTest1"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Hostname cannot end in special characters like " / ? * , " etc
                                    </div>
                                </div>
                            </div>
                            <div class="chi-col">
                                <div class="chi-form__item">
                                    <label class="chi-label" for="test2-host-id" data-cy="cy-test2_label"
                                        >Test2 Host</label
                                    >
                                    <input
                                        type="url"
                                        :class="[validHostnameTest2 && validEndTest2 ? activeClass : errorClass]"
                                        placeholder="http://mocktarget.apigee.net"
                                        id="test2-host-id"
                                        v-model="test2"
                                        @change="
                                            (validHostnameTest2 = isValidInput(test2)),
                                                (validEndTest2 = isValidEnd(test2))
                                        "
                                        @input="setDataInStore('test2', test2)"
                                        data-cy="cy-test2-host__input"
                                    />
                                    <div
                                        class="chi-label -status -danger"
                                        style="margin-bottom: -2px"
                                        v-if="!validHostnameTest2"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Invalid syntax: start with {{ http_string }} or {{ https_string }}
                                    </div>
                                    <div
                                        class="chi-label -status -danger"
                                        style="margin-bottom: -2px"
                                        v-if="!validEndTest2"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Hostname cannot end in special characters like " / ? * , " etc
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br />
                        <div class="chi-grid">
                            <div class="chi-col">
                                <div class="chi-form__item">
                                    <label class="chi-label" for="test3-host-id" data-cy="cy-test3_label"
                                        >Test3 Host</label
                                    >
                                    <input
                                        type="url"
                                        :class="[validHostnameTest3 && validEndTest3 ? activeClass : errorClass]"
                                        placeholder="http://mocktarget.apigee.net"
                                        id="test3-host-id"
                                        v-model="test3"
                                        @change="
                                            (validHostnameTest3 = isValidInput(test3)),
                                                (validEndTest3 = isValidEnd(test3))
                                        "
                                        @input="setDataInStore('test3', test3)"
                                        data-cy="cy-test3-host__input"
                                    />
                                    <div
                                        class="chi-label -status -danger"
                                        style="margin-bottom: -2px"
                                        v-if="!validHostnameTest3"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Invalid syntax: start with {{ http_string }} or {{ https_string }}
                                    </div>
                                    <div
                                        class="chi-label -status -danger"
                                        style="margin-bottom: -2px"
                                        v-if="!validEndTest3"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Hostname cannot end in special characters like " / ? * , " etc
                                    </div>
                                    <div
                                        class="chi-label -status -danger"
                                        v-if="isDevbox"
                                        data-cy="cy-targetEndpoint-error_Host"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Please provide at least one Host<br />
                                    </div>
                                </div>
                            </div>
                            <div class="chi-col">
                                <div class="chi-form__item">
                                    <label class="chi-label" for="test4-host-id" data-cy="cy-test4_label"
                                        >Test4 Host</label
                                    >
                                    <input
                                        type="url"
                                        :class="[validHostnameTest4 && validEndTest4 ? activeClass : errorClass]"
                                        placeholder="http://mocktarget.apigee.net"
                                        id="test4-host-id"
                                        v-model="test4"
                                        @change="
                                            (validHostnameTest4 = isValidInput(test4)),
                                                (validEndTest4 = isValidEnd(test4))
                                        "
                                        @input="setDataInStore('test4', test4)"
                                        data-cy="cy-test4-host__input"
                                    />
                                    <div
                                        class="chi-label -status -danger"
                                        style="margin-bottom: -2px"
                                        v-if="!validHostnameTest4"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Invalid syntax: start with {{ http_string }} or {{ https_string }}
                                    </div>
                                    <div
                                        class="chi-label -status -danger"
                                        style="margin-bottom: -2px"
                                        v-if="!validEndTest4"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Hostname cannot end in special characters like " / ? * , " etc
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br />
                        <div class="chi-grid">
                            <div class="chi-col -w--6">
                                <div class="chi-form__item" data-cy="cy-resource-path__input">
                                    <label class="chi-label" for="resource-path-id">Resource Path </label>
                                    <input
                                        type="url"
                                        :class="[!isRsp ? 'chi-input' : 'chi-input -danger']"
                                        placeholder="/"
                                        v-model="resourcePath"
                                        @keyup="pathCheck()"
                                        @input="setDataInStore('resourcePath', resourcePath)"
                                        id="resource-path-id"
                                    />
                                    <div
                                        class="chi-label -status -danger"
                                        style="margin-bottom: -2px"
                                        v-if="isRsp"
                                        data-cy="cy-targetEndpoint-error_resourcepath"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        {{ resourcePathAlert }}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br /><br />
                        <div class="chi-epanel__footer -justify-content--end">
                            <button class="chi-button -lg" data-chi-epanel-action="previous" @click="clickTEPrevious">
                                Previous
                            </button>
                            <button
                                class="chi-button -lg -primary"
                                @click="clickTEContinue"
                                data-cy="cy-target-Endpoint-continue__button"
                            >
                                Continue
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { HTTP_STRING, HTTPS_STRING } from '@/modules/exchange/_constants/proxy';
import { Compare } from '@/utils/compare';
import { getModule } from 'vuex-module-decorators';
import ProxyModule from '@/modules/proxy/_store';
import { Validate } from '@/utils/validate';
import { ExpansionPanelStates, ExpansionPanels } from '../../_constants/proxy';

@Component
export default class TargetEndpoint extends Vue {
    private proxyStore!: ProxyModule;
    dev1: any = '';
    dev2: any = '';
    dev3: any = '';
    dev4: any = '';
    test1: any = '';
    test2: any = '';
    test3: any = '';
    test4: any = '';
    validHostnameDev1: boolean = true;
    validHostnameDev2: boolean = true;
    validHostnameDev3: boolean = true;
    validHostnameDev4: boolean = true;
    validHostnameTest1: boolean = true;
    validHostnameTest2: boolean = true;
    validHostnameTest3: boolean = true;
    validHostnameTest4: boolean = true;
    validEndDev1: boolean = true;
    validEndDev2: boolean = true;
    validEndDev3: boolean = true;
    validEndDev4: boolean = true;
    validEndTest1: boolean = true;
    validEndTest2: boolean = true;
    validEndTest3: boolean = true;
    validEndTest4: boolean = true;
    disable: boolean = true;
    isDevbox: boolean = false;
    resourcePath: any = '';
    isRsp: boolean = false;
    isValid: boolean = false;
    resourcePathAlert: string = '';
    http_string = HTTP_STRING;
    https_string = HTTPS_STRING;
    activeClass: any;
    errorClass: any;
    step = 2;
    currentState = ExpansionPanelStates.Pending;
    isValidatedAtLeastOnce = false;

    data() {
        return {
            activeClass: 'chi-input',
            errorClass: 'chi-input -danger',
        };
    }

    get consolidatedHeaderValue() {
        return this.resourcePath;
    }

    get isTargetEndpointValid(): boolean {
        return (
            !this.isRsp &&
            !(
                Compare.isElementEmpty(this.dev1) &&
                Compare.isElementEmpty(this.dev2) &&
                Compare.isElementEmpty(this.dev3) &&
                Compare.isElementEmpty(this.dev4) &&
                Compare.isElementEmpty(this.test1) &&
                Compare.isElementEmpty(this.test2) &&
                Compare.isElementEmpty(this.test3) &&
                Compare.isElementEmpty(this.test4)
            ) &&
            this.isValidInput(this.dev1) &&
            this.isValidInput(this.dev2) &&
            this.isValidInput(this.dev3) &&
            this.isValidInput(this.dev4) &&
            this.isValidInput(this.test1) &&
            this.isValidInput(this.test2) &&
            this.isValidInput(this.test3) &&
            this.isValidInput(this.test4) &&
            this.isValidEnd(this.dev1) &&
            this.isValidEnd(this.dev2) &&
            this.isValidEnd(this.dev3) &&
            this.isValidEnd(this.dev4) &&
            this.isValidEnd(this.test1) &&
            this.isValidEnd(this.test2) &&
            this.isValidEnd(this.test3) &&
            this.isValidEnd(this.test4)
        );
    }

    created() {
        if (!this.proxyStore) {
            this.proxyStore = getModule(ProxyModule, this.$store);
        }
        this.$store.subscribe((mutation) => {
            const currentMutation = mutation.type.split('/')[1];
            if (currentMutation === 'setCurrentStep' || currentMutation === 'setCurrentStepCollapse') {
                this.setCurrentState(currentMutation);
            }
        });
    }

    setDataInStore(key: string, value: string): void {
        this.proxyStore.loadTargetEndpointValidation(this.isTargetEndpointValid);
        switch (key) {
            case 'dev1':
                this.proxyStore.setDev1EndpointHostname(value);
                break;
            case 'dev2':
                this.proxyStore.setDev2EndpointHostname(value);
                break;
            case 'dev3':
                this.proxyStore.setDev3EndpointHostname(value);
                break;
            case 'dev4':
                this.proxyStore.setDev4EndpointHostname(value);
                break;
            case 'test1':
                this.proxyStore.setTest1EndpointHostname(value);
                break;
            case 'test2':
                this.proxyStore.setTest2EndpointHostname(value);
                break;
            case 'test3':
                this.proxyStore.setTest3EndpointHostname(value);
                break;
            case 'test4':
                this.proxyStore.setTest4EndpointHostname(value);
                break;
            case 'resourcePath':
                this.proxyStore.setEndpointPath(value);
                break;
        }
    }

    private submitValidation(): boolean {
        if (Compare.isElementEmpty(this.resourcePath) === false) {
            this.pathCheck();
        }
        this.isValid =
            this.isValidInput(this.dev1) &&
            this.isValidInput(this.dev2) &&
            this.isValidInput(this.dev3) &&
            this.isValidInput(this.dev4) &&
            this.isValidInput(this.test1) &&
            this.isValidInput(this.test2) &&
            this.isValidInput(this.test3) &&
            this.isValidInput(this.test4) &&
            this.isValidEnd(this.dev1) &&
            this.isValidEnd(this.dev2) &&
            this.isValidEnd(this.dev3) &&
            this.isValidEnd(this.dev4) &&
            this.isValidEnd(this.test1) &&
            this.isValidEnd(this.test2) &&
            this.isValidEnd(this.test3) &&
            this.isValidEnd(this.test4);
        this.isDevbox =
            Compare.isElementEmpty(this.dev1) &&
            Compare.isElementEmpty(this.dev2) &&
            Compare.isElementEmpty(this.dev3) &&
            Compare.isElementEmpty(this.dev4) &&
            Compare.isElementEmpty(this.test1) &&
            Compare.isElementEmpty(this.test2) &&
            Compare.isElementEmpty(this.test3) &&
            Compare.isElementEmpty(this.test4);
        return this.isTargetEndpointValid;
    }

    isValidInput(hostname: any): boolean {
        this.isValid = Compare.isElementEmpty(hostname);

        if (!this.isValid) {
            this.isDevbox = false;
            this.isValid = Validate.validateHostname(hostname);
        }

        return this.isValid;
    }

    isValidEnd(hostname: any): boolean {
        this.isValid = Compare.isElementEmpty(hostname);

        if (!this.isValid) {
            this.isDevbox = false;
            this.isValid = Validate.isValidDomain(hostname);
        }
        return this.isValid;
    }

    pathCheck(): boolean {
        const resourceValue = this.resourcePath;
        let regex = '^/[^\n ]*$';
        let specialCharRegex = /[\{\}\|\\\^\~\[\]#<>:]/g;
        if (resourceValue.length === 0) {
            this.isRsp = false;
        } else {
            if (resourceValue === '/' || resourceValue === '/ ') {
                this.isRsp = true;
                this.resourcePathAlert = 'Resource path should not be "/" alone';
            } else if (resourceValue.match(specialCharRegex)) {
                this.isRsp = true;
                this.resourcePathAlert = 'Resource path should not contain {, }, |, \, ^, ~, [, ], #, <, >, and :';
            } else if (resourceValue.match(regex)) {
                this.isRsp = false;
            } else {
                this.isRsp = true;
                this.resourcePathAlert = 'Resource path should begin with /';
            }
        }
        return this.isRsp;
    }

    private setCurrentState(mutation: string): void {
        if (this.proxyStore.getCurrentStep === this.step) {
            if (mutation === 'setCurrentStep') {
                this.currentState = ExpansionPanelStates.Active;
            } else {
                this.currentState = this.isValidatedAtLeastOnce
                    ? ExpansionPanels.getStateByCollapse(this.submitValidation())
                    : ExpansionPanelStates.Pending;
            }
        }
    }

    clickTEChange(): void {
        ExpansionPanels.setChangeAction(this.proxyStore, this.step);
    }

    clickTEContinue(): void {
        if (this.submitValidation()) {
            this.isValidatedAtLeastOnce = true;
            this.currentState = ExpansionPanels.getContinueAction(this.proxyStore, this.step);
        }
    }

    clickTEPrevious(): void {
        this.currentState = this.isValidatedAtLeastOnce
            ? ExpansionPanels.getStateByCollapse(this.submitValidation())
            : ExpansionPanelStates.Pending;
        ExpansionPanels.setPreviousAction(this.proxyStore, this.step);
    }
}
</script>
