<template>
    <div
        :class="'chi-epanel -' + currentState"
        data-chi-epanel-group="proxy_chi__epanel"
        data-cy="cy-managementRights__epanel"
    >
        <div class="chi-epanel__header">
            <div class="chi-epanel__number">{{ step + 1 }}.</div>
            <div class="chi-epanel__title">Management Rights</div>
            <div class="chi-epanel__content">
                <div class="chi-epanel__collapse">
                    <div class="-done--only"></div>
                </div>
            </div>
        </div>
        <div class="chi-epanel__collapse">
            <div class="-active--only">
                <div class="chi-epanel__body">
                    <div class="chi-epanel__content">
                        <div v-if="isNoOwners" class="chi-grid">
                            <div class="chi-col">
                                <AlertComponent :alertObject="alertObject" />
                            </div>
                        </div>
                        <br />
                        <div class="chi-grid -mt--1">
                            <div class="chi-col">
                                <div class="chi-label__wrapper">
                                    <chi-label for="owners__label-with-icon" required>Owners (3 maximum)</chi-label>
                                    <div class="chi-label__help">
                                        <chi-button
                                            id="owners__help-button"
                                            type="icon"
                                            size="xs"
                                            variant="flat"
                                            alternative-text="Help"
                                            data-cy="cy_owners__help-button"
                                        >
                                            <chi-icon icon="circle-info-outline"></chi-icon>
                                        </chi-button>
                                        <chi-popover
                                            id="owners__help-popover"
                                            position="right"
                                            variant="text"
                                            arrow
                                            reference="#owners__help-button"
                                            data-cy="cy_owners__help-popover"
                                        >
                                            <div>
                                                <b>{{ messages.ownerPopoverTitle }}</b>
                                            </div>
                                            <div class="-mt--1">{{ messages.ownerPopoverCapability1 }}</div>
                                            <div>{{ messages.ownerPopoverCapability2 }}</div>
                                            <div>{{ messages.ownerPopoverCapability3 }}</div>
                                            <div>{{ messages.ownerPopoverCapability4 }}</div>
                                            <div>{{ messages.ownerPopoverCapability5 }}</div>
                                        </chi-popover>
                                    </div>
                                </div>
                                <div v-for="(item, key) in owners" :key="key">
                                    <div class="chi-grid">
                                        <div class="chi-col -w--11">
                                            <input
                                                :data-cy="'cy-input-owner-' + key"
                                                class="chi-input"
                                                type="text"
                                                :id="'unique-owner' + key"
                                                :value="item"
                                                @input="changeOwner($event, key)"
                                                placeholder="Last Name, First Name"
                                            />
                                        </div>
                                        <div class="chi-col -w--1 no-padding">
                                            <chi-button
                                                v-if="key !== 0"
                                                type="icon"
                                                variant="flat"
                                                color="primary"
                                                alternative-text="Remove Owner"
                                                data-tooltip="Remove Owner"
                                                data-cy="cy-button-remove-owner"
                                                size="sm"
                                                @chiClick="removeOwner(key)"
                                            >
                                                <chi-icon icon="circle-minus-outline"></chi-icon>
                                            </chi-button>
                                        </div>
                                    </div>
                                    <br />
                                </div>
                                <div>
                                    <chi-button
                                        size="xs"
                                        data-cy="cy-button-add-owner"
                                        @chiClick="addOwner()"
                                        :disabled="!isAddOwnersVisible"
                                    >
                                        <chi-icon icon="circle-plus-outline"></chi-icon>
                                        <span>Add Owner</span>
                                    </chi-button>
                                </div>
                            </div>
                            <div class="chi-col"></div>
                        </div>
                        <div class="chi-grid -mt--6">
                            <div class="chi-col">
                                <div class="chi-label__wrapper">
                                    <chi-label>Admins</chi-label>
                                    <div class="chi-label__help">
                                        <chi-button
                                            id="admins__help-button"
                                            type="icon"
                                            size="xs"
                                            variant="flat"
                                            alternative-text="Help"
                                            data-cy="cy_admins__help-button"
                                        >
                                            <chi-icon icon="circle-info-outline"></chi-icon>
                                        </chi-button>
                                        <chi-popover
                                            id="admins__help-popover"
                                            position="right"
                                            variant="text"
                                            arrow
                                            reference="#admins__help-button"
                                            data-cy="cy_admins__help-popover"
                                        >
                                            <div>
                                                <b>{{ messages.adminPopoverTitle }}</b>
                                            </div>
                                            <div class="-mt--1">{{ messages.adminPopoverCapability1 }}</div>
                                            <div>{{ messages.adminPopoverCapability2 }}</div>
                                        </chi-popover>
                                    </div>
                                </div>
                                <div v-for="(item, key) in admins" :key="key">
                                    <div class="chi-grid">
                                        <div class="chi-col -w--11">
                                            <input
                                                :data-cy="'cy-input-admin-' + key"
                                                class="chi-input"
                                                type="text"
                                                :id="'unique-admin' + key"
                                                :value="item"
                                                @input="changeAdmin($event, key)"
                                                placeholder="Last Name, First Name"
                                            />
                                        </div>
                                        <div class="chi-col -w--1 no-padding">
                                            <chi-button
                                                type="icon"
                                                variant="flat"
                                                color="primary"
                                                alternative-text="Remove Admin"
                                                data-tooltip="Remove Admin"
                                                data-cy="cy-button-remove-admin"
                                                size="sm"
                                                @chiClick="removeAdmin(key)"
                                            >
                                                <chi-icon icon="circle-minus-outline"></chi-icon>
                                            </chi-button>
                                        </div>
                                    </div>
                                    <br />
                                </div>
                                <div>
                                    <chi-button size="xs" data-cy="cy-button-add-admin" @chiClick="addAdmin()">
                                        <chi-icon icon="circle-plus-outline"></chi-icon>
                                        <span>Add Admin</span>
                                    </chi-button>
                                </div>
                            </div>
                            <div class="chi-col"></div>
                        </div>
                        <br />
                    </div>
                    <div class="chi-epanel__footer -justify-content--end">
                        <button class="chi-button -lg" data-chi-epanel-action="previous" @click="clickManagPrevious">
                            Previous
                        </button>
                        <button
                            class="chi-button -lg -primary"
                            @click="clickCreateProxy"
                            data-cy="cy-mrights_finish__button"
                        >
                            Create Proxy
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class="chi-backdrop -center" v-if="isRemovingOwners">
            <div class="chi-backdrop__wrapper">
                <section id="modal-1" class="chi-modal" role="dialog" aria-label="Modal description" aria-modal="true">
                    <header class="chi-modal__header">
                        <h2 class="chi-modal__title">Delete Owner</h2>
                        <button class="chi-button -icon -close" data-dismiss="modal" aria-label="Close">
                            <div class="chi-button__content">
                                <i class="chi-icon icon-x" aria-hidden="true" @click="closeModalCancel()"></i>
                            </div>
                        </button>
                    </header>
                    <div class="chi-modal__content">
                        <div class="chi-grid">
                            <div class="chi-col -w--1">
                                <chi-icon icon="warning" color="warning" size="sm--3"></chi-icon>
                            </div>
                            <div class="chi-col -w--11">
                                <p class="-text--bold -m--0">
                                    Are you sure that you want to delete this owner -{{
                                        owners[ownerIndexToBeRemoved]
                                    }}-?
                                </p>
                                <br />
                                <p class="-text -m--0">
                                    If you made this selection in error or have changed your mind, click Cancel.
                                    Otherwise click Confirm to proceed.
                                </p>
                            </div>
                        </div>
                    </div>
                    <footer class="chi-modal__footer">
                        <button class="chi-button" @click="closeModalCancel()" data-cy="cancel_remove_owner_button">
                            CANCEL
                        </button>
                        <button
                            class="chi-button -primary"
                            @click="closeModalConfirm()"
                            data-cy="confirm_remove_owner_button"
                        >
                            CONFIRM
                        </button>
                    </footer>
                </section>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import { getModule } from 'vuex-module-decorators';
import ProxyModule from '@/modules/proxy/_store';
import AlertComponent from '@/modules/common/_components/AlertComponent.vue';
import { Alert } from '@/models/alert';
import { ALERTMSGAPB } from '@/modules/proxy/_constants/AlertMessages';
import { ExpansionPanelStates, ExpansionPanels, Validations } from '../../_constants/proxy';
import { ElementTypes, GroupRequest } from '../../_models/groupRequest';
import { Compare } from '@/utils/compare';
import { UserContext } from '@/utils/entities/userContext';

@Component({
    components: {
        AlertComponent,
    },
})
export default class EndpointAuthentication extends Vue {
    @Prop({ default: false }) internalAvailability;
    @Prop({ default: false }) externalAvailability;
    @Prop({ default: 4 }) step;
    private proxyStore!: ProxyModule;
    owners: string[] = [];
    admins: string[] = [];
    isOwnersEmpty = false;
    alertObject: Alert = new Alert('At least one owner is required to proceed.', {
        color: 'danger',
        icon: 'circle-x',
        closable: false,
    });
    maxOwners = 3;
    isRemovingOwners = false;
    ownerIndexToBeRemoved = -1;
    messages = ALERTMSGAPB;
    currentState = ExpansionPanelStates.Pending;

    get isNoOwners(): boolean {
        return this.owners?.length >= 1 && this.isOwnersEmpty;
    }

    get isAddOwnersVisible(): boolean {
        return this.owners?.length < this.maxOwners;
    }

    created() {
        if (!this.proxyStore) {
            this.proxyStore = getModule(ProxyModule, this.$store);
        }
        this.owners.push(this.$store.state.userContext.details.displayUsername);
        this.$store.subscribe((mutation) => {
            const currentMutation = mutation.type.split('/')[1];
            if (currentMutation === 'setCurrentStep' || currentMutation === 'setCurrentStepCollapse') {
                this.setCurrentState(currentMutation);
            }
        });
    }

    async mounted() {
        this.setPopoverOwners();
        this.setPopoverAdmins();
    }

    addAdmin(): void {
        this.admins.push('');
    }

    addOwner(): void {
        this.owners.push('');
    }

    removeAdmin(key: number): void {
        this.admins.splice(key, 1);
    }

    removeOwner(key: number): void {
        this.ownerIndexToBeRemoved = key;
        this.toogleModal(true);
    }

    changeAdmin(event: any, key: number): void {
        this.admins[key] = event.target.value;
    }

    changeOwner(event: any, key: number): void {
        this.owners[key] = event.target.value;
        this.isOwnersEmpty = this.checkIsEmptyOwners();
    }

    private checkIsEmptyOwners(): boolean {
        let isEmpty = true;
        this.owners.forEach((element) => {
            if (element?.trim().length > 0) {
                isEmpty = false;
            }
        });
        return isEmpty;
    }

    private setPopoverOwners(): void {
        const popoverOwners = document.querySelector('#owners__help-button');
        if (popoverOwners) {
            popoverOwners.addEventListener('click', function () {
                const popoverElem: any = document.querySelector('#owners__help-popover');
                if (popoverElem) {
                    popoverElem.toggle();
                }
            });
        }
    }

    private setPopoverAdmins(): void {
        const popoverAdmins = document.querySelector('#admins__help-button');
        if (popoverAdmins) {
            popoverAdmins.addEventListener('click', function () {
                const popoverElem: any = document.querySelector('#admins__help-popover');
                if (popoverElem) {
                    popoverElem.toggle();
                }
            });
        }
    }

    private toogleModal(visible: boolean): void {
        this.isRemovingOwners = visible;
    }

    closeModalCancel(): void {
        this.toogleModal(false);
    }

    closeModalConfirm(): void {
        this.owners.splice(this.ownerIndexToBeRemoved, 1);
        this.isOwnersEmpty = this.checkIsEmptyOwners();
        this.toogleModal(false);
    }

    submitValidation(): boolean {
        return Validations.submitApiCreation(this.proxyStore) && !this.isNoOwners;
    }

    private setCurrentState(mutation: string): void {
        if (this.proxyStore.getCurrentStep === this.step) {
            this.currentState =
                mutation === 'setCurrentStep'
                    ? ExpansionPanelStates.Active
                    : ExpansionPanels.getStateByCollapse(this.submitValidation());
        }
    }

    clickCreateProxy(): void {
        if (this.submitValidation()) {
            const token = localStorage.getItem('token');
            this.proxyStore.setGroupRequest(
                new GroupRequest(
                    ElementTypes.Proxy,
                    this.proxyStore.getMalId,
                    Compare.removeEmptyEntries(this.admins),
                    Compare.removeEmptyEntries(this.owners),
                    UserContext.parseJwt(token).cuid
                )
            );
            this.$emit('clickLastPanelFinish');
        } else {
            this.currentState = ExpansionPanelStates.Pending;
            this.proxyStore.setCurrentStep(ExpansionPanels.getNextStep(this.step));
        }
    }

    clickManagPrevious(): void {
        this.currentState = ExpansionPanels.getStateByCollapse(this.submitValidation());
        ExpansionPanels.setPreviousAction(this.proxyStore, this.step);
    }
}
</script>
<style>
.no-padding {
    padding: 0 !important;
}
</style>
