<template>
    <div :class="'chi-epanel -' + currentState" data-chi-epanel-group="proxy_chi__epanel" data-cy="cy-endPoint__epanel">
        <div class="chi-epanel__header">
            <div class="chi-epanel__number">{{ step + 1 }}.</div>
            <div class="chi-epanel__title">Endpoint Authentication</div>
            <div class="chi-epanel__content">
                <div class="chi-epanel__collapse">
                    <div class="-done--only"></div>
                </div>
            </div>
            <div class="chi-epanel__action -done--only">
                <button class="chi-button -primary -flat" data-chi-epanel-action="active" @click="clickEndAuthChange">
                    Change
                </button>
            </div>
        </div>
        <div class="chi-epanel__collapse">
            <div class="-active--only">
                <div class="chi-epanel__body">
                    <div class="chi-epanel__content">
                        <div class="chi-grid">
                            <div class="chi-col -w--4" id="authTypeSelect">
                                <div class="chi-form__item">
                                    <label class="chi-label" for="example-ba1"
                                        >Authentication Type
                                        <abbr class="chi-label__required" title="Required field">*</abbr></label
                                    >
                                    <select
                                        :class="[!isAuthenticationEmpty ? 'chi-select' : 'chi-select -danger']"
                                        id="authentication-type__select"
                                        @change="authType($event)"
                                        v-model="authenticationType"
                                        data-cy="cy-authentication-type__select"
                                    >
                                        <option value="">- Select -</option>
                                        <option value="none">None</option>
                                        <option value="authHeaderPassThrough">Authorization Header Pass-through</option>
                                        <option value="basicAuth">Basic Auth</option>
                                        <option value="jwt">JWT</option>
                                        <option value="oAuth">OAuth</option>
                                        <option value="x509Cert">x509 Certificate</option>
                                    </select>
                                    <div class="chi-label -status -danger" v-if="isAuthenticationEmpty">
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Please select Authentication Type
                                    </div>
                                </div>
                                <br /><br />
                            </div>
                            <div class="chi-col -w--4"></div>
                        </div>
                        <div class="chi-grid" v-if="basicAuth">
                            <div class="chi-col -w--2"></div>
                            <div class="chi-col -w--4" data-cy="cy-basicAuth_uname">
                                <div class="chi-form__item">
                                    <label class="chi-label" for="example__base1">
                                        Username
                                        <abbr class="chi-label__required" title="Required field">*</abbr></label
                                    >
                                    <input
                                        type="text"
                                        :class="[!isUser ? 'chi-input' : 'chi-input -danger']"
                                        @change="userValidation"
                                        v-model="endpointBasicUser"
                                        id="example__base1"
                                    />
                                    <div class="chi-label -status -danger" v-if="isUser">
                                        <chi-icon icon="circle-warning"></chi-icon>Please enter a Username
                                    </div>
                                </div>
                            </div>

                            <div class="chi-col -w--4" data-cy="cy-basicAuth_pwd">
                                <div class="chi-form__item">
                                    <chi-label for="example__base2"
                                        >Password
                                        <abbr class="chi-label__required" title="Required field">*</abbr></chi-label
                                    >
                                    <input
                                        type="password"
                                        :class="[!isPasswd ? 'chi-input' : 'chi-input -danger']"
                                        @change="passValidation"
                                        v-model="endpointBasicPassword"
                                        id="example__base2"
                                    />
                                    <div class="chi-label -status -danger" v-if="isPasswd">
                                        <chi-icon icon="circle-warning"></chi-icon>Please enter a password
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="chi-grid" v-if="certificate">
                            <div class="chi-col -w--4"></div>
                            <div class="chi-col -w--4">
                                <div class="chi-form__item" data-cy="cy-xcert">
                                    <chi-label for="example__base3"
                                        >Certificate Alias
                                        <abbr class="chi-label__required" title="Required field">*</abbr></chi-label
                                    ><input
                                        type="text"
                                        :class="[!isCert ? 'chi-input' : 'chi-input -danger']"
                                        v-model="x509CertAlias"
                                        @change="x509CertValidation()"
                                        id="example__base3"
                                    />

                                    <div class="chi-label -status -danger" v-if="isCert">
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Please enter a Certificate Alias
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div v-if="oAuth">
                            <div class="chi-grid" data-cy="cy-oauth">
                                <div class="chi-col -w--4">
                                    <div class="chi-form__item">
                                        <label class="chi-label" for="example-ba1" id="labelGrantType"
                                            >Grant Type
                                            <abbr class="chi-label__required" title="Required field">*</abbr></label
                                        >
                                        <select
                                            :class="[!isoauthGrantType ? 'chi-input' : 'chi-input -danger']"
                                            id="grantTypeSelect"
                                            @change="grantType($event)"
                                            v-model="oauthGrantType"
                                            data-cy="cy-grant-type__select"
                                        >
                                            <option value="">Select</option>
                                            <option value="client_credentials">Client Credentials</option>
                                            <option value="password">Password</option>
                                            <option value="jwt-bearer">JWT Bearer</option>
                                        </select>
                                        <div class="chi-label -status -danger" v-if="isoauthGrantType">
                                            <chi-icon icon="circle-warning"></chi-icon>
                                            Please select a Grant Type
                                        </div>
                                    </div>
                                </div>
                                <div class="chi-col -w--4">
                                    <div class="chi-form__item">
                                        <label class="chi-label" for="example-ba1"
                                            >Location
                                            <abbr class="chi-label__required" title="Required field">*</abbr></label
                                        >
                                        <select
                                            :class="[!isoauthGrantloc ? 'chi-select' : 'chi-select -danger']"
                                            id="example-ba1"
                                            @change="grantTypeLocValidation"
                                            v-model="oauthGrantloc"
                                            data-cy="cy-grant-loc__select"
                                        >
                                            <option value="">Select</option>
                                            <option value="Query Parameter">Query Parameter</option>
                                            <option value="Form Parameter">Form Parameter</option>
                                        </select>
                                        <div class="chi-label -status -danger" v-if="isoauthGrantloc">
                                            <chi-icon icon="circle-warning"></chi-icon>
                                            Please select a Location
                                        </div>
                                    </div>
                                </div>

                                <div class="chi-col -w--4"></div>
                            </div>

                            <br /><br />

                            <div class="chi-grid">
                                <div class="chi-col -w--4">
                                    <div class="chi-form__item">
                                        <chi-label for="example__danger1"
                                            >Token Hostname<abbr class="chi-label__required" title="Required field"
                                                >*</abbr
                                            ></chi-label
                                        >
                                        <input
                                            :class="[!isHostName ? 'chi-input' : 'chi-input -danger']"
                                            id="example__danger1"
                                            placeholder="my.token.host"
                                            v-model="tokenHost"
                                            @keyup="hostValidation"
                                            data-cy="cy-token-host__input"
                                        />
                                        <div class="chi-label -status -danger" v-if="isHostName">
                                            <chi-icon icon="circle-warning"></chi-icon>
                                            {{ tokenHostAlert }}
                                        </div>
                                    </div>
                                </div>
                                <div class="chi-col -w--4">
                                    <div class="chi-form__item">
                                        <chi-label for="example__danger2"
                                            >Token Path<abbr class="chi-label__required" title="Required field"
                                                >*</abbr
                                            ></chi-label
                                        >
                                        <input
                                            type="text"
                                            :class="[isPath ? 'chi-input' : 'chi-input -danger']"
                                            @input="pathValidation"
                                            id="example__danger2"
                                            placeholder="/token"
                                            v-model="tokenPath"
                                            data-cy="cy-token-path__input"
                                        />
                                        <div class="chi-label -status -danger" v-if="!isPath">
                                            <chi-icon icon="circle-warning"></chi-icon>{{ resourcePathAlert }}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br /><br />
                            <div class="chi-grid">
                                <div class="chi-col -w--4">
                                    <div class="chi-form__item">
                                        <chi-label for="example__base">Scope</chi-label>
                                        <input type="text" class="chi-input" id="example__base" v-model="oauthscope" />
                                    </div>
                                </div>
                                <div class="chi-col -w--4">
                                    <div class="chi-form__item">
                                        <label class="chi-label" for="example-ba1">Location </label>
                                        <select
                                            data-cy="cy-grant-loc__select_2"
                                            class="chi-select"
                                            id="example-ba1"
                                            v-model="oauthScopeloc"
                                        >
                                            <option value="">Select</option>
                                            <option value="Query Parameter">Query Parameter</option>
                                            <option value="Form Parameter">Form Parameter</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <br /><br />

                            <div class="chi-grid" v-if="grantClient">
                                <div class="chi-col -w--4">
                                    <div class="chi-form__item">
                                        <chi-label for="example__danger3"
                                            >Client ID<abbr class="chi-label__required" title="Required field"
                                                >*</abbr
                                            ></chi-label
                                        >
                                        <input
                                            type="text"
                                            :class="[!isId ? 'chi-input' : 'chi-input -danger']"
                                            id="example__danger3"
                                            @change="oauthClietIdValidation"
                                            data-cy="cy-oauth_cl_id"
                                            v-model="oauthClientId"
                                        />
                                        <div class="chi-label -status -danger" v-if="isId">
                                            <chi-icon icon="circle-warning"></chi-icon>
                                            Please enter a Client ID
                                        </div>
                                    </div>
                                </div>
                                <div class="chi-col -w--4">
                                    <div class="chi-form__item">
                                        <chi-label for="example__danger4"
                                            >Client Secret<abbr class="chi-label__required" title="Required field"
                                                >*</abbr
                                            ></chi-label
                                        >
                                        <input
                                            type="text"
                                            :class="[!isSecret ? 'chi-input' : 'chi-input -danger']"
                                            id="example__danger4"
                                            @change="oauthClSecretValidation"
                                            data-cy="cy-oauth_cl_secret"
                                            v-model="oauthClSecret"
                                        />
                                        <div class="chi-label -status -danger" v-if="isSecret">
                                            <chi-icon icon="circle-warning"></chi-icon>
                                            Please enter a Client Secret
                                        </div>
                                    </div>
                                </div>
                                <div class="chi-col -w--4">
                                    <div class="chi-form__item">
                                        <label class="chi-label" for="example-ba1"
                                            >Location
                                            <abbr class="chi-label__required" title="Required field">*</abbr></label
                                        >
                                        <select
                                            data-cy="cy-grant-loc__select_3"
                                            :class="[!isoauthClientloc ? 'chi-select' : 'chi-select -danger']"
                                            id="example-ba1"
                                            @change="oauthClientlocValidation"
                                            v-model="oauthClientloc"
                                        >
                                            <option value="">Select</option>
                                            <option value="Query Parameter">Query Parameter</option>
                                            <option value="Form Parameter">Form Parameter</option>
                                            <option value="Basic Auth">Basic Auth</option>
                                        </select>
                                        <div class="chi-label -status -danger" v-if="isoauthClientloc">
                                            <chi-icon icon="circle-warning"></chi-icon>
                                            Please select a location
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="chi-grid" v-if="grantPwd">
                                <div class="chi-col -w--4">
                                    <div class="chi-form__item">
                                        <chi-label for="example__base"
                                            >Username<abbr class="chi-label__required" title="Required field">*</abbr>
                                        </chi-label>
                                        <input
                                            type="text"
                                            :class="[!isoauthgtpwdUserName ? 'chi-input' : 'chi-input -danger']"
                                            id="example__base"
                                            data-cy="cy-oauth_username"
                                            v-model="oauthgtpwdUserName"
                                            @change="oauthUser($event)"
                                            name="oauthname"
                                        />
                                        <div class="chi-label -status -danger" v-if="isoauthgtpwdUserName">
                                            <chi-icon icon="circle-warning"></chi-icon>
                                            Please provide a Username
                                        </div>
                                    </div>
                                </div>

                                <div class="chi-col -w--4">
                                    <div class="chi-form__item">
                                        <chi-label for="example__base"
                                            >Password<abbr class="chi-label__required" title="Required field"
                                                >*</abbr
                                            ></chi-label
                                        >
                                        <input
                                            :class="[!isoauthgtpwdPassword ? 'chi-input' : 'chi-input -danger']"
                                            id="oauthgtpwdPassword"
                                            data-cy="cy-oauth_password"
                                            type="password"
                                            @change="oauthPassword($event)"
                                            name="oauthgtpwdPassword"
                                            v-model="oauthgtpwdPassword"
                                        />
                                        <div class="chi-label -status -danger" v-if="isoauthgtpwdPassword">
                                            <chi-icon icon="circle-warning"></chi-icon>
                                            Please provide a Password
                                        </div>
                                    </div>
                                </div>

                                <div class="chi-col -w--4">
                                    <div class="chi-form__item">
                                        <label class="chi-label" for="example-ba1"
                                            >Location<abbr class="chi-label__required" title="Required field">*</abbr>
                                        </label>
                                        <select
                                            data-cy="cy-grant-loc__select_4"
                                            :class="[!isoauthgtpwdLoc ? 'chi-select' : 'chi-select -danger']"
                                            id="example-ba1"
                                            @change="oauthPwdLocValidation"
                                            v-model="oauthgtpwdLoc"
                                        >
                                            <option value="">Select</option>
                                            <option value="Query Parameter">Query Parameter</option>
                                            <option value="Form Parameter">Form Parameter</option>
                                            <option value="Basic Auth">Basic Auth</option>
                                        </select>
                                        <div class="chi-label -status -danger" v-if="isoauthgtpwdLoc">
                                            <chi-icon icon="circle-warning"></chi-icon>
                                            Please select a location
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="chi-grid" v-if="grantJwt">
                                <div class="chi-col -w--4">
                                    <div class="chi-form__item">
                                        <chi-label for="example__base"
                                            >Username<abbr class="chi-label__required" title="Required field">*</abbr>
                                        </chi-label>
                                        <input
                                            type="text"
                                            :class="[!isoauthgtjwtUserName ? 'chi-input' : 'chi-input -danger']"
                                            id="example__base"
                                            v-model="oauthgtjwtUserName"
                                            @change="oauthjwtUser($event)"
                                            data-cy="cy-grant-jwt-username__input"
                                        />
                                        <div class="chi-label -status -danger" v-if="isoauthgtjwtUserName">
                                            <chi-icon icon="circle-warning"></chi-icon>
                                            Please provide a Username
                                        </div>
                                    </div>
                                </div>
                                <div class="chi-col -w--4">
                                    <div class="chi-form__item">
                                        <chi-label for="example__base"
                                            >KVM<abbr class="chi-label__required" title="Required field">*</abbr>
                                        </chi-label>
                                        <input
                                            type="text"
                                            :class="[!isoauthgtjwtKvm ? 'chi-input' : 'chi-input -danger']"
                                            id="example__base"
                                            placeholder="SFDC@Dev1"
                                            v-model="oauthgtjwtKvm"
                                            @change="oauthjwtKvm($event)"
                                            data-cy="cy-grant-jwt-kvm__input"
                                        />
                                        <div class="chi-label -status -danger" v-if="isoauthgtjwtKvm">
                                            <chi-icon icon="circle-warning"></chi-icon>
                                            Please provide a KVM
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="chi-epanel__footer -justify-content--end">
                        <button
                            class="chi-button -lg"
                            @click="clickEndAuthPrevious"
                            data-cy="cy-endpoint-authentication-previous__button"
                        >
                            Previous
                        </button>
                        <button
                            v-if="isManagementRights"
                            class="chi-button -lg -primary"
                            @click="clickEndAuthContinue"
                            data-cy="cy-endpoint-authentication-continue__button"
                        >
                            Continue
                        </button>
                        <button
                            v-else
                            class="chi-button -lg -primary"
                            @click="clickCreateProxy"
                            data-cy="cy-endpoint_finish__button"
                        >
                            Create Proxy
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import { getModule } from 'vuex-module-decorators';
import ProxyModule, { STORE_KEY } from '@/modules/proxy/_store';
import { Compare } from '@/utils/compare';
import { ExpansionPanelStates, ExpansionPanels, Validations } from '../../_constants/proxy';

@Component
export default class EndpointAuthentication extends Vue {
    @Prop({ default: false }) internalAvailability;
    @Prop({ default: false }) externalAvailability;
    @Prop({ default: false }) isManagementRights: any;
    @Prop({ default: 3 }) step;
    private proxyStore!: ProxyModule;
    basicAuth: boolean = false;
    authenticationType: any = '';
    endpointBasicUser: string = '';
    endpointBasicPassword: string = '';
    x509CertAlias: string = '';
    oauthGrantType: any = '';
    tokenHost: string = '';
    tokenPath: string = '';
    oauthscope: string = '';
    oauthScopeloc: any = '';
    oauthClientId: string = '';
    oauthClSecret: string = '';
    oauthClientloc: any = '';
    oauthgtpwdUserName: string = '';
    oauthgtpwdPassword: string = '';
    certificate: boolean = false;
    oAuth: boolean = false;
    grantPwd: boolean = false;
    grantClient: boolean = false;
    grantJwt: boolean = false;
    isHostName: boolean = false;
    tokenHostAlert: any = 'Please enter a Host';
    oauthgtjwtUserName: string = '';
    oauthgtjwtKvm: string = '';
    isUser: boolean = false;
    isPasswd: boolean = false;
    isCert: boolean = false;
    isPath: boolean = true;
    isId: boolean = false;
    isSecret: boolean = false;
    isoauthgtjwtUserName: boolean = false;
    isoauthgtjwtKvm: boolean = false;
    isoauthGrantType: boolean = false;
    isoauthGrantloc: boolean = false;
    isoauthClientloc: boolean = false;
    isoauthgtpwdUserName: boolean = false;
    isoauthgtpwdPassword: boolean = false;
    isoauthgtpwdLoc: boolean = false;
    oauthgtpwdLoc: any = '';
    oauthGrantloc: any = '';
    isPrimaryButtonClick = false;
    resourcePathAlert: string = '';
    currentState = ExpansionPanelStates.Pending;
    isValidatedAtLeastOnce = false;

    get isAuthenticationEmpty(): boolean {
        return this.isPrimaryButtonClick && this.authenticationType?.trim().length <= 0;
    }

    created() {
        if (!this.proxyStore) {
            this.proxyStore = getModule(ProxyModule, this.$store);
        }
        this.$store.subscribe((mutation, state) => {
            const currentMutation = mutation.type.split('/')[1];
            const currentStore = state[STORE_KEY];
            if (currentMutation === 'setCurrentStep' && currentStore.currentStep === this.step) {
                this.updateAuthenticationEndpointTypes();
                this.currentState = ExpansionPanelStates.Active;
            }
            if (currentMutation === 'setCurrentStepCollapse' && currentStore.currentStep === this.step) {
                this.onCollapse();
            }
            if (currentMutation === 'setAvailabilityExternal' && !currentStore.availabilityExternal) {
                const selectType = document.getElementById('authentication-type__select') as HTMLSelectElement;
                const namedItem = selectType.namedItem('LIAMJwt');
                if (namedItem) {
                    this.authenticationType = '';
                    selectType.remove(5);
                    this.currentState = ExpansionPanelStates.Pending;
                }
            }
        });
    }

    private updateAuthenticationEndpointTypes(): void {
        const selectType = document.getElementById('authentication-type__select') as HTMLSelectElement;
        if (selectType) {
            const namedItem = selectType.namedItem('LIAMJwt');
            if (this.proxyStore.availabilityExternal && this.proxyStore.isLiamOAuth) {
                if (!namedItem) {
                    const opt = document.createElement('option');
                    opt.value = 'LIAMJwt';
                    opt.text = 'LIAM JWT';
                    opt.id = 'LIAMJwt';
                    selectType.add(opt, 5);
                }
            } else {
                if (namedItem) {
                    this.authenticationType = '';
                    selectType.remove(5);
                }
            }
        }
    }

    authType(e: any): void {
        if (e.target.value == 'basicAuth') {
            this.basicAuth = true;
            this.certificate = false;
            this.oAuth = false;
        } else if (e.target.value == 'x509Cert') {
            this.basicAuth = false;
            this.oAuth = false;
            this.certificate = true;
        } else if (e.target.value == 'oAuth') {
            this.oAuth = true;
            this.basicAuth = false;
            this.certificate = false;
        } else {
            this.basicAuth = false;
            this.certificate = false;
            this.oAuth = false;
        }
    }

    grantType(e: any): void {
        if (e.target.value == 'client_credentials') {
            this.grantClient = true;
            this.grantPwd = false;
            this.grantJwt = false;
        } else if (e.target.value == 'password') {
            this.grantPwd = true;
            this.grantClient = false;
            this.grantJwt = false;
        } else if (e.target.value == 'jwt-bearer') {
            this.grantJwt = true;
            this.grantPwd = false;
            this.grantClient = false;
        } else {
            this.grantPwd = false;
            this.grantClient = false;
            this.grantJwt = false;
        }
        this.isoauthGrantType = false;
    }

    hostValidation(): void {
        this.isHostName = Compare.isElementEmpty(this.tokenHost);
        if (this.isHostName) {
            this.tokenHostAlert = 'Please enter a Host';
        } else {
            if (this.tokenHost === 'https://' || this.tokenHost === 'http://') {
                this.isHostName = true;
                this.tokenHostAlert = 'Please do not start hostname with https:// or http://';
            } else {
                this.isHostName = false;
            }
        }
    }

    oauthUser(event): void {
        this.oauthgtpwdUserName = event.target.value;
        this.oauthPwdUserNameValidation();
    }

    oauthPassword(event): void {
        this.oauthgtpwdPassword = event.target.value;
        this.oauthPwdPassValidation();
    }

    oauthjwtUser(event): void {
        this.oauthgtjwtUserName = event.target.value;
        this.oauthJWTUserNameValidation();
    }

    oauthjwtKvm(event): void {
        this.oauthgtjwtKvm = event.target.value;
        this.oauthJWTKVMValidation();
    }

    checkValuesToTrue([...values]) {
        let valid = true;
        for (let index of values) {
            if (index) {
                valid = false;
            }
        }
        return valid;
    }

    async setEndpointAuthenticationByAuthenticationType(authenticationType: any): Promise<boolean> {
        this.proxyStore.setEndpointAuthenticationData({});
        switch (authenticationType) {
            case 'basicAuth': {
                return this.basicAuthValidation();
            }
            case 'oAuth': {
                return this.oAuthValidation();
            }
            case 'x509Cert': {
                return this.x509CertValidation();
            }
            case 'none':
            case 'jwt':
            case 'LIAMJwt':
            case 'authHeaderPassThrough': {
                return this.authHeaderPassThroughValidation();
            }
        }
        return false;
    }

    async authHeaderPassThroughValidation(): Promise<boolean> {
        await this.proxyStore.setEndpointAuthenticationData({ endpointAuth: this.authenticationType });
        return true;
    }

    async x509CertValidation(): Promise<boolean> {
        this.x509CertAliasValidation();
        const valid = this.checkValuesToTrue([this.isCert]);
        if (valid) {
            await this.proxyStore.setEndpointAuthenticationData({
                endpointAuth: this.authenticationType,
                x509CertAlias: this.x509CertAlias,
            });
            return valid;
        }
        return false;
    }

    async x509CertAliasValidation() {
        this.isCert = Compare.isElementEmpty(this.x509CertAlias);
    }

    async grantTypeValidation() {
        this.isoauthGrantType = Compare.isElementEmpty(this.oauthGrantType);
    }

    async grantTypeLocValidation() {
        this.isoauthGrantloc = Compare.isElementEmpty(this.oauthGrantloc);
    }

    async oauthPwdUserNameValidation() {
        this.isoauthgtpwdUserName = Compare.isElementEmpty(this.oauthgtpwdUserName);
    }

    async oauthPwdPassValidation() {
        this.isoauthgtpwdPassword = Compare.isElementEmpty(this.oauthgtpwdPassword);
    }

    async oauthPwdLocValidation() {
        this.isoauthgtpwdLoc = Compare.isElementEmpty(this.oauthgtpwdLoc);
    }

    async oauthJWTUserNameValidation() {
        this.isoauthgtjwtUserName = Compare.isElementEmpty(this.oauthgtjwtUserName);
    }

    async oauthJWTKVMValidation() {
        this.isoauthgtjwtKvm = Compare.isElementEmpty(this.oauthgtjwtKvm);
    }

    async oauthClietIdValidation() {
        this.isId = Compare.isElementEmpty(this.oauthClientId);
    }

    async oauthClSecretValidation() {
        this.isSecret = Compare.isElementEmpty(this.oauthClSecret);
    }

    async oauthClientlocValidation() {
        this.isoauthClientloc = Compare.isElementEmpty(this.oauthClientloc);
    }

    async oAuthValidation(): Promise<boolean> {
        this.grantTypeValidation();
        this.grantTypeLocValidation();
        this.hostValidation();
        this.pathValidation(this.tokenPath);
        if (this.oauthGrantType === 'client_credentials') {
            this.oauthClietIdValidation();
            this.oauthClSecretValidation();
            this.oauthClientlocValidation();
            const valid =
                this.isPath &&
                this.checkValuesToTrue([
                    this.isHostName,
                    this.isoauthGrantType,
                    this.isoauthGrantloc,
                    this.isId,
                    this.isSecret,
                    this.isoauthClientloc,
                ]);
            if (valid) {
                await this.proxyStore.setEndpointAuthenticationData({
                    endpointAuth: this.authenticationType,
                    oauthScope: this.oauthscope,
                    oauthScopeLocation: this.oauthScopeloc,
                    oauthGrantType: this.oauthGrantType,
                    oauthGrantLocation: this.oauthGrantloc,
                    oauthTokenServiceHost: this.tokenHost,
                    oauthTokenServiceURI: this.tokenPath,
                    oauthClientId: this.oauthClientId,
                    oauthClientIdLocation: this.oauthClientloc,
                    oauthSecret: this.oauthClSecret,
                });

                return valid;
            }
        } else if (this.oauthGrantType === 'password') {
            this.oauthPwdUserNameValidation();
            this.oauthPwdPassValidation();
            this.oauthPwdLocValidation();
            const valid =
                this.isPath &&
                this.checkValuesToTrue([
                    this.isHostName,
                    this.isoauthGrantType,
                    this.isoauthGrantloc,
                    this.isoauthgtpwdUserName,
                    this.isoauthgtpwdPassword,
                    this.isoauthgtpwdLoc,
                ]);
            if (valid) {
                await this.proxyStore.setEndpointAuthenticationData({
                    endpointAuth: this.authenticationType,
                    oauthScope: this.oauthscope,
                    oauthScopeLocation: this.oauthScopeloc,
                    oauthGrantType: this.oauthGrantType,
                    oauthGrantLocation: this.oauthGrantloc,
                    oauthTokenServiceHost: this.tokenHost,
                    oauthTokenServiceURI: this.tokenPath,
                    oauthUserName: this.oauthgtpwdUserName,
                    oauthpw: this.oauthgtpwdPassword,
                    oauthCredentialsLocation: this.oauthgtpwdLoc,
                });
                return valid;
            }
        } else if (this.oauthGrantType === 'jwt-bearer') {
            this.oauthJWTUserNameValidation();
            this.oauthJWTKVMValidation();
            const valid =
                this.isPath &&
                this.checkValuesToTrue([
                    this.isHostName,
                    this.isoauthGrantType,
                    this.isoauthGrantloc,
                    this.isoauthgtjwtUserName,
                    this.isoauthgtjwtKvm,
                ]);
            if (valid) {
                await this.proxyStore.setEndpointAuthenticationData({
                    endpointAuth: this.authenticationType,
                    oauthScope: this.oauthscope,
                    oauthScopeLocation: this.oauthScopeloc,
                    oauthGrantType: this.oauthGrantType,
                    oauthGrantLocation: this.oauthGrantloc,
                    oauthTokenServiceHost: this.tokenHost,
                    oauthTokenServiceURI: this.tokenPath,
                    oauthKvmUserName: this.oauthgtjwtUserName,
                    oauthKVM: this.oauthgtjwtKvm,
                });
                return valid;
            }
        }
        return false;
    }

    async userValidation() {
        this.isUser = Compare.isElementEmpty(this.endpointBasicUser);
    }

    async passValidation() {
        this.isPasswd = Compare.isElementEmpty(this.endpointBasicPassword);
    }

    async basicAuthValidation(): Promise<boolean> {
        this.userValidation();
        this.passValidation();
        const valid = this.checkValuesToTrue([this.isUser, this.isPasswd]);
        if (valid) {
            await this.proxyStore.setEndpointAuthenticationData({
                endpointAuth: this.authenticationType,
                endpointBasicAuthUserAll: this.endpointBasicUser,
                endpointBasicAuthPwAll: this.endpointBasicPassword,
            });
            return valid;
        }
        return false;
    }

    async pathValidation(resourcePath) {
        let resourceValue = resourcePath !== '' && resourcePath.target ? resourcePath.target.value : resourcePath;
        let regex = '^/[^\n ]*$';
        if (Compare.isElementEmpty(resourceValue)) {
            this.isPath = false;
            this.resourcePathAlert = 'Please enter a Path';
        } else {
            if (resourceValue === '/' || resourceValue === '/ ') {
                this.isPath = false;
                this.resourcePathAlert = 'Resource path should not be "/" alone';
            } else if (resourceValue.match(regex)) {
                this.isPath = true;
            } else {
                this.isPath = false;
                this.resourcePathAlert = 'Resource path should begin with /';
            }
        }
        return this.isPath;
    }

    async submitValidation(isOnlyValidatingEndpointAuthentication?: boolean): Promise<boolean> {
        this.isPrimaryButtonClick = true;
        let isValid = false;
        if (
            (isOnlyValidatingEndpointAuthentication && !this.isAuthenticationEmpty) ||
            (Validations.submitApiCreation(this.proxyStore) && !this.isAuthenticationEmpty)
        ) {
            await this.setEndpointAuthenticationByAuthenticationType(this.authenticationType).then(
                (isSetEndpointValid) => {
                    isValid = isSetEndpointValid;
                }
            );
        }
        return isValid;
    }

    async clickCreateProxy() {
        if (await this.submitValidation()) {
            this.$emit('clickLastPanelFinish');
        } else {
            this.currentState = ExpansionPanelStates.Pending;
            this.proxyStore.setCurrentStep(ExpansionPanels.getNextStep(this.step));
        }
    }

    clickEndAuthChange(): void {
        ExpansionPanels.setChangeAction(this.proxyStore, this.step);
    }

    async clickEndAuthContinue(): Promise<void> {
        if (await this.submitValidation(true)) {
            this.isValidatedAtLeastOnce = true;
            this.currentState = ExpansionPanels.getContinueAction(this.proxyStore, this.step);
        }
    }

    clickEndAuthPrevious(): void {
        this.onCollapse();
        ExpansionPanels.setPreviousAction(this.proxyStore, this.step);
    }

    async onCollapse() {
        this.currentState = this.isValidatedAtLeastOnce
            ? ExpansionPanels.getStateByValidation(await this.submitValidation(true))
            : ExpansionPanelStates.Pending;
    }
}
</script>
