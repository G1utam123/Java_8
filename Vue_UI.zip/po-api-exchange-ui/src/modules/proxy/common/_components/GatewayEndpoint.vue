<template>
    <div
        :class="'chi-epanel -' + currentState"
        data-chi-epanel-group="proxy_chi__epanel"
        data-cy="cy-gatewayEndpoint__epanel"
    >
        <div class="chi-epanel__header">
            <div class="chi-epanel__number">{{ step + 1 }}.</div>
            <div class="chi-epanel__title">Gateway Endpoint</div>
            <div class="chi-epanel__content">
                <div class="chi-epanel__collapse">
                    <div class="-done--only">
                        {{ consolidatedHeaderValue }}
                    </div>
                </div>
            </div>
            <div class="chi-epanel__action -done--only">
                <button class="chi-button -primary -flat" data-chi-epanel-action="active" @click="clickGwChange">
                    Change
                </button>
            </div>
        </div>
        <div class="chi-epanel__collapse">
            <div class="-active--only">
                <div class="chi-epanel__body">
                    <div class="chi-epanel__content">
                        <p class="card_categories -text--xs -text--primary -text--muted">
                            These options determine the URL that will be used by consumers of your endpoint. The base
                            paths for Lumen endpoints consist of four parts:

                            <br /><br /><strong>1. Service Category</strong> - Defines the capability group or logical
                            grouping of a set services in a portfolio (i.e. how to partition the services in the
                            Enterprise inventory into organized sets). The Service Category is init-capitalized (i.e.
                            Enterprise, ServiceAssurance, ServiceDelivery etc.) <br /><strong>2. Version</strong> -
                            Defines the various versions that are supported for the services in this capability group
                            <br /><strong>3. Service</strong> - Defines a cohesive and sufficiently abstracted set of
                            business capabilities resulting in an independently managed set of functions and data (i.e.
                            how to best organize functions and data into a well scoped modular unit). The Service is
                            init-capitalized (i.e. Document, Ordering etc.) <br /><strong>4. Resource</strong>
                            - Defines the representation of a subset of data and/or function of the service that is
                            granular enough to be autonomously represented (i.e. how to best organize the granular data
                            and functions into reusable units that have affinity of data and/or interaction). Please
                            ensure that the resource is camelcase.

                            <br /><br />The four attributes are combined to form the final URL: <br /><br />

                            <u>https://api.lumen.com/ServiceCategory/Version/Service/Resource</u>
                            <br /><br />
                            <br />
                            <strong>Note that </strong> Service Category, Service and Resource must be approved by
                            Enterprise Architecture during the Service Review process.
                            <a
                                class="chi-link"
                                href="https://centurylink.sharepoint.com/sites/TAWG-MAINMainTAWGSite/SitePages/SRB---Service-Review-Requests.aspx"
                                rel="noreferrer noopener"
                                onclick="window.open(this.href,'_blank');return false;"
                                >More information.</a
                            ><br />
                        </p>
                        <br />

                        <div class="chi-grid">
                            <div class="chi-col">
                                <div class="chi-form__item" id="vueSimple2">
                                    <label class="chi-label" for="example-ba1">
                                        Taxonomy
                                        <abbr class="chi-label__required" title="Required field">*</abbr>
                                    </label>
                                    <vue-simple-suggest
                                        ref="suggest"
                                        v-model="serviceCategory"
                                        mode="select"
                                        :list="authorization"
                                        @select="onTaxonomySelect($event)"
                                        @input="onTaxonamyChanged"
                                        data-cy="cy-service-category__select"
                                        :styles="autoCompleteStyle"
                                        :destyled="true"
                                        :filter-by-query="true"
                                        :id="isServiceCat ? 'simpledanger_endpoint' : 'simple_endpoint'"
                                    >
                                    </vue-simple-suggest>
                                    <div
                                        class="chi-label -status -danger"
                                        v-if="isServiceCat"
                                        data-cy="cy-gatewayEndpoint-error_Taxonamy"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Please select a Taxonomy from the list
                                    </div>
                                </div>
                            </div>
                            <div class="chi-col">
                                <div class="chi-form__item">
                                    <label class="chi-label" for="example-ba1">
                                        Version
                                        <abbr class="chi-label__required" title="Required field">*</abbr>
                                    </label>
                                    <select
                                        :class="[!isVersion ? 'chi-select' : 'chi-select -danger']"
                                        id="example-ba1"
                                        v-model="version"
                                        data-cy="cy-version__select"
                                        @change="versionChange($event)"
                                    >
                                        <option value="" selected>Select</option>
                                        <option value="v1" selected>1</option>
                                        <option value="v2">2</option>
                                        <option value="v3">3</option>
                                        <option value="v4">4</option>
                                        <option value="v5">5</option>
                                        <option value="v6">6</option>
                                        <option value="v7">7</option>
                                        <option value="v8">8</option>
                                        <option value="v9">9</option>
                                        <option value="v10">10</option>
                                    </select>
                                    <div
                                        class="chi-label -status -danger"
                                        v-if="isVersion"
                                        data-cy="cy-gatewayEndpoint-error_Version"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        Please select a Version
                                    </div>
                                </div>
                            </div>
                            <div class="chi-col">
                                <div class="chi-form__item">
                                    <label class="chi-label" for="example-ba1">
                                        Resource
                                        <abbr class="chi-label__required" title="Required field">*</abbr></label
                                    >
                                    <input
                                        type="text"
                                        :class="[!isResource ? 'chi-input' : 'chi-input -danger']"
                                        placeholder="submitOrder"
                                        @keyup="validateResource()"
                                        id="Resource-Name"
                                        v-model="resourceName"
                                        data-cy="cy-resourcename__input"
                                    />
                                    <div
                                        class="chi-label -status -danger"
                                        v-if="isResource"
                                        data-cy="cy-resourcename__err"
                                    >
                                        <chi-icon icon="circle-warning"></chi-icon>
                                        {{ resourceAlert }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="chi-epanel__footer -justify-content--end">
                        <button
                            class="chi-button -lg"
                            data-chi-epanel-action="previous"
                            data-cy="cy-gatewayEndpoint-previous__button"
                            @click="clickGwPrevious"
                        >
                            Previous
                        </button>
                        <button
                            class="chi-button -lg -primary"
                            @click="clickGwContinue"
                            data-cy="cy-gatewayEndpoint-continue__button"
                        >
                            Continue
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import VueSimpleSuggest from 'vue-simple-suggest';
import { getModule } from 'vuex-module-decorators';
import ProxyModule, { STORE_KEY } from '@/modules/proxy/_store';
import { Compare } from '@/utils/compare';
import { ExpansionPanelStates, ExpansionPanels } from '../../_constants/proxy';
Vue.component('vue-simple-suggest', VueSimpleSuggest);

@Component
export default class GatewayEndpoint extends Vue {
    private proxyStore!: ProxyModule;
    authorization: string[] = [];
    version: any = '';
    isServiceCat: boolean = false;
    isVersion: boolean = false;
    resourceName: any = '';
    isResource: boolean = false;
    resourceAlert: any = 'Please provide a Resource';
    serviceCategory: any = '';
    splittedStr: any;
    service: any;
    category: any;
    autoCompleteStyle: any;
    $refs: any;
    step = 1;
    currentState = ExpansionPanelStates.Pending;
    isValidatedAtLeastOnce = false;

    data() {
        return {
            autoCompleteStyle: {
                vueSimpleSuggest: 'position-relative',
                inputWrapper: '',
                defaultInput: 'form-control',
                suggestions: 'position-absolute list-group z-1000',
                suggestItem: 'list-group-item',
            },
        };
    }

    get consolidatedHeaderValue() {
        return (
            Vue.prototype.$config.gateway_url +
            this.service +
            '/' +
            this.version +
            '/' +
            this.category +
            '/' +
            this.resourceName
        );
    }

    created() {
        if (!this.proxyStore) {
            this.proxyStore = getModule(ProxyModule, this.$store);
        }
        this.proxyStore.loadTaxonomies();
        this.$store.subscribe((mutation, state) => {
            const currentMutation = mutation.type.split('/')[1];
            const currentStore = state[STORE_KEY];
            if (currentMutation === 'setTaxonomy') {
                this.authorization = JSON.parse(JSON.stringify(currentStore.taxonomyData));
            }
            if (currentMutation === 'setCurrentStep' || currentMutation === 'setCurrentStepCollapse') {
                this.setCurrentState(currentMutation);
            }
        });
    }

    onTaxonamyChanged(value): void {
        this.serviceCategory = value;
        this.proxyStore.loadServiceCategory(this.serviceCategory);
        this.splittedStr = this.serviceCategory.split('/');
        this.service = this.splittedStr[0];
        this.category = this.splittedStr[1];
        this.checkTaxonamyData();
    }

    onTaxonomySelect(event): void {
        if (event) {
            // needed timeout to delay the hide of the suggestions
            setTimeout(() => {
                this.$refs.suggest.hideList();
            }, 0);
        }
    }

    checkTaxonamyData(): void {
        this.isServiceCat =
            Compare.isElementEmpty(this.serviceCategory) ||
            !Compare.doesElementExist(this.authorization, this.serviceCategory);
    }

    checkVersion(): void {
        this.isVersion = Compare.isElementEmpty(this.version);
    }

    private submitValidation() {
        this.checkTaxonamyData();
        this.checkVersion();
        this.validateResource();
        return !this.isServiceCat && !this.isVersion && !this.isResource;
    }

    validateResource(): void {
        const valResource = this.resourceName;
        this.proxyStore.loadResourceName(this.resourceName);
        let regex = '[^A-Za-z0-9]';
        let regexLetter = '[^a-z]';
        this.isResource = true;
        this.resourceAlert = 'Please provide a Resource';
        if (valResource != undefined && valResource != '') {
            if (valResource[0].match(regexLetter)) {
                this.isResource = true;
                this.resourceAlert = 'First letter should be lowercase';
            } else if (valResource.match(regex)) {
                this.isResource = true;
                this.resourceAlert = 'Please enter only alpha-numeric characters';
            } else {
                this.isResource = false;
            }
        }
    }

    versionChange($event: any): void {
        this.isVersion = !$event.target.value;
        this.proxyStore.loadVersion($event.target.value);
    }

    private setCurrentState(mutation: string): void {
        if (this.proxyStore.getCurrentStep === this.step) {
            if (mutation === 'setCurrentStep') {
                this.currentState = ExpansionPanelStates.Active;
            } else {
                this.currentState = this.isValidatedAtLeastOnce
                    ? ExpansionPanels.getStateByCollapse(this.submitValidation())
                    : ExpansionPanelStates.Pending;
            }
        }
    }

    clickGwChange(): void {
        ExpansionPanels.setChangeAction(this.proxyStore, this.step);
    }

    clickGwContinue(): void {
        if (this.submitValidation()) {
            this.isValidatedAtLeastOnce = true;
            this.currentState = ExpansionPanels.getContinueAction(this.proxyStore, this.step);
        }
    }

    clickGwPrevious(): void {
        this.currentState = this.isValidatedAtLeastOnce
            ? ExpansionPanels.getStateByCollapse(this.submitValidation())
            : ExpansionPanelStates.Pending;
        ExpansionPanels.setPreviousAction(this.proxyStore, this.step);
    }
}
</script>
<style>
#simple_endpoint {
    width: 100% !important;
    border: 0.0625rem solid #dadee2;
    border-radius: 0.25rem;
    color: #242526;
    display: block;
    font-size: 0.875rem;
    height: 2.5rem;
    line-height: 1.25rem;
    outline: none;
    padding: 0.5625rem 0.75rem;
    -webkit-transition: all 0.15s ease-in-out;
    transition: all 0.15s ease-in-out;
}
#simpledanger_endpoint {
    width: 100% !important;
    border: 0.0625rem solid #dadee2;
    border-color: #ee3026;
    border-radius: 0.25rem;
    color: #242526;
    display: block;
    font-size: 0.875rem;
    height: 2.5rem;
    line-height: 1.25rem;
    outline: none;
    padding: 0.5625rem 0.75rem;
    -webkit-transition: all 0.15s ease-in-out;
    transition: all 0.15s ease-in-out;
}
.z-1000 {
    z-index: 1000;
}
.hover {
    background-color: #007bff;
    color: #fff;
}
.suggestions {
    opacity: 1;
}

.vue-simple-suggest-enter-active.suggestions,
.vue-simple-suggest-leave-active.suggestions {
    transition: opacity 0.2s;
}

.vue-simple-suggest-enter.suggestions,
.vue-simple-suggest-leave-to.suggestions {
    opacity: 0;
}
</style>
