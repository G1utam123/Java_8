export interface ApiProxyBuilderResponse {
    proxy: string;
    guid: string;
    proxyBuiltInEnvironments: string[];
    proxyNotBuiltInEnvironments: string[];
}

export class Validations {
    static submitApiCreation(store): boolean {
        let internalAndExternalValidation;
        if (store.getAvailabilityInternal && store.getAvailabilityExternal) {
            internalAndExternalValidation =
                store.getInternalGatewayAuthenticationValidation && store.getExternalGatewayAuthenticationValidation;
        } else {
            internalAndExternalValidation = store.getAvailabilityInternal
                ? store.getInternalGatewayAuthenticationValidation
                : store.getExternalGatewayAuthenticationValidation;
        }
        return (
            // General validations
            store.getAppKey?.trim().length > 0 &&
            store.getMalId?.trim().length > 0 &&
            (store.getAvailabilityInternal || store.getAvailabilityExternal) &&
            store.getType?.trim().length > 0 &&
            // GatewayEndpoint validations
            store.getServiceCategory?.trim().length > 0 &&
            store.getResourceName?.trim().length > 0 &&
            store.getVersion?.trim().length > 0 &&
            // TargetEndpoint validations
            store.getTargetEndpointValidation &&
            // InternalGatewayAuthentication validations && ExternalGatewayAuthentication validations
            internalAndExternalValidation
        );
    }
}

export enum ExpansionPanelStates {
    Active = 'active',
    Done = 'done',
    Pending = 'pending',
}

export class ExpansionPanels {
    // (return): first ocurrence of a panel that's not the current one and It's not in state 'done'
    static getNextStep(currentStep: number): number {
        let nextStep = 0;
        const epPanel = document.querySelectorAll('[data-chi-epanel-group="proxy_chi__epanel"]');
        if (epPanel?.length > 0) {
            nextStep = epPanel.length - 1; // last possible step, assuming that the rest are already in state 'done'
            let iStep = 0; // default step to continue from
            let found = false;
            epPanel.forEach((element) => {
                if (!found && iStep !== currentStep && !element.className.includes('-done')) {
                    found = true;
                    nextStep = iStep;
                }
                iStep++;
            });
        } else {
            console.error('(getNextStep) Expansion panels were not successfully loaded.');
        }
        return nextStep;
    }

    static getStateByValidation(isValid: boolean): ExpansionPanelStates {
        return isValid ? ExpansionPanelStates.Done : ExpansionPanelStates.Pending;
    }

    static setChangeAction(store: any, step: number): void {
        store.setCurrentStepCollapse(true);
        store.setCurrentStep(step);
    }

    static getContinueAction(store: any, step: number): ExpansionPanelStates {
        store.setCurrentStep(this.getNextStep(step));
        return ExpansionPanelStates.Done;
    }

    static setPreviousAction(store: any, step: number): void {
        store.setCurrentStep(step - 1);
    }

    static getStateByCollapse(isValid: boolean): ExpansionPanelStates {
        return ExpansionPanels.getStateByValidation(isValid);
    }
}

export function checkHealthESP(res: HealthESPResponse): boolean {
    let isESPHealthy = true;
    Object.keys(res).forEach((element) => {
        if (res[element] < 1) {
            isESPHealthy = false;
        }
    });
    return isESPHealthy;
}

export const CHECK_APB_AVAILABILITY_TIME = 30000;

export interface HealthESPResponse {
    'ESP-DEV1': number;
    'ESP-DEV2': number;
    'ESP-DEV3': number;
    'ESP-DEV4': number;
    'ESP-TEST1': number;
    'ESP-TEST2': number;
    'ESP-TEST3': number;
    'ESP-TEST4': number;
    'ESP-PROD': number;
}
