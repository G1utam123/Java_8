import * as fetch from '../../../wrappers/fetch';
import { GroupRequest } from '../_models/groupRequest';

export const registerProxy = {
    loadApplicationKey: async () => fetch.get('/v1/applicationKeys'),
    loadTaxonomies: async () => fetch.get('/v1/taxonomies'),
    loadProxyData: async (json: any) => fetch.post('/v1/postProxyBuildDeploy', json),
    getOwnershipDetails: async (ownershipId: string) => fetch.get('/v1/ownerships/' + ownershipId),
    loadGroupRequest: async (groupRequest: GroupRequest) => fetch.post('/v1/servicenow/grouprequest', groupRequest),
    healthESP: async () => fetch.get('/v1/health/esp'),
};
