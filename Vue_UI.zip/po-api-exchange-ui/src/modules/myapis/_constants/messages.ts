export const MSG = {
    comingSoon: 'Coming Soon!',
};
