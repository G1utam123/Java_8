export const PROXIES_DATATABLE_TEMPLATES = {
    TAXONAMY: 'resourceTaxonomy',
    RESOURCE_NAME: 'resourceName',
    VERSION: 'version',
    SERVICE_ENDPOINT: 'endPointUrl',
    ROUTING_EXPRESSION: 'routingExpression',
    OWNER: 'createdBy',
};

export const PROXIES_DATATABLE_COLUMNS = {
    Taxonomy: {
        label: 'Resource Taxonomy',
        sortable: true,
        sortBy: PROXIES_DATATABLE_TEMPLATES.TAXONAMY,
        sortDataType: 'string',
    },
    ResourceName: {
        label: 'Resource Name',
        sortable: true,
        sortBy: PROXIES_DATATABLE_TEMPLATES.RESOURCE_NAME,
        sortDataType: 'string',
    },
    Version: { label: 'Version', sortable: true, sortBy: PROXIES_DATATABLE_TEMPLATES.VERSION, sortDataType: 'string' },
    ServiceEndpoint: {
        label: 'Service Endpoint',
        sortable: true,
        sortBy: PROXIES_DATATABLE_TEMPLATES.SERVICE_ENDPOINT,
        sortDataType: 'string',
    },
    RoutingExpression: {
        label: 'Routing Expression',
        sortable: true,
        sortBy: PROXIES_DATATABLE_TEMPLATES.ROUTING_EXPRESSION,
        sortDataType: 'string',
    },
    Owner: { label: 'Owner', sortable: true, sortBy: PROXIES_DATATABLE_TEMPLATES.OWNER, sortDataType: 'string' },
    Actions: { label: 'Actions', sortable: false, sortBy: 'resourceGuid', align: 'right', allowOverflow: true },
};
