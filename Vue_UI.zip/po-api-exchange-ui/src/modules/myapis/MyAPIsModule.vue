<template>
    <AppLayout>
        <template v-slot:myApi>
            <div class="chi-grid">
                <div
                    class="chi-col -w-md--10 -mt--2 chi-main__title-heading -text--boldest--navy"
                    title="My APIs"
                    data-cy="cy-my_apis_name"
                >
                    My APIs
                </div>
                <div class="chi-col -w-sm--2 -mt--2 -text-xl--right">
                    <router-link
                        data-cy="cy-create__appbtn"
                        :to="{
                            name: 'proxy',
                            params: {
                                page: 'proxy',
                                alert: '',
                                alertmsg: '',
                            },
                        }"
                    >
                        <button class="chi-button -primary" data-cy="cy-create-new-app__btn">Create New</button>
                    </router-link>
                </div>

                <div class="chi-col -w-sm--12 -pt--3">
                    <ul
                        class="chi-tabs -solid -lg -border"
                        ref="tabs"
                        role="tablist"
                        aria-label="chi-tabs-horizontal"
                        data-cy="cy-tabs"
                    >
                        <li class="-active">
                            <a
                                href="#myapisproxies"
                                aria-selected="false"
                                tabindex="-1"
                                aria-controls="myapisproxies"
                                data-cy="cy-myapisproxies_tab"
                                >Proxies</a
                            >
                        </li>
                        <li role="tab">
                            <a
                                href="#myapisproducts"
                                role="tab"
                                aria-selected="true"
                                aria-controls="myapisproducts"
                                data-cy="cy-myapisproducts_tab"
                                >Products</a
                            >
                        </li>
                    </ul>
                    <div class="chi-tabs-panel -active -py--6" id="myapisproxies" role="tabpanel">
                        <MyAPIsProxies />
                    </div>
                    <div class="chi-tabs-panel -py--6" id="myapisproducts" role="tabpanel">
                        <MyAPIsProducts />
                    </div>
                </div>
            </div>
        </template>
    </AppLayout>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import MyAPIsProxies from './_components/MyAPIsProxies.vue';
import MyAPIsProducts from './_components/MyAPIsProducts.vue';
import AppLayout from '@/modules/common/_components/AppLayout.vue';
declare const chi: any;
@Component({
    components: {
        MyAPIsProxies,
        MyAPIsProducts,
        AppLayout,
    },
})
export default class MyAPIsModule extends Vue {
    tabs: any;

    mounted() {
        this.tabs = chi.tab(this.$refs.tabs as HTMLElement);
    }

    beforeDestroy() {
        this.tabs.dispose();
    }
}
</script>
<style scoped>
.chi-main > .chi-main__header {
    display: none;
}
</style>
