<template>
    <div class="-pt--2">
        <AlertComponent :alertObject="alertObject" />
    </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import AlertComponent from '@/modules/common/_components/AlertComponent.vue';
import { Alert } from '@/models/alert';
import { MSG } from '@/modules/myapis/_constants/messages';
@Component({
    components: {
        AlertComponent,
    },
})
export default class MyAPIsProducts extends Vue {
    alertObject!: Alert;

    beforeMount() {
        this.alertObject = new Alert('', {
            color: 'info',
            icon: 'circle-info',
            size: 'lg',
            tag: 'cy-api__coming_soon__alert',
            title: MSG.comingSoon,
            closable: false,
        });
    }
}
</script>
