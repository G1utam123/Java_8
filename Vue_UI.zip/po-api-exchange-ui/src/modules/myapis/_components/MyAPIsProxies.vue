<template>
    <div>
        <ul
            class="chi-tabs -border"
            ref="proxiestabs"
            role="tablist"
            aria-label="chi-tabs-horizontal"
            data-cy="cy-tabs"
        >
            <li role="tab">
                <a
                    href="#myapisproxiesproduction"
                    role="tab"
                    aria-selected="true"
                    aria-controls="myapisproxiesproduction"
                    data-cy="cy-myapisproxiesproduction_tab"
                    @click="loadProxiesData('myapisproxiesproduction')"
                    >Production</a
                >
            </li>
            <li class="-active">
                <a
                    href="#myapisproxiesdevtest"
                    aria-selected="false"
                    tabindex="-1"
                    aria-controls="myapisproxiesdevtest"
                    data-cy="cy-myapisproxiesdevtest_tab"
                    @click="loadProxiesData('myapisproxiesdevtest')"
                    >Dev Test</a
                >
            </li>
        </ul>

        <div class="chi-tabs-panel -py--6" id="myapisproxiesproduction" role="tabpanel">
            <chi-spinner v-if="dataSearchingProd" color="primary" backdrop="inverse"></chi-spinner>
            <Loader v-if="dataLoading" />
            <div v-else class="chi-card">
                <template>
                    <div class="chi-card">
                        <div class="chi-card__header">
                            <div class="chi-card__title" data-cy="cy-display_header-prod">Production Proxies</div>
                        </div>
                    </div>

                    <ChiDataTable
                        data-cy="cy-api-chi-data-table-prod"
                        :config="configProd"
                        :data="tableDataProd"
                        v-if="!dataLoading"
                    >
                        <template #toolbar>
                            <ChiDataTableToolbar>
                                <template v-slot:start>
                                    <ChiSearchInput
                                        @chiChange="(e) => searchProd(e)"
                                        @chiClean="() => searchProd('')"
                                        placeholder="Search"
                                        :dataTableSearch="true"
                                        data-cy="cy-api__search-input-prod"
                                        class="input-width input-left-margin"
                                    ></ChiSearchInput>
                                </template>
                            </ChiDataTableToolbar>
                        </template>

                        <template #resourceTaxonomy="payload">
                            {{ payload.resourceTaxonomy }}
                        </template>

                        <template #resourceName="payload">
                            {{ payload.resourceName }}
                        </template>

                        <template #version="payload">
                            {{ payload.version }}
                        </template>

                        <template #endPointUrl="payload">
                            {{ payload.endPointUrl }}
                        </template>

                        <template #routingExpression="payload">
                            {{ payload.routingExpression }}
                        </template>

                        <template #createdBy="payload">
                            {{ payload.createdBy }}
                        </template>

                        <template #actions="payload">
                            <router-link
                                v-if="payload.id"
                                class="link"
                                :to="{
                                    name: 'migrate',
                                    params: { ID: payload.id },
                                }"
                                >Migrate</router-link
                            >
                        </template>
                    </ChiDataTable>
                </template>
            </div>
        </div>

        <div class="chi-tabs-panel -active -py--6" id="myapisproxiesdevtest" role="tabpanel">
            <chi-spinner v-if="dataSearchingDevTest" color="primary" backdrop="inverse"></chi-spinner>
            <Loader v-if="dataLoading" />
            <div v-else class="chi-card">
                <template>
                    <div class="chi-card">
                        <div class="chi-card__header">
                            <div class="chi-card__title" data-cy="cy-display_header-dev-test">Dev Test Proxies</div>
                        </div>
                    </div>

                    <ChiDataTable
                        data-cy="cy-api-chi-data-table-dev-test"
                        :config="configDevTest"
                        :data="tableDataDevTest"
                        v-if="!dataLoading"
                    >
                        <template #toolbar>
                            <ChiDataTableToolbar>
                                <template v-slot:start>
                                    <ChiSearchInput
                                        @chiChange="(e) => searchDevTest(e)"
                                        @chiClean="() => searchDevTest('')"
                                        placeholder="Search"
                                        :dataTableSearch="true"
                                        data-cy="cy-api__search-input-dev-test"
                                        class="input-width input-left-margin"
                                    ></ChiSearchInput>
                                    <div class="chi-divider -vertical"></div>
                                    <ChiDataTableFilters
                                        :portal="true"
                                        :filtersData="toolbarFiltersDevTest"
                                        @chiFiltersChange="(e) => filtersChangeDevTest(e)"
                                        data-cy="cy-api__filter-dev-test"
                                    />
                                </template>
                            </ChiDataTableToolbar>
                        </template>

                        <template #resourceTaxonomy="payload">
                            {{ payload.resourceTaxonomy }}
                        </template>

                        <template #replaceUrlToValue="payload">
                            <p style="white-space: pre-line">
                                <strong>Matching Expression</strong>
                                <br />
                                {{ payload.replaceUrlToValue }}
                            </p>
                        </template>

                        <template #resourceName="payload">
                            {{ payload.resourceName }}
                        </template>

                        <template #version="payload">
                            {{ payload.version }}
                        </template>

                        <template #endPointUrl="payload">
                            {{ payload.endPointUrl }}
                        </template>

                        <template #routingExpression="payload">
                            {{ payload.routingExpression }}
                        </template>

                        <template #createdBy="payload">
                            {{ payload.createdBy }}
                        </template>

                        <template #actions="payload">
                            <router-link
                                v-if="payload.id"
                                class="link"
                                :to="{
                                    name: 'migrate',
                                    params: { ID: payload.id },
                                }"
                                >Migrate</router-link
                            >
                        </template>
                    </ChiDataTable>
                </template>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { PROXIES_TOOLBAR_FILTERS, PROXIES_DATATABLE_CONFIG } from '@/modules/exchange/_constants/proxiesTable';
import { PROXIES_DATATABLE_COLUMNS, PROXIES_DATATABLE_TEMPLATES } from '@/modules/myapis/_constants/myAPIsProxiesTable';
import { DataTableRow, FilterType } from '@/models/chiTableTypes';
import { SearchUtils } from '@/utils/searchUtils';
import Loader from '@/modules/common/_components/Loader.vue';
import MyAPIsStore, { STORE_KEY } from '@/modules/myapis/_store';
import { getModule } from 'vuex-module-decorators';
import { DataTableUtils } from '@/utils/dataTableUtils';
declare const chi: any;
@Component({
    data() {
        return {
            PROXIES_DATATABLE_TEMPLATES,
            PROXIES_DATATABLE_COLUMNS,
            DataTableUtils,
        };
    },
    components: {
        Loader,
    },
})
export default class MyAPIsProxies extends Vue {
    toolbarFiltersDevTest: any;
    configDevTest: any;
    configProd: any;
    dataLoading = true;
    dataSearchingDevTest = false;
    dataSearchingProd = false;
    proxiesTabs: any;
    private appStore!: MyAPIsStore;
    private searchInputDevTest = '';
    private searchInputProd = '';
    private currentEnv!: string;
    private envByDefault = 'dev1';
    private email!: string;

    created() {
        const isModuleRegistered = Object.keys(this.$store.state).includes(STORE_KEY);
        if (!isModuleRegistered) {
            this.$store.registerModule(STORE_KEY, MyAPIsStore);
        }
        this.appStore = getModule(MyAPIsStore, this.$store);
    }

    mounted() {
        if (this.$refs.proxiestabs) {
            this.proxiesTabs = chi.tab(this.$refs.proxiestabs as HTMLInputElement);
        }
        this.email = this.$store.state.userContext.email;
        this.loadDatatableData();
        this.loadProxiesDevTest();
    }

    get tableDataDevTest(): any {
        return {
            head: PROXIES_DATATABLE_COLUMNS,
            body: this.filteredTableBodyDevTest,
        };
    }

    get tableDataProd(): any {
        return {
            head: PROXIES_DATATABLE_COLUMNS,
            body: this.filteredTableBodyProd,
        };
    }

    get filteredTableBodyDevTest(): DataTableRow[] {
        const tableDataBody = DataTableUtils.getMyProxiesDevTestTableBody(
            this.appStore.getProxiesDetailsDevTest,
            PROXIES_DATATABLE_TEMPLATES
        );
        let rows: DataTableRow[] = [...tableDataBody];
        const searchValue = this.searchInputDevTest.trim().toLowerCase();
        if (rows.length > 0 && !!this.searchInputDevTest) {
            rows = rows.filter((__: any, index: number) => {
                const searchValueString = SearchUtils.formSearchValueString(tableDataBody);
                return searchValueString[index]?.indexOf(searchValue) > -1;
            });
        }
        this.dataSearchingDevTest = this.appStore.getLoadingProxiesDetailsDevTest;
        return rows;
    }

    get filteredTableBodyProd(): DataTableRow[] {
        const tableDataBody = DataTableUtils.getMyProxiesProdTableBody(
            this.appStore.getProxiesDetailsProd,
            PROXIES_DATATABLE_TEMPLATES
        );
        let rows: DataTableRow[] = [...tableDataBody];
        const searchValue = this.searchInputProd.trim().toLowerCase();
        if (rows.length > 0 && !!this.searchInputProd) {
            rows = rows.filter((__: any, index: number) => {
                const searchValueString = SearchUtils.formSearchValueString(tableDataBody);
                return searchValueString[index]?.indexOf(searchValue) > -1;
            });
        }
        this.dataSearchingProd = this.appStore.getLoadingProxiesDetailsProd;
        return rows;
    }

    filtersChangeDevTest(filters: FilterType[] = []): void {
        this.dataSearchingDevTest = true;
        this.currentEnv = filters[0].value;
        localStorage.setItem('myProxiesEnv', this.currentEnv);
        this.loadProxiesDevTest();
    }

    searchDevTest(searchInputValue: string): void {
        this.dataSearchingDevTest = true;
        setTimeout(() => {
            this.searchInputDevTest = searchInputValue;
        }, 1000);
    }

    searchProd(searchInputValue: string): void {
        this.dataSearchingProd = true;
        setTimeout(() => {
            this.searchInputProd = searchInputValue;
        }, 1000);
    }

    loadDatatableData(): void {
        let myProxiesEnv: any = localStorage.getItem('myProxiesEnv');
        this.currentEnv = myProxiesEnv ? myProxiesEnv : this.envByDefault;

        const filtersByDefault = PROXIES_TOOLBAR_FILTERS;
        filtersByDefault[0].value = myProxiesEnv ? myProxiesEnv : this.envByDefault;
        filtersByDefault[0].options = filtersByDefault[0].options.filter((option) => option.value !== 'prod');
        this.toolbarFiltersDevTest = filtersByDefault;

        const configByDefault = PROXIES_DATATABLE_CONFIG;
        configByDefault.selectable = false;
        if (configByDefault.defaultSort) {
            configByDefault.defaultSort.direction = 'descending';
        }
        this.configDevTest = configByDefault;
        this.configProd = configByDefault;
    }

    loadProxiesDevTest(): void {
        let options: any = { params: { env: this.currentEnv, createdBy: this.email } };
        try {
            this.appStore.loadProxiesDetailsDevTest(options);
        } finally {
            this.dataLoading = false;
        }
    }

    loadProxiesProd(): void {
        let options: any = { params: { env: 'prod', createdBy: this.email } };
        try {
            this.appStore.loadProxiesDetailsProd(options);
        } finally {
            this.dataLoading = false;
        }
    }

    loadProxiesData(destination: 'myapisproxiesproduction' | 'myapisproxiesdevtest') {
        if (destination === 'myapisproxiesdevtest') {
            this.loadProxiesDevTest();
        } else {
            this.loadProxiesProd();
        }
    }

    beforeDestroy() {
        if (this.proxiesTabs) {
            this.proxiesTabs.dispose();
        }
    }
}
</script>
