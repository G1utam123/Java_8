import Vue from 'vue';
import { Module, VuexModule, Action, Mutation } from 'vuex-module-decorators';
import { Store } from 'vuex';
import { myAPIsApi } from '@/modules/myapis/_api/myAPIsApi';
export const STORE_KEY = '$_api_myapis';

@Module({
    namespaced: true,
    name: STORE_KEY,
    store: Vue.prototype.$store,
})
export default class MyAPIsStore extends VuexModule {
    static register($store: Store<any>) {
        if (!$store.state[STORE_KEY]) {
            $store.registerModule(STORE_KEY, this);
        }
    }
    static unregister($store: Store<any>) {
        if ($store.state[STORE_KEY]) {
            $store.unregisterModule(STORE_KEY);
        }
    }

    //#region states
    proxiesArrDevTest: any = [];
    proxiesArrProd: any = [];
    loadingProxiesDetailsDevTest = true;
    loadingProxiesDetailsProd = true;
    //#endregion

    //#region getters
    get getProxiesDetailsDevTest(): any {
        return this.proxiesArrDevTest;
    }

    get getProxiesDetailsProd(): any {
        return this.proxiesArrProd;
    }

    get getLoadingProxiesDetailsDevTest(): boolean {
        return this.loadingProxiesDetailsDevTest;
    }

    get getLoadingProxiesDetailsProd(): boolean {
        return this.loadingProxiesDetailsProd;
    }
    //#endregion

    //#region Actions
    @Action
    async loadProxiesDetailsDevTest(options: any): Promise<void> {
        this.context.commit('setLoadingProxiesDetailsDevTest', true);
        let proxiesArr: any = [];
        await myAPIsApi
            .loadMyAPIsProxiesDetails(options)
            .then((response: any) => {
                proxiesArr = response.data;
            })
            .catch(() => {})
            .finally(() => {
                this.context.commit('setProxiesDetailsDevTest', proxiesArr);
                this.context.commit('setLoadingProxiesDetailsDevTest', false);
            });
    }

    @Action
    async loadProxiesDetailsProd(options: any): Promise<void> {
        this.context.commit('setLoadingProxiesDetailsProd', true);
        let proxiesArr: any = [];
        await myAPIsApi
            .loadMyAPIsProxiesDetails(options)
            .then((response: any) => {
                proxiesArr = response.data;
            })
            .catch(() => {})
            .finally(() => {
                this.context.commit('setProxiesDetailsProd', proxiesArr);
                this.context.commit('setLoadingProxiesDetailsProd', false);
            });
    }
    //#endregion

    //#region mutations
    @Mutation
    setProxiesDetailsDevTest(proxiesArrDevTest: any[]) {
        this.proxiesArrDevTest = [...proxiesArrDevTest];
    }

    @Mutation
    setProxiesDetailsProd(proxiesArrProd: any[]) {
        this.proxiesArrProd = [...proxiesArrProd];
    }

    @Mutation
    setLoadingProxiesDetailsDevTest(loadingProxiesDetailsDevTest: boolean) {
        this.loadingProxiesDetailsDevTest = loadingProxiesDetailsDevTest;
    }

    @Mutation
    setLoadingProxiesDetailsProd(loadingProxiesDetailsProd: boolean) {
        this.loadingProxiesDetailsProd = loadingProxiesDetailsProd;
    }
    //#endregion
}
