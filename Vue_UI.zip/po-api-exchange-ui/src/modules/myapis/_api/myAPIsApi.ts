import * as fetch from '../../../wrappers/fetch';

export const myAPIsApi = {
    loadMyAPIsProxiesDetails: async (options: any) => fetch.get('/v1/apiProxyDetails', options),
};
