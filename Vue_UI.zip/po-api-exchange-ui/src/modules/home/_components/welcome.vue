<template>
    <AppLayout>
        <template v-slot:welcome>
            <div class="chi-epanel">
                <div class="chi-card -highlight -mb--7 heroimage">
                    <div class="chi-card__content -pr--2 -w--200 heroimagecontent">
                        <div class="-w--70">
                            <p
                                class="-text--left -text--h1 -text--boldest -text--white -pl--3 -w--12 -m--0"
                                data-cy="cy-Welcome-text"
                            >
                                Welcome to the API Hub
                            </p>
                            <p
                                class="-text--left -text--h4 -w--12 -text--white -mb--2 -pl--3 -mt--0"
                                data-cy="cy-getting-started"
                            >
                                Explore. Build. Manage. Your journey to building the perfect API starts here.
                            </p>
                            <div class="chi-col -text--left -mb--3 -pl--3 -pt--3">
                                <a
                                    class="chi-button button -primary"
                                    data-cy="cy-share-feedback-button"
                                    href="/feedback"
                                >
                                    Share Feedback
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="-text--h4 -text--boldest -text--center -mb--3 -ml--9" data-cy="cy-label-text">
                    WHAT WOULD YOU LIKE TO DO TODAY?
                </div>

                <div class="chi-grid gridcenter">
                    <td>
                        <div class="box -ml--2 -pr--2 -align--right">
                            <div class="textIn -text--boldest -mt--3" data-cy="cy-explore">Explore</div>

                            <div class="-text--sm -mt--1 -text--center" data-cy="cy-api">Lumen APIs</div>
                            <div class="product">
                                <chi-marketing-icon data-cy="cy-marketing-icon" size="xs" icon="products-apps" />
                            </div>
                            <div class="linkbox -text-sm--center">
                                <a class="chi-link -cta boxtext" data-cy="cy-products" href="/exchange">Exchange</a>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="box -ml--2 -pr--2 -align--right">
                            <div class="textIn -text--boldest -mt--3" data-cy="cy-build-title">Build</div>
                            <div class="-text--sm -mt--1 -text--center" data-cy="cy-gateway">a new gateway proxy</div>
                            <div class="product">
                                <chi-marketing-icon data-cy="cy-business-icon" size="xs" icon="business-reliability" />
                            </div>
                            <div class="linkbox -text-sm--center">
                                <a class="chi-link -cta boxtext" data-cy="cy-proxy" href="/proxy">Get Started</a>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="box -ml--2 -pr--2 -align--right">
                            <div class="textIn -text--boldest -mt--3" data-cy="cy-manage-title">Manage</div>
                            <div class="-text--sm -mt--1 -text--center" data-cy="cy-manage-credentials">
                                Credentials
                            </div>
                            <div class="product">
                                <chi-marketing-icon data-cy="cy-developer-icon" icon="people-software-developer" />
                            </div>
                            <div class="linkbox -text-sm--center">
                                <a class="chi-link -cta boxtext" data-cy="cy-myapps" href="/credentials">Credentials</a>
                            </div>
                        </div>
                    </td>
                </div>
                <div class="chi-card -mt--9">
                    <div class="chi-card__content">
                        <div class="chi-card__caption">
                            <div class="-text--h3 -text--boldest" data-cy="cy-developer-text">
                                Have you seen the new Developer Center?
                            </div>
                            <div class="-text--h6 -mb--3 -text--semi-bold" data-cy="cy-developer-desciption">
                                The Developer Center is Lumen’s external-facing Digital Experience for developers.
                            </div>
                            <form target="_blank" action="https://developer.lumen.com/" class="chi-col -pl--0 -mb--9">
                                <chi-button data-cy="cy-developer-center-button" color="primary">
                                    DEVELOPER CENTER
                                </chi-button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </template>
    </AppLayout>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import AppLayout from '@/modules/common/_components/AppLayout.vue';
@Component({
    components: {
        AppLayout,
    },
})
export default class Welcome extends Vue {}
</script>
<style scoped>
.box {
    width: 312px;
    height: 243px;
    border: 1px solid #dadee2;
    border-radius: 4px;
    background-color: #ffffff;
    background-size: cover;
}
.boxtext {
    width: 78px;
    height: 18px;
    font-size: 13px;
}
.product {
    margin-left: 108px !important;
    margin-right: 132px !important;
    margin-top: 1.6rem !important;
    margin-bottom: 75px !important;
    width: 72px !important;
    height: 77px !important;
}
.linkbox {
    margin-left: -10px !important;
    margin-top: -50px !important;
}
.textIn {
    font-size: 24px;
    color: #242526;

    text-align: center;
}

.gridcenter {
    justify-content: center;
}
.heroimage {
    background-image: url('../../../assets/home-kra.jpg');
    max-width: 100rem !important;
    height: 376px;
    margin-left: auto;
    margin-right: auto;
}
.chi-main {
    padding-top: 0.75rem !important;
}
.heroimagecontent {
    margin-top: 3.5rem;
    margin-left: 2.5rem;
}
</style>
