<template>
    <div></div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
@Component({
    components: {
        HomeLayout: () =>
            import(/* webpackChunkName: "apiexchange-home-layout" */ '@/modules/exchange/_components/Products.vue'),
    },
})
export default class HomeModule extends Vue {}
</script>
