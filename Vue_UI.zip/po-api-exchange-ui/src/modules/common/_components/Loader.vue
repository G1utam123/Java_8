<template>
    <div :style="loaderStyle" class="chi-backdrop -center -inverse -bg--none loader" data-cy="cy-common__loader">
        <div class="chi-backdrop__wrapper">
            <svg class="chi-spinner -icon--primary" viewBox="0 0 66 66">
                <title>Loading</title>
                <circle class="path" cx="33" cy="33" r="30" fill="none" stroke-width="6"></circle>
            </svg>
            <div v-if="message" class="-mt--4">{{ message }}</div>
        </div>
    </div>
</template>

<script lang="ts">
// eslint-disable-next-line
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component({
    components: {},
})
export default class Loader extends Vue {
    @Prop({ default: '' }) message!: string;
    @Prop({ default: '45vh' }) height!: string;
    loaderStyle: any;

    data() {
        return {
            loaderStyle: {
                height: this.height,
            },
        };
    }
}
</script>

<style scoped>
.loader {
    position: relative;
}
</style>
