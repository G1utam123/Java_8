<template>
    <div :style="alertStyle" :class="paddingTop ? `-pt--${paddingTop}` : ''">
        <chi-alert
            :color="alertObject.options.color"
            :icon="alertObject.options.icon"
            :size="alertObject.options.size"
            mutable
            :closable="alertObject.options.closable"
            :data-cy="alertObject.options.tag"
            :title="alertObject.options.title"
            @dismissAlert="dismissAlertClick()"
        >
            <span v-if="alertObject.options.custom">
                <div v-if="alertObject.options.custom === 'apb'">
                    <a
                        @click="clickLink(alertObject.options.custom)"
                        class="chi-link"
                        rel="noreferrer noopener"
                        data-cy="cy-alert_link_apb"
                        >Learn more about this error</a
                    >
                    <i class="-pl--1 -mr--1 chi-icon icon-external-link" aria-hidden="true"></i>
                    {{ alertObject.message }}
                </div>
                <div v-if="alertObject.options.custom === 'groupRequest'">
                    <div>
                        {{ alertObject.options.customParameters.successGroupRequestAlert1 }}
                        <a
                            @click="clickLink(alertObject.options.custom, 'trackItLink')"
                            class="chi-link"
                            rel="noreferrer noopener"
                            data-cy="cy-alert_link_track_it"
                            >{{ alertObject.options.customParameters.successGroupRequestAlertLink1 }}</a
                        >
                        <i class="-pl--1 -mr--1 chi-icon icon-external-link" aria-hidden="true"></i>
                    </div>
                    <div class="-mt--1">
                        {{ alertObject.options.customParameters.successGroupRequestAlert2 }}
                        <a
                            @click="clickLink(alertObject.options.custom, 'managementRightsLink')"
                            class="chi-link"
                            rel="noreferrer noopener"
                            data-cy="cy-alert_link_management_rights"
                            >{{ alertObject.options.customParameters.successGroupRequestAlertLink2 }}</a
                        >
                        <i class="-pl--1 -mr--1 chi-icon icon-external-link" aria-hidden="true"></i>
                        {{ alertObject.options.customParameters.successGroupRequestAlert3 }}
                        <a
                            @click="clickLink(alertObject.options.custom, 'audioLink')"
                            class="chi-link"
                            rel="noreferrer noopener"
                            data-cy="cy-alert_link_audio"
                            >{{ alertObject.options.customParameters.successGroupRequestAlertLink3 }}</a
                        >
                        <i class="-pl--1 -mr--1 chi-icon icon-external-link" aria-hidden="true"></i>
                    </div>
                </div>
            </span>
            <span v-else>{{ alertObject.message }}</span>
        </chi-alert>
        <Loader v-if="spinner" :message="spinnerMessage" />
    </div>
</template>

<script lang="ts">
import { Alert } from '@/models/alert';
import { Component, Prop, Vue } from 'vue-property-decorator';
import Loader from '@/modules/common/_components/Loader.vue';

@Component({
    components: { Loader },
})
export default class AlertComponent extends Vue {
    @Prop({ required: true }) alertObject!: Alert;
    @Prop({ default: 'inherit' }) height!: string;
    @Prop({ default: false }) spinner!: boolean;
    @Prop({ default: '' }) spinnerMessage!: string;
    @Prop() paddingTop!: number;
    alertStyle: any;

    data() {
        return {
            alertStyle: {
                height: this.height,
            },
        };
    }

    clickLink(
        customType: 'apb' | 'groupRequest',
        customTypeLink?: 'trackItLink' | 'managementRightsLink' | 'audioLink'
    ) {
        if (customType === 'apb') {
            window.open(Vue.prototype.$config?.apihub_status_url, '_blank');
        } else if (customType === 'groupRequest') {
            switch (customTypeLink) {
                case 'trackItLink':
                    const serviceNowLink =
                        Vue.prototype.$config?.service_now_request_number_url +
                        this.alertObject.options.customParameters.requestNumber;
                    window.open(serviceNowLink, '_blank');
                    break;
                case 'managementRightsLink':
                    window.open(Vue.prototype.$config?.management_rights_how_to_url, '_blank');
                    break;
                case 'audioLink':
                    window.open(Vue.prototype.$config?.audio_url, '_blank');
                    break;
            }
        }
    }

    dismissAlertClick(): void {
        this.$emit('dismissAlert');
    }
}
</script>
