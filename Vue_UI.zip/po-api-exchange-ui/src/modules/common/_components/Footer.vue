<template>
    <div>
        <footer id="footer" class="chi-footer" slot="footer">
            <enterprise-nav-footer show-language="true"></enterprise-nav-footer>
        </footer>
    </div>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component({
    components: {},
})
export default class Footer extends Vue {}
</script>
<style>
/* #footer {
    display: contents !important;
    position: absolute !important;
    margin-bottom: 0 !important;
} */
</style>
