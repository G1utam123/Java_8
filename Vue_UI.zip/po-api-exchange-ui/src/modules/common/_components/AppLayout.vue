<template>
    <div class="chi-main">
        <div v-if="title" class="chi-main__header">
            <div class="chi-main__header-start">
                <div class="chi-main__title">
                    <div class="chi-main__title-heading -text--boldest--navy">{{ title }}</div>
                </div>
            </div>
        </div>
        <div class="chi-main__content">
            <slot name="welcome"></slot>
            <slot name="feedback"></slot>
            <slot name="myApi"></slot>
            <slot name="credentials"></slot>
            <slot name="exchange"></slot>
            <slot name="proxy"></slot>
            <slot name="community"></slot>
            <slot name="playbook"></slot>
        </div>
        <footer id="footer" class="chi-footer" slot="footer">
            <enterprise-nav-footer show-language="true"></enterprise-nav-footer>
        </footer>
    </div>
</template>
<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
@Component({
    components: {},
})
export default class AppLayout extends Vue {
    @Prop() title!: string;
}
</script>
<style scoped>
.chi-footer {
    margin-top: 3.5rem;
}
</style>
