<template>
    <div class="chi-backdrop -closed">
        <div class="chi-backdrop__wrapper">
            <section
                :id="id"
                class="chi-modal -portal"
                role="dialog"
                aria-label="Modal description"
                aria-modal="true"
                data-cy="cy-client__modal"
            >
                <header class="chi-modal__header">
                    <h2 class="chi-modal__title">{{ modalObject.title }}</h2>
                    <button class="chi-button -icon -close" data-dismiss="modal" aria-label="Close">
                        <div class="chi-button__content">
                            <i aria-hidden="true" role="image" class="chi-icon icon-x"></i>
                        </div>
                    </button>
                </header>
                <div class="chi-modal__content">
                    <p class="-text -m--0 -text--bold">
                        {{ modalObject.message }}
                    </p>
                </div>
                <footer class="chi-modal__footer">
                    <button
                        class="chi-button -primary -outline -lg -px--4 -text--uppercase -bg--white"
                        data-dismiss="modal"
                        :data-cy="modalObject.options.cancelTag"
                        @click="!!modalObject.options.cancelCallback && modalObject.options.cancelCallback()"
                    >
                        {{ modalObject.options.cancelText }}
                    </button>
                    <button
                        class="chi-button -primary -lg -px--4 -text--uppercase"
                        data-dismiss="modal"
                        @click="modalObject.callback()"
                        :data-cy="modalObject.options.acceptTag"
                    >
                        {{ modalObject.options.acceptText }}
                    </button>
                </footer>
            </section>
        </div>
    </div>
</template>

<script lang="ts">
// eslint-disable-next-line
import { CustomModal } from '@/models/custom-modal';
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component({
    components: {},
})
export default class Modal extends Vue {
    @Prop() id!: string;
    @Prop() modalObject!: CustomModal;
}
</script>
