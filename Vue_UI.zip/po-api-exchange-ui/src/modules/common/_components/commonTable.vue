<template>
    <div class="chi-data-table -mt--2 -bordered" data-cy="cy-data-table">
        <div class="chi-data-table__head">
            <div class="chi-data-table__row">
                <div
                    class="chi-data-table__cell"
                    v-for="(columnName, index) in headerColumns"
                    :key="index"
                    v-bind:style="checkWidth(columnName)"
                >
                    <div :data-cy="`cy-column__${trimData(columnName)}`">{{ columnName }}</div>
                </div>
            </div>
        </div>
        <div class="chi-data-table__body">
            <transition-group name="slide" tag="tr" data-cy="cy-table_row">
                <div class="chi-data-table__row -striped" v-for="(section, index) in rowData" :key="`section_${index}`">
                    <div class="chi-data-table__cell">
                        <div>{{ section.apiName }}</div>
                    </div>
                    <div
                        class="chi-data-table__cell"
                        style="max-width: 15%; text-transform: capitalize"
                        data-cy="cy_section_type_colum"
                    >
                        <div>{{ section.sectionType }}</div>
                    </div>

                    <div class="chi-data-table__cell -text--center" id="deleteButton" data-cy="cy_action_colum">
                        <button
                            class="chi-button -icon -mr--1 -p--0"
                            aria-label="Button action"
                            @click="removeSection(section.id)"
                            data-cy="cy-delete-text__button"
                        >
                            <div class="chi-button__content">
                                <i class="chi-icon icon-delete"></i>
                            </div>
                        </button>
                        <button
                            class="chi-button -icon -mx--1 -p--0"
                            aria-label="Button action"
                            @click="editSection(section)"
                            data-cy="cy-icon-edit__button"
                        >
                            <div class="chi-button__content">
                                <i class="chi-icon icon-edit"></i>
                            </div>
                        </button>

                        <button
                            class="chi-button -icon -mx--1 -p--0"
                            aria-label="Button action"
                            :disabled="index == 0"
                            @click="moveSection(index, 'up')"
                            data-cy="cy-icon-moveup__button"
                        >
                            <div class="chi-button__content">
                                <i class="chi-icon icon-arrow-up -sm -icon--black"></i>
                            </div>
                        </button>
                        <button
                            class="chi-button -icon -mx--1 -p--0"
                            aria-label="Button action"
                            :disabled="index == rowData.length - 1"
                            @click="moveSection(index, 'down')"
                            data-cy="cy-icon-movedown__button"
                        >
                            <div class="chi-button__content">
                                <i class="chi-icon icon-arrow-down -sm -icon--black"></i>
                            </div>
                        </button>
                    </div>
                </div>
            </transition-group>
        </div>
    </div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
@Component({
    components: {},
})
export default class CommonTable extends Vue {
    @Prop() headerColumns!: any;
    @Prop() rowData!: any;
    checkWidth(columnName): any {
        if (columnName == 'Section Type') {
            return { 'max-width': '15%' };
        }
        if (columnName == 'Action') {
            return { 'max-width': '25%' };
        }
    }
    removeSection(sectionId: number): void {
        this.$emit('removeSectionEvent', sectionId);
    }
    editSection(sectionData: any): void {
        this.$emit('editSectionEvent', sectionData);
    }
    moveSection(index: number, direction: string): void {
        this.$emit('moveSectionEvent', { index: index, direction: direction });
    }
    trimData(coulmnName: string): string {
        return coulmnName.replace(/ /g, '');
    }
}
</script>
<style scoped>
#deleteButton {
    max-width: 25%;
    padding-top: 6px;
    padding-bottom: 6px;
}
.chi .chi-button .chi-icon,
.chi .chi-button .chi-spinner {
    font-size: 0.8rem;
}
.chi i[class*=' icon-'].-sm,
.chi i[class^='icon-'].-sm {
    font-size: 0.6rem !important;
}
</style>
