import { APP_MENU } from '@/utils/app';
import { RouteConfig } from 'vue-router';

export const routes = [
    {
        path: '/',
        redirect: '/apiexchange/home',
        meta: {
            title: APP_MENU[0].title,
            hide: true,
        },
    },
    {
        path: '/home',
        redirect: '/apiexchange/home',
        meta: {
            hide: true,
        },
    },
    {
        path: '/apiexchange/home',
        name: 'Home',
        component: () =>
            import(/* webpackChunkName: "apiexchange-home-view" */ '@/modules/home/_components/welcome.vue'),
        meta: {
            name: 'Home',
            icon: 'icon-home',
            title: APP_MENU[0].title,
            hide: false,
        },
    },
    {
        path: '/feedback',
        name: 'feedback',
        component: () =>
            import(/* webpackChunkName: "apiexchange-app-chart-view" */ '@/modules/exchange/_components/feedback.vue'),
        meta: {
            name: 'Feedback',
            title: APP_MENU[0].title,
            hide: true,
        },
    },
    {
        path: '/myapis',
        name: 'My APIs',
        component: () => import(/* webpackChunkName: "myapis-home-view" */ '@/modules/myapis/MyAPIsModule.vue'),
        meta: {
            name: 'My APIs',
            icon: 'icon-api',
            title: APP_MENU[0].title,
            hide: false,
        },
    },
    {
        path: '/credentials',
        name: 'Credentials',
        component: () =>
            import(/* webpackChunkName: "apiexchange-home-view" */ '@/modules/myapps/_index/list/Index.vue'),
        meta: {
            name: 'Credentials',
            icon: 'icon-lock',
            title: APP_MENU[0].title,
            hasNoChildren: true,
            requiresAuth: false,
        },
    },
    {
        path: '/credentials/addnew',
        name: 'addnew',
        component: () =>
            import(/* webpackChunkName: "apiexchange-home-view" */ '@/modules/myapps/_index/create/Index.vue'),
        meta: {
            name: 'Add New',
            title: APP_MENU[0].title,
            hasNoChildren: true,
            requiresAuth: false,
            hide: true,
        },
    },
    {
        path: '/credentials/edit/:appName',
        name: 'editapp',
        component: () =>
            import(/* webpackChunkName: "apiexchange-home-view" */ '@/modules/myapps/_index/edit/Index.vue'),
        meta: {
            name: 'Edit App',
            title: APP_MENU[0].title,
            hasNoChildren: true,
            requiresAuth: false,
            hide: true,
        },
    },
    {
        path: '/exchange',
        name: 'exchange',
        component: () =>
            import(/* webpackChunkName: "apiexchange-exchange-view" */ '@/modules/exchange/ExchangeModule.vue'),
        meta: {
            name: 'Exchange',
            icon: 'icon-arrow-sync',
            title: APP_MENU[0].title,
        },
    },
    {
        path: '/exchange/migrate/:ID',
        name: 'migrate',
        component: () =>
            import(
                /* webpackChunkName: "apiexchange-app-proxy-inventory-view" */ '@/modules/exchange/_components/Proxy.vue'
            ),
        meta: {
            name: 'Migrate',
            title: APP_MENU[0].title,
            hide: true,
        },
    },
    {
        path: '/exchange/migrate/:ID/:alert/:message',
        name: 'migrate-params',
        component: () =>
            import(
                /* webpackChunkName: "apiexchange-app-proxy-inventory-view" */ '@/modules/exchange/_components/Proxy.vue'
            ),
        meta: {
            name: 'Migrate',
            title: APP_MENU[0].title,
            hide: true,
        },
    },
    {
        path: '/proxy',
        name: 'proxy',
        component: () =>
            import(/* webpackChunkName: "apiexchange-app-swagger-viewer-view" */ '@/modules/proxy/ProxyModule.vue'),
        meta: {
            name: 'API Proxy Builder',
            icon: 'icon-globe-network',
            title: APP_MENU[0].title,
        },
    },
    {
        path: '/community',
        name: 'Community',
        component: () =>
            import(
                /* webpackChunkName: "apiexchange-community-view" */ '@/modules/community/_components/Community.vue'
            ),
        meta: {
            name: 'Community',
            icon: 'icon-users',
            title: APP_MENU[0].title,
        },
    },
    {
        path: '/playbook',
        name: 'playbook',
        component: () =>
            import(/* webpackChunkName: "apiexchange-playbook-view" */ '@/modules/playbook/_components/Playbook.vue'),
        meta: {
            name: 'Playbook',
            icon: 'icon-circle-info',
            title: APP_MENU[0].title,
        },
    },
    {
        path: '/apiexchange',
        component: () => import(/* webpackChunkName: "apiexchange-microapp-view" */ '@/views/MicroAppView.vue'),
        meta: {
            title: APP_MENU[0].title,
            ccid: APP_MENU[0].ccid,
            name: APP_MENU[0].name,
            icon: APP_MENU[0].icon,
            hasNoChildren: false,
            requiresAuth: false,
            hide: true,
        },
        children: [
            {
                path: 'exchange/overview/:apiid/:apiname',
                name: 'overview',
                component: () =>
                    import(
                        /* webpackChunkName: "apiexchange-app-swagger-viewer-view" */ '@/modules/exchange/_components/apiDetail/Overview.vue'
                    ),
                meta: { name: 'overview' },
            },
            {
                path: 'exchange/editAPIDocumentation/edittext',
                name: 'EditTextSection',
                component: () =>
                    import(
                        /* webpackChunkName: "apiexchange-app-chart-view" */ '@/modules/exchange/_components/Documentation/EditTextSection.vue'
                    ),
                //meta: { name: 'apidetail' },
            },
            {
                path: 'exchange/editAPIDocumentation',
                name: 'EditAPIDocumentation',
                component: () =>
                    import(
                        /* webpackChunkName: "apiexchange-app-chart-view" */ '@/modules/exchange/_components/Documentation/EditAPIDocumentation.vue'
                    ),
                meta: { name: 'EditAPIDocumentation' },
            },
            {
                path: 'exchange/editAPIDocumentation/editor',
                name: 'EditSwagger',
                component: () =>
                    import(
                        /* webpackChunkName: "apiexchange-app-swagger-editor-view" */ '@/modules/exchange/_components/swagger/SwaggerEditorComponent.vue'
                    ),
                meta: { name: 'Editor' },
            },
        ],
    },
];
export const routerConfig: RouteConfig[] = routes;
