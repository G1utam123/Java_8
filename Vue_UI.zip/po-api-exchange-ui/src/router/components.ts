import { RouteConfig } from 'vue-router';
import { routerConfig as microappRouterConfig } from '@/router';

export const componentRouterConfig: RouteConfig = {
    path: '/components',
    meta: {
        name: 'Go to commons',
        icon: 'icon-attachment',
    },
    beforeEnter() {
        window.open('https://nginx-master-po-enterprise-common.kubeodc-test.corp.intranet/');
    },
};

export const shortcutRouterConfig: RouteConfig = {
    path: microappRouterConfig[0].path,
    meta: {
        name: 'Go to my µapp',
        icon: 'icon-attachment',
    },
};
