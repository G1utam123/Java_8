<template>
    <ShellModule :site="site" :menus="menus" :customize="customize">
        <router-view />
    </ShellModule>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { APP_ENTERPRISE_NAV } from '@/utils/app';

@Component
export default class App extends Vue {
    site: string = '';
    menus: string | Record<string, any>[] = [];
    customize: Record<string, any> = {};

    created() {
        this.site = APP_ENTERPRISE_NAV.site;
        this.menus = APP_ENTERPRISE_NAV.menus;
        this.customize = APP_ENTERPRISE_NAV.customize;
    }
}
</script>
