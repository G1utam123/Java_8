import Vue, { CreateElement, ComponentOptions } from 'vue';
import App from '@/App.vue';
import { routerConfig as microappRouterConfig } from '@/router';
import { shortcutRouterConfig } from '@/router/components';
import { APP_CUSTOMIZE, APP_MODE, isAppCustomized, getPublicPath } from '@/utils/constants';
import { APP_ENTERPRISE_NAV, APP_NAME } from '@/utils/app';

const APP_SHORTCUT: string = 'Shortcut';
// 'dev' as mode by default
const mode =
    process.env.VUE_APP_MODE === APP_MODE.DEV || process.env.VUE_APP_MODE === APP_MODE.PROD
        ? process.env.VUE_APP_MODE
        : APP_MODE.DEV;
const config = require('../public/config-' + mode);

let library: any;
let options: ComponentOptions<Vue> = {};

if (isAppCustomized(APP_CUSTOMIZE.SHELL)) {
    require('@centurylink/po-enterprise-shell/dist/po-enterprise-shell.css');

    const importedShell = require(/* webpackChunkName: "shell-ui" */ '@centurylink/po-enterprise-shell');
    library = importedShell.library;
    library.initialize({ publicPath: getPublicPath(), theme: 'portal', enableAppDynamics: false });
} else {
    const ambientShell = (window as any).shell;
    if (!ambientShell || !ambientShell.library) {
        throw new Error(
            `The ambient Shell dependency is not loaded.
        Please check:
            - if you are connected to the VPN.
            - if you have an .env.X.local file overwriting the VUE_APP_SHELL value.
    `
        );
    }

    library = ambientShell.library;
}

// Router setup
const application: any = [];
application.push({
    name: APP_NAME,
    routes: [microappRouterConfig],
    enterpriseNav: isAppCustomized(APP_CUSTOMIZE.ENTERPRISE_NAV) ? APP_ENTERPRISE_NAV : undefined,
});

if (isAppCustomized(APP_CUSTOMIZE.SHELL)) {
    options = Object.assign(options, { render: (ce: CreateElement) => ce(App) });

    library.setApplications(application);
} else {
    if (process.env.VUE_APP_MODE === APP_MODE.DEV) {
        if (isAppCustomized(APP_CUSTOMIZE.ENTERPRISE_NAV)) {
            application.push({ name: APP_SHORTCUT, routes: [shortcutRouterConfig] });
        }
    }

    library.setApplications(application, APP_NAME);
}

// To use with Azure authentication, pass the following values:
const app: any = library.getVue('INTERNAL', 'apihub-application', 'apihub-secret', options);

Vue.prototype.$config = config;

app.$mount('#app');
