<template>
    <router-view data-cy="cy-parent-router__element" />
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

import store, { STORE_KEY } from '@/modules/exchange/_store';

@Component
export default class MicroAppView extends Vue {
    created() {
        const isModuleRegistered = Object.keys(this.$store.state).includes(STORE_KEY);

        if (!isModuleRegistered) {
            this.$store.registerModule(STORE_KEY, store);
        }
        this.$store.dispatch('chiCssVersion', '5.4.0');
        this.$store.dispatch('notifyNetworkErrors', 'ALERT');
    }

    destroyed() {
        this.$store.unregisterModule(STORE_KEY);
    }
}
</script>
