import Vue from 'vue';
import { Module, VuexModule, Action, Mutation } from 'vuex-module-decorators';
import { Store } from 'vuex';
export const STORE_KEY = '$_app';
import { UserContext } from '@/utils/entities/userContext';

@Module({
    namespaced: true,
    name: STORE_KEY,
    store: Vue.prototype.$store,
})
export default class AppStore extends VuexModule {
    static register($store: Store<any>) {
        if (!$store.state[STORE_KEY]) {
            $store.registerModule(STORE_KEY, this);
        }
    }
    static unregister($store: Store<any>) {
        if ($store.state[STORE_KEY]) {
            $store.unregisterModule(STORE_KEY);
        }
    }

    //#region states
    userContext: any;
    //#endregion

    //#region getters
    get getUserContext(): any {
        return this.userContext;
    }
    //#endregion

    //#region mutations
    @Mutation
    setUserContext(userContext: any): any {
        this.userContext = userContext;
    }
    //#endregion

    //#region actions
    @Action
    loadUserContext(userContext: any): any {
        this.context.commit('setUserContext', UserContext.loadUserContext(userContext));
    }
    //#endregion
}
