export class Alert {
    message: string;
    options: {
        color: string;
        size: string;
        tag: string;
        icon: string;
        closable: boolean;
        title: string;
        custom: string;
        customParameters: any;
    };

    constructor(
        message: string,
        options: {
            color?: string;
            size?: string;
            tag?: string;
            icon?: string;
            closable?: boolean;
            title?: string;
            custom?: string;
            customParameters?: any;
        } = {}
    ) {
        const defaultOptions = {
            color: 'success',
            size: 'lg',
            tag: 'cy-alert',
            icon: 'circle-check',
            closable: true,
            title: '',
            custom: '',
            customParameters: {},
        };

        this.message = message;
        this.options = { ...defaultOptions, ...options };
    }
}
