export class CustomModal {
    title: string;
    message: string;
    callback: () => void;
    options: {
        acceptText: string;
        acceptTag: string;
        cancelText: string;
        cancelTag: string;
        cancelCallback: () => void;
    };

    constructor(
        title: string,
        message: string,
        callback: () => void,
        options: {
            acceptText?: string;
            acceptTag?: string;
            cancelText?: string;
            cancelTag?: string;
            cancelCallback?: () => void;
        } = {}
    ) {
        const defaultOptions = {
            acceptText: 'Accept',
            acceptTag: 'cy-modal__accept__button',
            cancelText: 'Cancel',
            cancelTag: 'cy-modal__cancel__button',
            cancelCallback: (): void => undefined,
        };

        this.title = title;
        this.message = message;
        this.callback = callback;
        this.options = { ...defaultOptions, ...options };
    }
}
