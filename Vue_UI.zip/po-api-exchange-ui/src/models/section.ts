export declare class Section {
    id: number;
    apiId: string;
    apiName: any;
    documentation: any;
    sectionType: any;
    filecontent: any;
}
