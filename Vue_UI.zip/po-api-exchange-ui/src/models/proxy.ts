export interface ApplicationKeyData {
    applicationKeyID: string;
    applicationKeyType: string;
    applicationName: string;
    applicationType: string;
    authorizationType: string;
    clientPublicKeys: string;
    customerType: string;
    customernumbers: string;
    itpkmServiceId: string;
    owneremail: string;
    user: string;
    usertype: string;
}
