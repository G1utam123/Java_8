import Vue from 'vue';

/**
 * Makes the http call to the provided endpoint.
 *
 * @param path the path used in the http call. for example: '/def1/def2'.
 * @param method the method of the http call. restricted to the defined entries.
 * @param body the data to be included as body in the http call. no specified format.
 * @returns the response from a successful http call or the error within the error.message (error.message management could require JSON.parse at the destination if an object was used for the response).
 * DOC: https://www.rfc-editor.org/rfc/rfc7231
 */
async function http<T>(path: string, method: 'get' | 'post' | 'put' | 'delete', body?: T): Promise<T> {
    const trace = '> fetch.http (' + method.toUpperCase() + ') ' + path;
    console.log(trace);
    try {
        const url = Vue.prototype.$config.base_url + path;
        switch (method) {
            case 'get':
                return await Vue.prototype.$http.get(url, body);
            case 'post':
                return await Vue.prototype.$http.post(url, body);
            case 'put':
                return await Vue.prototype.$http.put(url, body);
            case 'delete':
                return await Vue.prototype.$http.delete(url, body);
        }
    } catch (error: any) {
        console.error(trace + ': ' + error.message);
        throw new Error(error.response?.data ? JSON.stringify(error.response.data) : error.message);
    }
}

export async function get<T>(path: string, body?: T): Promise<T> {
    return http<T>(path, 'get', body);
}

export async function post<T>(path: string, body?: T): Promise<T> {
    return http<T>(path, 'post', body);
}

export async function put<T>(path: string, body?: T): Promise<T> {
    return http<T>(path, 'put', body);
}

// 'delete' is a reserved word so an alias is required
async function _delete<T>(path: string, body?: T): Promise<T> {
    return http<T>(path, 'delete', body);
}
export { _delete as delete };
