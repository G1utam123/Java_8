export class OrderUtils {
    static orderEnvironments(environments: string[]): string[] {
        const environmentsOrdered: string[] = [];
        if (environments?.length > 0) {
            let environmentsAndPriorities: EnvironmentPriority[] = [];
            environments.forEach((environment) => {
                environmentsAndPriorities.push({
                    environment: environment,
                    priority: getPriorityFromEnvironment(environment),
                });
            });
            environmentsAndPriorities = environmentsAndPriorities.sort((a, b) => (a.priority < b.priority ? -1 : 1));
            environmentsAndPriorities.forEach((envOrdered) => {
                environmentsOrdered.push(envOrdered.environment);
            });
        }
        return environmentsOrdered;
    }
}

export function getPriorityFromEnvironment(environment: string): number {
    let priority = 0;
    if (environment.includes(ORDER_LABEL_ENVIRONMENTS.DEV)) {
        priority = ORDER_PRIORITY_ENVIRONMENTS.DEV;
    }
    if (environment.includes(ORDER_LABEL_ENVIRONMENTS.TEST)) {
        priority = ORDER_PRIORITY_ENVIRONMENTS.TEST;
    }
    if (environment.includes(ORDER_LABEL_ENVIRONMENTS.MOCK)) {
        priority = ORDER_PRIORITY_ENVIRONMENTS.MOCK;
    }
    if (environment.includes(ORDER_LABEL_ENVIRONMENTS.SANDBOX)) {
        priority = ORDER_PRIORITY_ENVIRONMENTS.SANDBOX;
    }
    if (environment.includes(ORDER_LABEL_ENVIRONMENTS.PROD)) {
        priority = ORDER_PRIORITY_ENVIRONMENTS.PROD;
    }
    return priority;
}

export interface EnvironmentPriority {
    environment: string;
    priority: number;
}

export const ORDER_LABEL_ENVIRONMENTS = {
    DEV: 'dev',
    TEST: 'test',
    MOCK: 'mock',
    SANDBOX: 'sandbox',
    PROD: 'prod',
};

export const ORDER_PRIORITY_ENVIRONMENTS = {
    DEV: 1,
    TEST: 2,
    MOCK: 3,
    SANDBOX: 4,
    PROD: 5,
};
