// eslint-disable-next-line
import { DataTableRow, TableTemplate } from '@/models/chiTableTypes';

export class SearchUtils {
    static formSearchValueString(localTableDataBody: DataTableRow[]): string[] {
        const localTableData: DataTableRow[] = [...localTableDataBody];
        let searchValues: string[] = [];

        if (localTableData.length > 0) {
            searchValues = localTableData.map((rowElement: DataTableRow) => {
                let rowValue = '';

                rowValue += rowElement.id;
                rowElement.data.forEach((dataElement: string | TableTemplate) => {
                    if (typeof dataElement === 'string') {
                        rowValue += dataElement;
                    } else {
                        rowValue += (dataElement?.payload && dataElement.payload[dataElement.template]) ?? '';
                    }
                    if (rowElement.nestedContent?.table?.data) {
                        rowValue += SearchUtils.formSearchValueString(rowElement.nestedContent.table?.data);
                    }
                });
                return rowValue.toLowerCase();
            });
        }
        return searchValues;
    }
}
