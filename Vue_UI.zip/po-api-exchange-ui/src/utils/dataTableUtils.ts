import {
    DataTableRow,
    FilterType,
    TableTemplate,
    ProductsTableResponse,
    ProxiesTableResponse,
} from '@/models/chiTableTypes';

export class DataTableUtils {
    static getProductsTableBody(
        data: ProductsTableResponse[],
        tableTemplates: Record<string, string>,
        filters: FilterType[]
    ): DataTableRow[] {
        const localTableData: DataTableRow[] = [];
        const localData: ProductsTableResponse[] = [...data];
        localData.forEach((element: ProductsTableResponse) => {
            const row: DataTableRow = {
                id: element.displayName.toString(),
                active: false,
                data: this.getProductsRowData(localData, element.displayName.toString(), tableTemplates),
                nestedContent: {
                    table: {
                        data: [
                            {
                                id: element.displayName.toString(),
                                active: false,
                                data: this.getProductsDescription(
                                    localData,
                                    element.displayName.toString(),
                                    tableTemplates
                                ),
                            },
                        ],
                    },
                    payload: element,
                },
            };
            localTableData.push(row);
        });

        return localTableData;
    }

    static getProductsRowData(
        data: ProductsTableResponse[],
        id: string,
        tableTemplates: Record<string, string>
    ): (string | TableTemplate)[] {
        const row: (string | TableTemplate)[] = [];

        for (const key in tableTemplates) {
            const value = tableTemplates[key];
            const dataIndex = data.findIndex(
                (element: ProductsTableResponse) => element.displayName.toString() === id.toString()
            );
            const template: TableTemplate = {
                template: value,
                payload: { [value]: data[dataIndex][value as keyof ProductsTableResponse], element: data[dataIndex] },
            };
            row.push(template);
        }

        return row;
    }

    static getProductsDescription(
        data: ProductsTableResponse[],
        id: string,
        tableTemplates: Record<string, string>
    ): (string | TableTemplate)[] {
        const row: (string | TableTemplate)[] = [];
        const dataIndex = data.findIndex(
            (element: ProductsTableResponse) => element.displayName.toString() === id.toString()
        );
        const template: TableTemplate = {
            template: 'description',
            payload: {
                ['description']: data[dataIndex]['description' as keyof ProductsTableResponse],
                element: data[dataIndex],
            },
        };
        row.push(template);
        return row;
    }

    static getProxyTableBody(
        data: ProxiesTableResponse[],
        tableTemplates: Record<string, string>,
        filters: FilterType[]
    ): DataTableRow[] {
        const localTableData: DataTableRow[] = [];
        const localData: ProxiesTableResponse[] = [...data];

        localData.forEach((element: ProxiesTableResponse) => {
            const row: DataTableRow = {
                id: element.resourceGuid.toString(),
                active: false,
                data: this.getProxyRowData(localData, element.resourceGuid.toString(), tableTemplates),
                allowMigration: element.allowMigration,
            };
            localTableData.push(row);
        });

        return localTableData;
    }

    static getMyProxiesDevTestTableBody(
        data: ProxiesTableResponse[],
        tableTemplates: Record<string, string>
    ): DataTableRow[] {
        const localTableData: DataTableRow[] = [];
        const localData: ProxiesTableResponse[] = [...data];

        localData.forEach((element: ProxiesTableResponse) => {
            const row: DataTableRow = {
                id: element.resourceGuid.toString(),
                active: false,
                data: this.getProxyRowData(localData, element.resourceGuid.toString(), tableTemplates),
                nestedContent: {
                    table: {
                        data: [
                            {
                                id: element.resourceGuid.toString(),
                                active: false,
                                data: this.getProxyRowDataNestedContent(
                                    localData,
                                    element.resourceGuid.toString(),
                                    tableTemplates
                                ),
                            },
                        ],
                    },
                    payload: element,
                },
            };
            localTableData.push(row);
        });

        return localTableData;
    }

    static getMyProxiesProdTableBody(
        data: ProxiesTableResponse[],
        tableTemplates: Record<string, string>
    ): DataTableRow[] {
        const localTableData: DataTableRow[] = [];
        const localData: ProxiesTableResponse[] = [...data];

        localData.forEach((element: ProxiesTableResponse) => {
            const row: DataTableRow = {
                id: element.resourceGuid.toString(),
                active: false,
                data: this.getProxyRowData(localData, element.resourceGuid.toString(), tableTemplates),
            };
            localTableData.push(row);
        });

        return localTableData;
    }

    static getProxyRowData(
        data: ProxiesTableResponse[],
        id: string,
        tableTemplates: Record<string, string>
    ): (string | TableTemplate)[] {
        const row: (string | TableTemplate)[] = [];
        let dataIndex;
        for (const key in tableTemplates) {
            const value = tableTemplates[key];

            dataIndex = data.findIndex(
                (element: ProxiesTableResponse) => element.resourceGuid.toString() === id.toString()
            );
            const template: TableTemplate = {
                template: value,
                payload: { [value]: data[dataIndex][value as keyof ProxiesTableResponse], element: data[dataIndex] },
            };
            row.push(template);
        }
        const actionsTemplate: TableTemplate = {
            template: 'actions',
            payload: { id: data[dataIndex].resourceGuid, allowMigration: data[dataIndex].allowMigration },
        };
        row.push(actionsTemplate);

        return row;
    }

    static getProxyRowDataNestedContent(
        data: ProxiesTableResponse[],
        id: string,
        tableTemplates: Record<string, string>
    ): (string | TableTemplate)[] {
        const row: (string | TableTemplate)[] = [];
        let dataIndex;
        for (const key in tableTemplates) {
            const value = tableTemplates[key];
            if (value === 'resourceTaxonomy') {
                dataIndex = data.findIndex(
                    (element: ProxiesTableResponse) => element.resourceGuid.toString() === id.toString()
                );
                const template: TableTemplate = {
                    template: 'replaceUrlToValue',
                    payload: {
                        ['replaceUrlToValue']: data[dataIndex]['replaceUrlToValue' as keyof ProxiesTableResponse],
                        element: data[dataIndex],
                    },
                };
                row.push(template);
            }
        }

        return row;
    }
}
