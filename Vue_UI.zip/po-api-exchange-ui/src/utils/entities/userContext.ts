export class UserContext {
    static loadUserContext(userContext: any): any {
        const resultList: string[] = [];
        if (!!userContext) {
            const regex = /APIHUB (ADMIN|(PRODUCT|PROXY)_[A-z0-9,-]*).*/g;
            userContext.groups.forEach((group) => {
                const matches = group.match(regex);
                if (matches) {
                    resultList.push(matches.join(''));
                }
            });
            userContext.groups = resultList;
        }
        return userContext;
    }

    static parseJwt(token): any {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace('-', '+').replace('_', '/');
        return JSON.parse(window.atob(base64));
    }
}
