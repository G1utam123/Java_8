export class Environments {
    static parseListOfEnvironmentsToString(envList: string[]): string {
        let envListAsString = '';
        envList.forEach((env) => {
            if (envListAsString) {
                envListAsString += ', ';
            }
            envListAsString += env;
        });
        return envListAsString;
    }
}
