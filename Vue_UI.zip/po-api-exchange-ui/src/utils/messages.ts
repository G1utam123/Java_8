export const MODAL_TITLES = {
    DELETE_CLIENT: 'Delete API',
};

export const MODAL_APPLY_BUTTONS = {
    DELETE_CLIENT: 'Delete',
};

export const MODAL_MESSAGE_FUNC = {
    deleteClient: (apiClientName: string): string => `Are you sure you want to delete ${apiClientName}`,
};
