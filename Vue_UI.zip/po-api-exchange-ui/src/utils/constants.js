module.exports = {
    APP_MODE: {
        DEV: 'dev',
        PR: 'pr',
        STAGE: 'stage',
        PROD: 'prod',
        TEST_E2E: 'test-e2e',
        TEST_UNIT: 'test-unit',
    },
    APP_TARGET: {
        STANDALONE: 'standalone', // bundle for standalone app
        COMPONENT: 'component', // bundle for exporting the µcomponents library (only available using APP_MODE.PROD)
        LIBRARY: 'library', // bundle for exporting the µapp library (only available using APP_MODE.PROD)
        TESTING: 'testing', // bundle for unit testing
    },
    APP_CUSTOMIZE: {
        ENTERPRISE_NAV: 'enterprise-nav', // using a customized enterprise-nav instead of the default
        SHELL: 'shell', // using a customized shell version (defined in package.json)
    },
    isAppCustomized: (appCustomize) => process.env.VUE_APP_CUSTOMIZE.split(',').includes(appCustomize),
    getPublicPath: (appCustomize = process.env.VUE_APP_CUSTOMIZE) =>
        !appCustomize.split(',').includes('shell') ? '/enterprise' : '/',
};
