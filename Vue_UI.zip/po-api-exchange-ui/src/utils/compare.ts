export class Compare {
    static isElementEmpty(element: any) {
        if (element === undefined || element === '' || element === null) {
            return true;
        } else {
            return false;
        }
    }
    static doesElementExist(array: any[], value: string): boolean {
        return array.findIndex((item) => value.toLowerCase() === item.toLowerCase()) !== -1;
    }
    static concatenateElements(source: any, target: any) {
        if (!this.isEmptyArray(source) && !this.isEmptyArray(target)) {
            return source.concat(',', target);
        } else if (!this.isEmptyArray(source)) {
            return source;
        } else {
            return target;
        }
    }
    static isEmptyArray<T>(array: T[]): boolean {
        return !array || array.length === 0;
    }
    static checkElementsHaveValues([...array]: any[]): boolean {
        let valid = true;
        for (const values of array) {
            if (this.isElementEmpty(values)) {
                valid = false;
            }
        }
        return valid;
    }
    static removeEmptyEntries([...array]: any[]): any[] {
        const copyArray: any[] = [];
        for (const value of array) {
            if (!this.isElementEmpty(value)) {
                copyArray.push(value);
            }
        }
        return copyArray;
    }
}
