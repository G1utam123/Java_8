import { v4 as uuidv4 } from 'uuid';

export class UUID {
    protected uuid_str: string;

    constructor(uuid_str: string) {
        this.uuid_str = uuid_str?.length > 0 ? uuid_str : UUID.newUuid();
    }

    public static newUuid(): string {
        return new UUID(uuidv4()).toString();
    }

    public toString(): string {
        return this.uuid_str;
    }
}
