import { AppMenu, EnterpriseNav } from '@/models/app';

const APP_NAME: string = 'api-exchange';

const APP_MENU: AppMenu[] = [
    {
        title: 'API Hub',
        name: 'API-Exchange App',
        ccid: undefined,
        icon: 'icon-rocket',
    },
];

const site: string = 'API Hub';
const APP_ENTERPRISE_NAV: EnterpriseNav = {
    site: site,
    menus: [
        {
            [site]: {
                description: 'Internal app description',
                origin: [
                    {
                        PF: 'https://internal.url',
                    },
                ],
                menu: [],
            },
        },
    ],
    customize: {
        infobar: {
            hide: false,
            content: [
                {
                    position: 1,
                    hide: true,
                    text: 'explore',
                    path: 'https://www.lumen.com/en-us/home.html',
                },
                {
                    position: 2,
                    hide: false,
                    text: 'help',
                    path: 'https://mysupportdesk.service-now.com/msd?id=sc_cat_item&table=sc_cat_item&sys_id=82cb22121b246514873d6288bd4bcb14',
                },
                {
                    position: 3,
                    hide: true,
                    text: 'contact',
                    path: 'mailto:APIEnablementTeam@centurylink.com?subject=API%20Proxy%20request%20for%20help',
                },
            ],
        },
        infofooter: {
            contact: {
                hide: false,
                path: 'mailto:APIEnablementTeam@centurylink.com?subject=API%20Proxy%20request%20for%20help',
            },
        },
        notification: {
            hide: true,
        },
        enterprises: {
            hide: true,
        },
        user: {
            profile: {
                hide: true,
            },
            notificationSettings: {
                hide: true,
            },
        },
    },
};

export { APP_NAME, APP_MENU, APP_ENTERPRISE_NAV };
