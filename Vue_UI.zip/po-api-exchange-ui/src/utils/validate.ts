import { HTTP_STRING, HTTPS_STRING } from '@/modules/exchange/_constants/proxy';

export class Validate {
    static validateHostname(input: string): boolean {
        return (
            input?.length > 0 &&
            (input.startsWith(HTTP_STRING) || input.startsWith(HTTPS_STRING)) &&
            input.indexOf('://') + 3 < input?.length
        );
    }
    static isValidDomain(input: string): boolean {
        return !input.endsWith('/') && !input.endsWith('?') && !input.endsWith('*');
    }
}
