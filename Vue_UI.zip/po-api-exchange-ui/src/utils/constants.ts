export const { APP_MODE, APP_TARGET, APP_CUSTOMIZE, isAppCustomized, getPublicPath } = require('@/utils/constants.js');

export const ACTIONS: Record<string, string> = {
    userContext: 'userContext',
};

export const CALENDAR_EVENT_TYPE: Record<string, string> = {
    DAYS: 'days',
    HOURS: 'hours',
};

export const TOOLTIP_TEXTS = {
    DEFAULT: 'Copy to clipboard',
    COPIED: 'Copied!',
};
export const HIDE_TIME = 5000;
export const CHI_WAIT_TIME = 300;

export const CARD_LABELS: Record<string, string> = {
    CARD_COMPACT_2: 'cardCompact2',
    HELP_TEXT_CARD_COMPACT_2: 'helpText_CardCompact2',
    SECONDARY_TAG_CARD_COMPACT_2: 'secondaryTag_CardCompact2',
    SECONDARY_ITEM_CARD_COMPACT_2: 'secondaryItem_CardCompact2',
    PRIMARY_TAG_CARD_COMPACT_2: 'primaryTag_CardCompact2',
    PRIMARY_ITEM_CARD_COMPACT_2: 'primaryItem_CardCompact2',
    CARD_TITLE_CARD_COMPACT_2: 'cardTitle_CardCompact2',
    CARD_COMPACT_1: 'cardCompact1',
    HELP_TEXT_CARD_COMPACT_1: 'helpText_CardCompact1',
    SECONDARY_TAG_CARD_COMPACT_1: 'secondaryTag_CardCompact1',
    SECONDARY_ITEM_CARD_COMPACT_1: 'secondaryItem_CardCompact1',
    PRIMARY_TAG_CARD_COMPACT_1: 'primaryTag_CardCompact1',
    PRIMARY_ITEM_CARD_COMPACT_1: 'primaryItem_CardCompact1',
    CARD_TITLE_CARD_COMPACT_1: 'cardTitle_CardCompact1',
    CARD_2: 'card2',
    SECONDARY_TAG_CARD_2: 'secondaryTag_Card2',
    SECONDARY_ITEM_CARD_2: 'secondaryItem_Card2',
    PRIMARY_TAG_CARD_2: 'primaryTag_Card2',
    PRIMARY_ITEM_CARD_2: 'primaryItem_Card2',
    CARD_1: 'card1',
    SECONDARY_TAG_CARD_1: 'secondaryTag_Card1',
    SECONDARY_ITEM_CARD_1: 'secondaryItem_Card1',
    PRIMARY_TAG_CARD_1: 'primaryTag_Card1',
    PRIMARY_ITEM_CARD_1: 'primaryItem_Card1',
};

export const CARD_LOGICAL_LABELS: Record<string, string> = {
    AVAILABLE_VALUE_CARD_1: 'availableValueCard1',
    AVAILABLE_VALUE_CARD_2: 'availableValueCard2',
    AVAILABLE_VALUE_CARD_COMPACT_1: 'availableValueCardCompact1',
    AVAILABLE_VALUE_CARD_COMPACT_2: 'availableValueCardCompact2',
};

export const JSON_LABELS: Record<string, string> = {
    CARD_TITLE: 'cardTitle',
    PRIMARY_ITEM: 'primaryItem',
    PRIMARY_TAG: 'primaryTag',
    SECONDARY_ITEM: 'secondaryItem',
    SECONDARY_TAG: 'secondaryTag',
    HELP_TEXT: 'helpText',
    IS_CARD_AVAILABLE: 'isCardAvailable',
};

export const ALERT_DISPLAY_TIME = 7000;

export const FULLCALENDAR_LABELS: Record<string, string> = {
    START_DATE: 'Event Start Date',
    END_DATE: 'Event End date',
    TYPE: 'typeEvent_event1',
    TITLE: 'tittle_event1',
    DAYS: 'days',
    HOURS: 'hours',
};

export const FULLCALENDAR_VIEW_ALL_LABELS: Record<string, string> = {
    START_DATE_VIEW_ALL: 'Start Date',
    ID: 'id',
};

export const PIECHART_LABELS: Record<string, string> = {
    label1: 'label1',
    label2: 'label2',
    label3: 'label3',
    value1: 'value1',
    value2: 'value2',
    value3: 'value3',
    color1: 'color1',
    color2: 'color2',
    color3: 'color3',
    LABEL_FORMAT: 'labelFormat',
    TOOLTIP_FORMAT: 'tootipFormat',
    WITH_LABELS: 'withLabels',
    WITH_LEGEND: 'withLegends',
    WITH_TOOLTIPS: 'withToolTips',
};

export const PIECHART_CONSTANTS: Record<string, string> = {
    linux: 'Linux',
    windows: 'Windows',
    mac: 'Mac',
    red: 'hsl(10, 100%, 50%)',
    green: 'hsl(100, 100%, 50%)',
    blue: 'hsl(200, 100%, 50%)',
    tooltip: 'Kb',
};

export const DATATABLE_PAGE_DATA: Record<any, any> = {
    pageConfig: {
        pageName: 'TestData202024',
        viewName: 'TestviewName',
        searchString: {},
        oldViewName: 'TestviewName2022',
        defaultView: false,
    },
    pages: 'TestData202024',
};

export const RUDRA_CONFIG_DATA: Record<any, any> = {
    TestData202024: [
        {
            data: null,
            status: 0,
            message: null,
            cachedResponse: false,
            responseTime: 0,
            networkResponseTime: 0,
            result: null,
            addlResults: null,
            queriedOnCache: false,
            createDate: '2021-03-24T17:28:14',
            updateDate: '2021-04-26T13:08:17',
            secondaryKey: null,
            supplementalInfo: null,
            reqText: null,
            enterpriseId: null,
            avgResponseTime: 0,
            alertType: null,
            activityType: null,
            viewName: 'TestviewName',
            viewData:
                '{"columnResize":true,"noResultsMessage":"No Results Found....NONO....","activePage":1,"resultsPerPage":10,"selectable":true,"style":{"portal":true,"bordered":false,"noBorder":true,"hover":false,"striped":true,"size":"md"},"pagination":{"compact":true,"firstLast":true,"pageJumper":true},"columnSizes":{"xs":["0","5","15","5","5","5","5","5"],"sm":["10","0","5","15","5","5","5","5"],"md":["5","10","0","5","15","5","5","5"],"lg":["10","5","10","0","5","15","5","5"],"xl":["0","5","5","10","0","5","15","5"]}}',
            isDefault: false,
            isSticky: false,
        },
    ],
};
