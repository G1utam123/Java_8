import { RouteConfig } from 'vue-router';
declare class EnterpriseNav {
    site: string;
    menus: string | Record<string, any>[];
    customize: Record<string, any>;
}
declare class MicroAppLibrary {
    name: string;
    enterpriseNav: EnterpriseNav | undefined;
    routerPath: RouteConfig[];
}

export declare const library: MicroAppLibrary;
export {};
