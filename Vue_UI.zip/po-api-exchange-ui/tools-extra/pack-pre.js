'use strict';

const fs = require('fs');

let raw = fs.readFileSync('package.json');
let packageJson = JSON.parse(raw);
let libraryPackageJson = {};

if (process.argv[2] === 'library') {
    libraryPackageJson.name = packageJson.name;
    libraryPackageJson.version = packageJson.version;
    libraryPackageJson.types = packageJson.types;
    libraryPackageJson.files = packageJson.files;
    libraryPackageJson.main = process.argv[3].replace("@centurylink/", "").replace("@portal-framework/", "");
} else {
    libraryPackageJson.name = packageJson.component.name;
    libraryPackageJson.version = packageJson.component.version;
    libraryPackageJson.types = packageJson.component.types;
    libraryPackageJson.files = packageJson.component.files;
    libraryPackageJson.main = process.argv[3];
}

libraryPackageJson.private = packageJson.private;
libraryPackageJson.publishConfig = packageJson.publishConfig;
libraryPackageJson.repository = packageJson.repository;

fs.writeFileSync('package-library.json', JSON.stringify(libraryPackageJson, null, 2));
