require('dotenv').config();

const { getPublicPath } = require('../src/utils/constants');
console.log(getPublicPath());