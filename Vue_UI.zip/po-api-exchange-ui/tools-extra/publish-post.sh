#!/bin/bash
set -e

echo 'Rename package-library-base.json by package.json'
mv package-library-base.json package.json
