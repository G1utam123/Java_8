#!/bin/bash
set -e

if [ -f package-library.json ]; then
    echo 'Rename old package.json by package-library-base.json'
    mv package.json package-library-base.json
    echo 'Rename package-library.json by package.json'
    mv package-library.json package.json
fi
