const { defineConfig } = require('cypress');

module.exports = defineConfig({
    chromeWebSecurity: false,
    defaultCommandTimeout: 10000,
    defaultTimeout: 50000,
    pageLoadTimeout: 150000,
    reporter: 'junit',
    reporterOptions: {
        mochaFile: 'tests/e2e/reports/cypress-browser.[hash].xml',
    },
    viewportHeight: 960,
    viewportWidth: 1280,
    e2e: {
        baseUrl: 'https://localhost:9090',
        fixturesFolder: 'tests/e2e/fixtures',
        screenshotsFolder: 'tests/e2e/screenshots',
        supportFile: 'tests/e2e/support/index.js',
        videosFolder: 'tests/e2e/videos',
        experimentalRunAllSpecs: true,
        numTestsKeptInMemory: 0,
        setupNodeEvents(on, config) {
            require('@cypress/code-coverage/task')(on, config); // e2e cypress tests
            on('file:preprocessor', require('@cypress/code-coverage/use-babelrc'));

            require('dotenv').config();
            config.env.VUE_APP_CUSTOMIZE = process.env.VUE_APP_CUSTOMIZE;
            config.specPattern = config.env.testType || 'tests/e2e/specs';

            return config;
        },
    },
});
