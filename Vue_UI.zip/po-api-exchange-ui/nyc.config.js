let nycConfiguration = {
    cache: false,
    instrument: false,
    sourceMap: false,

    include: ['src/'],
    exclude: ['cypress/', 'assets/', 'tests/', 'src/assets/', '**/*.d.ts'],
    extension: ['.vue', '.ts', '.js'],
    reporter: ['lcov', 'text-summary'],

    branches: 18,
    lines: 45,
    functions: 45,
    statements: 45,
};

module.exports = nycConfiguration;
