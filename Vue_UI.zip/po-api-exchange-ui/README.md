# How do I start developing a Portal Framework µapp?

    Visit [Portal Framework Confluence - First steps for running a µapp](https://ctl.atlassian.net/wiki/spaces/EPF/pages/672416989237/First+steps+for+running+a+app).

