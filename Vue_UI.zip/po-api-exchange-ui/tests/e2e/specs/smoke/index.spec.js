/// <reference types='Cypress'/>

describe('Commands and mocklogin', () => {
    beforeEach(function () {
        cy.mockLogin();
    });

    it('No path, profile and env by default', () => {
        cy.intercept('GET', '/v1/products/apigee?planet=PROD&internalExternal=EXTERNAL', {
            body: [],
            statusCode: 200,
        });
        cy.intercept('GET', '/v1/apiProxyDetails*', { body: [], statusCode: 200 });
        cy.visit('/exchange');
        cy.getStore('userState').its('isLoggedin').should('equal', true);
    });
});
