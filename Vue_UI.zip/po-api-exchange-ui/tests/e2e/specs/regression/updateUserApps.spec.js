/// <reference types="Cypress" />

import config from '../../../../public/config-dev.json';

const BASE_URL = Cypress.env('CYPRESS_SANITY_BASE_URL') ? Cypress.env('CYPRESS_SANITY_BASE_URL') : config.base_url;
const BACKDOOR_URL = Cypress.env('CYPRESS_SANITY_BASE_URL')
    ? Cypress.env('CYPRESS_SANITY_BASE_URL')
    : config.backdoor_url;
let user_payload = require('../../fixtures/user.json');
let createDeveloper_payload = require('../../fixtures/createDeveloperAccount.json');
let accessToken,
    deletedAppName,
    updatePayload = '';

describe('Update user apps', () => {
    before(() => {
        cy.request({
            method: 'PUT',
            url: `${BACKDOOR_URL}/backdoor/internal`,
            headers: {
                'Content-Type': 'application/json',
            },
            failOnStatusCode: false,
            body: user_payload,
        }).then((resp) => {
            accessToken = resp.body.access_token;
        });

        cy.request({
            method: 'GET',
            url: `${config.developer_url}/v1/organizations/ext/developers/${createDeveloper_payload[1].email}`,
            headers: {
                authorization: createDeveloper_payload[0].auth,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            if (resp.status != 200) {
                cy.request({
                    method: 'POST',
                    url: `${config.developer_url}/v1/organizations/ext/developers`,
                    headers: {
                        authorization: createDeveloper_payload[0].auth,
                        'Content-Type': 'application/json',
                    },
                    failOnStatusCode: false,
                    body: createDeveloper_payload[1],
                });
            }
        });
    });

    it('Update Single User Apps', () => {
        cy.fixture('CreateUserApp').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/createuserapps`,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.body).is.not.null;
                updatePayload = `{
                    "credentials": [
                        {
                            "apiProducts": [
                                {
                                    "apiproduct": "API Health Check"
                                }
                            ],
                            "consumerKey": "${resp.body.credentials[0].consumerKey}",
                            "expiresAt": -1
                        }
                    ],
                    "name": "prakash_test",
                    "keyExpiresIn": -1,
                    "status": "approved",
                    "attributes": [
                        {
                            "name": "environment",
                            "value": "dev1"
                        },
                        {
                            "name": "DisplayName",
                            "value": "prakash_test"
                        }
                    ]
                }
                `;

                cy.request({
                    method: 'POST',
                    url: `${BASE_URL}/v1/updateuserapps`,
                    headers: {
                        accept: 'application/json',
                        'content-type': 'application/json',
                        authorization: 'Bearer ' + accessToken,
                    },
                    failOnStatusCode: false,
                    body: updatePayload,
                }).then((resp) => {
                    expect(resp.status, 'Response status code should be match').to.eq(200);
                    expect(JSON.parse(updatePayload).name).to.be.eq(resp.body.name);
                    expect(JSON.parse(updatePayload).credentials[0].apiProducts[0].apiproduct).to.be.eq(
                        resp.body.credentials[0].apiProducts[0].apiproduct
                    );
                    expect(resp.duration, 'Response time should not be > 30000 milliSeconds').to.not.be.greaterThan(
                        30000
                    );
                    expect(resp.headers, 'Should be available in response header').to.include({
                        'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                        expires: '0',
                    });
                });
            });
        });
    });

    it(`Get Bad Request message while updating the user apps with multiple apps`, () => {
        cy.fixture('createNewAppStub3').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/createuserapps`,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload,
            });
        });
        cy.fixture('updateMultipleUserApps').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/updateuserapps`,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response status code should be match').to.eq(400);
                expect(resp.body.error, 'error message should be match').to.be.eql('Bad Request');
                expect(resp.headers, 'Should be available in response header').to.include({
                    'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                    expires: '0',
                    'content-type': 'application/json',
                });
            });
        });
    });

    it('Get unauthorized error while updating the user apps by using invalid token', () => {
        cy.fixture('updateUserApps').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/updateuserapps`,
                headers: {
                    accept: 'application/json',
                    'content-type': 'application/json',
                    authorization: 'Bearer ' + accessToken + 1,
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response status code should be match').to.eq(401);
                expect(resp.duration, 'Response time should not be > 30000 milliSeconds').to.not.be.greaterThan(30000);
                expect(resp.headers, 'Should be available in response header').to.include({
                    'content-type': 'application/json',
                });
            });
        });
    });

    it('Get invalid method error while Updating Single User Apps with invalid method type', () => {
        cy.fixture('singleDevApp').then((payload) => {
            cy.request({
                method: 'PUT',
                url: `${BASE_URL}/v1/updateuserapps`,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response status code should be match').to.eq(405);
                expect(resp.body.error, 'Error message should be equal').to.be.eql('Method Not Allowed');
                expect(resp.headers, 'Should be available in response header').to.include({
                    'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                    expires: '0',
                    'content-type': 'application/json',
                });
            });
        });
    });

    it('Get unsupported media error while Updating Single User Apps with invalid content type', () => {
        cy.fixture('singleDevApp').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/updateuserapps`,
                headers: {
                    accept: 'application/json',
                    'content-type': 'text/xml',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response status code should be match').to.eq(415);
                expect(resp.body.error, 'Error message should be equal').to.be.eql('Unsupported Media Type');
                expect(resp.headers, 'Should be available in response header').to.include({
                    'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                    expires: '0',
                    'content-type': 'application/json',
                });
            });
        });
    });

    it(`Get error while updating the user apps with invalid payload`, () => {
        cy.fixture('multiDevApp').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/updateuserapps`,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response status code should be match').to.eq(500);
                expect(resp.headers, 'Should be available in response header').to.include({
                    'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                    expires: '0',
                });
            });
        });
    });

    after('Clean Up', () => {
        cy.fixture('CreateUserApp').then((payload) => {
            deletedAppName = payload.name;
            cy.request({
                method: 'DELETE',
                url: `${BASE_URL}/v1/deleteuserapp/${deletedAppName}`,
                headers: {
                    accept: '*/*',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
            });
        });
    });
});
