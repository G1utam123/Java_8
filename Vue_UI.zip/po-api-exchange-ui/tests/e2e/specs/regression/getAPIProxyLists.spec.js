/// <reference types="Cypress" />

import data from '../../../../public/config-dev.json';

const BASE_URL = Cypress.env('CYPRESS_SANITY_BASE_URL') ? Cypress.env('CYPRESS_SANITY_BASE_URL') : data.base_url;
const BACKDOOR_URL = Cypress.env('CYPRESS_SANITY_BASE_URL')
    ? Cypress.env('CYPRESS_SANITY_BASE_URL')
    : data.backdoor_url;
let user_payload = require('../../fixtures/user.json');
let accessToken = '';
let env = 'dev1';

describe('Get API proxy Lists', () => {
    before(() => {
        cy.request({
            method: 'PUT',
            url: `${BACKDOOR_URL}/backdoor/internal`,
            headers: {
                'Content-Type': 'application/json',
            },
            failOnStatusCode: false,
            body: user_payload,
        }).then((resp) => {
            accessToken = resp.body.access_token;
        });
    });

    it('Get the List of API Proxy Details', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/apiProxyDetails`,
            qs: { env: env },
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(200);
            expect(resp.body[0].environment, 'Environment value should match').to.eq('dev1');
            expect(resp.body.length, 'API Proxy Lists should be > 0').to.be.greaterThan(0);
            expect(resp.duration, 'Response time should be < 30000 milliSeconds').to.not.be.greaterThan(30000);
            expect(Number.isNaN(+resp.body[0].mediatedResourceId)).to.eq(false);
            expect(resp.body[0].resourceTaxonomy).to.be.a('string');
            expect(resp.body[0].resourceName).to.be.a('string');
            expect(resp.body[0].version).to.be.a('string');
            expect(resp.body[0].active).to.be.a('string');
            expect(resp.body[0].endPointUrl).to.be.a('string');
            expect(Number.isNaN(+resp.body[0].throttlingRequestsPerSec)).to.eq(false);
            expect(Number.isNaN(+resp.body[0].timeoutSecs)).to.eq(false);
            expect(resp.body[0].connectionKeepAlive).to.be.a('string');
            expect(resp.body[0].owningApplicationId).to.be.a('string');
            expect(resp.body[0].owningApplicationKey).to.be.a('string');
            expect(resp.body[0].replaceUrlFromValue).to.be.a('string');
            expect(resp.body[0].replaceUrlToValue).to.be.a('string');
            expect(resp.body[0].routingExpression).to.be.a('string');
            expect(resp.body[0].resourceGuid).to.be.a('string');
            expect(resp.body[0].validAuthTypes).to.be.a('string');
            expect(resp.body[0].environment).to.be.a('string');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get invalid environment in response while fetching the API Proxy details by using invalid environment', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/apiProxyDetails`,
            qs: { env: 'test5' },
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(500);
            expect(resp.body, 'Error message should be equal').to.be.eql('Invalid environment');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get invalid method type error while fetching the API Proxy details by using invalid method type', () => {
        cy.request({
            method: 'POST',
            url: `${BASE_URL}/v1/apiProxyDetails`,
            qs: { env: env },
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(405);
            expect(resp.body.error, 'Error message should be equal').to.be.eql('Method Not Allowed');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get error while fetching the API proxy details by using invalid accept type in header', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/apiProxyDetails`,
            qs: { env: env },
            headers: {
                accept: 'text/xml',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(406);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
            });
        });
    });

    it('Get unauthorized error while fetching the API proxy by using invalid token', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/apiProxyDetails`,
            qs: { env: env },
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken + '1',
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(401);
            expect(resp.headers, 'Should be available in response header').to.include({
                'content-type': 'application/json',
            });
        });
    });

    it('Get Bad Request error while fetching the API proxy by using junk data', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/apiProxyDetails/%`,
            qs: { env: env },
            headers: {
                accept: 'text/xml',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(400);
        });
    });

    it('Get Bad Request error while fetching the API proxy without using env details', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/apiProxyDetails`,
            headers: {
                accept: 'text/xml',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(400);
        });
    });
});
