/// <reference types="Cypress" />

import data from '../../../../public/config-dev.json';

const BASE_URL = Cypress.env('CYPRESS_SANITY_BASE_URL') ? Cypress.env('CYPRESS_SANITY_BASE_URL') : data.base_url;
const BACKDOOR_URL = Cypress.env('CYPRESS_SANITY_BASE_URL')
    ? Cypress.env('CYPRESS_SANITY_BASE_URL')
    : data.backdoor_url;
let user_payload = require('../../fixtures/user.json');
let accessToken = '';

describe('Get Taxonomy Lists', () => {
    before(() => {
        cy.request({
            method: 'PUT',
            url: `${BACKDOOR_URL}/backdoor/internal`,
            headers: {
                'Content-Type': 'application/json',
            },
            failOnStatusCode: false,
            body: user_payload,
        }).then((resp) => {
            accessToken = resp.body.access_token;
        });
    });

    it('Create request for Get all taxonomy lists', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/taxonomies`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(200);
            expect(resp.duration, 'Response time should not be > 30000 milliseconds').to.be.not.greaterThan(30000);
            expect(resp.body.length, 'Taxonomy list should be > 0').to.be.greaterThan(0);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get error while sending the request to get taxonomy lists with invalid accept type', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/taxonomies`,
            headers: {
                accept: 'text/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.be.eql(406);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
            });
        });
    });

    it('Get error while sending the request to get taxonomy lists with invalid token', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/taxonomies`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken + '1',
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.be.eql(401);
            expect(resp.headers, 'Should be available in response header').to.include({
                'content-type': 'application/json',
            });
        });
    });

    it('Get error while sending the request to get taxonomy lists with invalid method type', () => {
        cy.request({
            method: 'POST',
            url: `${BASE_URL}/v1/taxonomies`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(405);
            expect(resp.body.error, 'Error message should match').to.be.eql('Method Not Allowed');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get error while sending the request to get taxonomy lists with invalid endpoints', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/taxonomie`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(404);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get Bad request error while sending the request to get taxonomy lists with junk data in URL', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/taxonomies/%`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken + '1',
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.be.eql(400);
        });
    });
});
