/// <reference types="Cypress" />

import data from '../../../../public/config-dev.json';

const BASE_URL = Cypress.env('CYPRESS_SANITY_BASE_URL') ? Cypress.env('CYPRESS_SANITY_BASE_URL') : data.base_url;
const BACKDOOR_URL = Cypress.env('CYPRESS_SANITY_BASE_URL')
    ? Cypress.env('CYPRESS_SANITY_BASE_URL')
    : data.backdoor_url;
let user_payload = require('../../fixtures/user.json');
let accessToken = '';
const docIdForDeleteProxy = 'c9709a77-e3f5-4246-a0c1-35a644caea47';

// TODO -- DPEAPI-2195, DPEAPI-611 - Analysis work. Tests will be enabled once implementation is Done.
describe.skip('Delete Existing API Proxies', () => {
    before(() => {
        cy.request({
            method: 'PUT',
            url: `${BACKDOOR_URL}/backdoor/internal`,
            headers: {
                'Content-Type': 'application/json',
            },
            failOnStatusCode: false,
            body: user_payload,
        }).then((resp) => {
            accessToken = resp.body.access_token;
        });
    });

    it('Delete the existing api proxy', () => {
        cy.request({
            method: 'DELETE',
            url: `${BASE_URL}/v1/deleteapi/` + docIdForDeleteProxy,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status should match').to.eq(200);
            expect(resp.isOkStatusCode, 'Status should be OK').ok;
            expect(resp.body).to.be.eql('OK');
            expect(resp.duration, 'Response duration should not > 30000 ').to.not.be.greaterThan(30000);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get error while deleting the api proxy by using invalid documentId', () => {
        cy.request({
            method: 'DELETE',
            url: `${BASE_URL}/v1/deleteapi/` + docIdForDeleteProxy + '-2222',
            headers: {
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Status code should match').to.eq(400);
            expect(resp.body.error, 'Error message should be equal').to.be.eql('Bad Request');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get unauthorized error while deleting the api proxy by using invalid token', () => {
        cy.request({
            method: 'DELETE',
            url: `${BASE_URL}/v1/deleteapi/` + docIdForDeleteProxy,
            headers: {
                authorization: 'Bearer ' + accessToken + '1',
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status should match').to.eq(401);
            expect(resp.headers, 'Should be available in response header').to.include({
                'content-type': 'application/json',
            });
        });
    });

    it('Get invalid method error while deleting the api proxy by using invalid method', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/deleteapi/` + docIdForDeleteProxy,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'status should match').to.eq(405);
            expect(resp.body.error, 'Error message should match').to.be.eql('Method Not Allowed');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });
});
