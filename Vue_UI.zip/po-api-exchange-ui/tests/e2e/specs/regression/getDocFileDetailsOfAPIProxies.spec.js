/// <reference types="Cypress" />

import data from '../../../../public/config-dev.json';

const BASE_URL = Cypress.env('CYPRESS_SANITY_BASE_URL') ? Cypress.env('CYPRESS_SANITY_BASE_URL') : data.base_url;
const BACKDOOR_URL = Cypress.env('CYPRESS_SANITY_BASE_URL')
    ? Cypress.env('CYPRESS_SANITY_BASE_URL')
    : data.backdoor_url;
let user_payload = require('../../fixtures/user.json');
let accessToken = '';
const docIdForProxyDetails = 101;

describe('Get Document File details for API proxies', () => {
    before(() => {
        cy.request({
            method: 'PUT',
            url: `${BACKDOOR_URL}/backdoor/internal`,
            headers: {
                'Content-Type': 'application/json',
            },
            failOnStatusCode: false,
            body: user_payload,
        }).then((resp) => {
            accessToken = resp.body.access_token;
        });
    });

    it('Get document file details for API Proxies', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/docFile/` + docIdForProxyDetails,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status should match').to.eq(200);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, must-revalidate',
                expires: '0',
                'content-type': 'application/octet-stream',
            });
        });
    });

    it('Get unauthorized error while fetching the document file details for API proxy by using invalid token', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/docFile/` + docIdForProxyDetails,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken + '1',
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status should match').to.be.eql(401);
            expect(resp.headers, 'Should be available in response header').to.include({
                'content-type': 'application/json',
            });
        });
    });

    it('Get invalid method error while fetching the document file details for API proxies by using invalid method type', () => {
        cy.request({
            method: 'POST',
            url: `${BASE_URL}/v1/docFile/` + docIdForProxyDetails,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be equal').to.eq(405);
            expect(resp.body.error, 'Error message should be equal').to.be.eql('Method Not Allowed');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get error while fetching document file details for API proxies with invalid ID', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/docFile/` + docIdForProxyDetails + '-1',
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be equal').to.eq(400);
            expect(resp.body.error, 'Error message should match').to.be.eql('Bad Request');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });
});
