/// <reference types="Cypress" />

import data from '../../../../public/config-dev.json';

const BASE_URL = Cypress.env('CYPRESS_SANITY_BASE_URL') ? Cypress.env('CYPRESS_SANITY_BASE_URL') : data.base_url;
const BACKDOOR_URL = Cypress.env('CYPRESS_SANITY_BASE_URL')
    ? Cypress.env('CYPRESS_SANITY_BASE_URL')
    : data.backdoor_url;
let user_payload = require('../../fixtures/user.json');
let accessToken = '';
const docIdForProxyDocumentDetails = 'b4e056c7-5499-4a0e-9582-bd36fb20aa70';

describe('Get Document details of the proxy', () => {
    before(() => {
        cy.request({
            method: 'PUT',
            url: `${BACKDOOR_URL}/backdoor/internal`,
            headers: {
                'Content-Type': 'application/json',
            },
            failOnStatusCode: false,
            body: user_payload,
        }).then((resp) => {
            accessToken = resp.body.access_token;
        });
    });

    it('Get the documentation details of the proxy', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/documentationwithproxy/` + docIdForProxyDocumentDetails,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should match').to.eq(200);
            expect(resp.duration, 'Response time should not exceed more that 30000 milliSeconds').to.not.be.greaterThan(
                30000
            );
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get unauthorized error while fetching the documentation details of the proxy with invalid token', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/documentationwithproxy/` + docIdForProxyDocumentDetails,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken + '1',
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should match').to.eq(401);
            expect(resp.headers, 'Should be available in response header').to.include({
                'content-type': 'application/json',
            });
        });
    });

    it('Get the error while fetching documentation details of the proxy with invalid documentId', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/documentationwithproxy/` + docIdForProxyDocumentDetails + '-111',
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should match').to.eq(400);
            expect(resp.body.error, 'Error message should be equal').to.eq('Bad Request');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get invalid method error while fetching the documentation details of the proxy with invalid method type', () => {
        cy.request({
            method: 'POST',
            url: `${BASE_URL}/v1/documentationwithproxy/` + docIdForProxyDocumentDetails,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should match').to.eq(405);
            expect(resp.body.error, 'Error message should match').to.eq('Method Not Allowed');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get error while fetching the documentation details of the proxy with invalid accept type', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/documentationwithproxy/` + docIdForProxyDocumentDetails,
            headers: {
                accept: 'text/xml',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be equal').to.eq(406);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
            });
        });
    });
});
