/// <reference types="Cypress" />

import data from '../../../../public/config-dev.json';

const BASE_URL = Cypress.env('CYPRESS_SANITY_BASE_URL') ? Cypress.env('CYPRESS_SANITY_BASE_URL') : data.base_url;
const BACKDOOR_URL = Cypress.env('CYPRESS_SANITY_BASE_URL')
    ? Cypress.env('CYPRESS_SANITY_BASE_URL')
    : data.backdoor_url;
let user_payload = require('../../fixtures/user.json');
let accessToken = '';
const apiProxyDocPayload = {
    apiId: 'b110c503-16d4-47d4-aa18-d4ada50ce1dd',
    apiName: 'client text section 10',
    documentation: '<p>client text section 10</p>',
    filecontent: '',
    id: 0,
    sectionType: 'text',
};

describe('Add new doc for API Proxy', () => {
    before(() => {
        cy.request({
            method: 'PUT',
            url: `${BACKDOOR_URL}/backdoor/internal`,
            headers: {
                'Content-Type': 'application/json',
            },
            failOnStatusCode: false,
            body: user_payload,
        }).then((resp) => {
            accessToken = resp.body.access_token;
        });
    });

    it('Adding New Document for the API', () => {
        cy.request({
            method: 'POST',
            url: `${BASE_URL}/v1/newdoc`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
            body: apiProxyDocPayload,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(200);
            expect(resp.status, 'Status should be Ok').to.be.ok;
            expect(resp.body.apiId, 'ApiID should match').to.be.eql(apiProxyDocPayload.apiId);
            expect(resp.body.apiName, 'Api Name should match').to.be.eql(apiProxyDocPayload.apiName);
            expect(resp.body.documentation, 'Documentation details should match').to.be.eql(
                apiProxyDocPayload.documentation
            );
            expect(resp.body.apiName, 'API Name should be a string').to.be.a('string');
            expect(resp.body.documentation, 'Documentation should be in string format').to.be.a('string');
            expect(resp.body.sectionType, 'Section type should be a string').to.be.a('string');
            expect(resp.body.filecontent, 'File content should be in string format').to.be.a('string');
            expect(resp.duration, 'Response time should ne be > 30000').to.not.be.greaterThan(30000);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get error while Adding New Document for the API with invalid payload', () => {
        cy.request({
            method: 'POST',
            url: `${BASE_URL}/v1/newdoc`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
            body: {
                id: 78,
                apiId: 2,
                sectionOrder: 0,
                apiName: 'unit-test',
                documentation: '<p>client text section 10</p>',
                sectionType: 'text',
                filecontent: '',
            },
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(400);
            expect(resp.body.timestamp, 'Timestamp should be available').is.not.null;
            expect(resp.body.error, 'Error message should match').to.be.eql('Bad Request');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get unauthorized error while Adding New Document for the API with invalid token', () => {
        cy.request({
            method: 'POST',
            url: `${BASE_URL}/v1/newdoc`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken + '1',
            },
            failOnStatusCode: false,
            body: apiProxyDocPayload,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(401);
            expect(resp.headers, 'Should be available in response header').to.include({
                'content-type': 'application/json',
            });
        });
    });

    it('Get invalid method error while Adding New Document for the API with invalid method type', () => {
        cy.request({
            method: 'PUT',
            url: `${BASE_URL}/v1/newdoc`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
            body: apiProxyDocPayload,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.be.eql(405);
            expect(resp.body.error, 'Error message should be equal').to.be.eql('Method Not Allowed');
            expect(resp.body.timestamp, 'Timestamp should be available').is.not.null;
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get error while Adding New Document for the API with invalid accept type in header', () => {
        cy.request({
            method: 'POST',
            url: `${BASE_URL}/v1/newdoc`,
            headers: {
                accept: 'text/xml',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
            body: apiProxyDocPayload,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(406);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
            });
        });
    });

    it('Get unsupported media error while adding New Document for the API with invalid content type', () => {
        cy.request({
            method: 'POST',
            url: `${BASE_URL}/v1/newdoc`,
            headers: {
                accept: 'application/json',
                'content-type': 'text/xml',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
            body: apiProxyDocPayload,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(415);
            expect(resp.body.error, 'Error message should be equal').to.be.eql('Unsupported Media Type');
            expect(resp.body.timestamp, 'Timestamp should be available').is.not.null;
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });
});
