/// <reference types="Cypress" />

import config from '../../../../public/config-dev.json';

const BASE_URL = Cypress.env('CYPRESS_SANITY_BASE_URL') ? Cypress.env('CYPRESS_SANITY_BASE_URL') : config.base_url;
const BACKDOOR_URL = Cypress.env('CYPRESS_SANITY_BASE_URL')
    ? Cypress.env('CYPRESS_SANITY_BASE_URL')
    : config.backdoor_url;
let user_payload = require('../../fixtures/user.json');
let createDeveloper_payload = require('../../fixtures/createDeveloperAccount.json');
let accessToken,
    deletedAppName = '';

describe('Create new Apps', () => {
    before(() => {
        cy.request({
            method: 'PUT',
            url: `${BACKDOOR_URL}/backdoor/internal`,
            headers: {
                'Content-Type': 'application/json',
            },
            failOnStatusCode: false,
            body: user_payload,
        }).then((resp) => {
            accessToken = resp.body.access_token;
        });

        cy.request({
            method: 'GET',
            url: `${config.developer_url}/v1/organizations/ext/developers/${createDeveloper_payload[1].email}`,
            headers: {
                authorization: createDeveloper_payload[0].auth,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            if (resp.status != 200) {
                cy.request({
                    method: 'POST',
                    url: `${config.developer_url}/v1/organizations/ext/developers`,
                    headers: {
                        authorization: createDeveloper_payload[0].auth,
                        'Content-Type': 'application/json',
                    },
                    failOnStatusCode: false,
                    body: createDeveloper_payload[1],
                });
            }
        });
    });

    // TODO - FSAP-39082 - Waiting for the solution...
    it('Create New Apps', () => {
        cy.fixture('CreateUserApp').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/createuserapps`,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response status code should be match').to.eq(200);
                expect(resp.body).is.not.null;
                expect(resp.body.credentials[0].consumerKey).is.not.null;
                expect(resp.body.credentials[0].consumerSecret).is.not.null;
                expect(resp.body.name).to.be.eql(payload.attributes[1].value);
                expect(resp.body.keyExpiresIn).to.not.be.a('string');
                expect(resp.body.status).to.be.a('string');
                expect(resp.body.createdAt).to.not.be.a('string');
                expect(resp.headers, 'Should be available in response header').to.include({
                    'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                    expires: '0',
                });
            });
        });
    });

    it('Get error while Creating New Apps by using invalid payload', () => {
        cy.fixture('overviewdocs').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/createuserapps`,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response status code should be match').to.eq(400);
                expect(resp.headers, 'Should be available in response header').to.include({
                    'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                    expires: '0',
                });
            });
        });
    });

    it('Get unauthorized error while Creating New Apps by using invalid token', () => {
        cy.fixture('createNewAppStub').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/createuserapps`,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken + '1',
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response status code should be match').to.eq(401);
                expect(resp.headers, 'Should be available in response header').to.include({
                    'content-type': 'application/json',
                });
            });
        });
    });

    it('Get invalid method error while Creating New Apps by using invalid method type', () => {
        cy.fixture('createNewAppStub').then((payload) => {
            cy.request({
                method: 'PUT',
                url: `${BASE_URL}/v1/createuserapps`,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response status code should be match').to.eq(405);
                expect(resp.body.error, 'Error message should match').to.be.eql('Method Not Allowed');
                expect(resp.headers, 'Should be available in response header').to.include({
                    'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                    expires: '0',
                    'content-type': 'application/json',
                });
            });
        });
    });

    it('Get unsupported media error while Creating New Apps by using invalid content type', () => {
        cy.fixture('createNewAppStub').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/createuserapps`,
                headers: {
                    accept: 'application/json',
                    'content-type': 'text/xml',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response status code should be match').to.eq(415);
                expect(resp.body.error, 'Error message should match').to.be.eql('Unsupported Media Type');
                expect(resp.headers, 'Should be available in response header').to.include({
                    'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                    expires: '0',
                    'content-type': 'application/json',
                });
            });
        });
    });

    it('Get error while Creating New Apps by using invalid payload', () => {
        cy.fixture('overviewdata').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/createuserapps`,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response status code should be match').to.be.oneOf([500, 200]);
                expect(resp.headers, 'Should be available in response header').to.include({
                    'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                    expires: '0',
                });
            });
        });
    });

    after('Clean Up', () => {
        cy.fixture('CreateUserApp').then((payload) => {
            deletedAppName = payload.attributes[1].value;
            cy.request({
                method: 'DELETE',
                url: `${BASE_URL}/v1/deleteuserapp/${deletedAppName}`,
                headers: {
                    accept: '*/*',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
            });
        });
    });
});
