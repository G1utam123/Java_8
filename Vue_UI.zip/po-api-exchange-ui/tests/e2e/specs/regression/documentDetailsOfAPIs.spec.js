/// <reference types="Cypress" />

import data from '../../../../public/config-dev.json';

const BASE_URL = Cypress.env('CYPRESS_SANITY_BASE_URL') ? Cypress.env('CYPRESS_SANITY_BASE_URL') : data.base_url;
const BACKDOOR_URL = Cypress.env('CYPRESS_SANITY_BASE_URL')
    ? Cypress.env('CYPRESS_SANITY_BASE_URL')
    : data.backdoor_url;
let user_payload = require('../../fixtures/user.json');
let accessToken = '';
const docIdForDetailDocumentation = '01908d73-4ea1-4d41-9d33-251916070fe7';
const docIdToBeDeleted = 101;

describe('Get document details of APIs', () => {
    before(() => {
        cy.request({
            method: 'PUT',
            url: `${BACKDOOR_URL}/backdoor/internal`,
            headers: {
                'Content-Type': 'application/json',
            },
            failOnStatusCode: false,
            body: user_payload,
        }).then((resp) => {
            accessToken = resp.body.access_token;
        });
    });

    it('Get Documentation details with valid data', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/documentation/` + docIdForDetailDocumentation,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should match').to.eq(200);
            expect(resp.duration, 'Response time should not be > 30000').to.not.be.greaterThan(30000);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get error while fetching the Documentation details with invalid document Id', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/documentation/` + docIdForDetailDocumentation + '-55555',
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should match').to.eq(400);
            expect(resp.body.error, 'Error message should be equal').to.be.eql('Bad Request');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get unauthorized error while fetching the Documentation details with invalid token', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/documentation/` + docIdForDetailDocumentation,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken + '1',
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should match').to.eq(401);
            expect(resp.headers, 'Should be available in response header').to.include({
                'content-type': 'application/json',
            });
        });
    });

    it('Get invalid method error while fetching Documentation details with invalid method type', () => {
        cy.request({
            method: 'POST',
            url: `${BASE_URL}/v1/documentation/` + docIdForDetailDocumentation,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'status code should match').to.eq(405);
            expect(resp.body.error, 'Error message should match').to.be.eql('Method Not Allowed');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get error while fetching Documentation details with invalid accept type', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/documentation/` + docIdForDetailDocumentation,
            headers: {
                accept: 'text/xml',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should match').to.eq(406);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
            });
        });
    });
});
