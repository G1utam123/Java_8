/// <reference types="Cypress" />

import data from '../../../../public/config-dev.json';

const BASE_URL = Cypress.env('CYPRESS_SANITY_BASE_URL') ? Cypress.env('CYPRESS_SANITY_BASE_URL') : data.base_url;
const BACKDOOR_URL = Cypress.env('CYPRESS_SANITY_BASE_URL')
    ? Cypress.env('CYPRESS_SANITY_BASE_URL')
    : data.backdoor_url;
let user_payload = require('../../fixtures/user.json');
let accessToken = '';
let resourceGUid = 'a3c78fe9-c486-4c27-a235-35347e3315d4';

describe('Get environment details of proxies', () => {
    before(() => {
        cy.request({
            method: 'PUT',
            url: `${BACKDOOR_URL}/backdoor/internal`,
            headers: {
                'Content-Type': 'application/json',
            },
            failOnStatusCode: false,
            body: user_payload,
        }).then((resp) => {
            accessToken = resp.body.access_token;
        });
    });

    it('Get the Environment details of the proxy', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/apiEnvironments`,
            qs: { resourceGuid: resourceGUid },
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(200);
            expect(resp.body.length, 'Environment list should be greater than 0').to.be.greaterThan(0);
            expect(resp.duration, 'Response time should not be > 30000 milliSeconds').to.not.be.greaterThan(30000);
            expect(Number.isNaN(+resp.body[0].mediatedResourceId)).to.eq(false);
            expect(resp.body[0].resourceTaxonomy).to.be.a('string');
            expect(resp.body[0].resourceName).to.be.a('string');
            expect(resp.body[0].version).to.be.a('string');
            expect(resp.body[0].serviceType).to.be.a('string');
            expect(resp.body[0].active).to.be.a('string');
            expect(resp.body[0].endPointUrl).to.be.a('string');
            expect(Number.isNaN(+resp.body[0].throttlingRequestsPerSec)).to.eq(false);
            expect(Number.isNaN(+resp.body[0].timeoutSecs)).to.eq(false);
            expect(resp.body[0].connectionKeepAlive).to.be.a('string');
            expect(resp.body[0].owningApplicationId).to.be.a('string');
            expect(resp.body[0].owningApplicationKey).to.be.a('string');
            expect(resp.body[0].replaceUrlFromValue).to.be.a('string');
            expect(resp.body[0].replaceUrlToValue).to.be.a('string');
            expect(resp.body[0].routingExpression).to.be.a('string');
            expect(resp.body[0].resourceGuid).to.be.a('string');
            expect(resp.body[0].validAuthTypes).to.be.a('string');
            expect(resp.body[0].environment).to.be.a('string');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get no Environment details for an invalid proxy id', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/apiEnvironments`,
            qs: { resourceGuid: '4e3cba11--4131-b223-6371f6cb673b' },
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(200);
            expect(resp.body.length, 'Get empty JSON array in the response').to.eq(0);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get unauthorized error while fetching environment details of the proxy by using invalid Token', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/apiEnvironments`,
            qs: { resourceGuid: resourceGUid },
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken + '1',
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(401);
            expect(resp.headers, 'Should be available in response header').to.include({
                'content-type': 'application/json',
            });
        });
    });

    it('Get invalid method error while fetching the Environment details of the proxy by using invalid method type', () => {
        cy.request({
            method: 'POST',
            url: `${BASE_URL}/v1/apiEnvironments`,
            qs: { resourceGuid: resourceGUid },
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(405);
            expect(resp.body.error, 'Error message should be equal').to.be.eql('Method Not Allowed');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get error while fetching the Environment details of the proxy by using invalid accept type', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/apiEnvironments`,
            qs: { resourceGuid: resourceGUid },
            headers: {
                accept: 'text/xml',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(406);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
            });
        });
    });

    it('Get error while fetching the Environment details of the proxy by using invalid path', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/apiEnvironment`,
            qs: { resourceGuid: resourceGUid },
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(404);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get Bad Request error while fetching environment details of the proxy by using junk data in URL', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/apiEnvironments/%`,
            qs: { resourceGuid: resourceGUid },
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(400);
        });
    });
});
