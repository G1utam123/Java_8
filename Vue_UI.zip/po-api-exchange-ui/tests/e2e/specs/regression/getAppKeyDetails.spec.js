/// <reference types="Cypress" />

import data from '../../../../public/config-dev.json';

const BASE_URL = Cypress.env('CYPRESS_SANITY_BASE_URL') ? Cypress.env('CYPRESS_SANITY_BASE_URL') : data.base_url;
const BACKDOOR_URL = Cypress.env('CYPRESS_SANITY_BASE_URL')
    ? Cypress.env('CYPRESS_SANITY_BASE_URL')
    : data.backdoor_url;
let user_payload = require('../../fixtures/user.json');
let accessToken = '';

describe('Get Application key details', () => {
    before(() => {
        cy.request({
            method: 'PUT',
            url: `${BACKDOOR_URL}/backdoor/internal`,
            headers: {
                'Content-Type': 'application/json',
            },
            failOnStatusCode: false,
            body: user_payload,
        }).then((resp) => {
            accessToken = resp.body.access_token;
        });
    });

    it('Get all application keys details', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/applicationKeys`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(200);
            expect(resp.duration, 'Response time should not be > 30000 milliSeconds').to.be.not.greaterThan(30000);
            expect(resp.body.length, 'App Key list should be > 0').to.be.greaterThan(0);
            expect(resp.body[0].applicationKeyID).to.be.a('string');
            expect(resp.body[0].applicationKeyType).to.be.a('string');
            expect(resp.body[0].applicationName).to.be.a('string');
            expect(resp.body[0].applicationType).to.be.a('string');
            expect(resp.body[0].authorizationType).to.be.a('string');
            expect(resp.body[0].customerType).to.be.a('string');
            expect(resp.body[0].customernumbers).to.be.a('string');
            expect(resp.body[0].itpkmServiceId).to.be.a('string');
            expect(resp.body[0].owneremail).to.be.a('string');
            expect(resp.body[0].user).to.be.a('string');
            expect(resp.body[0].usertype).to.be.a('string');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get error while sending the invalid accept type for application keys', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/applicationKeys`,
            headers: {
                accept: 'text/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.be.eql(406);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
            });
        });
    });

    it('Get unauthorized error while fetching the app keys by using invalid token', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/applicationKeys`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken + '1',
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(401);
            expect(resp.headers, 'Should be available in response header').to.include({
                'content-type': 'application/json',
            });
        });
    });

    it('Get invalid method error while fetching the app keys by using invalid method type', () => {
        cy.request({
            method: 'POST',
            url: `${BASE_URL}/v1/applicationKeys`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(405);
            expect(resp.body.error, 'Error message should be equal').to.be.eql('Method Not Allowed');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get Bad request error while fetching the app keys by using junk data in URL', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/applicationKeys/%`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.be.eql(400);
        });
    });
});
