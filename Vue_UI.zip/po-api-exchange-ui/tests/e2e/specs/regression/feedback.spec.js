/// <reference types="Cypress"/>

import data from '../../../../public/config-dev.json';

const BASE_URL = Cypress.env('CYPRESS_SANITY_BASE_URL') ? Cypress.env('CYPRESS_SANITY_BASE_URL') : data.base_url;
const BACKDOOR_URL = Cypress.env('CYPRESS_SANITY_BASE_URL')
    ? Cypress.env('CYPRESS_SANITY_BASE_URL')
    : data.backdoor_url;
let user_payload = require('../../fixtures/user.json');
let accessToken = '';

describe('Update User Feedback', () => {
    before(() => {
        cy.request({
            method: 'PUT',
            url: `${BACKDOOR_URL}/backdoor/internal`,
            headers: {
                'Content-Type': 'application/json',
            },
            failOnStatusCode: false,
            body: user_payload,
        }).then((resp) => {
            accessToken = resp.body.access_token;
        });
    });

    it('Update user feedback with valid data', () => {
        cy.fixture('feedback').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/feedback`,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken,
                },
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response Status code should match').to.eql(202);
            });
        });
    });

    it('Update user feedback with invalid data', () => {
        cy.request({
            method: 'POST',
            url: `${BASE_URL}/v1/feedback`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
            body: {
                firstName: 'Nidhi',
                lastName: 'Kedia',
                email: 'Nidhi.Kedia@lumen.com',
                phoneNumber: '267383992',
            },
        }).then((resp) => {
            expect(resp.status, 'Response status code should match').to.equal(400);
        });
    });

    it('Update user feedback with invalid token', () => {
        cy.fixture('feedback').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/feedback`,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken + 'e',
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response status code should match').to.equal(401);
            });
        });
    });

    it('Update user feedback with invalid method type', () => {
        cy.fixture('feedback').then((payload) => {
            cy.request({
                method: 'GET',
                url: `${BASE_URL}/v1/feedback`,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response status code should match').to.equal(405);
            });
        });
    });

    it('Update user feedback with invalid content-type', () => {
        cy.fixture('feedback').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/feedback`,
                headers: {
                    'content-type': 'application/xml',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response status code should match').to.equal(415);
            });
        });
    });
});
