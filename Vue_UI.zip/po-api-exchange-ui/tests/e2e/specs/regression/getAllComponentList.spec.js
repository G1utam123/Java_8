/// <reference types="Cypress" />

import data from '../../../../public/config-dev.json';

const BASE_URL = Cypress.env('CYPRESS_SANITY_BASE_URL') ? Cypress.env('CYPRESS_SANITY_BASE_URL') : data.base_url;
const BACKDOOR_URL = Cypress.env('CYPRESS_SANITY_BASE_URL')
    ? Cypress.env('CYPRESS_SANITY_BASE_URL')
    : data.backdoor_url;
let user_payload = require('../../fixtures/user.json');
let accessToken = '';

describe('Get All components list', () => {
    before(() => {
        cy.request({
            method: 'PUT',
            url: `${BACKDOOR_URL}/backdoor/internal`,
            headers: {
                'Content-Type': 'application/json',
            },
            failOnStatusCode: false,
            body: user_payload,
        }).then((resp) => {
            accessToken = resp.body.access_token;
        });
    });

    it('Get All the Component List in the Home Section', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/products/apigee?planet=PROD&internalExternal=EXTERNAL`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(200);
            expect(resp.body.apiProduct.length, `API Lists should be greater than 0`).to.be.greaterThan(0);
            expect(resp.body.apiProduct[0].id).is.not.null;
            expect(resp.body.apiProduct[0].approvalType).to.be.a('string');
            expect(resp.body.apiProduct[0].attributes[0].name).to.be.a('string');
            expect(resp.body.apiProduct[0].attributes[0].value).to.be.a('string');
            expect(Number.isNaN(+resp.body.apiProduct[0].createdAt)).to.eq(false);
            expect(resp.body.apiProduct[0].createdBy).to.be.a('string');
            expect(resp.body.apiProduct[0].lastModifiedBy).to.be.a('string');
            expect(resp.body.apiProduct[0].name).to.be.a('string').is.not.null;
            expect(resp.duration, 'Response time should be < 30000 milliSeconds').to.not.be.greaterThan(30000);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get invalid method error while fetching component list by using invalid method type', () => {
        cy.request({
            method: 'PUT',
            url: `${BASE_URL}/v1/products/apigee?planet=PROD&internalExternal=EXTERNAL`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(405);
            expect(resp.body.error, 'Error message should be equal').to.be.eql('Method Not Allowed');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get unauthorized error while fetching the component list by using invalid token', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/products/apigee?planet=PROD&internalExternal=EXTERNAL`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken + '1',
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(401);
            expect(resp.headers, 'Should be available in response header').to.include({
                'content-type': 'application/json',
            });
        });
    });

    it('Getting error while fetching the Component List by using invalid accept type', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/products/apigee?planet=PROD&internalExternal=EXTERNAL`,
            headers: {
                accept: 'text/xml',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(406);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
            });
        });
    });

    it('Getting error while fetching the Component List by using invalid path', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/p/v1/products/apigee?planet=PROD&internalExternal=EXTERNAL`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(404);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get Bad request error while fetching the component list by using invalid path', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/products/apigee?planet=PROD&internalExternal=EXTERNAL/%`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(400);
        });
    });
});
