/// <reference types="Cypress" />

import data from '../../../../public/config-dev.json';

const BASE_URL = Cypress.env('CYPRESS_SANITY_BASE_URL') ? Cypress.env('CYPRESS_SANITY_BASE_URL') : data.base_url;
const BACKDOOR_URL = Cypress.env('CYPRESS_SANITY_BASE_URL')
    ? Cypress.env('CYPRESS_SANITY_BASE_URL')
    : data.backdoor_url;
let user_payload = require('../../fixtures/user.json');
let accessToken = '';
// specific properties
let groupRequest = require('../../fixtures/groupRequest.json');
let malId = groupRequest.element_name;

describe('Get ownership details', () => {
    before(() => {
        cy.request({
            method: 'PUT',
            url: `${BACKDOOR_URL}/backdoor/internal`,
            headers: {
                'Content-Type': 'application/json',
            },
            failOnStatusCode: false,
            body: user_payload,
        }).then((resp) => {
            accessToken = resp.body.access_token;
        });
    });

    it('Get the ownership details for a non-existent malId', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/ownerships/${malId}`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(404);
            expect(resp.duration, 'Response time should not be > 30000 milliSeconds').to.not.be.greaterThan(30000);
            expect(resp.body).to.be.a('string').eq(`No Record Found for the ID ${malId}`);
        });
    });

    it('Create the ownership details for a non-existent malId', () => {
        cy.request({
            method: 'POST',
            url: `${BASE_URL}/v1/servicenow/grouprequest`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
            body: groupRequest,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(200);
            expect(resp.duration, 'Response time should not be > 30000 milliSeconds').to.not.be.greaterThan(30000);
        });
    });

    it('Get the ownership details for an existent malId', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/ownerships/${malId}`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(200);
            expect(resp.duration, 'Response time should not be > 30000 milliSeconds').to.not.be.greaterThan(30000);
            expect(resp.body.id).to.eq(malId);
            expect(resp.body.UUID).to.be.a('string');
            expect(resp.body.type).to.be.a('string');
            expect(resp.body.request).to.be.a('string');
            expect(resp.body.status).to.be.a('string');
            expect(resp.body.requester).to.be.a('string');
        });
    });

    it('Get unauthorized error while fetching ownership details by using invalid Token', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/ownerships/${malId}`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken + '1',
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(401);
            expect(resp.headers, 'Should be available in response header').to.include({
                'content-type': 'application/json',
            });
        });
    });

    it('Get invalid method error while fetching ownership details by using invalid method type', () => {
        cy.request({
            method: 'POST',
            url: `${BASE_URL}/v1/ownerships/${malId}`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(405);
            expect(resp.body.error, 'Error message should be equal').to.be.eql('Method Not Allowed');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get error while fetching ownership details by using invalid accept type', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/ownerships/${malId}`,
            headers: {
                accept: 'text/xml',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(406);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
            });
        });
    });

    it('Get error while fetching ownership details by using invalid path', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/ownershipssss/${malId}`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(404);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get Bad Request error while fetching ownership details by using junk data in URL', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/ownerships/%`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(400);
        });
    });

    it('Delete the ownership details for an existent malId', () => {
        cy.request({
            method: 'DELETE',
            url: `${BASE_URL}/v1/ownerships/${malId}`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(200);
            expect(resp.duration, 'Response time should not be > 30000 milliSeconds').to.not.be.greaterThan(30000);
        });
    });
});
