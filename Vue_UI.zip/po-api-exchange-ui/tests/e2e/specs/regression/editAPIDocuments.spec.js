/// <reference types="Cypress" />

import data from '../../../../public/config-dev.json';

const BASE_URL = Cypress.env('CYPRESS_SANITY_BASE_URL') ? Cypress.env('CYPRESS_SANITY_BASE_URL') : data.base_url;
const BACKDOOR_URL = Cypress.env('CYPRESS_SANITY_BASE_URL')
    ? Cypress.env('CYPRESS_SANITY_BASE_URL')
    : data.backdoor_url;
let user_payload = require('../../fixtures/user.json');
let accessToken = '';
const docIdForEdit = {
    apiId: 'b110c503-16d4-47d4-aa18-d4ada50ce1dd',
    apiName: 'client text section 10',
    documentation: '<p>client text section 10 desc</p>',
    filecontent: '',
    id: 48,
    sectionType: 'text',
    sectionOrder: 0,
};

describe('Edit API Documents', () => {
    before(() => {
        cy.request({
            method: 'PUT',
            url: `${BACKDOOR_URL}/backdoor/internal`,
            headers: {
                'Content-Type': 'application/json',
            },
            failOnStatusCode: false,
            body: user_payload,
        }).then((resp) => {
            accessToken = resp.body.access_token;
        });
    });

    it('Edit Document details for the API', () => {
        cy.request({
            method: 'PUT',
            url: `${BASE_URL}/v1/editdoc`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
            body: docIdForEdit,
        }).then((resp) => {
            expect(resp.status, 'Response status code should match').to.eq(200);
            expect(resp.body.id).to.be.eql(docIdForEdit.id);
            expect(Number.isNaN(+resp.body.id), 'Check the Id is a number').to.eq(false);
            expect(resp.body.apiId).to.be.eql(docIdForEdit.apiId);
            expect(resp.body.apiId).to.be.a('string');
            expect(resp.body.sectionOrder).to.be.eql(docIdForEdit.sectionOrder);
            expect(Number.isNaN(+resp.body.sectionOrder), 'Check the section Order is a number').to.eq(false);
            expect(resp.body.apiName).to.be.a('string');
            expect(resp.body.documentation).to.be.a('string');
            expect(resp.body.sectionType).to.be.a('string');
            expect(resp.body.filecontent).to.be.a('string');
            expect(resp.duration, 'Response time should not be > 30000 milliseconds').to.not.be.greaterThan(30000);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get invalid method error while editing API Document with invalid method type', () => {
        cy.request({
            method: 'POST',
            url: `${BASE_URL}/v1/editdoc`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
            body: docIdForEdit,
        }).then((resp) => {
            expect(resp.status).to.eq(405);
            expect(resp.body.error, 'Response status code should match').to.be.eql('Method Not Allowed');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get unauthorized error while editing API Document with invalid token', () => {
        cy.request({
            method: 'PUT',
            url: `${BASE_URL}/v1/editdoc`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken + '1',
            },
            failOnStatusCode: false,
            body: docIdForEdit,
        }).then((resp) => {
            expect(resp.status, 'Response status code should match').to.eq(401);
            expect(resp.headers, 'Should be available in response header').to.include({
                'content-type': 'application/json',
            });
        });
    });

    it('Get unsupported media error while editing API Document with invalid content type', () => {
        cy.request({
            method: 'PUT',
            url: `${BASE_URL}/v1/editdoc`,
            headers: {
                accept: 'application/json',
                'content-type': 'text/xml',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
            body: docIdForEdit,
        }).then((resp) => {
            expect(resp.status).to.eq(415);
            expect(resp.body.error, 'Response status code should be equal').to.be.eql('Unsupported Media Type');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get error while editing API Document with invalid payload', () => {
        cy.request({
            method: 'PUT',
            url: `${BASE_URL}/v1/editdoc`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
            body: {
                apiId: 2,
                sectionOrder: 0,
                apiName: 'unit-test',
            },
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(400);
            expect(resp.body.error, 'Error message should be equal').to.be.eql('Bad Request');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });
});
