/// <reference types="Cypress" />

import config from '../../../../public/config-dev.json';

const BASE_URL = Cypress.env('CYPRESS_SANITY_BASE_URL') ? Cypress.env('CYPRESS_SANITY_BASE_URL') : config.base_url;
const BACKDOOR_URL = Cypress.env('CYPRESS_SANITY_BASE_URL')
    ? Cypress.env('CYPRESS_SANITY_BASE_URL')
    : config.backdoor_url;
let user_payload = require('../../fixtures/user.json');
let createDeveloper_payload = require('../../fixtures/createDeveloperAccount.json');
let accessToken,
    deletedAppName = '';

describe('Get App details of Users', () => {
    before(() => {
        cy.request({
            method: 'PUT',
            url: `${BACKDOOR_URL}/backdoor/internal`,
            headers: {
                'Content-Type': 'application/json',
            },
            failOnStatusCode: false,
            body: user_payload,
        }).then((resp) => {
            accessToken = resp.body.access_token;
        });

        cy.request({
            method: 'GET',
            url: `${config.backdoor_url}/v1/organizations/ext/developers/${createDeveloper_payload[1].email}`,
            headers: {
                authorization: createDeveloper_payload[0].auth,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            if (resp.status != 200) {
                cy.request({
                    method: 'POST',
                    url: `${config.backdoor_url}/v1/organizations/ext/developers`,
                    headers: {
                        authorization: createDeveloper_payload[0].auth,
                        'Content-Type': 'application/json',
                    },
                    failOnStatusCode: false,
                    body: createDeveloper_payload[1],
                });
            }
        });
    });

    it('Get App details of the users', () => {
        cy.fixture('CreateUserApp').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/createuserapps`,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response status code should be match').to.eq(200);
            });

            cy.request({
                method: 'GET',
                url: `${BASE_URL}/v1/userapps`,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
            }).then((resp) => {
                expect(resp.status, 'Response status code should be match').to.eq(200);
                expect(resp.body.app.length).to.be.greaterThan(-1);
                expect(resp.body.app[0].displayName).to.be.eq(payload.name);
                expect(resp.duration, 'Response time should be < 30000 milliSeconds').to.not.be.greaterThan(30000);
                expect(resp.headers, 'Should be available in response header').to.include({
                    'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                    expires: '0',
                    'content-type': 'application/json',
                });
            });
        });
    });

    it('Get error while fetching the App details of the users by using invalid method type', () => {
        cy.request({
            method: 'POST',
            url: `${BASE_URL}/v1/userapps`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(405);
            expect(resp.body.error, 'Error message should be equal').to.be.eq('Method Not Allowed');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get unauthorized error while fetching App details of the users by using invalid token', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/userapps`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken + '1',
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(401);
            expect(resp.headers, 'Should be available in response header').to.include({
                'content-type': 'application/json',
            });
        });
    });

    it('Get error while fetching App details of the users by using invalid accept type', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/userapps`,
            headers: {
                accept: 'text/xml',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(406);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
            });
        });
    });

    it('Get Bad Request error while fetching App details of the users by using junk data in URL', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/userapps/%`,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(400);
        });
    });

    after('Clean Up', () => {
        cy.fixture('CreateUserApp').then((payload) => {
            deletedAppName = payload.name;
            cy.request({
                method: 'DELETE',
                url: `${BASE_URL}/v1/deleteuserapp/${deletedAppName}`,
                headers: {
                    accept: '*/*',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
            });
        });
    });
});
