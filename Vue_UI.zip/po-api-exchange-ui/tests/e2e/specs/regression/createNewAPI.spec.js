/// <reference types="Cypress" />

import data from '../../../../public/config-dev.json';

const BASE_URL = Cypress.env('CYPRESS_SANITY_BASE_URL') ? Cypress.env('CYPRESS_SANITY_BASE_URL') : data.base_url;
const BACKDOOR_URL = Cypress.env('CYPRESS_SANITY_BASE_URL')
    ? Cypress.env('CYPRESS_SANITY_BASE_URL')
    : data.backdoor_url;
let user_payload = require('../../fixtures/user.json');
let accessToken = '';

describe('Create new API', () => {
    before(() => {
        cy.request({
            method: 'PUT',
            url: `${BACKDOOR_URL}/backdoor/internal`,
            headers: {
                'Content-Type': 'application/json',
            },
            failOnStatusCode: false,
            body: user_payload,
        }).then((resp) => {
            accessToken = resp.body.access_token;
        });
    });

    it('Create New API by using valid payload', () => {
        cy.fixture('createdNewApp2').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/addnewapi`,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Status should match').to.eq(200);
                expect(resp.duration, 'duration should be < 30000 milliseconds').to.not.be.greaterThan(30000);
                expect(resp.body.name, 'API name should match').to.be.eql(payload.apiName);
                expect(resp.body.name, 'API name should be a string').to.be.a('string');
                expect(resp.body.description, 'Description should match').to.be.eql(payload.description);
                expect(resp.body.description, 'Description should be in string format').to.be.a('string');
                expect(resp.body.author, 'Author name should be available').is.not.null;
                expect(resp.body.type, 'Type should be match').to.be.eql(payload.type);
                expect(resp.body.type, 'Type should be in string format').to.be.a('string');
                expect(resp.body.status, 'Status should match').to.be.eql(payload.status);
                expect(resp.body.version, 'app version should match').to.be.eql(payload.version);
                expect(resp.body.version, 'version should be in string format').to.be.a('string');
                expect(resp.body.oasUrl, 'oasUrl should be in string format').to.be.a('string');
                expect(resp.body.sourceCodeUrl, 'sourceCodeUrl should be in string format').to.be.a('string');
                expect(resp.body.createdDate, 'Created date should not be null').is.not.null;
                expect(resp.body.lastUpdatedDate, 'Last updated date should not be null').is.not.null;
                expect(resp.headers, 'Should available in response header').to.include({
                    'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                    expires: '0',
                    'content-type': 'application/json',
                });
            });
        });
    });

    it('Get Bad request error while creating new API by using invalid payload', () => {
        cy.fixture('createdNewAppMultiple').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/addnewapi`,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response status should match').to.eq(400);
                expect(resp.body.error, 'Error message should match').to.be.eql('Bad Request');
                expect(resp.headers, 'Should available in response header').to.include({
                    'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                    expires: '0',
                    'content-type': 'application/json',
                });
            });
        });
    });

    it('Get authorization error while creating New API by using invalid token', () => {
        cy.fixture('createdNewApp2').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/addnewapi`,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken + '1',
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response status should match').to.eq(401);
                expect(resp.headers, 'Should available in response header').to.include({
                    'content-type': 'application/json',
                });
            });
        });
    });

    it('Get invalid method error while creating New API by using invalid method', () => {
        cy.fixture('createdNewApp2').then((payload) => {
            cy.request({
                method: 'PUT',
                url: `${BASE_URL}/v1/addnewapi`,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response status should match').to.eq(405);
                expect(resp.body.error, 'Error message should match').to.be.eql('Method Not Allowed');
                expect(resp.headers, 'Should available in response header').to.include({
                    'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                    expires: '0',
                    'content-type': 'application/json',
                });
            });
        });
    });

    it('Get not acceptable error while creating New API by using invalid accept type', () => {
        cy.fixture('createdNewApp2').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/addnewapi`,
                headers: {
                    accept: 'text/xml',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response status should match').to.eq(406);
                expect(resp.headers, 'Should available in response header').to.include({
                    'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                    expires: '0',
                });
            });
        });
    });

    it('Get media type error while creating New API by using invalid content-type', () => {
        cy.fixture('createdNewApp2').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/addnewapi`,
                headers: {
                    accept: 'application/json',
                    'content-type': 'text/xml',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload,
            }).then((resp) => {
                expect(resp.status, 'Response status should match').to.eq(415);
                expect(resp.body.error, 'Error message should match').to.be.eql('Unsupported Media Type');
                expect(resp.headers, 'Should available in response header').to.include({
                    'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                    expires: '0',
                    'content-type': 'application/json',
                });
            });
        });
    });
});
