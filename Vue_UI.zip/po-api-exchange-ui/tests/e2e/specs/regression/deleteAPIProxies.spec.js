/// <reference types="Cypress" />

import data from '../../../../public/config-dev.json';

const BASE_URL = Cypress.env('CYPRESS_SANITY_BASE_URL') ? Cypress.env('CYPRESS_SANITY_BASE_URL') : data.base_url;
const BACKDOOR_URL = Cypress.env('CYPRESS_SANITY_BASE_URL')
    ? Cypress.env('CYPRESS_SANITY_BASE_URL')
    : data.backdoor_url;
let user_payload = require('../../fixtures/user.json');
let accessToken = '';
const apiIdForDeleteProxy = 'b10fc377-04c6-4860-92a9-56c67e244372';

describe('Delete API Proxies', () => {
    before(() => {
        cy.request({
            method: 'PUT',
            url: `${BACKDOOR_URL}/backdoor/internal`,
            headers: {
                'Content-Type': 'application/json',
            },
            failOnStatusCode: false,
            body: user_payload,
        }).then((resp) => {
            accessToken = resp.body.access_token;
        });
    });

    it('Delete API Proxies by using valid id', () => {
        cy.request({
            method: 'DELETE',
            url: `${BASE_URL}/v1/deleteapiProxies/` + apiIdForDeleteProxy,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(200);
            expect(resp.body, `"OK" message should be available in response body`).to.be.eql('OK');
            expect(resp.duration, 'Response time should not be > 30000 milliSeconds').to.not.be.greaterThan(30000);
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get error while deleting API Proxies by using invalid id', () => {
        cy.request({
            method: 'DELETE',
            url: `${BASE_URL}/v1/deleteapiProxies/` + apiIdForDeleteProxy + '-666666',
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(400);
            expect(resp.body.error, 'Error message should match').to.be.eql('Bad Request');
            expect(resp.body.timestamp).is.not.null;
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get unauthorized error while deleting API Proxies by using invalid token', () => {
        cy.request({
            method: 'DELETE',
            url: `${BASE_URL}/v1/deleteapiProxies/` + apiIdForDeleteProxy,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken + '1',
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(401);
            expect(resp.headers, 'Should be available in response header').to.include({
                'content-type': 'application/json',
            });
        });
    });

    it('Get invalid method error while deleting API Proxies by using invalid method type', () => {
        cy.request({
            method: 'GET',
            url: `${BASE_URL}/v1/deleteapiProxies/` + apiIdForDeleteProxy,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(405);
            expect(resp.body.timestamp).is.not.null;
            expect(resp.body.error, 'Error message should match').to.be.eql('Method Not Allowed');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });
});
