/// <reference types="Cypress" />

import data from '../../../../public/config-dev.json';

const BASE_URL = Cypress.env('CYPRESS_SANITY_BASE_URL') ? Cypress.env('CYPRESS_SANITY_BASE_URL') : data.base_url;
const BACKDOOR_URL = Cypress.env('CYPRESS_SANITY_BASE_URL')
    ? Cypress.env('CYPRESS_SANITY_BASE_URL')
    : data.backdoor_url;
let user_payload = require('../../fixtures/user.json');
let accessToken = '';
const idForProxyDetails = '5c9e1428-115c-4c81-b0ad-220c53daef48';
const updateAPIDoc = { apiId: idForProxyDetails, formData: 'Test' };

describe('Update API Document', () => {
    before(() => {
        cy.request({
            method: 'PUT',
            url: `${BACKDOOR_URL}/backdoor/internal`,
            headers: {
                'Content-Type': 'application/json',
            },
            failOnStatusCode: false,
            body: user_payload,
        }).then((resp) => {
            accessToken = resp.body.access_token;
        });
    });

    it('Update API Proxy details', () => {
        cy.request({
            method: 'PUT',
            url: `${BASE_URL}/v1/updateapi/` + idForProxyDetails,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
            body: updateAPIDoc,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(200);
            expect(resp.duration, 'Response time should not be > 30000 milliSeconds').is.not.greaterThan(30000);
            expect(resp.body.id, 'Proxy ID should match').to.be.eql(idForProxyDetails).to.be.a('string');
            expect(resp.body.createdDate, 'Created date should be a string').to.be.a('string');
            expect(resp.body.lastUpdatedDate, 'Created date should be a string').to.be.a('string');
            expect(resp.body.createdDate, 'Prox created date should not be null').is.not.null;
            expect(resp.body.lastUpdatedDate, 'Prox created date should not be null').is.not.null;
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get error while updating API Document with invalid method type', () => {
        cy.request({
            method: 'POST',
            url: `${BASE_URL}/v1/updateapi/` + idForProxyDetails,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
            body: updateAPIDoc,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(405);
            expect(resp.body.error, 'Error message should match').to.be.eql('Method Not Allowed');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get unauthorized error while updating API Document with invalid token', () => {
        cy.request({
            method: 'PUT',
            url: `${BASE_URL}/v1/updateapi/` + idForProxyDetails,
            headers: {
                accept: 'application/json',
                authorization: 'Bearer ' + accessToken + '1',
            },
            failOnStatusCode: false,
            body: updateAPIDoc,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(401);
            expect(resp.headers, 'Should be available in response header').to.include({
                'content-type': 'application/json',
            });
        });
    });

    it('Get unsupported media error while updating API Document with invalid content type', () => {
        cy.request({
            method: 'PUT',
            url: `${BASE_URL}/v1/updateapi/` + idForProxyDetails,
            headers: {
                accept: 'application/json',
                'content-type': 'text/xml',
                authorization: 'Bearer ' + accessToken,
            },
            failOnStatusCode: false,
            body: updateAPIDoc,
        }).then((resp) => {
            expect(resp.status, 'Response status code should be match').to.eq(415);
            expect(resp.body.error, 'Error message should match').to.be.eql('Unsupported Media Type');
            expect(resp.headers, 'Should be available in response header').to.include({
                'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                expires: '0',
                'content-type': 'application/json',
            });
        });
    });

    it('Get error while editing API Document with invalid payload', () => {
        cy.fixture('createdNewApp2').then((payload) => {
            cy.request({
                method: 'PUT',
                url: `${BASE_URL}/v1/updateapi/` + idForProxyDetails,
                headers: {
                    accept: 'application/json',
                    'content-type': 'application/json',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload + 1,
            }).then((resp) => {
                expect(resp.status, 'Response status code should be match').to.eq(400);
                expect(resp.body.error, 'Error message should match').to.be.eql('Bad Request');
                expect(resp.headers, 'Should be available in response header').to.include({
                    'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                    expires: '0',
                    'content-type': 'application/json',
                });
            });
        });
    });
});
