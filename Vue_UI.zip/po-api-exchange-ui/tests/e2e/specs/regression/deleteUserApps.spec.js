/// <reference types="Cypress" />

import config from '../../../../public/config-dev.json';

const BASE_URL = Cypress.env('CYPRESS_SANITY_BASE_URL') ? Cypress.env('CYPRESS_SANITY_BASE_URL') : config.base_url;
const BACKDOOR_URL = Cypress.env('CYPRESS_SANITY_BASE_URL')
    ? Cypress.env('CYPRESS_SANITY_BASE_URL')
    : config.backdoor_url;
let user_payload = require('../../fixtures/user.json');
let createDeveloper_payload = require('../../fixtures/createDeveloperAccount.json');
let accessToken,
    deletedAppName = '';

describe('Delete User apps', () => {
    before(() => {
        cy.request({
            method: 'PUT',
            url: `${BACKDOOR_URL}/backdoor/internal`,
            headers: {
                'Content-Type': 'application/json',
            },
            failOnStatusCode: false,
            body: user_payload,
        }).then((resp) => {
            accessToken = resp.body.access_token;
        });

        cy.request({
            method: 'GET',
            url: `${config.backdoor_url}/v1/organizations/ext/developers/${createDeveloper_payload[1].email}`,
            headers: {
                authorization: createDeveloper_payload[0].auth,
            },
            failOnStatusCode: false,
        }).then((resp) => {
            if (resp.status != 200) {
                cy.request({
                    method: 'POST',
                    url: `${config.developer_url}/v1/organizations/ext/developers`,
                    headers: {
                        authorization: createDeveloper_payload[0].auth,
                        'Content-Type': 'application/json',
                    },
                    failOnStatusCode: false,
                    body: createDeveloper_payload[1],
                });
            }
        });
    });

    it(`Delete User app`, () => {
        cy.fixture('createNewAppStub3').then((payload) => {
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/createuserapps`,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: payload,
            });

            deletedAppName = payload.name;
            cy.request({
                method: 'DELETE',
                url: `${BASE_URL}/v1/deleteuserapp/${deletedAppName}`,
                headers: {
                    accept: '*/*',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
                body: {
                    name: `${deletedAppName}`,
                    appName: `${deletedAppName}`,
                },
            }).then((resp) => {
                expect(resp.status, 'Response status code should be match').to.eq(200);
                expect(resp.body.data).to.not.be.a('string');
                expect(resp.body.statusCode).to.not.be.a('string');
                expect(resp.body.message).to.be.eql('Successfully deleted API Client from apigee');
                expect(resp.headers, 'Should be available in response header').to.include({
                    'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                    expires: '0',
                    'content-type': 'application/json',
                });
            });
        });
    });

    it(`Get unauthorized error while deleting User app by using invalid token`, () => {
        cy.fixture('createNewAppStub').then((payload) => {
            deletedAppName = payload.name;
            cy.request({
                method: 'DELETE',
                url: `${BASE_URL}/v1/deleteuserapp/` + deletedAppName,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken + '1',
                },
                failOnStatusCode: false,
            }).then((resp) => {
                expect(resp.status, 'Response status code should be match').to.eq(401);
                expect(resp.headers, 'Should be available in response header').to.include({
                    'content-type': 'application/json',
                });
            });
        });
    });

    it(`Get not found error while deleting User aps by using invalid app name`, () => {
        cy.fixture('createNewAppStub').then((payload) => {
            cy.request({
                method: 'DELETE',
                url: `${BASE_URL}/v1/deleteuserapp/` + 'invalidApp',
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
            }).then((resp) => {
                expect(resp.status, 'Response status code should be match').to.eq(404);
                expect(resp.body.message, 'Error message should display').to.have.string(
                    `App named invalidApp does not exist under ${createDeveloper_payload[1].email}`
                );
                expect(resp.headers, 'Should be available in response header').to.include({
                    'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                    expires: '0',
                    'content-type': 'application/json',
                });
            });
        });
    });

    it(`Get invalid method error while deleting User app by using invalid method type`, () => {
        cy.fixture('createNewAppStub').then((payload) => {
            deletedAppName = payload.name;
            cy.request({
                method: 'POST',
                url: `${BASE_URL}/v1/deleteuserapp/` + deletedAppName,
                headers: {
                    accept: 'application/json',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
            }).then((resp) => {
                expect(resp.status, 'Response status code should be match').to.eq(405);
                expect(resp.body.error, 'Error message should be equal').to.be.eql('Method Not Allowed');
                expect(resp.headers, 'Should be available in response header').to.include({
                    'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                    expires: '0',
                    'content-type': 'application/json',
                });
            });
        });
    });

    it(`Get "Not Acceptable" error while deleting User app by using invalid accept type`, () => {
        cy.fixture('createNewAppStub').then((payload) => {
            deletedAppName = payload.name;
            cy.request({
                method: 'DELETE',
                url: `${BASE_URL}/v1/deleteuserapp/` + deletedAppName,
                headers: {
                    accept: 'text/cmd',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
            }).then((resp) => {
                expect(resp.status, 'Response status code should be match').to.eq(406);
                expect(resp.headers, 'Should be available in response header').to.include({
                    'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
                    expires: '0',
                });
            });
        });
    });

    after('Clean Up', () => {
        cy.fixture('createNewAppStub3').then((payload) => {
            cy.request({
                method: 'DELETE',
                url: `${BASE_URL}/v1/deleteuserapp/${payload.name}`,
                headers: {
                    accept: '*/*',
                    authorization: 'Bearer ' + accessToken,
                },
                failOnStatusCode: false,
            });
        });
    });
});
