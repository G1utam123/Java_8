/// <reference types='Cypress'/>

import data from '../../fixtures/variables.json';
import { postFeedback } from '../../utils';
import { destroyStub } from '../../utils/utility';

const viewPort = require('../../fixtures/viewPort.json');

describe('Feedback Form Page Tests', function () {
    beforeEach(function () {
        cy.mockLogin();
    });

    viewPort.screenSizes.forEach((size) => {
        it(`Feedback Page is rendered as per the provided Wireframe in the ${size} screen`, () => {
            if (Cypress._.isArray(size)) {
                cy.viewport(size[0], size[1]);
            } else {
                cy.viewport(size);
            }
            cy.visit('/home');
            cy.get('[data-cy="cy-share-feedback-button"]')
                .scrollIntoView()
                .should('be.visible')
                .and('contain.text', ' Share Feedback ')
                .click({ force: true });
            cy.get('[data-cy="cy-feedback__title"]')
                .should('be.visible', 'Page Title should visible')
                .and('contain.text', 'Feedback');

            cy.get('[data-cy="cy-share-feedback"]')
                .should('be.visible')
                .and(
                    'contain.text',
                    'Thank you for taking the time to share your feedback. When you click submit, an email will be sent to the API Hub Experience Team and someone will get back to you shortly.'
                );

            cy.get('[data-cy="cy-firstName_lbl"]').should('be.visible').contains('First Name *');
            cy.get('[data-cy="cy-lastName_lbl"]').should('be.visible').contains('Last Name *');
            cy.get('[data-cy="cy-email_lbl"]').should('be.visible').contains('Email *');
            cy.get('[data-cy="cy-phone_lbl"]')
                .should('be.visible')
                .and('contain.text', 'Phone Number')
                .not(':contains(' * ')');
            cy.get('[data-cy="cy-feedback_lbl"]').should('be.visible').contains('Feedback *');

            cy.get('[data-cy="cy-firstname__tbx"]').should('be.disabled');
            cy.get('[data-cy="cy-lastname__tbx"]').should('be.disabled');
            cy.get('[data-cy="cy-email__tbx"]').should('be.disabled');
            cy.get('[data-cy="cy-phone__tbx"]').should('not.be.disabled');
            cy.get('[data-cy="cy-feedback__tbx"]').should('not.be.disabled').should('not.have.value');

            cy.get('[data-cy="cy-firstname__tbx"]').invoke('val').should('not.be.empty');
            cy.get('[data-cy="cy-lastname__tbx"]').invoke('val').should('not.be.empty');

            cy.get('h6').should('be.visible').and('contain.text', 'The remaining characters : 3800');

            cy.get('[data-cy="cy-button-cancel"]')
                .scrollIntoView()
                .should('be.visible')
                .and('include.text', 'CANCEL')
                .should('not.be.disabled')
                .should('have.css', 'background-color')
                .and('eq', 'rgba(0, 0, 0, 0)');

            cy.get('[data-cy="cy-button-submit"]')
                .find('.chi-button')
                .should('be.visible')
                .and('include.text', 'SUBMIT')
                .should('not.be.disabled')
                .should('have.css', 'background-color')
                .and('eq', 'rgb(0, 117, 201)');

            cy.get('[data-cy="cy-en-footer"]')
                .parent()
                .scrollIntoView()
                .should('be.visible')
                .and('have.css', 'margin-top', '56px');
        });
    });
});

describe('Feedback Form functionality tests', function () {
    beforeEach(function () {
        cy.mockLogin();
        cy.visit('/home');
        cy.get('[data-cy="cy-share-feedback-button"]')
            .should('be.visible')
            .and('contain.text', ' Share Feedback ')
            .click();
    });

    it('Test for the valid phone number format', () => {
        cy.fixture('FeedbackTestData').then((payload) => {
            payload.phoneNumberTestData.map((phoneNum) => {
                cy.get('[data-cy="cy-phone__tbx"]').clear().type(phoneNum.phone_num, { delay: 0 });
                cy.get('[data-cy="cy-feedback__tbx"]')
                    .clear()
                    .type('This is phone number field Validation', { delay: 0 });
                postFeedback(200).as('feedback');
                cy.get('[data-cy="cy-button-submit"]').click();
                cy.location('href').should('include', '/home');
                cy.get('[data-cy="cy-share-feedback-button"]').and('contain.text', ' Share Feedback ').click();
            });
        });
    });

    it('Check for the Alert message while service is unavailable', () => {
        postFeedback(500);
        cy.get('[data-cy="cy-phone__tbx"]').type(`${data.phoneNum}`, { delay: 0 });
        cy.get('[data-cy="cy-button-submit"]').click();
        cy.get('[data-cy="cy-feedback__required__error"]')
            .should('be.visible')
            .and('include.text', ' Feedback required ')
            .find('i.icon-circle-warning');
        cy.get('[data-cy="cy-feedback__tbx"]').type('This is a test for Alert message', { delay: 0 });
        cy.get('[data-cy="cy-button-submit"]').click();
        cy.get('.chi .chi-modal__title').should('be.visible').contains('Error');
        cy.get('.chi .chi-modal__content').should('be.visible').find('i.icon-circle-x');
        cy.get('.chi .chi-modal__content')
            .should('be.visible')
            .contains('Something went wrong. Please try again later.');
        cy.get('.chi-modal__footer').find('.chi-button').should('be.visible').contains('OK');
        cy.get('.chi-modal__content')
            .find('.-d--flex')
            .should('be.visible')
            .contains('Something went wrong. Please try again later.');
        cy.get('.chi .chi-modal .-close').should('be.visible').find('i.icon-x').click();
        cy.get('[data-cy="cy-feedback__title"]')
            .should('be.visible', 'User should stay on the Feedback Page')
            .and('contain.text', 'Feedback');
        cy.location('href').should('include', '/feedback');
    });

    it('User should stay on the feedback form after clicking on the close icon in the Alert', () => {
        postFeedback(500);
        cy.get('[data-cy="cy-phone__tbx"]').type(`${data.phoneNum}`, { delay: 0 });
        cy.get('[data-cy="cy-feedback__tbx"]').type('This is a test for Alert message', { delay: 0 });
        cy.get('[data-cy="cy-button-submit"]').click();
    });

    it(`Only one warning message should show at a time for each field`, () => {
        cy.get('[data-cy="cy-button-submit"]').click();
        cy.get('[data-cy="cy-feedback__required__error"]')
            .should('be.visible')
            .and('include.text', ' Feedback required ')
            .find('i.icon-circle-warning');

        cy.get('[data-cy="cy-feedback__tbx"]').type(`${data.feedbackField_Char_Limit}`.repeat(100), { delay: 0 });
        cy.get('[data-cy="cy-feedback__required__error"]').should('not.exist');

        cy.get('.chi-form__item_ > .chi-input-addon')
            .should('be.visible')
            .and('include.text', ' You have reached your maximum characters limit ')
            .find('i.icon-circle-warning');

        cy.get('[data-cy="cy-feedback__tbx"]').clear();
        cy.get('[data-cy="cy-button-submit"]').click();

        cy.get('.chi-form__item_ > .chi-input-addon').should('not.exist');
        cy.get('[data-cy="cy-feedback__required__error"]')
            .should('be.visible')
            .and('include.text', ' Feedback required ')
            .find('i.icon-circle-warning');
    });

    it('User should return to the Home page after clicking on the OK button in the Alert', () => {
        postFeedback(500);
        cy.get('[data-cy="cy-phone__tbx"]').type(`${data.phoneNum}`, { delay: 0 });
        cy.get('[data-cy="cy-feedback__tbx"]').type('This is a test for Alert message', { delay: 0 });
        cy.get('[data-cy="cy-button-submit"]').click();
        cy.get('.chi-modal__footer').should('be.visible').contains('OK').click();
        cy.location('href').should('include', '/home');
    });

    it('User should return to the Home page after Submit the feedback', () => {
        cy.get('[data-cy="cy-phone__tbx"]').type(`${data.phoneNum}`, { delay: 0 });
        cy.get('[data-cy="cy-feedback__tbx"]').type('This is a Feedback page Test', { delay: 0 });
        postFeedback(200).as('feedback');
        cy.get('[data-cy="cy-button-submit"]').click();
        cy.location('href').should('include', '/home');
    });

    it('User should return to the Home page after click on Cancel button', () => {
        cy.get('[data-cy="cy-phone__tbx"]').type(`${data.phoneNum}`, { delay: 0 });
        cy.get('[data-cy="cy-feedback__tbx"]').type('This is a Cancel Button Test', { delay: 0 });
        cy.get('[data-cy="cy-button-cancel"]').click();
        cy.location('href').should('include', '/home');
    });

    it('beforeDestroy', () => {
        destroyStub();
    });
});
