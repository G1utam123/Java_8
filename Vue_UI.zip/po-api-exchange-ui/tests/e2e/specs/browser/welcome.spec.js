/// <reference types='Cypress'/>

const viewPort = require('../../fixtures/viewPort.json');

describe('Home page working', function () {
    beforeEach(() => {
        cy.mockLogin();
        cy.visit('/home');
    });

    viewPort.screenSizes.forEach((size) => {
        it(`Home page should rendered as per the Wireframe in the ${size} screen`, () => {
            if (Cypress._.isArray(size)) {
                cy.viewport(size[0], size[1]);
            } else {
                cy.viewport(size);
            }
            cy.get('[data-cy="cy-Welcome-text"]').should('be.visible').contains('Welcome to the API Hub');
            cy.get('[data-cy="cy-getting-started"]')
                .scrollIntoView()
                .should('be.visible')
                .contains(' Explore. Build. Manage. Your journey to building the perfect API starts here.');
            cy.get('[data-cy="cy-share-feedback-button"]').should('be.visible').contains('Share Feedback');
            cy.get('[data-cy="cy-label-text"]').should('be.visible').contains('WHAT WOULD YOU LIKE TO DO TODAY?');
            cy.get('[data-cy="cy-explore"]').should('be.visible').contains('Explore');
            cy.get('[data-cy="cy-api"]').scrollIntoView().should('be.visible').contains('Lumen APIs');
            cy.get('[data-cy="cy-marketing-icon"]').should('be.visible');
            cy.get('[data-cy="cy-products"]').should('be.visible').contains('Exchange');
            cy.get('[data-cy="cy-build-title"]').scrollIntoView().should('be.visible').contains('Build');
            cy.get('[data-cy="cy-gateway"]').should('be.visible').contains('a new gateway proxy');
            cy.get('[data-cy="cy-business-icon"]').should('be.visible');
            cy.get('[data-cy="cy-proxy"]').should('be.visible').contains('Get Started');
            cy.get('[data-cy="cy-manage-title"]').should('be.visible').contains('Manage');
            cy.get('[data-cy="cy-developer-icon"]').scrollIntoView().should('be.visible');
            cy.get('[data-cy="cy-myapps"]').should('be.visible').contains('Credentials');

            cy.get('[data-cy="cy-developer-text"]')
                .should('be.visible')
                .contains('Have you seen the new Developer Center?');
            cy.get('[data-cy="cy-developer-center-button"]')
                .scrollIntoView()
                .should('be.visible')
                .contains('DEVELOPER CENTER');
            cy.scrollTo('bottomLeft', { ensureScrollable: false });
            cy.get('[data-cy="cy-enterprise-nav-footer"]')
                .parents('footer#footer')
                .scrollIntoView()
                .should('be.visible')
                .and('have.css', 'margin-top', '56px');
        });
    });

    it('Hero image position in the home page should align with the wireframe', () => {
        cy.get('[data-cy="cy-shell-content"]').find('div.heroimage').should('have.css', 'max-width', '1600px');
        cy.get('[data-cy="cy-shell-content"]').find('div.heroimage').invoke('height').should('be.gte', 375);
        cy.get('[data-cy="cy-shell-content"]').find('div.chi-main__content').should('have.css', 'margin-right', '64px');
        cy.get('[data-cy="cy-shell-content"]').find('div.chi-main__content').should('have.css', 'margin-left', '64px');
        cy.get('[data-cy="cy-shell-content"]').find('div.chi-main').should('have.css', 'padding-top', '12px');
        cy.get('[data-cy="cy-shell-content"]').find('div.chi-epanel').should('have.css', 'padding-top', '20px');
        cy.get('[data-cy="cy-shell-content"]').find('div.heroimage').should('have.css', 'margin-bottom', '56px');
        cy.get('[data-cy="cy-label-text"]').should('have.css', 'margin-top', '8px');
        cy.get('[data-cy="cy-Welcome-text"]')
            .invoke('width')
            .then((str) => parseInt(str))
            .should('be.lt', 1600);
        cy.get('[data-cy="cy-getting-started"]')
            .invoke('width')
            .then((str) => parseInt(str))
            .should('be.lt', 1600);
    });
});

describe('Home Page Responsiveness working', function () {
    viewPort.screenSizes.forEach((size) => {
        context(`Test Responsiveness for ${size} resolution`, () => {
            beforeEach(() => {
                if (Cypress._.isArray(size)) {
                    cy.viewport(size[0], size[1]);
                } else {
                    cy.viewport(size);
                }
                cy.mockLogin();
                cy.visit('/home');
            });

            it('display or hide left menu bar', () => {
                if (size[0] > 992) {
                    cy.get('[data-cy="cy-en-menu-laptop"]').should('be.visible');
                    cy.get('[data-cy="cy-en-header__mobile--button"]').should('not.be.visible');
                } else {
                    cy.get('[data-cy="cy-en-menu-laptop"]').should('not.be.visible');
                    cy.get('[data-cy="cy-en-header__mobile--button"]').should('be.visible');
                }
            });

            it('Hero Image width should be less than screen width', () => {
                cy.get('[data-cy="cy-shell-content"]')
                    .find('div.heroimage')
                    .invoke('width')
                    .then((str) => parseInt(str))
                    .should('be.lt', size[0]);
            });

            it('Footer width should be less than screen width', () => {
                cy.get('[data-cy="cy-en-footer"]')
                    .invoke('width')
                    .then((str) => parseInt(str))
                    .should('be.lte', size[0]);
            });

            it('Header width should be less than screen width', () => {
                cy.get('.chi-header')
                    .invoke('width')
                    .then((str) => parseInt(str))
                    .should('be.lte', size[0]);

                cy.get('[data-cy="cy-en-infobar"]')
                    .invoke('width')
                    .then((str) => parseInt(str))
                    .should('be.lte', size[0]);
            });

            it('Body Card width should be less than screen width', () => {
                cy.get('.chi-main__content')
                    .invoke('width')
                    .then((str) => parseInt(str))
                    .should('be.lte', size[0]);

                cy.get('.chi-card__content')
                    .invoke('width')
                    .then((str) => parseInt(str))
                    .should('be.lte', size[0]);

                cy.get('[data-cy="cy-label-text"]')
                    .invoke('width')
                    .then((str) => parseInt(str))
                    .should('be.lte', size[0]);

                cy.get('.chi-grid')
                    .invoke('width')
                    .then((str) => parseInt(str))
                    .should('be.lte', size[0]);

                cy.get('.chi-card.-mt--9 > .chi-card__content')
                    .invoke('width')
                    .then((str) => parseInt(str))
                    .should('be.lte', size[0]);
            });

            it('Check for Share Feedback Button', () => {
                cy.get('[data-cy="cy-share-feedback-button"]')
                    .scrollIntoView()
                    .should('be.visible')
                    .contains('Share Feedback')
                    .click({ force: true });
                cy.location('href').should('include', '/feedback');
            });

            it('Check for Exchange Link', () => {
                cy.get('[data-cy="cy-products"]').scrollIntoView().should('be.visible').contains('Exchange').click();
                cy.location('href').should('include', '/exchange');
            });

            it('Check for GetStarted Link', () => {
                cy.get('[data-cy="cy-proxy"]').scrollIntoView().should('be.visible').contains('Get Started').click();
                cy.location('href').should('include', '/proxy');
            });

            it('Check for credentials Link', () => {
                cy.get('[data-cy="cy-myapps"]').scrollIntoView().should('be.visible').contains('Credentials').click();
                cy.location('href').should('include', '/credentials');
            });
        });
    });
});
