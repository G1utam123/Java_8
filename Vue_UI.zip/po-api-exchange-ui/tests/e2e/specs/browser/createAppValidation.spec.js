/// <reference types='Cypress'/>

import { featureFlagMenuActive } from '../../utils/utility.js';
import {
    deleteAPIs,
    deleteDocumentDetailsOfAPIs,
    getAPIDocumentation,
    getAllComponentList,
    getApiProxyDetails,
    getDocumentationWithProxy,
    postAddNewDocForProxy,
    postCreateNewApi,
    postSaveAPIProxyDetails,
} from '../../utils/index.js';

const documentationObject = {
    id: 78,
    apiId: 'b264bff9-08fd-44c1-a214-16280202691f',
    sectionOrder: 0,
    apiName: 'unit-test',
    documentation: '',
    sectionType: 'text',
    filecontent: '',
};

describe('create new App validation', function () {
    beforeEach(function () {
        cy.mockLogin('', featureFlagMenuActive());
        getAllComponentList('products.json', 200);
        getApiProxyDetails('', 'proxies.json', 200).as('apiproxydetails');
        cy.visit('/exchange');
        postCreateNewApi('createdNewApp.json', 200);
    });

    it('if no description for API', () => {
        cy.get('[data-cy="cy-products_tab"]').click();
        cy.get('[data-cy="cy-create-new-product__button"]', {
            timeout: Cypress.config('defaultTimeout'),
        })
            .find('.chi-button')
            .click({ force: true });
        cy.get('[data-cy="cy-api-title__input"]').type('unit-test', { delay: 0 });
        cy.get('[data-cy="cy-save-api-details__button"]').click();
        cy.get('[data-cy="cy-api-description__err"]', { timeout: Cypress.config('defaultTimeout') }).should(
            'be.visible'
        );
    });

    it('if no title for API', () => {
        cy.get('[data-cy="cy-products_tab"]').click();
        cy.get('[data-cy="cy-create-new-product__button"]', {
            timeout: Cypress.config('defaultTimeout'),
        })
            .find('.chi-button')
            .click({ force: true });
        cy.get('[data-cy=cy-api-title__input]').focus().clear();
        cy.get('[data-cy=cy-api-description__textarea]').type('unit-test description', { delay: 0 });
        cy.get('[data-cy=cy-save-api-details__button]').click();
        cy.get('[data-cy=cy-api-title__err]', { timeout: Cypress.config('defaultTimeout') }).should('be.visible');
    });

    it('create new api and check for no data alert when new app created', () => {
        cy.get('[data-cy="cy-products_tab"]').click();
        cy.get('[data-cy="cy-create-new-product__button"]', {
            timeout: Cypress.config('defaultTimeout'),
        })
            .find('.chi-button')
            .click({ force: true });
        cy.get('[data-cy=cy-api-title__input]').type('testAPI1234', { delay: 0 });
        cy.get('[data-cy=cy-api-description__textarea]').type('unit-test-Description', { delay: 0 });
        cy.get('[data-cy=cy-api-type__select]').select('RESTful').should('be.visible');
        cy.get('[data-cy=cy-api-status__select]').select('Beta').should('be.visible');
        cy.get('[data-cy=cy-api-version__input]').within(() => {
            cy.get('input[type=text]').type('1.0');
        });
        cy.get('[data-cy=cy-api-link-to-oas__input]').type('https:\\testOASurl.com', { delay: 0 });
        cy.get('[data-cy=cy-api-link-to-api-source-code__input]').type('https:\\testSourceurl.com', { delay: 0 });
        cy.get('[data-cy=cy-save-api-details__button]').click({ force: true });
        cy.get('[data-cy=cy-success_alert]', { timeout: Cypress.config('defaultTimeout') })
            .should('be.visible')
            .should('have.text', 'API details saved successfully');
        getDocumentationWithProxy({ documentations: [], proxies: [] }, '', 200).as('documentationwithproxy-1');
        cy.get('[data-cy="cy-back_link"]')
            .should('be.visible')
            .within(() => {
                cy.get('a')
                    .should('have.attr', 'href')
                    .and('include', 'exchange/overview/12ae1932-a08e-4db3-8c85-3fd7412e9fdc/unit-test');
                cy.get('a', { timeout: Cypress.config('defaultTimeout') }).click();
            });
        cy.get('[data-cy=cy-no_data]', { timeout: Cypress.config('defaultTimeout') })
            .find('span')
            .should('include.text', 'Currently no data available!');
        getAPIDocumentation([], '', 200).as('documentation-1');
        cy.get('[data-cy="cy-overview_edit__button"]').click();
        cy.wait(['@documentation-1'], Cypress.config('defaultTimeout'));
        cy.get('[data-cy="cy-new-text__button"]').click();
        cy.get('[data-cy="cy-section-title__input"]').type('unit-test', { delay: 0 });
        postAddNewDocForProxy(documentationObject, 200).as('newdoc-1');
        getAPIDocumentation([documentationObject], '', 200).as('documentation-2');
        cy.get('[data-cy="cy-section-save__button"]').click();
        cy.wait(['@newdoc-1', '@documentation-2'], Cypress.config('defaultTimeout'));
        getDocumentationWithProxy({ documentations: [documentationObject], proxies: [] }, '', 200).as(
            'documentationwithproxy-2'
        );
        cy.get('[data-cy="cy-back_link"]')
            .should('be.visible')
            .within(() => {
                cy.get('a')
                    .should('have.attr', 'href')
                    .and('include', 'exchange/overview/12ae1932-a08e-4db3-8c85-3fd7412e9fdc/unit-test');
                cy.get('a').click();
            });
        cy.get('[data-cy="cy-proxy-sections"]').click();
        cy.get('[data-cy="no_proxy_alert"]').should('include.text', 'Currently no Proxies available');
        cy.get('[data-cy="cy-overview_edit__button"]').click();
        cy.wait(['@documentation-2'], Cypress.config('defaultTimeout'));
        deleteDocumentDetailsOfAPIs(78, 200).as('delete-78');
        getAPIDocumentation([], '', 200).as('documentation-3');
        cy.get('[data-cy="cy-delete-text__button"]').first().click();
        cy.wait(['@delete-78', '@documentation-3', '@apiproxydetails'], Cypress.config('defaultTimeout'));
        cy.get('[data-cy="cy-api-chi-data-table"]').should('be.visible');
        cy.get('[data-cy="cy-api-chi-data-table"]', { timeout: Cypress.config('defaultTimeout') })
            .find('input[type="checkbox"]')
            .eq(1)
            .check({ force: true });
        postSaveAPIProxyDetails('proxyNewApp.json', 200).as('saveproxies');
        cy.get('[data-cy="cy-api-proxy_save_button"]').click();
        cy.get('[data-cy="cy-proxy-save-alert"]', { timeout: Cypress.config('defaultTimeout') })

            .should('be.visible')
            .should('have.text', 'Proxy data saved successfully');
        cy.wait('@saveproxies', Cypress.config('defaultTimeout'));
        getDocumentationWithProxy('', 'createdWithProxyNewApp.json', 200).as('documentationwithproxy-3');
        cy.get('[data-cy="cy-back_link"]')
            .scrollIntoView()
            .should('be.visible')
            .within(() => {
                cy.get('a')
                    .should('have.attr', 'href')
                    .and('include', 'exchange/overview/12ae1932-a08e-4db3-8c85-3fd7412e9fdc/unit-test');
                cy.get('a').click();
            });
        cy.get('[data-cy="no_doc_alert"]').should('include.text', 'Currently no Documentation available');
        deleteAPIs(200).as('delete-1');
        cy.get('[data-cy="cy-overview_delete__button"]').click();
        cy.get('[data-cy="cy-delete-api-modal__accept__button"]').click();
    });
});
