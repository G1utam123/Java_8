/// <reference types='Cypress'/>

import data from '../../fixtures/variables.json';
import { validateDDLWithoutLIAMJwt } from '../../utils/utility';
import { getTaxonomy, getAppKeyDetails, getESPHealthStatus } from '../../utils/index';

describe('Internal Gateway Authentication', function () {
    beforeEach(function () {
        cy.mockLogin();
        getTaxonomy('taxonomies.json', 200).as('taxonomies');
        getAppKeyDetails('applicationkeys.json', 200);
        getESPHealthStatus('', 200);
        cy.visit('/proxy');
        cy.wait('@taxonomies');
    });

    it('Check the warning message for BasicAuth details', () => {
        cy.get('[data-cy="cy-app-key__input"]').click().type(`${data.applicationKey}`, { delay: 0 });
        cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });

        cy.get('[data-cy="cy-SOAP-checkbox"]').click();
        cy.get('[data-cy="cy-service-type__select"]').select('Inbound').trigger('click');
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();

        cy.get('[data-cy="cy-service-category__select"]').type(`${data.taxonomy}`, { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();

        cy.get('[data-cy="cy-dev1-host__input"]').type(`${data.dev1HostName}`, { delay: 0 });
        cy.get('[data-cy="cy-resource-path__input"]').type(`${data.resourcePath}`, { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();

        cy.get('[data-cy="cy-basicAuth__checkbox"]').click();
        cy.get('[data-cy="cy-intActive__epanel"]').find('.-danger').should('not.exist');

        cy.get('[data-cy="cy-intLdapUser_textInput"]').children('input').as('intLdapUserClass');
        cy.get('@intLdapUserClass').should('not.have.class', '-danger');
        cy.get('[data-cy="cy-intLdapGroup_textInput"]').children('input').as('intLdapGroupClass');
        cy.get('@intLdapGroupClass').should('not.have.class', '-danger');
        cy.get('[data-cy="cy-intLdapUser_textInput"]').type(`${data.ldapUser1}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapUser_button"]').click();
        cy.get('[data-cy="cy-intldapUserlist_grid"]').should('be.visible');
        cy.get('[data-cy="cy-intActive__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('[icon="circle-warning"]')
            .should('not.exist');
        cy.get('@intLdapUserClass').should('not.have.class', '-danger');
        cy.get('@intLdapGroupClass').should('not.have.class', '-danger');
        cy.get('[data-cy="cy-intLdapUser_delbutton"]').click();
        cy.get('[data-cy="cy-intActive__epanel"]').find('.-danger').should('not.exist');

        cy.get('@intLdapUserClass').should('not.have.class', '-danger');
        cy.get('@intLdapGroupClass').should('not.have.class', '-danger');

        cy.get('[data-cy="cy-intLdapGroup_textInput"]').type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapGroup_button"]').click();
        cy.get('[data-cy="cy-intldapGrouplist_grid"]').should('be.visible');
        cy.get('[data-cy="cy-intActive__epanel"]').find('.-danger').should('not.exist');
        cy.get('@intLdapUserClass').should('not.have.class', '-danger');
        cy.get('@intLdapGroupClass').should('not.have.class', '-danger');
        cy.get('[data-cy="cy-intLdapGroup_delbutton"]').click();
        cy.get('[data-cy="cy-intActive__epanel"]').find('.-danger').should('not.exist');

        cy.get('@intLdapUserClass').should('not.have.class', '-danger');
        cy.get('@intLdapGroupClass').should('not.have.class', '-danger');

        cy.get('[data-cy="cy-intLdapUser_textInput"]').type(`${data.ldapUser1}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapUser_button"]').click();
        cy.get('[data-cy="cy-intLdapGroup_textInput"]').type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapGroup_button"]').click();
        cy.get('[data-cy="cy-intActive__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('[icon="circle-warning"]')
            .should('not.exist');
        cy.get('@intLdapUserClass').should('not.have.class', '-danger');
        cy.get('@intLdapGroupClass').should('not.have.class', '-danger');
        cy.get('[data-cy="cy-intLdapGroup_delbutton"]').click();
        cy.get('[data-cy="cy-intActive__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('[icon="circle-warning"]')
            .should('not.exist');
        cy.get('@intLdapUserClass').should('not.have.class', '-danger');
        cy.get('@intLdapGroupClass').should('not.have.class', '-danger');

        cy.get('[data-cy="cy-intLdapGroup_textInput"]').type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapGroup_button"]').click();
        cy.get('[data-cy="cy-intLdapUser_delbutton"]').click();
        cy.get('[data-cy="cy-intActive__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('[icon="circle-warning"]')
            .should('not.exist');
        cy.get('@intLdapUserClass').should('not.have.class', '-danger');
        cy.get('@intLdapGroupClass').should('not.have.class', '-danger');

        cy.get('[data-cy="cy-intLdapGroup_textInput"]').type(`${data.ldapGroup2}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapGroup_button"]').click();
        cy.get('[data-cy="cy-intLdapGroup_delbutton"]').last().click();
        cy.get('[data-cy="cy-intActive__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('[icon="circle-warning"]')
            .should('not.exist');
        cy.get('@intLdapUserClass').should('not.have.class', '-danger');
        cy.get('@intLdapGroupClass').should('not.have.class', '-danger');
        cy.get('[data-cy="cy-intLdapGroup_delbutton"]').last().click();

        cy.get('[data-cy="cy-intLdapUser_textInput"]').type(`${data.ldapUser1}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapUser_button"]').click();
        cy.get('[data-cy="cy-intLdapUser_textInput"]').type(`${data.ldapUser2}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapUser_button"]').click();
        cy.get('[data-cy="cy-intLdapUser_delbutton"]').last().click();
        cy.get('[data-cy="cy-intActive__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('[icon="circle-warning"]')
            .should('not.exist');
        cy.get('@intLdapUserClass').should('not.have.class', '-danger');
        cy.get('@intLdapGroupClass').should('not.have.class', '-danger');
        cy.get('[data-cy="cy-internal-continue__button"]').click();
    });

    it('Warning message for basic auth should not appear while clicking on previous button in external/endpoint authentication panel', () => {
        cy.get('[data-cy="cy-app-key__input"]').click().type(`${data.applicationKey}`, { delay: 0 });
        cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });
        cy.get('[data-cy="cy-SOAP-checkbox"]').click();
        cy.get('[data-cy="cy-service-type__select"]').select('Inbound').trigger('click');
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();

        cy.get('[data-cy="cy-service-category__select"]').type(`${data.taxonomy}`, { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();

        cy.get('[data-cy="cy-dev1-host__input"]').type(`${data.dev1HostName}`, { delay: 0 });
        cy.get('[data-cy="cy-resource-path__input"]').type(`${data.resourcePath}`, { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();

        cy.get('[data-cy="cy-basicAuth__checkbox"]').click();
        cy.get('[data-cy="cy-intLdapUser_textInput"]').type(`${data.ldapUser1}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapUser_button"]').click();
        cy.get('[data-cy="cy-intLdapGroup_textInput"]').type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapGroup_button"]').click();
        cy.get('[data-cy="cy-internal-continue__button"]').click();

        cy.get('[data-cy="cy-endPoint__epanel"]').contains('Previous').click();
        cy.get('[data-cy="cy-intActive__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('[icon="circle-warning"]')
            .should('not.exist');
        cy.get('[data-cy="cy-intActive__epanel"]').contains('Previous').click();
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();
        cy.get('[data-cy="cy-endpoint-authentication-previous__button"]').click();

        cy.get('[data-cy="cy-intActive__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('[icon="circle-warning"]')
            .should('not.exist');
        cy.get('[data-cy="cy-internal-continue__button"]').click();
        cy.get('[data-cy="cy-intActive__epanel"]').contains('Change').click();
        cy.get('[data-cy="cy-intActive__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('[icon="circle-warning"]')
            .should('not.exist');

        cy.get('[data-cy="cy-general__epanel"]').contains('Change').click();
        cy.get('[data-cy="cy-external__checkbox"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();
        cy.get('[data-cy="cy-applicationKey__checkbox"]').click();
        cy.get('[data-cy="cy-ext-continue__button"]').click();
        cy.get('[data-cy="cy-endpoint-authentication-previous__button"]').click();
        cy.get('[data-cy="cy-ext-previous__button"]').click();
        cy.get('[data-cy="cy-intActive__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('[icon="circle-warning"]')
            .should('not.exist');
    });

    it('LIAMJwt option should not be visible in Endpoint auth-type drop down list', () => {
        cy.get('[data-cy="cy-app-key__input"]')
            .click()
            .type(`${data.applicationKey}`, { delay: 0 })
            .click({ force: true });
        cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });
        cy.get('[data-cy="cy-SOAP-checkbox"]').click();
        cy.get('[data-cy="cy-service-type__select"]').select('Inbound').trigger('click');
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();

        cy.get('[data-cy="cy-service-category__select"]').type(`${data.taxonomy}`, { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();

        cy.get('[data-cy="cy-dev1-host__input"]').type(`${data.dev1HostName}`, { delay: 0 });
        cy.get('[data-cy="cy-resource-path__input"]').type(`${data.resourcePath}`, { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();

        cy.get('[data-cy="cy-basicAuth__checkbox"]').as('basicAuth_check_box');
        cy.get('@basicAuth_check_box').click();
        cy.get('[data-cy="cy-intLdapUser_textInput"]').as('int_ldapUser_txtBox');
        cy.get('@int_ldapUser_txtBox').type(`${data.ldapUser1}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapUser_button"]').as('int_ldapUserAdd_btn');
        cy.get('@int_ldapUserAdd_btn').click();
        cy.get('[data-cy="cy-intLdapGroup_textInput"]').as('int_ldapGroup_txtbox');
        cy.get('@int_ldapGroup_txtbox').type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapGroup_button"]').as('int_ldapGroupAdd_btn');
        cy.get('@int_ldapGroupAdd_btn').click();
        cy.get('[data-cy="cy-internal-continue__button"]').as('intGateway_continue_btn');
        cy.get('@intGateway_continue_btn').click();

        cy.get('[data-cy="cy-authentication-type__select"]').children('option').as('endpoint_authType_ddl');
        cy.get('@endpoint_authType_ddl').then(validateDDLWithoutLIAMJwt());

        cy.get('[data-cy="cy-intActive__epanel"]').find('button.-primary').contains('Change').click();
        cy.get('@basicAuth_check_box').click();
        cy.get('[data-cy="cy-int-appln-key_label"]').click();
        cy.get('[data-cy="cy-internal-continue__button"]').click();
        cy.get('@endpoint_authType_ddl').then(validateDDLWithoutLIAMJwt());

        cy.get('[data-cy="cy-intActive__epanel"]').find('button.-primary').contains('Change').click();
        cy.get('@basicAuth_check_box').click();
        cy.get('@int_ldapUser_txtBox').type(`${data.ldapUser1}`, { delay: 0 });
        cy.get('@int_ldapUserAdd_btn').click();
        cy.get('@int_ldapGroup_txtbox').type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('@int_ldapGroupAdd_btn').click();
        cy.get('@intGateway_continue_btn').click();
        cy.get('@endpoint_authType_ddl').then(validateDDLWithoutLIAMJwt());
    });
});
