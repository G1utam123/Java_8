/// <reference types='Cypress'/>
import data from '../../fixtures/variables.json';
import { destroyStub } from '../../utils/utility';
import { getApiProxyDetails, getEnvironmentDetailsOfProxies } from '../../utils/index.js';

const viewPort = require('../../fixtures/viewPort.json');

describe('My APIs UI', function () {
    beforeEach(function () {
        cy.mockLogin();
        getApiProxyDetails([], '', 200).as('apiProxyDetailsByDef');
    });

    viewPort.screenSizes.forEach((size) => {
        it(`My APIs UI by default in ${size} screen`, () => {
            if (Cypress._.isArray(size)) {
                cy.viewport(size[0], size[1]);
            } else {
                cy.viewport(size);
            }
            cy.visit('/myapis');
            cy.get('[data-cy="cy-my_apis_name"]').should('be.visible').contains('My APIs');
            cy.get('[data-cy="cy-myapisproxies_tab"]').should('be.visible').contains('Proxies');
            cy.get('[data-cy="cy-myapisproducts_tab"]').should('be.visible').contains('Products');
            cy.get('[data-cy="cy-tabs"] > li').should('have.class', '-active').contains('Dev Test');
            cy.get('[data-cy="cy-myapisproxiesproduction_tab"]').contains('Production');
            cy.wait('@apiProxyDetailsByDef', Cypress.config('defaultTimeout'));
            cy.get('[data-cy="cy-display_header-dev-test"]').contains('Dev Test Proxies');
            cy.get('[data-cy="cy-display_header-prod"]').contains('Production Proxies');
            cy.get('[data-cy="cy-api-chi-data-table-dev-test"]').as('dev-test_data-table');
            cy.get('@dev-test_data-table').contains(`${data.noMatchesFound}`);
            cy.get('[data-cy="cy-api__search-input-dev-test"]').find('input').should('be.visible').should('be.empty');
            cy.get('[data-cy="cy-api__search-input-dev-test"]').find('[aria-label="Search"]').should('be.visible');
            cy.get('[data-cy="cy-api__filter-dev-test"]').as('filter_dev-test');
            cy.get('@filter_dev-test').should('be.visible').contains('Dev 1');
            cy.get('@filter_dev-test').find('option').contains('Dev 1');
            cy.get('@filter_dev-test').find('option').contains('Dev 2');
            cy.get('@filter_dev-test').find('option').contains('Dev 3');
            cy.get('@filter_dev-test').find('option').contains('Dev 4');
            cy.get('@filter_dev-test').find('option').contains('Test 1');
            cy.get('@filter_dev-test').find('option').contains('Test 2');
            cy.get('@filter_dev-test').find('option').contains('Test 3');
            cy.get('@filter_dev-test').find('option').contains('Test 4');
            cy.get('@dev-test_data-table').contains('Resource Taxonomy');
            cy.get('@dev-test_data-table').contains('Resource Name');
            cy.get('@dev-test_data-table').contains('Version');
            cy.get('@dev-test_data-table').contains('Service Endpoint');
            cy.get('@dev-test_data-table').contains('Routing Expression');
            cy.get('@dev-test_data-table').contains('Owner');
            cy.get('@dev-test_data-table').contains('Actions');
            cy.get('[data-cy="cy-api-chi-data-table-prod"]').as('prod_data-table');
            cy.get('@prod_data-table').contains('Resource Taxonomy');
            cy.get('@prod_data-table').contains('Resource Name');
            cy.get('@prod_data-table').contains('Version');
            cy.get('@prod_data-table').contains('Service Endpoint');
            cy.get('@prod_data-table').contains('Routing Expression');
            cy.get('@prod_data-table').contains('Owner');
            cy.get('@prod_data-table').contains('Actions');
            cy.get('[data-cy="cy-myapisproducts_tab"]').click();
            cy.get('[data-cy="cy-api__coming_soon__alert"]').should('be.visible').contains('Coming Soon!');
            cy.get('[data-cy="cy-en-footer"]').parent().should('be.visible').and('have.css', 'margin-top', '56px');
        });
    });

    it('beforeDestroy', () => {
        destroyStub();
    });
});

describe('My APIs functionalities', function () {
    beforeEach(function () {
        cy.mockLogin();
        getApiProxyDetails('', 'proxies.json', 200).as('apiProxyDetailsByDef');
        cy.visit('/myapis');
    });

    it('Navigation to APB', () => {
        cy.get('[data-cy="cy-create-new-app__btn"]').click();
        cy.location('href').should('include', '/proxy');
    });

    it('Navigation to Migration', () => {
        getEnvironmentDetailsOfProxies([], '', 200);
        cy.get('[data-cy="cy-api-chi-data-table-dev-test"]').find('a').contains('Migrate').click();
        cy.location('href').should('include', '/migrate');
    });

    it('Dev Test > Search by input works', () => {
        cy.get('[data-cy="cy-api-chi-data-table-dev-test"] .chi-data-table__body')
            .find('.chi-data-table__row')
            .should('have.length', 5);
        cy.get('[data-cy="cy-api-chi-data-table-dev-test"] .chi-data-table__body > .chi-data-table__row > .-expandable')
            .first()
            .click();
        cy.get('[data-cy="cy-api-chi-data-table-dev-test"]').contains('Matching Expression');
        cy.get('[data-cy="cy-api__search-input-dev-test"]').find('input').type(`${data.inputNoResults}`, { delay: 0 });
        cy.get('[data-cy="cy-api__search-input-dev-test"]').find('[aria-label="Search"]').click();
        cy.get('[data-cy="cy-api-chi-data-table-dev-test"]').contains(`${data.noMatchesFound}`);
    });

    it('Search by env filter works', () => {
        cy.get('[data-cy="cy-api-chi-data-table-dev-test"] .chi-data-table__body')
            .find('.chi-data-table__row')
            .should('have.length', 5);
        getApiProxyDetails([], '', 200);
        cy.get('[data-cy="cy-api__filter-dev-test"]').find('[id="environment-filter-desktop"]').select('Dev 3');
        cy.get('[data-cy="cy-api-chi-data-table-dev-test"]').contains(`${data.noMatchesFound}`);
    });

    it('Load filter by local storage', () => {
        // needed wait to avoid overlapping similar calls after the navigation
        cy.wait('@apiProxyDetailsByDef');
        getApiProxyDetails([], '', 200);
        cy.visit('/myapis', {
            onBeforeLoad(win) {
                win.localStorage.setItem('myProxiesEnv', 'test2');
            },
        });
        cy.get('[data-cy="cy-api__filter-dev-test"]').should('be.visible').contains('Test 2');
    });

    it('Dev Test > Load of the results fails', () => {
        // needed wait to avoid overlapping similar calls after the navigation
        cy.wait('@apiProxyDetailsByDef');
        getApiProxyDetails([], '', 404);
        cy.visit('/myapis');
        cy.get('[data-cy="cy-api-chi-data-table-dev-test"]').contains(`${data.noMatchesFound}`);
    });

    it('Load filter by local storage', () => {
        // needed wait to avoid overlapping similar calls after the navigation
        cy.wait('@apiProxyDetailsByDef');
        getApiProxyDetails([], '', 200);
        cy.visit('/myapis', {
            onBeforeLoad(win) {
                win.localStorage.setItem('myProxiesEnv', 'test2');
            },
        });
        cy.get('[data-cy="cy-api__filter-dev-test"]').should('be.visible').contains('Test 2');
    });

    it('Load of the results fails', () => {
        // needed wait to avoid overlapping similar calls after the navigation
        cy.wait('@apiProxyDetailsByDef');
        getApiProxyDetails([], '', 404);
        cy.visit('/myapis');
        cy.get('[data-cy="cy-api-chi-data-table-dev-test"]').contains(`${data.noMatchesFound}`);
    });

    it('Prod > Search by input works', () => {
        // needed wait to avoid overlapping similar calls after the navigation
        cy.wait('@apiProxyDetailsByDef');
        getApiProxyDetails('', 'proxiesProd.json', 200).as('proxiesProd');
        cy.get('[data-cy="cy-myapisproxiesproduction_tab"]').click();
        cy.wait('@proxiesProd');
        cy.get('[data-cy="cy-api-chi-data-table-prod"] .chi-data-table__body')
            .find('.chi-data-table__row')
            .should('have.length', 1);
        cy.get('[data-cy="cy-api__search-input-prod"]').find('input').type(`${data.inputNoResults}`, { delay: 0 });
        cy.get('[data-cy="cy-api__search-input-prod"]').find('[aria-label="Search"]').click();
        cy.get('[data-cy="cy-api-chi-data-table-prod"]').contains(`${data.noMatchesFound}`);
    });

    it('Prod > Load of the results fails', () => {
        // needed wait to avoid overlapping similar calls after the navigation
        cy.wait('@apiProxyDetailsByDef');
        getApiProxyDetails([], '', 404);
        cy.get('[data-cy="cy-myapisproxiesproduction_tab"]').click();
        cy.get('[data-cy="cy-api-chi-data-table-prod"]').contains(`${data.noMatchesFound}`);
    });
});
