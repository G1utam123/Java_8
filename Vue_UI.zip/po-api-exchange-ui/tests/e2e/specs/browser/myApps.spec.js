/// <reference types='Cypress'/>

import { featureFlagMenuActive, destroyStub } from '../../utils/utility';
import data from '../../fixtures/variables.json';
import { getAppDetailsOfUsers, deleteUserApps, getAPIProductLists } from '../../utils';

describe('My Apps page working', function () {
    beforeEach(function () {
        cy.mockLogin('', featureFlagMenuActive());
        getAppDetailsOfUsers('', 200).as('appsList');
        getAPIProductLists([], '', 200).as('prodList');
        cy.visit('/credentials');
        cy.wait('@appsList', Cypress.config('defaultTimeout'));
    });

    it('Check My Apps page', () => {
        cy.get('[data-cy="cy-my-app__title"]').should('be.visible').should('contain', 'Credentials');
        cy.get('[data-cy="cy-manage__label"]')
            .should('be.visible')
            .should('have.class', '-text--boldest')
            .contains(/^Manage$/);
        cy.get('[data-cy="cy-create-new-app__btn"]')
            .should('be.visible')
            .should('have.class', 'chi-button')
            .should('have.class', '-primary')
            .should('contain', 'Create New');
    });

    it('Message shown when user has no apps', () => {
        cy.get('[data-cy="cy-no-apps-info__title"]').contains(
            'You currently don’t have any Credentials. Click here to get started.'
        );
    });
});

// ****************************** Tests with only One App ****************************** //

describe('My Apps Tests with Stub for Only One App', () => {
    beforeEach(() => {
        cy.mockLogin('', featureFlagMenuActive());
        getAppDetailsOfUsers('singleDevApp.json', 200).as('appsList');
        getAPIProductLists('', 'APIProductsResponse.json', 200).as('prodList');
        cy.visit('/credentials');
        cy.wait('@appsList', Cypress.config('defaultTimeout'));
    });

    it('User should not see sort arrows', () => {
        cy.get('.icon-arrow-sort').should('have.length', 0).should('not.exist');
    });
});

// ****************************** Tests with more than One Apps ****************************** //

describe('My Apps Tests with Stub for more than One Apps', () => {
    beforeEach(() => {
        cy.mockLogin('', featureFlagMenuActive());
        cy.viewport(1280, 800);
        getAppDetailsOfUsers('multiDevApp.json', 200).as('appsList');
        getAPIProductLists('', 'APIProductsResponse.json', 200).as('prodList');
        cy.visit('/credentials');
        cy.wait('@appsList', Cypress.config('defaultTimeout')).its('response').should('deep.include', {
            statusCode: 200,
        });
    });

    it('Check My Apps Tests with Stub for more than One Apps', () => {
        cy.get('[data-cy="cy-no-apps-info__title"]').should(
            'not.exist',
            ' You currently don’t have any Apps. Click here to get started. '
        );
        data.lables.forEach((label) => {
            let labelAttribute = '[aria-label="Sort Column ' + label + '"]';
            cy.get(labelAttribute).should('have.attr', 'data-label', label).and('be.visible');
        });
        cy.get('[aria-label="Actions"]').should('have.attr', 'data-label', 'Actions').and('be.visible');
        cy.get('.icon-arrow-sort').should('have.length', 3).should('have.class', 'chi-icon').should('be.visible');
        const numberOfResults = 12; // Number of apps in the test data
        cy.get('[data-cy="cy-pagination__block"]').should('not.be.visible');
        cy.get('[data-cy="cy-myapps__table"] > .-d-screen--only > .chi-data-table__body > .chi-data-table__row').should(
            'have.length',
            numberOfResults
        );
    });

    it('Delete Modal displayed on clicking Delete from Actions menu for any App', () => {
        cy.log('Selecting Delete action for App 1...');
        cy.contains('div', 'App 1', { matchCase: true })
            .parents('div.chi-data-table__row')
            .find('div.chi-dropdown__menu')
            .invoke('attr', 'style', 'display: block')
            .contains('Delete')
            .should('be.visible')
            .click();

        cy.get('#delete-api-modal', { timeout: Cypress.config('defaultTimeout') }).should('be.visible');
        cy.log('Delete modal is visible!');
    });

    it('Delete App modal elements are according to the wireframe', () => {
        cy.get('[data-cy="cy-overview_delete__button"]').eq(0).click({ force: true });
        cy.get('h2.chi-modal__title').should('exist').and('include.text', 'Delete Credentials');
        cy.log('Delete App header exists!');
        cy.get('button.-close').should('exist');
        cy.log('Close button exists!');
        cy.get('[data-cy="cy-delete-api-modal__accept__button"]').should('exist').and('include.text', 'Delete');
        cy.log('Delete button exists!');
    });

    it('Cancel button click returns user to My Apps dashboard', () => {
        cy.get('[data-cy="cy-overview_delete__button"]').eq(0).click({ force: true });
        cy.get('[data-cy="cy-delete-api-modal__cancel__button"]').click({ force: true });
        cy.log('Clicked on Cancel button...');
        cy.get('#delete-api-modal').should('not.be.visible');
        cy.log('Delete Modal no longer visible!');
    });

    it('Delete button click returns user to My Apps dashboard with success message on successful request', () => {
        deleteUserApps(1, 200, 'Successfully deleted API Client from apigee');
        cy.log('Intercepting DELETE request... response stubbed');
        cy.contains('div', 'App 1', { matchCase: true })
            .parents('div.chi-data-table__row')
            .find('div.chi-dropdown__menu')
            .invoke('attr', 'style', 'display: block')
            .contains('Delete')
            .should('be.visible')
            .click();
        cy.log('Clicking on Delete action for App 1...');
        cy.get('#delete-api-modal').should('be.visible');
        cy.log('Delete modal is visible!');
        cy.get('[data-cy="cy-delete-api-modal__accept__button"]').click();
        cy.log('Clicked on Delete button!');
        cy.get('[data-cy="cy-alert__lbl"]')
            .scrollIntoView()
            .should('be.visible')
            .and('have.class', '-success')
            .and('include.text', 'App 1 has been deleted.')
            .find('i')
            .should('have.class', 'icon-circle-check');
        cy.log('Success message exists!');
    });

    it('Delete button click returns user to My Apps dashboard with failure message on unsuccessful request', () => {
        deleteUserApps(0, 404, 'App not found');
        cy.log('Intercepting DELETE request... response stubbed');
        cy.visit('/credentials');
        cy.wait(['@appsList', '@prodList'], Cypress.config('defaultTimeout'));
        cy.contains('div', 'App 1', { matchCase: true })
            .parents('div.chi-data-table__row')
            .find('div.chi-dropdown__menu')
            .invoke('attr', 'style', 'display: block')
            .contains('Delete')
            .should('be.visible')
            .click();
        cy.get('#delete-api-modal').should('be.visible');
        cy.log('Delete modal is visible!');
        cy.get('[data-cy="cy-delete-api-modal__accept__button"]').click();
        cy.log('Clicked on Delete button!');
        cy.get('[data-cy="cy-alert__lbl"]')
            .scrollIntoView()
            .should('be.visible')
            .and('have.class', '-danger')
            .and('include.text', 'App not found')
            .find('i')
            .should('have.class', 'icon-circle-warning');
        cy.log('Failure message exists!');
    });

    it('userapps error management', () => {
        getAppDetailsOfUsers('', 500).as('appsList');
        cy.visit('/credentials');
        cy.wait('@appsList', Cypress.config('defaultTimeout'));
        cy.get('[data-cy="cy-alert__lbl"]')
            .should('be.visible')
            .and('have.class', '-danger')
            .and('include.text', 'Request failed with status code 500')
            .find('i')
            .should('have.class', 'icon-circle-warning');
        cy.log('Failure message exists!');
        cy.get('[data-cy="chi-alert_dismiss"]').should('be.visible').click();
        cy.get('[data-cy="cy-alert__lbl"]').should('not.exist');
    });

    it('apiproducts error management', () => {
        getAPIProductLists('Request failed with status code 500', '', 500).as('prodList');
        cy.visit('/credentials');
        cy.wait('@prodList', Cypress.config('defaultTimeout'));
        cy.get('[data-cy="cy-alert__lbl"]')
            .should('be.visible')
            .and('have.class', '-danger')
            .and('include.text', 'Request failed with status code 500')
            .find('i')
            .should('have.class', 'icon-circle-warning');
        cy.log('Failure message exists!');
    });

    it('beforeDestroy', () => {
        destroyStub();
    });
});
