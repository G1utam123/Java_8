/// <reference types='Cypress'/>

import data from '../../fixtures/variables.json';
import { getTaxonomy, getAppKeyDetails, getESPHealthStatus, postAPIProxyDeploy } from '../../utils/index';

describe('Initial Validation of APB', function () {
    beforeEach(function () {
        cy.mockLogin();
        getTaxonomy('taxonomies.json', 200).as('taxonomies');
        getAppKeyDetails('applicationkeys.json', 200);
        getESPHealthStatus('', 200);
        cy.visit('/proxy');
        cy.wait('@taxonomies');
    });

    it('Check both External and Internal', () => {
        cy.get('[data-cy="cy-general__epanel"]').should('be.visible');
        cy.get('[data-cy="cy-general__epanel"]').should('be.class', '-active');
        //API Proxy Builder title is visible
        cy.get('[data-cy="cy-title-api-proxy-builder"]').should('be.visible');
        cy.get('[data-cy="cy-general__epanel"]').find('div#vueSimple1').children('label').as('appKeyHeader_label');
        cy.get('@appKeyHeader_label').contains(' API Producer’s Application Key ').should('be.visible');
        cy.get('@appKeyHeader_label')
            .find('abbr.chi-label__required')
            .contains('*')
            .should('be.visible')
            .and('have.css', 'color', 'rgb(214, 32, 21)');
        cy.get('[data-cy="cy-general__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('[placeholder="Start typing…"]')
            .should('be.visible');
        cy.get('[data-cy="cy-app-key__input"]').next().find('i.icon-search').should('be.visible');

        //general panel error condition
        cy.get('[data-cy="cy-general-error_Applicationkey"]').should('not.exist');
        cy.get('[data-cy="cy-general-continue__button"]').click();
        cy.get('[data-cy="cy-general-error_Applicationkey"]')
            .contains('Please select an Application Key from the list')
            .should('be.visible');
        cy.get('[data-cy="cy-app-key__input"]').should('have.css', 'border-color', 'rgb(238, 48, 38)');
        cy.get('[data-cy="cy-general-error_MalId"]')
            .contains('Please provide CMS Asset Tag / ID #')
            .should('be.visible');
        cy.get('[ data-cy="cy-general-error_Service"]').contains('Please select a Service Type').should('be.visible');
        //Testing internal checkbox from General Panel
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        cy.get('[data-cy="cy-intActive__epanel"]').scrollIntoView().should('be.visible').should('be.class', '-pending');
        //Testing external checkbox from General Panel
        cy.get('[data-cy="cy-external__checkbox"]').click({ force: true });
        cy.get('[data-cy="cy-extActive__epanel"]').scrollIntoView().should('be.visible').should('be.class', '-pending');
        //general panel
        cy.get('[data-cy="cy-general-continue__button"]').should('be.visible');
        cy.get('[data-cy="cy-app-key__input"]')
            .click()
            .type(`${data.applicationKey}`, { delay: 0 })
            .click({ force: true });
        cy.get('[data-cy="cy-appkeydesc_paragraph"]').contains('Request an Application Key').should('be.visible');
        cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });
        cy.get('[data-cy="cy-malIddesc_paragraph"]')
            .contains(
                'An entry in the Master Application List is required to expose an endpoint through the gateway, click here to request a CMS Asset Tag / ID #'
            )
            .should('be.visible');
        cy.get('[data-cy="cy-SOAP-checkbox"]').should('be.visible');
        cy.get('[data-cy="cy-SOAP-checkbox"]').click();
        cy.get('[data-cy="cy-service-type__select"]').select('Inbound').trigger('click');
        cy.get('[data-cy="cy-service-type__inbound"]')
            .contains('Inbound - Endpoint service is inside the Lumen network')
            .should('be.visible');
        cy.get('[data-cy="cy-service-type__outbound"]')
            .contains('Outbound - Endpoint service is outside the Lumen network')
            .should('be.visible');
        cy.get('[data-cy="cy-internal__checkbox"]').should('be.visible');
        cy.get('[data-cy="cy-external__checkbox"]').should('be.visible');
        cy.get('[data-cy="cy-internal-checkbox__div"]').click({ force: true });
        cy.get('[data-cy="cy-external__checkbox_div"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();
        cy.get('[data-cy="cy-general__epanel"]').should('be.class', '-done');
        cy.get('[data-cy="cy-gatewayEndpoint__epanel"]').should('be.visible');
        cy.get('[data-cy="cy-gatewayEndpoint__epanel"]').should('be.class', '-active');

        //gatewayEndpoint error condition
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();
        cy.get('[data-cy="cy-gatewayEndpoint-error_Taxonamy"]')
            .contains('Please select a Taxonomy from the list')
            .should('be.visible');
        cy.get('[data-cy="cy-gatewayEndpoint-error_Version"]').contains('Please select a Version').should('be.visible');
        cy.get('[data-cy="cy-resourcename__err"]').contains('Please provide a Resource').should('be.visible');
        //gatewayEndpoint panel
        cy.get('[data-cy="cy-gatewayEndpoint__epanel"]').should('be.visible');
        cy.get('[data-cy="cy-gatewayEndpoint__epanel"]').should('be.class', '-active');
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').should('be.visible');
        cy.get('[data-cy="cy-gatewayEndpoint-previous__button"]').should('be.visible');
        cy.get('[data-cy="cy-service-category__select"]').type(`${data.taxonomy}`, { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();

        //targetEndpoint error condition
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').as('targetEndpoint_continue_btn');
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-targetEndpoint-error_Host"]')
            .contains(' Please provide at least one Host')
            .should('be.visible');

        cy.get('[data-cy="cy-dev1-host__input"]', { timeout: Cypress.config('defaultTimeout') }).as('dev1Host_input');
        cy.get('@dev1Host_input').scrollIntoView().should('be.visible').type('test*', { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-targetEndpoint-error_Host"]').should('not.exist');
        cy.get('[data-cy="cy-dev1-host__input"]')
            .next()
            .contains(`${data.hostHttpErrorMessage}`)
            .scrollIntoView()
            .should('be.visible');
        cy.get('[data-cy="cy-dev1-host__input"]')
            .next()
            .next()
            .contains(`${data.hostNameErrorMessage}`)
            .should('be.visible');
        cy.get('@dev1Host_input').clear().type(`${data.invalidHostUrl1}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-dev1-host__input"]').next().contains(`${data.hostHttpErrorMessage}`);
        cy.get('@dev1Host_input').clear().type(`${data.invalidHostUrl2}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-dev1-host__input"]').next('div.-danger').as('dev1_warning_Message');
        cy.get('@dev1_warning_Message').find('div.sc-chi-icon').scrollIntoView().should('be.visible');
        cy.get('@dev1_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@dev1Host_input').clear().type(`${data.invalidHostUrl3}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('@dev1_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@dev1Host_input').clear().type(`${data.invalidHostUrl4}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('@dev1_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@dev1Host_input').clear().type(`${data.validHostUrl}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-intActive__epanel"]').find('button').contains(' Previous ').click();
        cy.get('[data-cy="cy-dev1-host__input"]').next('div.-danger').should('not.exist');
        cy.get('@dev1Host_input').clear();

        cy.get('[data-cy="cy-dev2-host__input"]').as('dev2Host_input');
        cy.get('@dev2Host_input').should('be.visible').type('test*', { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-dev2-host__input"]')
            .next()
            .contains(`${data.hostHttpErrorMessage}`)
            .scrollIntoView()
            .should('be.visible');
        cy.get('[data-cy="cy-dev2-host__input"]')
            .next()
            .next()
            .contains(`${data.hostNameErrorMessage}`)
            .should('be.visible');
        cy.get('@dev2Host_input').clear().type(`${data.invalidHostUrl1}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-dev2-host__input"]').next().contains(`${data.hostHttpErrorMessage}`);
        cy.get('@dev2Host_input').clear().type(`${data.invalidHostUrl2}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-dev2-host__input"]').next('div.-danger').as('dev2_warning_Message');
        cy.get('@dev2_warning_Message').find('div.sc-chi-icon').scrollIntoView().should('be.visible');
        cy.get('@dev2_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@dev2Host_input').clear().type(`${data.invalidHostUrl3}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('@dev2_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@dev2Host_input').clear().type(`${data.invalidHostUrl4}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('@dev2_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@dev2Host_input').clear().type(`${data.validHostUrl}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-intActive__epanel"]').find('button').contains(' Previous ').click();
        cy.get('[data-cy="cy-dev2-host__input"]').next('div.-danger').should('not.exist');
        cy.get('@dev2Host_input').clear();

        cy.get('[data-cy="cy-dev3-host__input"]').as('dev3Host_input');
        cy.get('@dev3Host_input').should('be.visible').type('test*', { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-dev3-host__input"]')
            .next()
            .contains(`${data.hostHttpErrorMessage}`)
            .scrollIntoView()
            .should('be.visible');
        cy.get('[data-cy="cy-dev3-host__input"]')
            .next()
            .next()
            .contains(`${data.hostNameErrorMessage}`)
            .should('be.visible');
        cy.get('@dev3Host_input').clear().type(`${data.invalidHostUrl1}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-dev3-host__input"]').next().contains(`${data.hostHttpErrorMessage}`);
        cy.get('@dev3Host_input').clear().type(`${data.invalidHostUrl2}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-dev3-host__input"]').next('div.-danger').as('dev3_warning_Message');
        cy.get('@dev3_warning_Message').find('div.sc-chi-icon').scrollIntoView().should('be.visible');
        cy.get('@dev3_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@dev3Host_input').clear().type(`${data.invalidHostUrl3}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('@dev3_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@dev3Host_input').clear().type(`${data.invalidHostUrl4}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('@dev3_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@dev3Host_input').clear().type(`${data.validHostUrl}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-intActive__epanel"]').find('button').contains(' Previous ').click();
        cy.get('@dev3Host_input').clear();

        cy.get('[data-cy="cy-dev4-host__input"]').as('dev4Host_input');
        cy.get('@dev4Host_input').should('be.visible').type('test*', { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-dev4-host__input"]')
            .next()
            .contains(`${data.hostHttpErrorMessage}`)
            .scrollIntoView()
            .should('be.visible');
        cy.get('[data-cy="cy-dev4-host__input"]')
            .next()
            .next()
            .contains(`${data.hostNameErrorMessage}`)
            .should('be.visible');
        cy.get('@dev4Host_input').clear().type(`${data.invalidHostUrl1}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-dev4-host__input"]').next().contains(`${data.hostHttpErrorMessage}`);
        cy.get('@dev4Host_input').clear().type(`${data.invalidHostUrl2}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-dev4-host__input"]').next('div.-danger').as('dev4_warning_Message');
        cy.get('@dev4_warning_Message').find('div.sc-chi-icon').scrollIntoView().should('be.visible');
        cy.get('@dev4_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@dev4Host_input').clear().type(`${data.invalidHostUrl3}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('@dev4_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@dev4Host_input').clear().type(`${data.invalidHostUrl4}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('@dev4_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@dev4Host_input').clear().type(`${data.validHostUrl}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-intActive__epanel"]').find('button').contains(' Previous ').click();
        cy.get('@dev4Host_input').clear();

        cy.get('[data-cy="cy-test1-host__input"]').as('test1Host_input');
        cy.get('@test1Host_input').should('be.visible').type('test*', { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-test1-host__input"]').next().contains(`${data.hostHttpErrorMessage}`).should('be.visible');
        cy.get('[data-cy="cy-test1-host__input"]')
            .next()
            .next()
            .contains(`${data.hostNameErrorMessage}`)
            .should('be.visible');
        cy.get('@test1Host_input').clear().type(`${data.invalidHostUrl1}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-test1-host__input"]').next().contains(`${data.hostHttpErrorMessage}`);
        cy.get('@test1Host_input').clear().type(`${data.invalidHostUrl2}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-test1-host__input"]').next('div.-danger').as('test1_warning_Message');
        cy.get('@test1_warning_Message').find('div.sc-chi-icon').should('be.visible');
        cy.get('@test1_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@test1Host_input').clear().type(`${data.invalidHostUrl3}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('@test1_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@test1Host_input').clear().type(`${data.invalidHostUrl4}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('@test1_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@test1Host_input').clear().type(`${data.validHostUrl}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-intActive__epanel"]').find('button').contains(' Previous ').click();
        cy.get('@test1Host_input').clear();

        cy.get('[data-cy="cy-test2-host__input"]').as('test2Host_input');
        cy.get('@test2Host_input').should('be.visible').type('test*', { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-test2-host__input"]').next().contains(`${data.hostHttpErrorMessage}`).should('be.visible');
        cy.get('[data-cy="cy-test2-host__input"]')
            .next()
            .next()
            .contains(`${data.hostNameErrorMessage}`)
            .should('be.visible');
        cy.get('@test2Host_input').clear().type(`${data.invalidHostUrl1}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-test2-host__input"]').next().contains(`${data.hostHttpErrorMessage}`);
        cy.get('@test2Host_input').clear().type(`${data.invalidHostUrl2}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-test2-host__input"]').next('div.-danger').as('test2_warning_Message');
        cy.get('@test2_warning_Message').find('div.sc-chi-icon').should('be.visible');
        cy.get('@test2_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@test2Host_input').clear().type(`${data.invalidHostUrl3}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('@test2_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@test2Host_input').clear().type(`${data.invalidHostUrl4}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('@test2_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@test2Host_input').clear().type(`${data.validHostUrl}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-intActive__epanel"]').find('button').contains(' Previous ').click();
        cy.get('@test2Host_input').clear();

        cy.get('[data-cy="cy-test3-host__input"]').as('test3Host_input');
        cy.get('@test3Host_input').should('be.visible').type('test*', { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-test3-host__input"]').next().contains(`${data.hostHttpErrorMessage}`).should('be.visible');
        cy.get('[data-cy="cy-test3-host__input"]')
            .next()
            .next()
            .contains(`${data.hostNameErrorMessage}`)
            .should('be.visible');
        cy.get('@test3Host_input').clear().type(`${data.invalidHostUrl1}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-test3-host__input"]').next().contains(`${data.hostHttpErrorMessage}`);
        cy.get('@test3Host_input').clear().type(`${data.invalidHostUrl2}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-test3-host__input"]').next('div.-danger').as('test3_warning_Message');
        cy.get('@test3_warning_Message').find('div.sc-chi-icon').should('be.visible');
        cy.get('@test3_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@test3Host_input').clear().type(`${data.invalidHostUrl3}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('@test3_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@test3Host_input').clear().type(`${data.invalidHostUrl4}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('@test3_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@test3Host_input').clear().type(`${data.validHostUrl}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-intActive__epanel"]').find('button').contains(' Previous ').click();
        cy.get('@test3Host_input').clear();

        cy.get('[data-cy="cy-test4-host__input"]').as('test4Host_input');
        cy.get('@test4Host_input').should('be.visible').type('test*', { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-test4-host__input"]').next().contains(`${data.hostHttpErrorMessage}`).should('be.visible');
        cy.get('[data-cy="cy-test4-host__input"]')
            .next()
            .next()
            .contains(`${data.hostNameErrorMessage}`)
            .should('be.visible');
        cy.get('@test4Host_input').clear().type(`${data.invalidHostUrl1}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-test4-host__input"]').next().contains(`${data.hostHttpErrorMessage}`);
        cy.get('@test4Host_input').clear().type(`${data.invalidHostUrl2}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-test4-host__input"]').next('div.-danger').as('test4_warning_Message');
        cy.get('@test4_warning_Message').find('div.sc-chi-icon').should('be.visible');
        cy.get('@test4_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@test4Host_input').clear().type(`${data.invalidHostUrl3}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('@test4_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@test4Host_input').clear().type(`${data.invalidHostUrl4}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('@test4_warning_Message').contains(`${data.hostNameErrorMessage}`);
        cy.get('@test4Host_input').clear().type(`${data.validHostUrl}`, { delay: 0 });
        cy.get('@targetEndpoint_continue_btn').click();
        cy.get('[data-cy="cy-intActive__epanel"]').find('button').contains(' Previous ').click();
        cy.get('@test4Host_input').clear();

        cy.get('[data-cy="cy-resource-path__input"]').as('resource_path_input');
        cy.get('@resource_path_input').type('/');
        cy.get('[data-cy="cy-targetEndpoint-error_resourcepath"]')
            .contains('Resource path should not be "/" alone')
            .should('be.visible');
        cy.get('@resource_path_input').find('input').clear();
        cy.get('@resource_path_input').find('input').type('test');
        cy.get('[data-cy="cy-targetEndpoint-error_resourcepath"]')
            .contains('Resource path should begin with /')
            .should('be.visible');
        cy.get('@resource_path_input').find('input').clear();
        cy.get('@resource_path_input').type('{');
        cy.get('[data-cy="cy-targetEndpoint-error_resourcepath"]')
            .contains(`Resource path should not contain {, }, |, \, ^, ~, [, ], #, <, >, and :`)
            .should('be.visible');
        cy.get('@resource_path_input').find('input').clear();
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();

        //targetEndpoint panel
        cy.get('@resource_path_input', { timeout: Cypress.config('defaultTimeout') }).should('be.visible');
        cy.get('[data-cy="cy-targetEndpoint__epanel"]').should('be.class', '-active');
        cy.get('@resource_path_input').type(`${data.resourcePath}`, { delay: 0 });
        cy.get('[data-cy="cy-dev1_label"]').contains('Dev1 Host');
        cy.get('[data-cy="cy-dev2_label"]').contains('Dev2 Host');
        cy.get('[data-cy="cy-dev3_label"]').contains('Dev3 Host');
        cy.get('[data-cy="cy-dev4_label"]').contains('Dev4 Host');
        cy.get('[data-cy="cy-test1_label"]').contains('Test1 Host');
        cy.get('[data-cy="cy-test2_label"]').contains('Test2 Host');
        cy.get('[data-cy="cy-test3_label"]').contains('Test3 Host');
        cy.get('[data-cy="cy-test4_label"]').contains('Test4 Host');
        cy.get('[data-cy="cy-dev1-host__input"]').type(`${data.dev1HostName}`, { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();
        cy.get('[data-cy="cy-targetEndpoint__epanel"]').should('be.class', '-done');
        cy.get('[data-cy="cy-intActive__epanel"]').scrollIntoView().should('be.visible').should('be.class', '-active');

        //internal panel error condition
        cy.get('[data-cy="cy-internal-continue__button"]').click();
        cy.get('[data-cy="cy-internal-error__checkbox"]')
            .contains(`${data.intExt_checkBox_error_message}`)
            .should('be.visible');
        //internal panel
        //Check for Basic Authentication
        cy.get('[data-cy="cy-basicAuth__checkbox"]').click();
        cy.get('[data-cy="cy-int-basAuth_label"]')
            .contains(
                'Basic Authentication – Lumen employees can provide their LDAP credentials in a basic authentication header. Access can be granted to'
            )
            .should('be.visible');
        cy.get('[data-cy="cy-LdapUser"]').should('be.visible');
        cy.get('[data-cy="cy-LdapGroup"]').should('be.visible');
        cy.get('[data-cy="cy-intLdapUser_button"]')
            .find('.chi-button')
            .contains('Add')
            .should('be.visible')
            .click()
            .click();
        cy.get('[data-cy="cy-intLdapUser_textInput"]').type(`${data.ldapUser1}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapUser_button"]').click();
        cy.get('[data-cy="cy-intldapUserlist_grid"]').should('be.visible');
        cy.get('[data-cy="cy-intLdapGroup_button"]').click();
        cy.get('[data-cy="cy-intLdapGroup_textInput"]').type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapGroup_button"]').click();
        cy.get('[data-cy="cy-intldapGrouplist_grid"]').should('be.visible');
        cy.get('[data-cy="cy-intLdapGroup_delbutton"]').click();
        cy.get('[data-cy="cy-intLdapUser_delbutton"]').click();
        cy.get('[data-cy="cy-basicAuth__checkbox"]').click();

        cy.get('[data-cy="cy-intActive__epanel"]').children().find('[data-chi-epanel-action="previous"]').click();
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();
        cy.get('[data-cy="cy-intActive__epanel"]')
            .children()
            .find('[data-cy="cy-appln-key__checkbox"]')
            .next()
            .next()
            .find('[data-cy="cy-checkbox-enforceTaxonamy"]')
            .should('not.exist');

        cy.get('[data-cy="cy-intActive__epanel"]')
            .children()
            .find('[data-cy="cy-appln-key__checkbox"]')
            .next()
            .next()
            .find('[data-cy="cy-checkbox-enforceDigest"]')
            .should('not.exist');

        cy.get('[data-cy="cy-appln-key__checkbox"]').as('appKey_chkBox');
        cy.get('@appKey_chkBox').should('not.be.checked');
        cy.get('@appKey_chkBox').click();
        cy.get('[data-cy="cy-intActive__epanel"]')
            .children()
            .find('[data-cy="cy-appln-key__checkbox"]')
            .next()
            .next()
            .as('intAppKey_list');
        cy.get('@intAppKey_list').should('be.visible');
        cy.get('@intAppKey_list').children().find('.chi-checkbox__input').should('have.length.gte', 2);
        cy.get('[data-cy="cy-int-appln-key_label"]')
            .contains(
                'Application Key – Consumers are issued an application key and secret. A Unix timestamp is encrypted using the secret, this digest,'
            )
            .should('be.visible');
        cy.get('[data-cy="cy-checkbox-enforceTaxonamy"]').should('be.visible');
        cy.get('[data-cy="cy-checkbox-enforceDigest"]').should('be.visible');
        cy.get('@appKey_chkBox').click().click();

        cy.get('[data-cy="cy-internal-continue__button"]').click();
        cy.get('[data-cy="cy-intActive__epanel"]')
            .children()
            .find('.chi-epanel__action')
            .children('button')
            .contains(' Change ')
            .click();
        cy.get('[data-cy="cy-internal-continue__button"]').click();

        //external panel error condition
        cy.get('[data-cy="cy-ext-continue__button"]').click();
        cy.get('[data-cy="cy-ext-error__checkbox"]')
            .contains(`${data.intExt_checkBox_error_message}`)
            .should('be.visible');
        //external panel
        cy.get('[data-cy="cy-applicationKey__checkbox"]').find("label[for='checkbox-ch7']").as('appKey_cbx');
        cy.get('@appKey_cbx').should('not.be.checked');
        cy.get('@appKey_cbx').click();
        cy.get('#checkbox-ch7').should('be.checked');
        cy.get('[data-cy="cy-extActive__epanel"]').scrollIntoView().should('be.visible').should('be.class', '-active');
        cy.get('[data-cy="cy-extauthenticationwarning"]').should('be.visible');
        cy.get('@appKey_cbx').click();
        cy.get('[data-cy="cy-extoAuth__checkbox"]').click();
        cy.get('[data-cy="cy-extportalJwt__checkbox"]').click();
        cy.get('[data-cy="cy-basicAuthExternal__checkbox"]').click();
        cy.get('[data-cy="cy-LdapUserExt"]').contains('LDAP Users');
        cy.get('[data-cy="cy-LdapGroupExt"]').contains('LDAP Groups');
        cy.get('[data-cy="cy-extbasicauthwarning"]').should('be.visible');
        cy.get('[data-cy="cy-basicAuthExternal__checkbox"]').click();
        cy.get('[data-cy="cy-extoAuth__checkbox"]').click();
        cy.get('[data-cy="cy-extportalJwt__checkbox"]').click();
        cy.get('[data-cy="cy-extoAuth__checkbox"]').click();
        cy.get('[data-cy="cy-extportalJwt__checkbox"]').click();
        cy.get('[data-cy="cy-basicAuthExternal__checkbox"]').click();
        cy.get('[data-cy="cy-extLdapUser_textInput"]').type(`${data.ldapUser2}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapUser_button"]').click();
        cy.get('[data-cy="cy-extldapUserlist_grid"]').should('be.visible');
        cy.get('[data-cy="cy-extLdapUser_delbutton"]').click();
        cy.get('[data-cy="cy-extLdapGroup_textInput"]').type(`${data.ldapGroup2}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapGroup_button"]').click();
        cy.get('[data-cy="cy-extldapGrouplist_grid"]').should('be.visible');
        cy.get('@appKey_cbx').click();
        cy.get('[data-cy="cy-extoAuth__checkbox"]').click();
        cy.get('[data-cy="cy-extportalJwt__checkbox"]').click();
        cy.get('[data-cy="cy-ext-continue__button"]').click();

        //endpoint panel
        cy.get('[data-cy="cy-endPoint__epanel"]').should('be.visible');
        cy.get('[data-cy="cy-endPoint__epanel"]').should('be.class', '-active');
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        //if AuthType is Basic Auth
        cy.get('[data-cy="cy-authentication-type__select"]').select('Basic Auth').trigger('click');
        cy.get('[data-cy="cy-basicAuth_uname"]').should('be.visible');
        cy.get('[data-cy="cy-basicAuth_pwd"]').should('be.visible');
        //if AuthType is OAuth
        cy.get('[data-cy="cy-authentication-type__select"]').select('OAuth').trigger('click');
        cy.get('[data-cy="cy-oauth"]').should('be.visible');
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('[data-cy="cy-grant-type__select"]').select('Client Credentials').trigger('click');
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('[data-cy="cy-grant-loc__select"]').select('Form Parameter').trigger('click');
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('[data-cy="cy-grant-type__select"]').select('JWT Bearer').trigger('click');
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('[data-cy="cy-grant-loc__select"]').select('Form Parameter').trigger('click');
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('[data-cy="cy-grant-type__select"]').select('Password').trigger('click');
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('[data-cy="cy-grant-loc__select"]').select('Query Parameter').trigger('click');
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('[data-cy="cy-token-host__input"]').type('https://my.token.host', { delay: 0 });
        cy.get('[data-cy="cy-token-path__input"]').type('asdf');
        cy.get('[data-cy="cy-token-host__input"]').clear();
        cy.get('[data-cy="cy-token-path__input"]').type('/');
        cy.get('[data-cy="cy-token-path__input"]').clear();
        cy.get('[data-cy="cy-token-path__input"]').type('/{}');
        cy.get('[data-cy="cy-token-host__input"]').type('my.token.host', { delay: 0 });
        cy.get('[data-cy="cy-token-host__input"]').clear();
        cy.get('[data-cy="cy-token-path__input"]').clear();
        cy.get('[data-cy="cy-token-host__input"]').type('my.token.host', { delay: 0 });
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('[data-cy="cy-token-path__input"]').type('/token', { delay: 0 });
        cy.get('[data-cy="cy-token-host__input"]').clear();
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('[data-cy="cy-token-host__input"]').type('my.token.host', { delay: 0 });
        cy.get('[data-cy="cy-oauth_username"]').type('username', { delay: 0 });
        cy.get('[data-cy="cy-oauth_password"]').type('password', { delay: 0 });
        cy.get('[data-cy="cy-grant-loc__select_4"]').select('Form Parameter').trigger('click');
        //previous to external gateway authentication
        cy.get('[data-cy="cy-endPoint__epanel"]').contains('Previous').click();
        cy.get('[data-cy="cy-extActive__epanel"]').should('be.class', '-active');
        cy.get('[data-cy="cy-gatewayEndpoint__epanel"]').should('be.class', '-done');
        //previous to internal gateway authentication
        cy.get('[data-cy="cy-extActive__epanel"]').contains('Previous').click();
        cy.get('[data-cy="cy-intActive__epanel"]').should('be.class', '-active');
        cy.get('[data-cy="cy-extActive__epanel"]').should('be.class', '-done');
        //previous to target endpoint
        cy.get('[data-cy="cy-intActive__epanel"]').contains('Previous').click();
        cy.get('[data-cy="cy-targetEndpoint__epanel"]').should('be.class', '-active');
        cy.get('[data-cy="cy-intActive__epanel"]').should('be.class', '-done');
        //previous to gateway endpoint
        cy.get('[data-cy="cy-targetEndpoint__epanel"]').contains('Previous').click();
        cy.get('[data-cy="cy-gatewayEndpoint__epanel"]').should('be.class', '-active');
        cy.get('[data-cy="cy-targetEndpoint__epanel"]').should('be.class', '-done');
        //previous to general
        cy.get('[data-cy="cy-gatewayEndpoint__epanel"]').contains('Previous').click();
        cy.get('[data-cy="cy-general__epanel"]').should('be.class', '-active');
        cy.get('[data-cy="cy-gatewayEndpoint__epanel"]').should('be.class', '-done');
        //Change to internal gateway authentication
        cy.get('[data-cy="cy-intActive__epanel"]').contains('Change').click();
        cy.get('[data-cy="cy-general__epanel"]').should('be.class', '-done');
        cy.get('[data-cy="cy-intActive__epanel"]').should('be.class', '-active');
        //Continue to endpoint authentication
        cy.get('[data-cy="cy-internal-continue__button"]').click();
        postAPIProxyDeploy('error', '', 500);
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('#modal-1').should('be.visible').contains('OK');
    });
});

describe('External path', function () {
    beforeEach(function () {
        cy.mockLogin();
        getTaxonomy('taxonomies.json', 200).as('taxonomies');
        getAppKeyDetails('applicationkeys.json', 200);
        getESPHealthStatus('', 200);
        cy.visit('/proxy');
        cy.wait('@taxonomies');
    });

    it('Check External', () => {
        //general panel error condition
        cy.get('[data-cy="cy-general-continue__button"]', { timeout: Cypress.config('defaultTimeout') }).click({
            force: true,
        });
        //Testing external checkbox from General Panel
        cy.get('[data-cy="cy-external__checkbox"]').click({ force: true });
        //general panel
        cy.get('[data-cy="cy-app-key__input"]')
            .click()
            .type(`${data.applicationKey}`, { delay: 0 })
            .click({ force: true });
        cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });
        cy.get('[data-cy="cy-SOAP-checkbox"]').click();
        cy.get('[data-cy="cy-service-type__select"]').select('Inbound').trigger('click');
        cy.get('[data-cy="cy-external__checkbox_div"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //gatewayEndpoint error condition
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();
        //gatewayEndpoint panel
        cy.get('[data-cy="cy-service-category__select"]').click({ force: true }).type(`${data.taxonomy}`, { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();
        //targetEndpoint error condition
        cy.get('[data-cy="cy-resource-path__input"]').as('resource_path_input');
        cy.get('@resource_path_input').type('/');
        cy.get('@resource_path_input').type('{}');
        cy.get('@resource_path_input').find('input').clear();
        cy.get('@resource_path_input').type('test');
        cy.get('@resource_path_input').find('input').clear();
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();
        //targetEndpoint panel
        cy.get('@resource_path_input').type(`${data.resourcePath}`, { delay: 0 });
        cy.get('[data-cy="cy-dev1-host__input"]').type(`${data.dev1HostName}`, { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();
        //external panel error condition
        cy.get('[data-cy="cy-ext-continue__button"]').click();
        //Check JWT
        cy.get('[data-cy="cy-extportalJwt__checkbox"]').click();
        cy.get('[data-cy="cy-extportalJwt__checkbox"]').click();
        //Check OAuth
        cy.get('[data-cy="cy-extoAuth__checkbox"]').click();
        cy.get('[data-cy="cy-extoAuth__checkbox"]').click();
        //Check for Basic Authentication
        cy.get('[data-cy="cy-basicAuthExternal__checkbox"]').click();
        cy.get('[data-cy="cy-extLdapUser_textInput"]').type(`${data.ldapUser1}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapUser_button"]').click();
        cy.get('[data-cy="cy-extLdapUser_delbutton"]').click();
        cy.get('[data-cy="cy-extLdapGroup_textInput"]').type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapGroup_button"]').click();
        cy.get('[data-cy="cy-extLdapGroup_delbutton"]').click();
        //external panel
        cy.get('[data-cy="cy-extLdapUser_textInput"]').type(`${data.ldapUser1}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapUser_button"]').click();
        cy.get('[data-cy="cy-extLdapGroup_textInput"]').type(`${data.ldapGroup2}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapGroup_button"]').click();
        cy.get('[data-cy="cy-extLdapGroup_delbutton"]').click();
        cy.get('[data-cy="cy-basicAuthExternal__checkbox"]').click();
        cy.get('[data-cy="cy-basicAuthExternal__checkbox"]').click();
        cy.get('[data-cy="cy-ext-continue__button"]').click();
        //if AuthType is Basic Auth
        cy.get('[data-cy="cy-authentication-type__select"]').select('Basic Auth').trigger('click');
        //if AuthType is OAuth
        cy.get('[data-cy="cy-authentication-type__select"]').select('OAuth').trigger('click');
        //if AuthType is Xcertificate
        cy.get('[data-cy="cy-authentication-type__select"]').select('x509 Certificate').trigger('click');
        //endpoint panel
        cy.get('[data-cy="cy-authentication-type__select"]')
            .select('Authorization Header Pass-through')
            .trigger('click');
        cy.get('[data-cy="cy-authentication-type__select"]').select('OAuth').trigger('click');
        cy.get('[data-cy="cy-grant-type__select"]').select('Client Credentials').trigger('click');
        cy.get('[data-cy="cy-grant-loc__select"]').select('Query Parameter').trigger('click');
        cy.get('[data-cy="cy-token-host__input"]').type('https://a', { delay: 0 });
        cy.get('[data-cy="cy-token-host__input"]').clear();
        cy.get('[data-cy="cy-token-host__input"]').type('my.token.host', { delay: 0 });
        cy.get('[data-cy="cy-token-path__input"]').type('/token', { delay: 0 });
        cy.get('[data-cy="cy-oauth_cl_id"]').type('username', { delay: 0 });
        cy.get('[data-cy="cy-oauth_cl_secret"]').type('password', { delay: 0 });
        cy.get('[data-cy="cy-grant-loc__select_3"]').select('Query Parameter').trigger('click');
        //previous to external gateway authentication
        cy.get('[data-cy="cy-endPoint__epanel"]').contains('Previous').click();
        //previous to target endpoint
        cy.get('[data-cy="cy-extActive__epanel"]').contains('Previous').click();
        //previous to gateway endpoint
        cy.get('[data-cy="cy-targetEndpoint__epanel"]').contains('Previous').click();
        //previous to general
        cy.get('[data-cy="cy-gatewayEndpoint__epanel"]').contains('Previous').click();
        //change to target endpoint
        cy.get('[data-cy="cy-targetEndpoint__epanel"]').contains('Change').click();
        //change to endpoint panel and submit
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();
        postAPIProxyDeploy('', 'apbSuccessResponse.json', 200);
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('#modal-1').contains('OK');
    });
});

describe('Internal path', function () {
    beforeEach(function () {
        cy.mockLogin();
        getTaxonomy('taxonomies.json', 200).as('taxonomies');
        getAppKeyDetails('applicationkeys.json', 200);
        getESPHealthStatus('', 200);
        cy.visit('/proxy');
        cy.wait('@taxonomies');
    });

    it('Check Internal', () => {
        //general panel error condition
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //Testing internal checkbox from General Panel
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        //general panel
        cy.get('[data-cy="cy-app-key__input"]')
            .click()
            .type(`${data.applicationKey}`, { delay: 0 })
            .click({ force: true });
        cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });
        cy.get('[data-cy="cy-SOAP-checkbox"]').click();
        cy.get('[data-cy="cy-service-type__select"]').select('Inbound').trigger('click');
        cy.get('[data-cy="cy-internal-checkbox__div"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //gatewayEndpoint error condition
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();
        //gatewayEndpoint panel
        cy.get('[data-cy="cy-service-category__select"]').click({ force: true }).type(`${data.taxonomy}`, { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();
        //targetEndpoint error condition
        cy.get('[data-cy="cy-resource-path__input"]').as('resource_path_input');
        cy.get('@resource_path_input').find('input').type('/');
        cy.get('@resource_path_input').find('input').clear();
        cy.get('@resource_path_input').find('input').type('test');
        cy.get('@resource_path_input').find('input').clear();
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();
        //targetEndpoint panel
        cy.get('@resource_path_input').find('input').type(`${data.resourcePath}`, { delay: 0 });
        cy.get('[data-cy="cy-dev1-host__input"]').type(`${data.dev1HostName}`, { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();
        //internal panel error condition
        cy.get('[data-cy="cy-internal-continue__button"]').click();
        //Check OAuth
        cy.get('[data-cy="cy-appln-key__checkbox"]').click();
        cy.get('[data-cy="cy-appln-key__checkbox"]').click();
        //Check for Basic Authentication
        cy.get('[data-cy="cy-basicAuth__checkbox"]').click();
        cy.get('[data-cy="cy-intLdapGroup_textInput"]').type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapGroup_button"]').click();
        cy.get('[data-cy="cy-intLdapGroup_delbutton"]').click();
        //internal panel
        cy.get('[data-cy="cy-appln-key__checkbox"]').click();
        cy.get('[data-cy="cy-basicAuth__checkbox"]').click();
        cy.get('[data-cy="cy-internal-continue__button"]').click();
        //if AuthType is Basic Auth
        cy.get('[data-cy="cy-authentication-type__select"]').select('Basic Auth').trigger('click');
        //if AuthType is OAuth
        cy.get('[data-cy="cy-authentication-type__select"]').select('OAuth').trigger('click');
        //if AuthType is Xcertificate
        cy.get('[data-cy="cy-authentication-type__select"]').select('x509 Certificate').trigger('click');
        //endpoint panel
        cy.get('[data-cy="cy-authentication-type__select"]')
            .select('Authorization Header Pass-through')
            .trigger('click');
        cy.get('[data-cy="cy-authentication-type__select"]').select('OAuth').trigger('click');
        cy.get('[data-cy="cy-grant-type__select"]').select('JWT Bearer').trigger('click');
        cy.get('[data-cy="cy-grant-loc__select"]').select('Query Parameter').trigger('click');
        cy.get('[data-cy="cy-token-host__input"]').type('my.token.host', { delay: 0 });
        cy.get('[data-cy="cy-token-path__input"]').type('/token', { delay: 0 });
        cy.get('[data-cy="cy-grant-jwt-username__input"]').type('user');
        cy.get('[data-cy="cy-grant-jwt-kvm__input"]').type('SFDC@Dev1', { delay: 0 });
        //previous to internal gateway authentication
        cy.get('[data-cy="cy-endPoint__epanel"]').contains('Previous').click();
        //previous to target endpoint
        cy.get('[data-cy="cy-intActive__epanel"]').contains('Previous').click();
        //previous to gateway endpoint
        cy.get('[data-cy="cy-targetEndpoint__epanel"]').contains('Previous').click();
        //previous to general
        cy.get('[data-cy="cy-gatewayEndpoint__epanel"]').contains('Previous').click();
        //Change to internal gateway authentication
        cy.get('[data-cy="cy-intActive__epanel"]').contains('Change').click();
        //change to target endpoint
        cy.get('[data-cy="cy-targetEndpoint__epanel"]').contains('Change').click();
        //change to endpoint panel and submit
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();
        postAPIProxyDeploy('', 'apbSuccessResponse.json', 200);
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('#modal-1').contains('OK');
    });
});

describe('Check APB Availability', function () {
    beforeEach(function () {
        cy.mockLogin();
    });

    it('APB is available', () => {
        getTaxonomy('taxonomies.json', 200).as('taxonomies');
        getAppKeyDetails('applicationkeys.json', 200);
        getESPHealthStatus('healthESPResponse.json');
        cy.visit('/proxy');
        cy.wait('@taxonomies');
        cy.get('[data-cy="cy-general__epanel"]').should('be.visible');
    });

    it('APB is not available', () => {
        getESPHealthStatus('healthESPResponseError.json');
        cy.visit('/proxy');
        cy.get('[data-cy="alert-apb-available"]').should('be.visible').contains(`${data.checkAvailabilityAlert}`);
        cy.get('[data-cy="cy-common__loader"]').should('be.visible').contains(`${data.checkAvailabilitySpinner}`);
    });

    it('APB is not available due to an unexpected error in the call', () => {
        getESPHealthStatus('', 500);
        cy.visit('/proxy');
        cy.get('[data-cy="alert-apb-available"]').should('be.visible').contains(`${data.checkAvailabilityAlert}`);
        cy.get('[data-cy="cy-common__loader"]').should('be.visible').contains(`${data.checkAvailabilitySpinner}`);
    });

    it('APB is not available & then it comes available', () => {
        getESPHealthStatus('healthESPResponseError.json');
        cy.visit('/proxy');
        cy.get('[data-cy="alert-apb-available"]').should('be.visible').contains(`${data.checkAvailabilityAlert}`);
        cy.get('[data-cy="cy-common__loader"]').should('be.visible').contains(`${data.checkAvailabilitySpinner}`);
        cy.wait(`${data.checkAvailabilityTime}` - 10000);
        getESPHealthStatus('healthESPResponse.json');
        cy.get('[data-cy="cy-general__epanel"]', { timeout: Cypress.config('defaultTimeout') }).should('be.visible');
    });
});
