/// <reference types='Cypress'/>

import data from '../../fixtures/variables.json';
import { getTaxonomy, getAppKeyDetails, getESPHealthStatus, postAPIProxyDeploy } from '../../utils/index';

describe('Endpoint Basic Auth path', function () {
    beforeEach(function () {
        cy.mockLogin();
        getTaxonomy('taxonomies.json', 200).as('taxonomies');
        getAppKeyDetails('applicationkeys.json', 200);
        getESPHealthStatus('', 200);
        cy.visit('/proxy');
        cy.wait('@taxonomies');
    });

    it('Check Endpoint Basic Auth Coverage', () => {
        //general panel error condition
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //Testing internal checkbox from General Panel
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        //general panel
        cy.get('[data-cy="cy-app-key__input"]')
            .click()
            .type(`${data.applicationKey}`, { delay: 0 })
            .click({ force: true });
        cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });
        cy.get('[data-cy="cy-service-type__select"]').select('Outbound').trigger('click');
        cy.get('[data-cy="cy-internal-checkbox__div"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //gatewayEndpoint panel
        cy.get('[data-cy="cy-service-category__select"]').click({ force: true }).type(`${data.taxonomy}`, { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();
        //targetEndpoint panel
        cy.get('[data-cy="cy-resource-path__input"]').find('input').type(`${data.resourcePath}`, { delay: 0 });
        cy.get('[data-cy="cy-dev1-host__input"]').type(`${data.dev1HostName}`, { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();
        //internal panel
        cy.get('[data-cy="cy-appln-key__checkbox"]').click();
        cy.get('[data-cy="cy-internal-continue__button"]').click();
        //endpoint panel
        //if AuthType is Basic Auth
        cy.get('[data-cy="cy-authentication-type__select"]').select('Basic Auth').trigger('click');
        cy.get('[data-cy="cy-basicAuth_uname"]').type('uname');
        cy.get('[data-cy="cy-basicAuth_pwd"]').type('pword');
        //change to endpoint panel and submit
        postAPIProxyDeploy('', 'apbSuccessResponse.json', 200);
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('#modal-1').contains('OK');
    });
});

describe('Endpoint x509 Cert path', function () {
    beforeEach(function () {
        cy.mockLogin();
        getTaxonomy('taxonomies.json', 200).as('taxonomies');
        getAppKeyDetails('applicationkeys.json', 200);
        getESPHealthStatus('', 200);
        cy.visit('/proxy');
        cy.wait('@taxonomies');
    });

    it('Check Endpoint x509 Cert Coverage', () => {
        //general panel error condition
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //Testing internal checkbox from General Panel
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        //general panel
        cy.get('[data-cy="cy-app-key__input"]')
            .click()
            .type(`${data.applicationKey}`, { delay: 0 })
            .click({ force: true });
        cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });
        cy.get('[data-cy="cy-service-type__select"]').select('Outbound').trigger('click');
        cy.get('[data-cy="cy-internal-checkbox__div"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //gatewayEndpoint panel
        cy.get('[data-cy="cy-service-category__select"]').click({ force: true }).type(`${data.taxonomy}`, { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();
        //targetEndpoint panel
        cy.get('[data-cy="cy-resource-path__input"]').find('input').type(`${data.resourcePath}`, { delay: 0 });
        cy.get('[data-cy="cy-dev1-host__input"]').type(`${data.dev1HostName}`, { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();
        //internal panel
        cy.get('[data-cy="cy-appln-key__checkbox"]').click();
        cy.get('[data-cy="cy-internal-continue__button"]').click();
        //endpoint panel
        //if AuthType is x509 Certificate
        cy.get('[data-cy="cy-authentication-type__select"]').select('x509 Certificate').trigger('click');
        cy.get('[data-cy="cy-xcert"]').type('xcert');
        //change to endpoint panel and submit
        postAPIProxyDeploy('', 'apbSuccessResponse.json', 200);
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('#modal-1').contains('OK');
    });
});

describe('Endpoint OAuth Password path', function () {
    beforeEach(function () {
        cy.mockLogin();
        getTaxonomy('taxonomies.json', 200).as('taxonomies');
        getAppKeyDetails('applicationkeys.json', 200);
        getESPHealthStatus('', 200);
        cy.visit('/proxy');
        cy.wait('@taxonomies');
    });

    it('Check Endpoint OAuth Password Coverage', () => {
        //general panel error condition
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //Testing internal checkbox from General Panel
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        //general panel
        cy.get('[data-cy="cy-app-key__input"]')
            .click()
            .type(`${data.applicationKey}`, { delay: 0 })
            .click({ force: true });
        cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });
        cy.get('[data-cy="cy-service-type__select"]').select('Outbound').trigger('click');
        cy.get('[data-cy="cy-internal-checkbox__div"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //gatewayEndpoint panel
        cy.get('[data-cy="cy-service-category__select"]').click({ force: true }).type(`${data.taxonomy}`, { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();
        //targetEndpoint panel
        cy.get('[data-cy="cy-resource-path__input"]').find('input').type(`${data.resourcePath}`, { delay: 0 });
        cy.get('[data-cy="cy-dev1-host__input"]').type(`${data.dev1HostName}`, { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();
        //internal panel
        cy.get('[data-cy="cy-appln-key__checkbox"]').click();
        cy.get('[data-cy="cy-internal-continue__button"]').click();
        //endpoint panel
        //if AuthType is OAuth Password
        cy.get('[data-cy="cy-authentication-type__select"]').select('OAuth').trigger('click');
        cy.get('[data-cy="cy-grant-type__select"]').select('Password').trigger('click');
        cy.get('[data-cy="cy-grant-loc__select"]').select('Query Parameter').trigger('click');
        cy.get('[data-cy="cy-token-host__input"]').type('my.token.host', { delay: 0 });
        cy.get('[data-cy="cy-token-path__input"]').type('/token', { delay: 0 });
        cy.get('[data-cy="cy-oauth_username"]').type('user');
        cy.get('[data-cy="cy-oauth_password"]').type('password', { delay: 0 });
        cy.get('[data-cy="cy-grant-loc__select_4"]').select('Basic Auth');
        //change to endpoint panel and submit
        postAPIProxyDeploy('', 'apbSuccessResponse.json', 200);
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('#modal-1').contains('OK');
    });
});

describe('Endpoint None path', function () {
    beforeEach(function () {
        cy.mockLogin();
        getTaxonomy('taxonomies.json', 200).as('taxonomies');
        getAppKeyDetails('applicationkeys.json', 200);
        getESPHealthStatus('', 200);
        cy.visit('/proxy');
        cy.wait('@taxonomies');
    });

    it('Check Endpoint None Auth Coverage', () => {
        //general panel error condition
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //Testing internal checkbox from General Panel
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        //general panel
        cy.get('[data-cy="cy-app-key__input"]')
            .click()
            .type(`${data.applicationKey}`, { delay: 0 })
            .click({ force: true });
        cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });
        cy.get('[data-cy="cy-service-type__select"]').select('Outbound').trigger('click');
        cy.get('[data-cy="cy-internal-checkbox__div"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //gatewayEndpoint panel
        cy.get('[data-cy="cy-service-category__select"]').click({ force: true }).type(`${data.taxonomy}`, { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();
        //targetEndpoint panel
        cy.get('[data-cy="cy-resource-path__input"]').find('input').type(`${data.resourcePath}`, { delay: 0 });
        cy.get('[data-cy="cy-dev1-host__input"]').type(`${data.dev1HostName}`, { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();
        //internal panel
        cy.get('[data-cy="cy-appln-key__checkbox"]').click();
        cy.get('[data-cy="cy-internal-continue__button"]').click();
        //endpoint panel
        //if AuthType is Basic Auth
        cy.get('[data-cy="cy-authentication-type__select"]').select('None').trigger('click');
        //change to endpoint panel and submit
        postAPIProxyDeploy('', 'apbSuccessResponse.json', 200);
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('#modal-1').contains('OK');
    });
});

describe('Endpoint AuthHeaderPassThrough path', function () {
    beforeEach(function () {
        cy.mockLogin();
        getTaxonomy('taxonomies.json', 200).as('taxonomies');
        getAppKeyDetails('applicationkeys.json', 200);
        getESPHealthStatus('', 200);
        cy.visit('/proxy');
        cy.wait('@taxonomies');
    });

    it('Check Endpoint AuthHeaderPassThrough Coverage', () => {
        //general panel error condition
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //Testing internal checkbox from General Panel
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        //general panel
        cy.get('[data-cy="cy-app-key__input"]')
            .click()
            .type(`${data.applicationKey}`, { delay: 0 })
            .click({ force: true });
        cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });
        cy.get('[data-cy="cy-service-type__select"]').select('Outbound').trigger('click');
        cy.get('[data-cy="cy-internal-checkbox__div"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //gatewayEndpoint panel
        cy.get('[data-cy="cy-service-category__select"]').click({ force: true }).type(`${data.taxonomy}`, { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();
        //targetEndpoint panel
        cy.get('[data-cy="cy-resource-path__input"]').find('input').type(`${data.resourcePath}`, { delay: 0 });
        cy.get('[data-cy="cy-dev1-host__input"]').type(`${data.dev1HostName}`, { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();
        //internal panel
        cy.get('[data-cy="cy-appln-key__checkbox"]').click();
        cy.get('[data-cy="cy-internal-continue__button"]').click();
        //endpoint panel
        //if AuthType is Basic Auth
        cy.get('[data-cy="cy-authentication-type__select"]')
            .select('Authorization Header Pass-through')
            .trigger('click');
        //change to endpoint panel and submit
        postAPIProxyDeploy('', 'apbSuccessResponse.json', 200);
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('#modal-1').contains('OK');
    });
});

describe('Endpoint JWT path', function () {
    beforeEach(function () {
        cy.mockLogin();
        getTaxonomy('taxonomies.json', 200).as('taxonomies');
        getAppKeyDetails('applicationkeys.json', 200);
        getESPHealthStatus('', 200);
        cy.visit('/proxy');
        cy.wait('@taxonomies');
    });

    it('Check Endpoint JWT Auth Coverage', () => {
        //general panel error condition
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //Testing internal checkbox from General Panel
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        //general panel
        cy.get('[data-cy="cy-app-key__input"]').click().type(`${data.applicationKey}`, { delay: 0 });
        cy.get('[data-cy="cy-general__epanel"]').find('i.icon-x').click();
        cy.get('[data-cy="cy-general__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('input.chi-search__input')
            .click({ force: true })
            .type(`${data.applicationKey}`, { delay: 0 })
            .click({ force: true })
            .parents('div.vue-simple-suggest')
            .find('ul > li')
            .click({ force: true });
        cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });
        cy.get('[data-cy="cy-service-type__select"]').select('Outbound').trigger('click');
        cy.get('[data-cy="cy-internal-checkbox__div"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //gatewayEndpoint panel
        cy.get('[data-cy="cy-service-category__select"]')
            .click({ force: true })
            .type(`${data.taxonomy}`, { delay: 0 })
            .click({ force: true })
            .parents('div.vue-simple-suggest')
            .find('ul > li')
            .click({ force: true });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();
        //targetEndpoint panel
        cy.get('[data-cy="cy-resource-path__input"]').find('input').type(`${data.resourcePath}`, { delay: 0 });
        cy.get('[data-cy="cy-dev1-host__input"]').type(`${data.dev1HostName}`, { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();
        //internal panel
        cy.get('[data-cy="cy-appln-key__checkbox"]').click();
        cy.get('[data-cy="cy-internal-continue__button"]').click();
        //endpoint panel
        //if AuthType is Basic Auth
        cy.get('[data-cy="cy-authentication-type__select"]').select('JWT').trigger('click');
        //change to endpoint panel and submit
        postAPIProxyDeploy('', 'apbSuccessResponse.json', 200);
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('#modal-1').contains('OK');
    });
});

describe('Endpoint LIAM path', function () {
    beforeEach(function () {
        cy.mockLogin();
        getTaxonomy('taxonomies.json', 200).as('taxonomies');
        getAppKeyDetails('applicationkeys.json', 200);
        getESPHealthStatus('', 200);
        cy.visit('/proxy');
        cy.wait('@taxonomies');
    });

    it('Check Endpoint LIAM JWT Coverage', () => {
        cy.get('[data-cy="cy-app-key__input"]').click().type(`${data.applicationKey}`, { delay: 0 });
        cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });
        cy.get('[data-cy="cy-external__checkbox"]').click({ force: true });
        cy.get('[data-cy="cy-service-type__select"]').select('Outbound').trigger('click');
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //gatewayEndpoint panel
        cy.get('[data-cy="cy-service-category__select"]')
            .click({ force: true })
            .type(`${data.taxonomy}`, { delay: 0 })
            .click({ force: true })
            .parents('div.vue-simple-suggest')
            .find('ul > li')
            .click({ force: true });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();
        //targetEndpoint panel
        cy.get('[data-cy="cy-dev1-host__input"]').type(`${data.dev1HostName}`, { delay: 0 });
        cy.get('[data-cy="cy-resource-path__input"]').find('input').type(`${data.resourcePath}`, { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();
        //external panel
        cy.get('[data-cy="cy-extoAuth__checkbox"]').find('input').click({ force: true });
        cy.get('[for="liamJwtId"]').click();
        cy.get('[data-cy="cy-ext-continue__button"]').click();
        //change to endpoint panel and submit
        cy.get('[data-cy="cy-authentication-type__select"]').select('LIAMJwt').trigger('click');
        postAPIProxyDeploy('', 'apbSuccessResponse.json', 200);
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('#modal-1').contains('OK');
    });
});
