/// <reference types='Cypress'/>

import { getAllComponentList, getApiProxyDetails } from '../../utils/index.js';

describe('Proxies page working', function () {
    beforeEach(function () {
        cy.mockLogin();
        getAllComponentList('', 200).as('products');
        getApiProxyDetails('', 'proxies.json', 200).as('apiproxydetails');
        cy.visit('/exchange');
        cy.wait('@products', Cypress.config('defaultTimeout'));
        cy.get('[data-cy="cy-proxies_tab"]').click({ force: true });
        cy.wait('@apiproxydetails', Cypress.config('defaultTimeout'));
    });

    it('Search tab works', () => {
        getApiProxyDetails('', 'proxies.json', 200).as('apiproxydetails');
        cy.get('[data-cy="cy-api__search-input"]').as('proxy-section__search-input');
        cy.get('@proxy-section__search-input').should('be.visible');
        cy.get('@proxy-section__search-input').find('[aria-label="Search"]').as('proxy-section__search-button');
        cy.get('@proxy-section__search-button').should('be.visible');
        cy.get('@proxy-section__search-input').type('ntfwfSrvcImpPort', { delay: 0 });
        cy.get('@proxy-section__search-button', { timeout: Cypress.config('defaultTimeout') }).click({
            force: true,
        });
        cy.get('[data-cy="cy-api-chi-data-table"]').should('contain', '34S');
        cy.get('@proxy-section__search-input', { timeout: Cypress.config('defaultTimeout') })
            .find('input')
            .clear({
                force: true,
            });
        cy.get('@proxy-section__search-input').type('Adaptive/Inventory', { delay: 0 });
        cy.get('@proxy-section__search-button', { timeout: Cypress.config('defaultTimeout') }).click({
            force: true,
        });
        cy.get('[data-cy="cy-api-chi-data-table"]').should('contain', 'Adaptive/Inventory');
        cy.get('@proxy-section__search-input', { timeout: Cypress.config('defaultTimeout') })
            .find('input')
            .clear({
                force: true,
            });
    });

    it('The home filters are OK and Env filter is visible', () => {
        getApiProxyDetails('', 'proxies.json', 200).as('apiproxydetails');
        cy.get('[data-cy="cy-api__filter"]')
            .find('[id="environment-filter-desktop"]')
            .as('proxy-section__search-filter');
        cy.get('@proxy-section__search-filter').should('be.visible');
        cy.get('@proxy-section__search-filter').select(1);
        cy.get('[data-cy="cy-api__filter"]')
            .find('.chi-toolbar__filters-desktop')
            .find('.chi-form__item')
            .find('select')
            .select('Dev 1', 'Dev 2', 'Dev 3', 'Dev 4', 'Test 1', 'Test 2', 'Test 3', 'Test 4', 'Prod')
            .should('be.visible');
    });
    it('All the fields are present in summary table', () => {
        cy.get('[data-cy="cy-api-chi-data-table"]').as('summary_table');
        cy.get('@summary_table').contains('Taxonomy');
        cy.get('@summary_table').contains('Resource Name');
        cy.get('@summary_table').contains('Version');
        cy.get('@summary_table').contains('App ID');
        cy.get('@summary_table').contains('Routing Expression');
        cy.get('@summary_table').contains('Actions');
    });
    it('Open in a new tab the cms viewer from a given owningApplicationId', () => {
        cy.get('[data-cy="cy-api-chi-data-table-owningApplicationId"]').eq(0).contains('SYSGEN0008000031').click();
    });
});
