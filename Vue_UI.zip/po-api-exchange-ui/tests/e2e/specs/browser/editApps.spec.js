/// <reference types='Cypress'/>

import data from '../../fixtures/variables.json';
import { featureFlagMenuActive } from '../../utils/utility.js';
import { getAPIProductLists, getAppDetailsOfUsers, postUpdateUserApps } from '../../utils/index';

describe('Edit Apps Page Tests - I', () => {
    beforeEach(() => {
        cy.mockLogin('', featureFlagMenuActive());
        getAppDetailsOfUsers('multiDevApp.json', 200).as('appsStub');
        getAPIProductLists('', 'APIProductsResponse.json', 200).as('prodList');
        cy.visit('/credentials');
        cy.fixture('multiDevApp.json').as('appsList');
        cy.wait('@appsStub', Cypress.config('defaultTimeout'));
        cy.contains('div', 'App 1', { matchCase: true })
            .parents('div.chi-data-table__row')
            .find('[data-cy="cy-actionsDropdown__icn"]')
            .invoke('show')
            .find('[data-cy="cy-edit__appbtn"]')
            .click();
        cy.wait('@prodList', Cypress.config('defaultTimeout'));
    });

    it('Page Elements are displayed as per the wireframe', () => {
        cy.location('href').should('include', '/credentials/edit/app_1');
        cy.get('[data-cy="cy-app__name"]').should('be.visible');
        cy.get('[data-cy="cy-appName__lbl"]').should('be.visible');
        cy.get('[data-cy="cy-appName__tbx"]').should('be.visible');
        cy.get('[data-cy="cy-appEnv__lbl"]').should('be.visible');
        cy.get('[data-cy="cy-appEnv__name"]').should('be.visible');
        cy.get('[data-cy="cy-apiProducts__lbl"]').should('be.visible');
        cy.get('[data-cy="cy-apiProducts__table"]').should('be.visible');
        cy.get('[data-cy="cy-manage__btn"]').should('be.visible');
        cy.get('[data-cy="cy-save__btn"]').should('be.visible');
        cy.get('[data-cy="cy-cancel__btn"]').should('be.visible');
    });

    /*
        Use function () if you want to access this object as Cypress Commands are async.
        You cannot use a this.* reference until the .as() command runs.
    */
    it('API Products List is displayed as per wireframe', function () {
        cy.get('[data-cy="cy-apiProducts__lbl"]').should('be.visible');
        cy.get('[data-cy="cy-apiProducts__table"]').should('be.visible');
        let apiProductsCount = cy.get('[data-cy="cy-productsCount__lbl"]');
        let expectedProdCount = this.appsList.app.find((reqdApp) => reqdApp.displayName === 'App 1').apiProdCount;
        apiProductsCount.should('be.visible').and('have.text', ' ' + expectedProdCount + ' ');
        cy.get('div[aria-label="Sort Column API Name"]').click();
    });

    it('App Name field cannot be left empty', () => {
        let appNameField = cy.get('[data-cy="cy-appName__tbx"]');
        appNameField.should('have.value', 'App 1');
        appNameField.focus().clear();
        let appNameReqdError = cy.get('[data-cy="cy-name__required__error"]');
        appNameReqdError.should('be.visible');
        appNameReqdError.invoke('text').should('eq', ' Please enter a name. ');
    });

    it('App Name field throws error if input App Name already exists', () => {
        let appNameField = cy.get('[data-cy="cy-appName__tbx"]');
        appNameField.focus().clear();
        appNameField.type('Test App 5', { delay: 0 });
        let uniqueAppNameError = cy.get('[data-cy="cy-name__unique__error"]', {
            timeout: Cypress.config('defaultTimeout'),
        });
        uniqueAppNameError.should('be.visible');
        uniqueAppNameError
            .invoke('text')
            .should('eq', ' An App with this name already exists. Please try another name. ');
    });

    it('Error Message shown when all products are deselected in the API Products table', () => {
        cy.get('[data-cy="cy-apiProducts__table"]')
            .find('.-d-screen--only')
            .within(() => {
                cy.get('[data-cy="cy-removeProduct__btn"]').eq(0).click();
                cy.get('[data-cy="cy-removeProduct__btn"]').click();
            });
        cy.get('[data-cy="cy-minProdErr__lbl"]').should('be.visible');
        cy.get('[data-cy="cy-minProdErr__lbl"]').invoke('text').should('eq', ' You must select at least one product. ');
    });

    it('Cancel button click returns user to My Apps dashboard from the Edit App page', () => {
        getAppDetailsOfUsers('', 200).as('appsStub');
        getAPIProductLists([], '', 200).as('prodList');
        cy.get('[data-cy="cy-cancel__btn"]').click();
        cy.wait(['@appsStub', '@prodList'], Cypress.config('defaultTimeout'));
        cy.location('href').should('include', '/credentials');
    });

    it('Clicking on My Apps back-link navigates back to My Apps dashboard', () => {
        cy.get('[data-cy="cy-myapp__back"]').click();
        cy.location('href').should('include', '/credentials');
    });
});

describe('Manage Selected APIs Page Tests - I', () => {
    beforeEach(() => {
        cy.mockLogin('', featureFlagMenuActive());
        getAppDetailsOfUsers('multiDevApp.json', 200).as('appsList');
        getAPIProductLists('', 'APIProductsResponse.json', 200).as('prodList');
        cy.visit('/credentials');
        // Using the "App 1" app for all the tests
        cy.wait('@appsList', Cypress.config('defaultTimeout'));
        cy.contains('div', 'App 1', { matchCase: true })
            .parents('div.chi-data-table__row')
            .find('[data-cy="cy-actionsDropdown__icn"]')
            .invoke('show')
            .find('[data-cy="cy-edit__appbtn"]')
            .click();
        cy.get('[data-cy="cy-manage__btn"]').click();
        cy.wait('@prodList', Cypress.config('defaultTimeout'));
    });

    it('Error message shown when all API Products are deselected', () => {
        cy.get('[data-cy="cy-manageSelAPIProducts__table"]').find('.-active').eq(0).find('div.chi-checkbox').click();
        cy.get('[data-cy="cy-manageSelAPIProducts__table"]').find('.-active').find('div.chi-checkbox').click();
        let minProdsError = cy.get('[data-cy="cy-manageSelectedProdsError__lbl"]');
        minProdsError.should('be.visible');
        minProdsError.invoke('text').should('eq', ' You must select at least one product. ');
    });

    it('Error message focussed when all API Products are deselected and Update button is clicked', () => {
        cy.get('[data-cy="cy-manageSelAPIProducts__table"]').find('.-active').eq(0).find('div.chi-checkbox').click();
        cy.get('[data-cy="cy-manageSelAPIProducts__table"]').find('.-active').find('div.chi-checkbox').click();
        cy.get('[data-cy="cy-manageSelectedUpdate__btn"]').click();
        cy.get('[data-cy="cy-minProdErr__lbl"]').should('be.visible');
    });

    it('API Products to be not updated in Edit page if all products deselected and Update button clicked on Manage page', () => {
        // User deselects all API Products in Manage Selected APIs page
        cy.get('[data-cy="cy-manageSelAPIProducts__table"]').find('.-active').eq(0).find('div.chi-checkbox').click();
        cy.get('[data-cy="cy-manageSelAPIProducts__table"]').find('.-active').find('div.chi-checkbox').click();
        // User clicks Update button and then clicks on the Back button
        cy.get('[data-cy="cy-manageSelectedUpdate__btn"]').click();
        cy.get('[data-cy="cy-minProdErr__lbl"]').should('be.visible');
        cy.get('[data-cy="cy-manageSelectedBack__btn"]').click();

        // API Products should not have updated and should remain in original state
        cy.get('div.chi-data-table__body [data-label="API Name"]').should('have.length', 2);
    });

    it('Back button returns user to Edit screen without saving changes', () => {
        cy.contains('div', 'TestAPIProductBeta', { matchCase: true })
            .parents('div.chi-data-table__row')
            .find('div.chi-checkbox')
            .click();
        cy.get('[data-cy="cy-manageSelectedBack__btn"]').click();
        // Verifying that clicking on back button did not update the new API Product selected (TestAPIProductBeta)
        cy.get('[data-cy="cy-apiProducts__table"]')
            .find('.chi-data-table__body')
            .find('[data-label="API Name"]')
            .should('have.length', 2);
        // Add code to check if selection not retained when again navigated to Manage page
        cy.get('[data-cy="cy-manage__btn"]').click();
        cy.contains('div', 'TestAPIProductBeta', { matchCase: true })
            .parents('div.chi-data-table__row')
            .find('input[type="checkbox"]')
            .should('not.be.checked');
    });

    it('Update button returns user to Edit screen to review changes', () => {
        cy.contains('div', 'TestAPIProductBeta', { matchCase: true })
            .parents('div.chi-data-table__row')
            .find('div.chi-checkbox')
            .click();
        cy.get('[data-cy="cy-manageSelectedUpdate__btn"]').click();
        // Verifying that clicking on update button updated the new API Product selected (TestAPIProductBeta)
        cy.get('[data-cy="cy-apiProducts__table"]')
            .find('.chi-data-table__body')
            .find('[data-label="API Name"]')
            .should('have.length', 3);
        // Add code to check if selection retained when again navigated to Manage page
        cy.get('[data-cy="cy-manage__btn"]').click();
        cy.contains('div', 'TestAPIProductBeta', { matchCase: true })
            .parents('div.chi-data-table__row')
            .find('input[type="checkbox"]')
            .should('be.checked');
    });
});

describe('Manage Selected APIs Page Tests - II', () => {
    beforeEach(() => {
        cy.mockLogin('', featureFlagMenuActive());
        getAppDetailsOfUsers('multiDevApp.json', 200).as('appsList');
        getAPIProductLists('', 'APIProductsResponse.json', 200).as('prodList');
        cy.visit('/credentials');
        // Using the "App 1" app for all the tests
        cy.wait('@appsList', Cypress.config('defaultTimeout'));
        cy.contains('div', 'App 1', { matchCase: true })
            .parents('div.chi-data-table__row')
            .find('[data-cy="cy-actionsDropdown__icn"]')
            .invoke('show')
            .find('[data-cy="cy-edit__appbtn"]')
            .click();
        cy.get('[data-cy="cy-manage__btn"]').click();
        cy.wait('@prodList', Cypress.config('defaultTimeout'));
    });

    it('Page elements are displayed as per wireframe', () => {
        cy.get('[data-cy="cy-app__name"]').should('be.visible');
        cy.get('[data-cy="cy-manageSelected__label"]').should('be.visible');
        cy.get('[data-cy="cy-search__tbx"]').should('be.visible');
        cy.get('[data-cy="cy-appEnv__lbl"]').should('be.visible');
        cy.get('[data-cy="cy-appEnv__name"]').should('be.visible');
        cy.get('[data-cy="cy-manageSelProdCount__lbl"]').should('be.visible');
        cy.get('[data-cy="cy-showSelectedOnly__cbx"]').should('be.visible');
        cy.get('[data-cy="cy-showSelectedOnly__lbl"]').should('be.visible');
        cy.get('[data-cy="cy-manageSelAPIProducts__table"]').should('be.visible');
        cy.get('[data-cy="cy-manageSelectedBack__btn"]').scrollIntoView().should('be.visible');
        cy.get('[data-cy="cy-manageSelectedUpdate__btn"]').should('be.visible');
    });

    it('API Products not belonging to the specified environment is grayed out, not selectable and has information message in description', () => {
        // TestAPIProductDelta is not available in the dev environment. Hence checking if that Product has the above mentioned attributes
        cy.contains('div', 'TestAPIProductDelta', { matchCase: true })
            .parents('div.chi-data-table__row')
            .find('[data-label="API Name"]')
            .find('div')
            .should('have.class', 'disable_text');
        cy.contains('div', 'TestAPIProductDelta', { matchCase: true })
            .parents('div.chi-data-table__row')
            .find('input[type="checkbox"]')
            .should('be.disabled');
        cy.contains('div', 'TestAPIProductDelta', { matchCase: true })
            .parents('div.chi-data-table__row')
            .find('[data-label="Description"]')
            .find('div')
            .should('have.class', 'disable_text')
            .and('have.text', ' Product currently unavailable in selected environment. ');
    });

    it('Show Selected Only functionality', () => {
        cy.get('[data-cy="cy-showSelectedOnly__cbx"]').parents('div.chi-form__item').click('left');
        // Check that only two selected API Products are shown for App 1 app
        cy.get('[data-cy="cy-manageSelAPIProducts__table"]')
            .find('.chi-data-table__body')
            .find('[data-label="API Name"]')
            .should('have.length', 2);
    });

    it('Search availability for both API Product Name and API Product Description', () => {
        cy.get('[data-cy="cy-search__tbx"]').focus().clear().type('TestAPIProductBeta', { delay: 0 });
        cy.get('[data-cy="cy-manageSelAPIProducts__table"]', { timeout: Cypress.config('defaultTimeout') })
            .find('.chi-data-table__body')
            .find('[aria-label="API Name"]')
            .should('have.length', 1)
            .and('have.text', ' TestAPIProductBeta ');

        cy.get('[data-cy="cy-search__tbx"]').focus().clear().type(`${data.searchText1}`, { delay: 0 });
        cy.get('[data-cy="cy-manageSelAPIProducts__table"]', { timeout: Cypress.config('defaultTimeout') })
            .find('.chi-data-table__body')
            .find('[aria-label="Description"]')
            .should('have.length', 1)
            .and('include.text', `${data.searchText1}`);
    });

    it('Search results are case insensitive', () => {
        cy.get('[data-cy="cy-search__tbx"]').focus().clear().type('testApIprOducTBETA', { delay: 0 });
        cy.get('[data-cy="cy-manageSelAPIProducts__table"]', { timeout: Cypress.config('defaultTimeout') })
            .find('.chi-data-table__body')
            .find('[aria-label="API Name"]')
            .should('have.length', 1)
            .and('have.text', ' TestAPIProductBeta ');
    });

    it('Search results includes API Product Names and Descriptions even if unavailable in specified App Environment', () => {
        cy.get('[data-cy="cy-search__tbx"]').focus().clear().type('TestAPIProductDelta', { delay: 0 });
        cy.get('[data-cy="cy-manageSelAPIProducts__table"]', { timeout: Cypress.config('defaultTimeout') })
            .find('.chi-data-table__body')
            .find('[aria-label="API Name"]')
            .should('have.length', 1)
            .and('have.text', ' TestAPIProductDelta ');
        cy.get('[data-cy="cy-search__tbx"]').focus().clear().type('Do NOT create content cards', { delay: 0 });
        cy.get('[data-cy="cy-manageSelAPIProducts__table"]', { timeout: Cypress.config('defaultTimeout') })
            .find('.chi-data-table__body')
            .find('[aria-label="Description"]')
            .should('have.length', 1)
            .and('include.text', 'Product currently unavailable in selected environment.');
    });

    it('Search results are displayed as characters are entered', () => {
        cy.get('[data-cy="cy-search__tbx"]').focus().clear().type('T');
        // needed timeout to validate the functionality
        cy.wait(500);
        // Verify that search results are narrowing down on each keypress. 34 Products in total
        cy.get('[data-cy="cy-manageSelAPIProducts__table"]', { timeout: Cypress.config('defaultTimeout') })
            .find('.chi-data-table__body')
            .find('[aria-label="API Name"]')
            .should('have.length.lt', 34);

        // Verify that search results are narrowing down on each keypress (less than previous products count)
        cy.get('[data-cy="cy-search__tbx"]').focus().type('a');
        cy.get('[data-cy="cy-manageSelAPIProducts__table"]')
            .find('.chi-data-table__body')
            .find('[aria-label="API Name"]')
            .should('have.length.lt', 34);
        // Verify that search results are narrowing down on each keypress (less than previous products count)
        cy.get('[data-cy="cy-search__tbx"]').focus().type('p');
        cy.get('[data-cy="cy-manageSelAPIProducts__table"]')
            .find('.chi-data-table__body')
            .find('[aria-label="API Name"]')
            .should('have.length', 3);
    });

    it('Message displayed if searched item is not found', () => {
        cy.get('[data-cy="cy-search__tbx"]').focus().clear().type('PqwJdk', { delay: 0 });
        cy.get('[data-cy="cy-manageSelAPIProducts__table"]', { timeout: Cypress.config('defaultTimeout') })
            .find('.chi-data-table__row-empty')
            .should('include.text', 'No API Product(s)');
    });
});

describe('Edit App page tests - II', () => {
    beforeEach(() => {
        cy.mockLogin('', featureFlagMenuActive());
        getAppDetailsOfUsers('multiDevApp.json', 200).as('appsList');
        getAPIProductLists('', 'APIProductsResponse.json', 200).as('prodList');
        cy.visit('/credentials');
        // Using the "App 1" app for all the tests
        cy.wait('@appsList', Cypress.config('defaultTimeout'));
        cy.contains('div', 'App 1', { matchCase: true })
            .parents('div.chi-data-table__row')
            .find('[data-cy="cy-actionsDropdown__icn"]')
            .invoke('show')
            .find('[data-cy="cy-edit__appbtn"]')
            .click();
    });

    it('Save Changes button click returns user to My Apps dashboard with success message on successful request', () => {
        // Save Changes button click saves changes made on Edit App page and returns user to My Apps dashboard with new changes
        getAppDetailsOfUsers('multiDevApp.json', 200).as('appsList');
        getAPIProductLists('', 'APIProductsResponse.json', 200).as('prodList');
        cy.get('[data-cy="cy-appName__tbx"]').focus().clear().type('Updated Test App', { delay: 0 });
        postUpdateUserApps('', 'singleDevApp.json', 200);
        cy.get('[data-cy="cy-save__btn"]').click();
        cy.get('[data-cy="cy-alert__lbl"]')
            .should('be.visible')
            .and('have.class', '-success')
            .and('include.text', 'Updated Test App changes have been saved.')
            .find('i')
            .should('have.class', 'icon-circle-check');
    });

    it('Save Changes button click returns user to My Apps dashboard with failure message on unsuccessful request', () => {
        getAppDetailsOfUsers('', 200);
        getAPIProductLists([], '', 200).as('prodList');
        cy.get('[data-cy="cy-appName__tbx"]').focus().clear().type('Updated Test App', { delay: 0 });
        postUpdateUserApps({ error: 'Internal Server Error' }, '', 500);
        cy.get('[data-cy="cy-save__btn"]').click();
        cy.get('[data-cy="cy-alert__lbl"]')
            .should('be.visible')
            .and('have.class', '-danger')
            .and('include.text', 'Internal server error')
            .find('i')
            .should('have.class', 'icon-circle-warning');
    });
});
