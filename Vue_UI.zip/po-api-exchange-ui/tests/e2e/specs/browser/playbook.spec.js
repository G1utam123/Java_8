/// <reference types='Cypress'/>

const viewPort = require('../../fixtures/viewPort.json');

describe('Playbook page working', function () {
    beforeEach(function () {
        cy.mockLogin();
    });

    viewPort.screenSizes.forEach((size) => {
        it(`PlayBook page should rendered as per the Wireframe in the ${size} screen`, () => {
            if (Cypress._.isArray(size)) {
                cy.viewport(size[0], size[1]);
            } else {
                cy.viewport(size);
            }
            cy.visit('/playbook');
            cy.get('[data-cy="cy-playbook_name"]')
                .should('be.visible')
                .contains(/^Playbook$/);

            cy.get('[data-cy="cy-playbook_name"]').should('have.css', 'padding-top', '32px');
            if (size[0] > 991) {
                cy.get('[data-cy="cy-playbook_name"]')
                    .children('div.chi-main__content')
                    .should('have.css', 'margin-right', '64px')
                    .and('have.css', 'margin-left', '64px');
            } else if (size[0] > 767 && size[0] <= 991) {
                cy.get('[data-cy="cy-playbook_name"]')
                    .children('div.chi-main__content')
                    .should('have.css', 'margin-right', '32px')
                    .and('have.css', 'margin-left', '32px');
            } else {
                cy.get('[data-cy="cy-playbook_name"]')
                    .children('div.chi-main__content')
                    .should('have.css', 'margin-right', '16px')
                    .and('have.css', 'margin-left', '16px');
            }
            cy.get('[data-cy="cy-playbook_logo"]').should('have.css', 'margin-top', '64px');
            if (size[0] > 1280) {
                cy.get('[data-cy="cy-playbook_name"]')
                    .find('div.heroimage')
                    .invoke('width')
                    .should('be.gt', 1599)
                    .should('be.lte', 1600);
                cy.get('[data-cy="cy-playbook_name"]')
                    .find('div.heroimage')
                    .invoke('height')
                    .should('be.gt', 183)
                    .should('be.lte', 184);
            }

            cy.get('[data-cy="cy-playbook_text"]')
                .invoke('width')
                .then((contentWidth) => {
                    cy.get('[data-cy="cy-playbook_name"]')
                        .find('div.heroimage')
                        .invoke('width')
                        .should('not.be.greaterThan', contentWidth);
                });

            cy.get('[data-cy="cy-playbook_name"]')
                .find('div.heroimage')
                .should('have.css', 'background-image')
                .and('contain', 'playbook-kra');

            cy.get('[data-cy="cy-playbook_logo"]').should('be.visible');
            cy.get('[data-cy="cy-playbook_text"]').should('be.visible');

            cy.get('[data-cy="cy-playbook_text"]')
                .find('div.-text--bold')
                .should('be.visible')
                .contains('We are busy building.');
            cy.get('[data-cy="cy-playbook_text"]')
                .find('div.-text--bold')
                .should('be.visible')
                .contains('In the meantime, please visit our Community of Practice. ');

            cy.get('[data-cy="cy-playbook_button"]').scrollIntoView().should('be.visible');
            cy.scrollTo('bottom', { ensureScrollable: false });

            cy.get('[data-cy="cy-en-footer"]')
                .parent()
                .scrollIntoView()
                .should('be.visible')
                .and('have.css', 'margin-top', '56px');
        });
    });
});
