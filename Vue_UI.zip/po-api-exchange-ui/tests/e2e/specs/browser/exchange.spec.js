/// <reference types='Cypress'/>

import { featureFlagMenuActive, destroyStub } from '../../utils/utility.js';
import { getAllComponentList, getApiProxyDetails } from '../../utils/index.js';

const viewPort = require('../../fixtures/viewPort.json');

describe('Exchange page working', function () {
    beforeEach(() => {
        cy.mockLogin('', featureFlagMenuActive());
        getAllComponentList('', 200);
    });

    viewPort.screenSizes.forEach((size) => {
        it(`Exchange Page should rendered in the ${size} screen as per the Wireframe`, () => {
            if (Cypress._.isArray(size)) {
                cy.viewport(size[0], size[1]);
            } else {
                cy.viewport(size);
            }
            getApiProxyDetails([], '', 200);
            cy.visit('/exchange');
            cy.get('[data-cy="cy-proxies_tab"]')
                .should('be.visible')
                .contains(/^Proxies$/);
            cy.get('[data-cy="cy-display_header"]').should('be.visible').contains('Proxies');
            cy.get('[data-cy="cy-display_header_note"]').should('not.exist');
            cy.get('[data-cy="cy-proxy_btn"]').should('not.exist');
            cy.get('[data-cy="cy-create-new-proxy__button"]')
                .find('.chi-button')
                .should('be.visible')
                .contains('CREATE NEW PROXY')
                .should('have.css', 'background-color', 'rgb(0, 117, 201)');

            cy.get('[data-cy="cy-shell-content"]')
                .find('div.heroimage')
                .should('have.css', 'background-image')
                .and('contain', 'exchange-kra');

            cy.get('[data-cy="cy-shell-content"]').find('div.-pt--4').should('have.css', 'padding-top', '32px');
            cy.get('[data-cy="cy-shell-content"]')
                .children()
                .find('div.-mt--4')
                .should('have.css', 'margin-top', '32px');

            if (size[0] > 991) {
                cy.get('[data-cy="cy-shell-content"]')
                    .find('div.chi-main__content')
                    .should('have.css', 'margin-left', '64px')
                    .and('have.css', 'margin-right', '64px');
            } else if (size[0] > 767 && size[0] <= 991) {
                cy.get('[data-cy="cy-shell-content"]')
                    .find('div.chi-main__content')
                    .should('have.css', 'margin-left', '32px')
                    .and('have.css', 'margin-right', '32px');
            } else {
                cy.get('[data-cy="cy-shell-content"]')
                    .find('div.chi-main__content')
                    .should('have.css', 'margin-left', '16px')
                    .and('have.css', 'margin-right', '16px');
            }

            cy.get('[data-cy="cy-api-chi-data-table"]')
                .should('be.visible')
                .contains('No matches found. Please revise search criteria and try again.');

            if (size[0] > 1280) {
                cy.get('[data-cy="cy-shell-content"]')
                    .find('div.heroimage')
                    .invoke('width')
                    .should('be.gt', 1599)
                    .should('be.lte', 1600);
                cy.get('[data-cy="cy-shell-content"]')
                    .find('div.heroimage')
                    .invoke('height')
                    .should('be.gt', 183)
                    .should('be.lte', 184);
            }

            cy.get('[data-cy="cy-shell-content"]')
                .children()
                .find('div.-pt--1')
                .invoke('outerWidth')
                .then((data_table) =>
                    cy
                        .get('[data-cy="cy-shell-content"]')
                        .find('div.heroimage')
                        .invoke('width')
                        .should('not.be.greaterThan', data_table)
                );

            cy.get('[data-cy="cy-exchange_main"]').should('be.visible').contains('Exchange');
            cy.get('[data-cy="cy-shell-content"]')
                .children()
                .find('p')
                .contains(' Explore our inventory of internal and external Lumen APIs ')
                .should('be.visible');
            cy.get('[data-cy="cy-products_tab"]')
                .should('be.visible')
                .contains(/^Products$/)
                .click({ force: true });
            cy.get('[data-cy="cy-display_header"]').should('be.visible').contains('Products');

            cy.get('[data-cy="cy-product-chi-data-table"]')
                .should('be.visible')
                .contains('No matches found. Please revise search criteria and try again.');
            cy.get('[data-cy="cy-enterprise-nav-footer"]')
                .parents('footer#footer')
                .scrollIntoView()
                .should('be.visible')
                .and('have.css', 'margin-top', '56px');
        });
    });

    it('Exchange Page > Proxy Page > Should render as per the wireframe', () => {
        getApiProxyDetails('', 'proxies2.json', 200);
        cy.visit('/exchange');
        cy.get('[data-cy="cy-proxy_btn"]').should('not.exist');
    });

    it('Check the Proxies and Product Tab Orders', () => {
        cy.visit('/exchange');
        cy.get('[data-cy="cy-shell-content"]').find('[aria-label="chi-tabs-horizontal"]').as('Tabs');
        cy.get('@Tabs').children().should('have.length.gte', 2);
        cy.get('@Tabs').find('li').first().as('First-Tab');
        cy.get('@First-Tab').contains('Proxies');
        cy.get('@First-Tab').next().contains('Products');
    });

    it('Check Proxies tab > note capabilities', () => {
        getApiProxyDetails('', 'proxies.json', 200);
        cy.visit('/exchange');
        cy.get('[data-cy="cy-proxies_tab"]', { timeout: Cypress.config('defaultTimeout') }).click({ force: true });
        cy.get('[data-cy="cy-display_header_note"]').should('not.exist');
    });

    it('Check Proxies tab > note no capabilities and navigate', () => {
        getApiProxyDetails('', 'proxies.json', 200);
        cy.visit('/exchange');
        cy.get('[data-cy="cy-create-new-proxy__button"]').click();
        cy.location('href').should('include', '/proxy');
    });

    it('Create New Product Button should navigate to the Product page', () => {
        cy.visit('/exchange');
        cy.get('[data-cy="cy-products_tab"]').click();
        cy.get('[data-cy="cy-create-new-product__button"]').click();
        cy.location('href').should('include', '/editAPIDocumentation');
    });

    it('beforeDestroy', () => {
        destroyStub();
    });
});
