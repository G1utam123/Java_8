/// <reference types='Cypress'/>

import data from '../../fixtures/variables.json';
import {
    getAllComponentList,
    getApiProxyDetails,
    getEnvironmentDetailsOfProxies,
    postMigrateApiProxies,
} from '../../utils/index.js';

describe('Proxy Migration working', function () {
    beforeEach(function () {
        cy.mockLogin();
        getAllComponentList('products.json', 200).as('products');
        getApiProxyDetails('', 'proxies.json', 200).as('apiproxydetails');
        cy.visit('/exchange');
        cy.wait('@products', Cypress.config('defaultTimeout'));
        cy.get('[data-cy="cy-proxies_tab"]', { timeout: Cypress.config('defaultTimeout') }).click({ force: true });
        cy.wait('@apiproxydetails', Cypress.config('defaultTimeout'));
    });

    it('navigation from proxyDetails to apiMigration > data 0', () => {
        getEnvironmentDetailsOfProxies('', 'APIEnvironmentsResponseData0.json', 200).as('api-environments');
        it('Checks the loader is working as expected', () => {
            cy.get('[data-cy="cy-common__loader"]').should('be.visible');
        });
        cy.get('[data-cy="cy-api-chi-data-table"]').find('a:contains("Migrate")').first().click({ force: true });
        cy.wait('@api-environments', Cypress.config('defaultTimeout'));
        cy.get('[data-cy="cy-back_link"]').should('be.visible');
        cy.get('[data-cy="cy-proxy-migrate"]').should('be.visible');
        cy.get('[data-cy="cy-network-audit"]').should('be.visible');
        cy.get('[data-cy="cy-network-audit"]').contains('testProxy');
        cy.get('[data-cy="cy-environment"]').should('be.visible');
        cy.get('[data-cy="cy-text-dev"]').should('be.visible');
        cy.get('[data-cy="cy-text-test"]').should('be.visible');
        cy.get('[data-cy="cy-text-prod"]').should('be.visible');
        cy.get('[data-cy="cy-box-environment"]').should('be.visible');
        cy.get('[data-cy="cy-card__content__Dev1"]').click().should('be.visible');
        cy.get('[data-cy="cy-card__content__Dev2"]').click().should('be.visible');
        cy.get('[data-cy="cy-card__content__Dev3"]').click().should('be.visible');
        cy.get('[data-cy="cy-card__content__Dev4"]').click().should('be.visible');
        cy.get('[data-cy="cy-card__content__Test1"]').click().should('be.visible');
        cy.get('[data-cy="cy-card__content__Test2"]').click().should('be.visible');
        cy.get('[data-cy="cy-card__content__Test3"]').click().should('be.visible');
        cy.get('[data-cy="cy-card__content__Test4"]').click().should('be.visible');
        cy.get('[data-cy="cy-card__content__Prod"]').click().should('be.visible');
        cy.get('[data-cy="cy-card__content__Sandbox"]').click().should('be.visible');
        cy.get('[data-cy="cy-card__content__Mock"]').click().should('be.visible');
        cy.get('[data-cy="cy-endpoint-promo"]').should('be.visible');
        cy.get('[data-cy="cy-select-source"]').should('be.visible');
        cy.get('[data-cy="cy-select-dropdown"]').as('select-env_dropDown');
        cy.get('@select-env_dropDown').should('be.visible');
        cy.get('@select-env_dropDown').should('have.value', 'dev1');
        cy.get('@select-env_dropDown').select('test2');
        cy.get('@select-env_dropDown').should('have.value', 'test2');
        cy.get('[data-cy="cy-source-endpoint"]').contains('https://test2.endpoint');
        cy.get('[data-cy="cy-endpoint"]').should('be.visible');
        cy.get('[data-cy="cy-sel-endpoint-label"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpoint1"]').should('be.disabled');
        cy.get('[data-cy="cy-text-endpoint3"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpoint3"]').should('be.enabled');
        cy.get('[data-cy="cy-text-endpoint2"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpoint2"]').should('be.enabled');
        cy.get('[data-cy="cy-text-endpoint4"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpoint4"]').should('be.enabled');
        cy.get('[data-cy="cy-text-endpointt1"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpointt1"]').should('be.disabled');
        cy.get('[data-cy="cy-text-endpointt3"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpointt3"]').should('be.disabled');
        cy.get('[data-cy="cy-text-endpointt2"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpointt2"]').should('be.disabled');
        cy.get('[data-cy="cy-text-endpointt4"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpointt4"]').should('be.disabled');
        cy.get('[data-cy="cy-text-endpointm"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpointm"]').should('be.enabled');
        cy.get('[data-cy="cy-text-endpoints"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpoints"]').should('be.enabled');
        cy.get('[data-cy="cy-text-endpointp"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpointp"]').should('be.disabled');
        cy.get('[data-cy="cy-button-cancel"]').should('be.visible');
        cy.get('[data-cy="cy-button-submit"]').find('.chi-button').should('be.visible');
        cy.get('[data-cy="cy-button-submit"]').find('.chi-button').should('be.enabled');
        cy.get('[data-cy="cy-error-text-endpoint1"]').should('not.exist');
        cy.get('[data-cy="cy-check-text-endpoint1"]').should('not.exist');
        cy.get('[data-cy="cy-error-text-endpointt1"]').should('not.exist');
        cy.get('[data-cy="cy-check-text-endpointt1"]').should('not.exist');
        cy.get('[data-cy="cy-error-text-endpointt2"]').should('not.exist');
        cy.get('[data-cy="cy-check-text-endpointt2"]').should('not.exist');
        cy.get('[data-cy="cy-error-text-endpointt3"]').should('not.exist');
        cy.get('[data-cy="cy-check-text-endpointt3"]').should('not.exist');
        cy.get('[data-cy="cy-error-text-endpointt4"]').should('not.exist');
        cy.get('[data-cy="cy-check-text-endpointt4"]').should('not.exist');
        cy.get('[data-cy="cy-check-text-endpoint3"]').should('not.exist');
        cy.get('[data-cy="cy-error-text-endpoint3"]').should('not.exist');
        cy.get('[data-cy="cy-text-endpoint3"]').type('htt');
        cy.get('[data-cy="cy-error-text-endpoint3"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpoint3"]').type('p://endpoint3', { delay: 0 });
        cy.get('[data-cy="cy-error-text-endpoint3"]').should('not.exist');
        cy.get('[data-cy="cy-check-text-endpoint3"]').should('be.visible');
        cy.get('[data-cy="cy-check-text-endpoint4"]').should('not.exist');
        cy.get('[data-cy="cy-error-text-endpoint4"]').should('not.exist');
        cy.get('[data-cy="cy-text-endpoint4"]').type('http');
        cy.get('[data-cy="cy-error-text-endpoint4"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpoint4"]').type('s://endpoint4', { delay: 0 });
        cy.get('[data-cy="cy-error-text-endpoint4"]').should('not.exist');
        cy.get('[data-cy="cy-check-text-endpoint4"]').should('be.visible');
        cy.get('[data-cy="cy-check-text-endpoint2"]').should('not.exist');
        cy.get('[data-cy="cy-error-text-endpoint2"]').should('not.exist');
        cy.get('[data-cy="cy-text-endpoint2"]').type('h');
        cy.get('[data-cy="cy-error-text-endpoint2"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpoint2"]').type('ttp://endpoint2', { delay: 0 });
        cy.get('[data-cy="cy-error-text-endpoint2"]').should('not.exist');
        cy.get('[data-cy="cy-check-text-endpoint2"]').should('be.visible');
        cy.get('[data-cy="cy-check-text-mock"]').should('not.exist');
        cy.get('[data-cy="cy-error-text-mock"]').should('not.exist');
        cy.get('[data-cy="cy-text-endpointm"]').type('h');
        cy.get('[data-cy="cy-error-text-mock"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpointm"]').type('ttp://mock', { delay: 0 });
        cy.get('[data-cy="cy-error-text-mock"]').should('not.exist');
        cy.get('[data-cy="cy-check-text-mock"]').should('be.visible');
        cy.get('[data-cy="cy-check-text-sandbox"]').should('not.exist');
        cy.get('[data-cy="cy-error-text-sandbox"]').should('not.exist');
        cy.get('[data-cy="cy-text-endpoints"]').type('h');
        cy.get('[data-cy="cy-error-text-sandbox"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpoints"]').type('ttps://sandbox', { delay: 0 });
        cy.get('[data-cy="cy-error-text-sandbox"]').should('not.exist');
        cy.get('[data-cy="cy-check-text-sandbox"]').should('be.visible');
        cy.get('[data-cy="cy-button-submit"]').find('.chi-button').should('be.enabled');
    });

    it('navigation from proxyDetails to apiMigration > data 1', () => {
        getEnvironmentDetailsOfProxies('', 'APIEnvironmentsResponseData1.json', 200).as('api-environments');
        it('Checks the loader is working as expected', () => {
            cy.get('[data-cy="cy-common__loader"]').should('be.visible');
        });
        cy.get('[data-cy="cy-api-chi-data-table"]').find('a:contains("Migrate")').first().click({ force: true });
        cy.wait('@api-environments', Cypress.config('defaultTimeout'));
        cy.get('[data-cy="cy-button-submit"]').find('.chi-button').should('be.enabled');
        cy.get('[data-cy="cy-check-text-endpointt1"]').should('not.exist');
        cy.get('[data-cy="cy-error-text-endpointt1"]').should('not.exist');
        cy.get('[data-cy="cy-text-endpointt1"]').type('htt');
        cy.get('[data-cy="cy-error-text-endpointt1"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpointt1"]').type('p://endpointt1', { delay: 0 });
        cy.get('[data-cy="cy-error-text-endpointt1"]').should('not.exist');
        cy.get('[data-cy="cy-check-text-endpointt1"]').should('be.visible');
        cy.get('[data-cy="cy-check-text-endpointt2"]').should('not.exist');
        cy.get('[data-cy="cy-error-text-endpointt2"]').should('not.exist');
        cy.get('[data-cy="cy-text-endpointt2"]').type('htt');
        cy.get('[data-cy="cy-error-text-endpointt2"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpointt2"]').type('p://endpointt2', { delay: 0 });
        cy.get('[data-cy="cy-error-text-endpointt2"]').should('not.exist');
        cy.get('[data-cy="cy-check-text-endpointt2"]').should('be.visible');
        cy.get('[data-cy="cy-check-text-endpointt3"]').should('not.exist');
        cy.get('[data-cy="cy-error-text-endpointt3"]').should('not.exist');
        cy.get('[data-cy="cy-text-endpointt3"]').type('htt');
        cy.get('[data-cy="cy-error-text-endpointt3"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpointt3"]').type('p://endpointt3', { delay: 0 });
        cy.get('[data-cy="cy-error-text-endpointt3"]').should('not.exist');
        cy.get('[data-cy="cy-check-text-endpointt3"]').should('be.visible');
        cy.get('[data-cy="cy-check-text-endpointt4"]').should('not.exist');
        cy.get('[data-cy="cy-error-text-endpointt4"]').should('not.exist');
        cy.get('[data-cy="cy-text-endpointt4"]').type('htt');
        cy.get('[data-cy="cy-error-text-endpointt4"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpointt4"]').type('p://endpointt4', { delay: 0 });
        cy.get('[data-cy="cy-error-text-endpointt4"]').should('not.exist');
        cy.get('[data-cy="cy-check-text-endpointt4"]').should('be.visible');
        cy.get('[data-cy="cy-button-submit"]').find('.chi-button').should('be.enabled');
    });

    it('navigation from proxyDetails to apiMigration > data 2', () => {
        getEnvironmentDetailsOfProxies('', 'APIEnvironmentsResponseData2.json', 200).as('api-environments');
        it('Checks the loader is working as expected', () => {
            cy.get('[data-cy="cy-common__loader"]').should('be.visible');
        });
        cy.get('[data-cy="cy-api-chi-data-table"]').find('a:contains("Migrate")').first().click({ force: true });
        cy.wait('@api-environments', Cypress.config('defaultTimeout'));
        cy.get('[data-cy="cy-button-submit"]').find('.chi-button').should('be.enabled');
        cy.get('[data-cy="cy-check-text-mock"]').should('not.exist');
        cy.get('[data-cy="cy-error-text-mock"]').should('not.exist');
        cy.get('[data-cy="cy-text-endpointm"]').type('htt');
        cy.get('[data-cy="cy-error-text-mock"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpointm"]').type('p://endpointmock', { delay: 0 });
        cy.get('[data-cy="cy-error-text-mock"]').should('not.exist');
        cy.get('[data-cy="cy-check-text-mock"]').should('be.visible');
        cy.get('[data-cy="cy-button-submit"]').find('.chi-button').should('be.enabled');
    });

    it('navigation from proxyDetails to apiMigration > data 3', () => {
        getEnvironmentDetailsOfProxies('', 'APIEnvironmentsResponseData3.json', 200).as('api-environments');
        it('Checks the loader is working as expected', () => {
            cy.get('[data-cy="cy-common__loader"]').should('be.visible');
        });
        cy.get('#environment-filter-desktop', { timeout: Cypress.config('defaultTimeout') }).select('dev2');
        cy.get('[data-cy="cy-api-chi-data-table"]')
            .find('a:contains("Migrate")', { timeout: Cypress.config('defaultTimeout') })
            .first()
            .click({ force: true });
        cy.wait('@api-environments', Cypress.config('defaultTimeout'));
        cy.get('[data-cy="cy-button-submit"]').find('.chi-button').should('be.enabled');
        cy.get('[data-cy="cy-check-text-endpoint1"]').should('not.exist');
        cy.get('[data-cy="cy-error-text-endpoint1"]').should('not.exist');
        cy.get('[data-cy="cy-text-endpoint1"]').type('htt');
        cy.get('[data-cy="cy-error-text-endpoint1"]').should('be.visible');
        cy.get('[data-cy="cy-text-endpoint1"]').type('p://endpoint1', { delay: 0 });
        cy.get('[data-cy="cy-error-text-endpoint1"]').should('not.exist');
        cy.get('[data-cy="cy-check-text-endpoint1"]').should('be.visible');
        cy.get('[data-cy="cy-button-submit"]').find('.chi-button').should('be.enabled');
    });

    it('navigation from proxyDetails to apiMigration > cancel', () => {
        getEnvironmentDetailsOfProxies('', 'APIEnvironmentsResponseData0.json', 200).as('api-environments');
        it('Checks the loader is working as expected', () => {
            cy.get('[data-cy="cy-common__loader"]').should('be.visible');
        });
        cy.get('[data-cy="cy-api-chi-data-table"]').find('a:contains("Migrate")').first().click();
        cy.wait('@api-environments', Cypress.config('defaultTimeout'));
        cy.get('[data-cy="cy-button-cancel"]').find('.chi-button').click();
        cy.wait('@apiproxydetails').its('response.statusCode').should('eq', 200);
    });

    it('navigation from proxyDetails to apiMigration > submit ok 1 (data 1)', () => {
        getEnvironmentDetailsOfProxies('', 'APIEnvironmentsResponseData1.json', 200).as('api-environments');

        it('Checks the loader is working as expected', () => {
            cy.get('[data-cy="cy-common__loader"]').should('be.visible');
        });
        cy.get('[data-cy="cy-api-chi-data-table"]').find('a:contains("Migrate")').first().click();
        cy.wait('@api-environments', Cypress.config('defaultTimeout'));
        postMigrateApiProxies('', 200).as('migrate');
        cy.get('[data-cy="cy-text-endpoint1"]').type('http://endpoint1', { delay: 0 });
        cy.get('[data-cy="cy-text-endpoint2"]').type('http://endpoint2', { delay: 0 });
        cy.get('[data-cy="cy-text-endpoint3"]').type('http://endpoint3', { delay: 0 });
        cy.get('[data-cy="cy-text-endpoint4"]').type('http://endpoint4', { delay: 0 });
        cy.get('[data-cy="cy-text-endpointt1"]').type('http://endpointt1', { delay: 0 });
        cy.get('[data-cy="cy-text-endpointt2"]').type('http://endpointt2', { delay: 0 });
        cy.get('[data-cy="cy-text-endpointt3"]').type('http://endpointt3', { delay: 0 });
        cy.get('[data-cy="cy-text-endpointt4"]').type('http://endpointt4', { delay: 0 });
        cy.get('[data-cy="cy-button-submit"]').find('.chi-button').click();
        cy.get('[data-cy="cy-proxy-save-alert"]')
            .scrollIntoView()
            .should('be.visible')
            .should('have.text', 'Every proxy has been migrated to the selected environments');
    });

    it('navigation from proxyDetails to apiMigration > submit ok 2 (data 1) > alert', () => {
        getEnvironmentDetailsOfProxies('', 'APIEnvironmentsResponseData1.json', 200).as('api-environments');
        it('Checks the loader is working as expected', () => {
            cy.get('[data-cy="cy-common__loader"]').should('be.visible');
        });
        cy.get('[data-cy="cy-api-chi-data-table"]').find('a:contains("Migrate")').first().click();
        cy.wait('@api-environments', Cypress.config('defaultTimeout'));
        postMigrateApiProxies('', 200).as('migrate');
        cy.get('[data-cy="cy-text-endpoint1"]').type('http://endpoint1', { delay: 0 });
        cy.get('[data-cy="cy-text-endpoint2"]').type('http://endpoint2', { delay: 0 });
        cy.get('[data-cy="cy-text-endpoint3"]').type('http://endpoint3', { delay: 0 });
        cy.get('[data-cy="cy-text-endpoint4"]').type('http://endpoint4', { delay: 0 });
        cy.get('[data-cy="cy-text-endpointt1"]').type('http://endpointt1', { delay: 0 });
        cy.get('[data-cy="cy-text-endpointt2"]').type('http://endpointt2', { delay: 0 });
        cy.get('[data-cy="cy-text-endpointt3"]').type('http://endpointt3', { delay: 0 });
        cy.get('[data-cy="cy-text-endpointt4"]').type('http://endpointt4', { delay: 0 });
        cy.get('[data-cy="cy-button-submit"]').find('.chi-button').click();
        cy.get('[data-cy="cy-proxy-save-alert"]')
            .scrollIntoView()
            .should('be.visible')
            .should('have.text', 'Every proxy has been migrated to the selected environments');
        cy.get('[data-cy="cy-proxy-save-alert"]', { timeout: Cypress.config('defaultTimeout') }).should('not.exist');
    });

    it('navigation from proxyDetails to apiMigration > submit ok 3 (data 2)', () => {
        getEnvironmentDetailsOfProxies('', 'APIEnvironmentsResponseData2.json', 200).as('api-environments');
        it('Checks the loader is working as expected', () => {
            cy.get('[data-cy="cy-common__loader"]').should('be.visible');
        });
        cy.get('[data-cy="cy-api-chi-data-table"]').find('a:contains("Migrate")').first().click({ force: true });
        postMigrateApiProxies('', 200).as('migrate');
        cy.get('[data-cy="cy-text-endpointm"]').type('http://endpointm', { delay: 0 });
        cy.get('[data-cy="cy-text-endpoints"]').type('http://endpoints', { delay: 0 });
        cy.get('[data-cy="cy-button-submit"]').find('.chi-button').click();
        cy.get('[data-cy="cy-proxy-save-alert"]')
            .scrollIntoView()
            .should('be.visible')
            .should('have.text', 'Every proxy has been migrated to the selected environments');
    });

    it('navigation from proxyDetails to apiMigration > submit ok 4 (data 2) > alert with messageAlert', () => {
        const messageAlert = {
            routingExpression: 'endpoint',
            migratedEnv: ['mock', 'sandbox'],
            notMigratedEnv: [],
        };
        getEnvironmentDetailsOfProxies('', 'APIEnvironmentsResponseData2.json', 200).as('api-environments');
        it('Checks the loader is working as expected', () => {
            cy.get('[data-cy="cy-common__loader"]').should('be.visible');
        });
        cy.get('[data-cy="cy-api-chi-data-table"]').find('a:contains("Migrate")').first().click({ force: true });
        cy.wait('@api-environments', Cypress.config('defaultTimeout'));
        postMigrateApiProxies(messageAlert, 200).as('migrate');
        cy.get('[data-cy="cy-text-endpointm"]').type('http://endpointm', { delay: 0 });
        cy.get('[data-cy="cy-text-endpoints"]').type('http://endpoints', { delay: 0 });
        cy.get('[data-cy="cy-button-submit"]').find('.chi-button').click();
        cy.get('[data-cy="cy-proxy-save-alert"]')
            .scrollIntoView()
            .should('be.visible')
            .should('have.text', 'endpoint has been successfully migrated to mock, sandbox');
    });

    it('navigation from proxyDetails to apiMigration > submit error > alert without messageAlert > not closable (all fail)', () => {
        getEnvironmentDetailsOfProxies('', 'APIEnvironmentsResponseData0.json', 200).as('api-environments');
        it('Checks the loader is working as expected', () => {
            cy.get('[data-cy="cy-common__loader"]').should('be.visible');
        });
        cy.get('[data-cy="cy-api-chi-data-table"]').find('a:contains("Migrate")').first().click({ force: true });
        cy.wait('@api-environments', Cypress.config('defaultTimeout'));
        postMigrateApiProxies('', 404).as('migrate');
        cy.get('[data-cy="cy-text-endpoints"]').type('http://endpoints', { delay: 0 });
        cy.get('[data-cy="cy-text-endpointm"]').type('http://endpointmock', { delay: 0 });
        cy.get('[data-cy="cy-button-submit"]').find('.chi-button').click();
        cy.get('[data-cy="cy-proxy-save-alert"]')
            .scrollIntoView()
            .should('be.visible')
            .should('have.text', 'Proxy Migration error' + `${data.failureAPIProxyMigrationContact}`);
        cy.wait('@migrate');
        // this timeout is needed as we want to verify that the popup is not automatically closed
        cy.wait(7001);
        cy.get('[data-cy="cy-proxy-save-alert"]').should('be.visible');
        cy.get('.sc-chi-button > .chi-icon > svg.sc-chi-icon > .sc-chi-icon').click({ force: true });
        cy.get('[data-cy="cy-proxy-save-alert"]').should('not.exist');
    });

    it('navigation from proxyDetails to apiMigration > submit error > alert with messageAlert > not closable (success and fail)', () => {
        const messageAlert = {
            routingExpression: 'endpoint',
            migratedEnv: ['dev4', 'mock'],
            notMigratedEnv: ['sandbox'],
        };
        getEnvironmentDetailsOfProxies('', 'APIEnvironmentsResponseData0.json', 200).as('api-environments');
        it('Checks the loader is working as expected', () => {
            cy.get('[data-cy="cy-common__loader"]').should('be.visible');
        });
        cy.get('[data-cy="cy-api-chi-data-table"]').find('a:contains("Migrate")').first().click();
        cy.wait('@api-environments', Cypress.config('defaultTimeout'));
        postMigrateApiProxies(messageAlert, 404).as('migrate');
        cy.get('[data-cy="cy-text-endpoint4"]').type('http://endpointdev4', { delay: 0 });
        cy.get('[data-cy="cy-text-endpoints"]').type('http://endpoints', { delay: 0 });
        cy.get('[data-cy="cy-text-endpointm"]').type('http://endpointmock', { delay: 0 });
        cy.get('[data-cy="cy-button-submit"]').find('.chi-button').click();
        cy.get('[data-cy="cy-proxy-save-alert"]')
            .scrollIntoView()
            .should('be.visible')
            .should(
                'have.text',
                'endpoint has been successfully migrated to dev4, mock, but was not migrated to sandbox' +
                    `${data.failureAPIProxyMigrationContact}`
            );
    });

    it('navigation from proxyDetails to apiMigration > submit error > alert with messageAlert > not closable (all fails)', () => {
        const messageAlert = {
            routingExpression: 'endpoint',
            migratedEnv: [],
            notMigratedEnv: ['dev4', 'sandbox'],
        };
        getEnvironmentDetailsOfProxies('', 'APIEnvironmentsResponseData0.json', 200).as('api-environments');
        it('Checks the loader is working as expected', () => {
            cy.get('[data-cy="cy-common__loader"]').should('be.visible');
        });
        cy.get('[data-cy="cy-api-chi-data-table"]').find('a:contains("Migrate")').first().click();
        cy.wait('@api-environments', Cypress.config('defaultTimeout'));
        postMigrateApiProxies(messageAlert, 404).as('migrate');
        cy.get('[data-cy="cy-text-endpoint4"]').type('http://endpointdev4', { delay: 0 });
        cy.get('[data-cy="cy-text-endpoints"]').type('http://endpoints', { delay: 0 });
        cy.get('[data-cy="cy-text-endpointm"]').type('http://endpointmock', { delay: 0 });
        cy.get('[data-cy="cy-button-submit"]').find('.chi-button').click();
        cy.get('[data-cy="cy-proxy-save-alert"]')
            .scrollIntoView()
            .should('be.visible')
            .should(
                'have.text',
                'endpoint was not migrated to dev4, sandbox' + `${data.failureAPIProxyMigrationContact}`
            );
    });

    it('navigation from proxyDetails to apiMigration > submit no endpoints > alert', () => {
        getEnvironmentDetailsOfProxies('', 'APIEnvironmentsResponseData1.json', 200).as('api-environments');
        it('Checks the loader is working as expected', () => {
            cy.get('[data-cy="cy-common__loader"]').should('be.visible');
        });
        cy.get('[data-cy="cy-api-chi-data-table"]').find('a:contains("Migrate")').first().click();
        cy.wait('@api-environments', Cypress.config('defaultTimeout'));
        cy.get('[data-cy="cy-text-endpoint1"]').clear();
        cy.get('[data-cy="cy-text-endpoint2"]').clear();
        cy.get('[data-cy="cy-text-endpoint3"]').clear();
        cy.get('[data-cy="cy-text-endpoint4"]').clear();
        cy.get('[data-cy="cy-text-endpointt1"]').clear();
        cy.get('[data-cy="cy-text-endpointt2"]').clear();
        cy.get('[data-cy="cy-text-endpointt3"]').clear();
        cy.get('[data-cy="cy-text-endpointt4"]').clear();
        cy.get('[data-cy="cy-button-submit"]').find('.chi-button').click();
        cy.get('[data-cy="cy-proxy-save-alert"]')
            .should('be.visible')
            .should('have.text', 'You have not entered any new endpoint data');
    });

    it('navigation from proxyDetails to apiMigration > submit incorrect syntax > alert', () => {
        getEnvironmentDetailsOfProxies('', 'APIEnvironmentsResponseData1.json', 200).as('api-environments');
        it('Checks the loader is working as expected', () => {
            cy.get('[data-cy="cy-common__loader"]').should('be.visible');
        });
        cy.get('[data-cy="cy-api-chi-data-table"]').find('a:contains("Migrate")').first().click({ force: true });
        cy.wait('@api-environments', Cypress.config('defaultTimeout'));
        cy.get('[data-cy="cy-text-endpoint1"]').type('httpendpointmock', { delay: 0 });
        cy.get('[data-cy="cy-text-endpoint2"]').clear();
        cy.get('[data-cy="cy-text-endpoint3"]').clear();
        cy.get('[data-cy="cy-text-endpoint4"]').clear();
        cy.get('[data-cy="cy-text-endpointt1"]').clear();
        cy.get('[data-cy="cy-text-endpointt2"]').clear();
        cy.get('[data-cy="cy-text-endpointt3"]').clear();
        cy.get('[data-cy="cy-text-endpointt4"]').clear();
        cy.get('[data-cy="cy-button-submit"]').find('.chi-button').click();
        cy.get('[data-cy="cy-proxy-save-alert"]')
            .should('be.visible')
            .should('have.text', 'Please correct syntax for endpoint data');
    });

    it('navigation from proxyDetails to apiMigration > submit error > alert with messageAlert > not closable (unexpected)', () => {
        const messageAlert = 'Unexpected error';
        getEnvironmentDetailsOfProxies('', 'APIEnvironmentsResponseData0.json', 200).as('api-environments');
        it('Checks the loader is working as expected', () => {
            cy.get('[data-cy="cy-common__loader"]').should('be.visible');
        });
        cy.get('[data-cy="cy-api-chi-data-table"]').find('a:contains("Migrate")').first().click();
        cy.wait('@api-environments', Cypress.config('defaultTimeout'));
        postMigrateApiProxies(messageAlert, 500).as('migrate');
        cy.get('[data-cy="cy-text-endpoint4"]').type('http://endpointdev4', { delay: 0 });
        cy.get('[data-cy="cy-text-endpoints"]').type('http://endpoints', { delay: 0 });
        cy.get('[data-cy="cy-text-endpointm"]').type('http://endpointmock', { delay: 0 });
        cy.get('[data-cy="cy-button-submit"]').find('.chi-button').click();
        cy.get('[data-cy="cy-proxy-save-alert"]')
            .scrollIntoView()
            .should('be.visible')
            .should('have.text', 'Proxy Migration error' + `${data.failureAPIProxyMigrationContact}`);
    });
});
