/// <reference types='Cypress'/>
import { destroyStub } from '../../utils/utility';

const viewPort = require('../../fixtures/viewPort.json');
const footerLinks = require('../../fixtures/footer.json');
let countElement = 0;

describe('Exchange page functionality working', function () {
    beforeEach(function () {
        cy.mockLogin();
    });

    viewPort.screenSizes.forEach((size) => {
        it(`Footer should be visible as per the wireframe in the ${size} screen`, () => {
            if (Cypress._.isArray(size)) {
                cy.viewport(size[0], size[1]);
            } else {
                cy.viewport(size);
            }
            cy.visit('/home');
            cy.get('#language-dropdown-button').scrollIntoView().should('be.visible');
            cy.get('[data-cy="cy-po-footer__links"]').find('ul').find('li').as('footerLink');
            cy.get('@footerLink').should('have.length', 15);
            cy.get('@footerLink').then((elementLength) => {
                countElement = elementLength.length;
                for (let i = 1; i <= countElement; i++) {
                    cy.get('.chi-footer__links > ul > :nth-child(' + i + ') > a').then((ele) => {
                        expect(ele.text()).deep.equal(footerLinks.links[i - 1]);
                    });
                }
            });
            cy.get('[data-cy="cy-po-footer-copyright"]')
                .should('be.visible')
                .and(
                    'have.text',
                    `© 2023 Lumen Technologies. All Rights Reserved. Lumen is a registered trademark in the United States, EU and certain other countries.`
                );
            cy.get('.chi-footer__internal').should('have.css', 'background-color', 'rgb(63, 65, 69)');
        });
    });

    it(`User should able to select the language from the Drop-Down`, () => {
        cy.visit('/home');
        cy.get('[data-cy="cy-drodown-language"]')
            .children()
            .each(function ($ele) {
                if ($ele.text() == 'Español') {
                    cy.wrap($ele).click({ force: true });
                }
            });
    });

    it('beforeDestroy', () => {
        destroyStub();
    });
});
