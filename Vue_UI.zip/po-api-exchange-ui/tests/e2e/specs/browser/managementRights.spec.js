/// <reference types='Cypress'/>

import apbSuccessResponse from '../../fixtures/apbSuccessResponse.json';
import data from '../../fixtures/variables.json';
import { featureFlagApiOwnership } from '../../utils/utility';
import {
    getTaxonomy,
    getAppKeyDetails,
    getESPHealthStatus,
    postAPIProxyDeploy,
    getOwnershipDetails,
    postServiceNowGroupRequest,
} from '../../utils/index';

describe('Management Rights path', function () {
    beforeEach(function () {
        cy.mockLogin('', featureFlagApiOwnership());
        getTaxonomy('taxonomies.json', 200).as('taxonomies');
        getAppKeyDetails('applicationkeys.json', 200);
        getESPHealthStatus('', 200);
        cy.visit('/proxy');
        cy.wait('@taxonomies');
    });

    it('Management rights are not visible due to the response of the ownership command', () => {
        getOwnershipDetails(data.malCode, 'proxyOwnership.json', 200).as('ownerships');
        cy.get('[data-cy="cy-general__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('input.chi-search__input')
            .click()
            .type(data.applicationKey, { delay: 0 });
        cy.wait('@ownerships');
        cy.get('[data-cy="cy-managementRights__epanel"]').should('not.exist');
    });

    it('Proxy creation success & Group request success', () => {
        //general panel error condition
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //Testing internal checkbox from General Panel
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        //general panel
        getOwnershipDetails(data.malCode, '', 404).as('ownerships');
        cy.get('[data-cy="cy-general__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('input.chi-search__input')
            .click()
            .type(data.applicationKey, { delay: 0 });
        cy.wait('@ownerships');

        cy.get('[data-cy="cy-service-type__select"]').select('Outbound').trigger('click');
        cy.get('[data-cy="cy-internal-checkbox__div"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //gatewayEndpoint panel
        cy.get('[data-cy="cy-service-category__select"]')
            .click({ force: true })
            .type('Finance/AccountsReceivable', { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(data.resourceName, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();
        //targetEndpoint panel
        cy.get('[data-cy="cy-resource-path__input"]').find('input').type(data.resourcePath, { delay: 0 });
        cy.get('[data-cy="cy-dev1-host__input"]').type('http://mocktarget.apigee.net', { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();
        //internal panel
        cy.get('[data-cy="cy-appln-key__checkbox"]').click();
        cy.get('[data-cy="cy-internal-continue__button"]').click();
        //endpoint panel
        cy.get('[data-cy="cy-authentication-type__select"]').select('None').trigger('click');
        cy.get('[data-cy="cy-endpoint-authentication-continue__button"]').click();
        cy.get('[data-cy="cy-endPoint__epanel"]').contains('Change').click();
        cy.get('[data-cy="cy-endpoint-authentication-continue__button"]').click();
        //change to management rights panel and submit
        postAPIProxyDeploy('', 'apbSuccessResponse.json', 200).as('proxyBuild');
        postServiceNowGroupRequest(data.requestNumber, 200).as('groupRequest');
        cy.get('[data-cy="cy-mrights_finish__button"]').click();
        cy.wait(['@proxyBuild', '@groupRequest']);

        cy.get('[data-cy="cy-title-api-proxy-builder"]').find('h2.chi-modal__title').contains(data.successAlertHeader);
        cy.get('[data-cy="cy-managementRights__epanel"]')
            .next('div.chi-backdrop')
            .find('i.-icon--success')
            .should('be.visible');
        cy.get('[data-cy="cy-managementRights__epanel"]')
            .next('div.chi-backdrop')
            .find('div.-w--100')
            .find('p')
            .as('alertMessages');
        cy.get('@alertMessages').first().contains(data.successAlertMessage);
        cy.get('@alertMessages')
            .eq(1)
            .contains(
                `${apbSuccessResponse.proxy} is now deployed in ${apbSuccessResponse.proxyBuiltInEnvironments[0]}.`
            );
        cy.get('[data-cy="alert-apb-group-request"]').as('alertMessagesGroupRequest');
        cy.get('@alertMessagesGroupRequest').contains(data.successAlertGroupRequestTitle);
        cy.get('@alertMessagesGroupRequest').contains(data.successAlertGroupRequestMessage1);
        cy.get('@alertMessagesGroupRequest').contains(data.successAlertGroupRequestMessage2);
        cy.get('#modal-1').contains('OK');
    });

    it('Proxy creation success & Group request no valid', () => {
        //general panel error condition
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //Testing internal checkbox from General Panel
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        //general panel
        getOwnershipDetails(data.malCode, '', 404).as('ownerships');
        cy.get('[data-cy="cy-general__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('input.chi-search__input')
            .click()
            .type(data.applicationKey, { delay: 0 });
        cy.wait('@ownerships');

        cy.get('[data-cy="cy-service-type__select"]').select('Outbound').trigger('click');
        cy.get('[data-cy="cy-internal-checkbox__div"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //gatewayEndpoint panel
        cy.get('[data-cy="cy-service-category__select"]')
            .click({ force: true })
            .type('Finance/AccountsReceivable', { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(data.resourceName, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();
        //targetEndpoint panel
        cy.get('[data-cy="cy-resource-path__input"]').find('input').type('/resourcepath', { delay: 0 });
        cy.get('[data-cy="cy-dev1-host__input"]').type('http://mocktarget.apigee.net', { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();
        //internal panel
        cy.get('[data-cy="cy-appln-key__checkbox"]').click();
        cy.get('[data-cy="cy-internal-continue__button"]').click();
        //endpoint panel
        cy.get('[data-cy="cy-authentication-type__select"]').select('None').trigger('click');
        cy.get('[data-cy="cy-endpoint-authentication-continue__button"]').click();
        cy.get('[data-cy="cy-endPoint__epanel"]').contains('Change').click();
        cy.get('[data-cy="cy-endpoint-authentication-continue__button"]').click();
        //change to management rights panel and submit
        postAPIProxyDeploy('', 'apbSuccessResponse.json', 200).as('proxyBuild');
        postServiceNowGroupRequest('', 200).as('groupRequest');
        cy.get('[data-cy="cy-mrights_finish__button"]').click();
        cy.wait(['@proxyBuild', '@groupRequest']);

        cy.get('[data-cy="cy-title-api-proxy-builder"]').find('h2.chi-modal__title').contains(data.successAlertHeader);
        cy.get('[data-cy="cy-managementRights__epanel"]')
            .next('div.chi-backdrop')
            .find('i.-icon--success')
            .should('be.visible');
        cy.get('[data-cy="cy-managementRights__epanel"]')
            .next('div.chi-backdrop')
            .find('i.-icon--warning')
            .should('be.visible');
        cy.get('[data-cy="cy-managementRights__epanel"]')
            .next('div.chi-backdrop')
            .find('div.-w--100')
            .find('p')
            .as('alertMessages');
        cy.get('@alertMessages').first().contains(data.successAlertMessage);
        cy.get('@alertMessages')
            .eq(1)
            .contains(
                `${apbSuccessResponse.proxy} is now deployed in ${apbSuccessResponse.proxyBuiltInEnvironments[0]}.`
            );
        cy.get('[data-cy="groupRequestAlert"]').contains(data.errorGroupRequest);
        cy.get('#modal-1').contains('OK');
    });

    it('Proxy creation success & Group request error', () => {
        //general panel error condition
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //Testing internal checkbox from General Panel
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        //general panel
        getOwnershipDetails(data.malCode, '', 404).as('ownerships');
        cy.get('[data-cy="cy-general__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('input.chi-search__input')
            .click()
            .type(data.applicationKey, { delay: 0 });
        cy.wait('@ownerships');

        cy.get('[data-cy="cy-service-type__select"]').select('Outbound').trigger('click');
        cy.get('[data-cy="cy-internal-checkbox__div"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //gatewayEndpoint panel
        cy.get('[data-cy="cy-service-category__select"]')
            .click({ force: true })
            .type('Finance/AccountsReceivable', { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(data.resourceName, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();
        //targetEndpoint panel
        cy.get('[data-cy="cy-resource-path__input"]').find('input').type('/resourcepath', { delay: 0 });
        cy.get('[data-cy="cy-dev1-host__input"]').type('http://mocktarget.apigee.net', { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();
        //internal panel
        cy.get('[data-cy="cy-appln-key__checkbox"]').click();
        cy.get('[data-cy="cy-internal-continue__button"]').click();
        //endpoint panel
        cy.get('[data-cy="cy-authentication-type__select"]').select('None').trigger('click');
        cy.get('[data-cy="cy-endpoint-authentication-continue__button"]').click();
        cy.get('[data-cy="cy-endPoint__epanel"]').contains('Change').click();
        cy.get('[data-cy="cy-endpoint-authentication-continue__button"]').click();
        //change to management rights panel and submit
        postAPIProxyDeploy('', 'apbSuccessResponse.json', 200).as('proxyBuild');
        postServiceNowGroupRequest('', 500).as('groupRequest');
        cy.get('[data-cy="cy-mrights_finish__button"]').click();
        cy.wait(['@proxyBuild', '@groupRequest']);

        cy.get('[data-cy="cy-title-api-proxy-builder"]').find('h2.chi-modal__title').contains(data.successAlertHeader);
        cy.get('[data-cy="cy-managementRights__epanel"]')
            .next('div.chi-backdrop')
            .find('i.-icon--success')
            .should('be.visible');
        cy.get('[data-cy="cy-managementRights__epanel"]')
            .next('div.chi-backdrop')
            .find('i.-icon--warning')
            .should('be.visible');
        cy.get('[data-cy="cy-managementRights__epanel"]')
            .next('div.chi-backdrop')
            .find('div.-w--100')
            .find('p')
            .as('alertMessages');
        cy.get('@alertMessages').first().contains(data.successAlertMessage);
        cy.get('@alertMessages')
            .eq(1)
            .contains(
                `${apbSuccessResponse.proxy} is now deployed in ${apbSuccessResponse.proxyBuiltInEnvironments[0]}.`
            );
        cy.get('[data-cy="groupRequestAlert"]').contains(data.errorGroupRequest);
        cy.get('#modal-1').contains('OK');
    });

    it('UI interactions', () => {
        //general panel error condition
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //Testing internal checkbox from General Panel
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        //general panel
        getOwnershipDetails(data.malCode, '', 404).as('ownerships');
        cy.get('[data-cy="cy-general__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('input.chi-search__input')
            .click()
            .type(data.applicationKey, { delay: 0 });
        cy.wait('@ownerships');

        cy.get('[data-cy="cy-service-type__select"]').select('Outbound').trigger('click');
        cy.get('[data-cy="cy-internal-checkbox__div"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();
        //gatewayEndpoint panel
        cy.get('[data-cy="cy-service-category__select"]')
            .click({ force: true })
            .type('Finance/AccountsReceivable', { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(data.resourceName, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();
        //targetEndpoint panel
        cy.get('[data-cy="cy-resource-path__input"]').find('input').type(data.resourcePath, { delay: 0 });
        cy.get('[data-cy="cy-dev1-host__input"]').type('http://mocktarget.apigee.net', { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();
        //internal panel
        cy.get('[data-cy="cy-appln-key__checkbox"]').click();
        cy.get('[data-cy="cy-internal-continue__button"]').click();
        //endpoint panel
        cy.get('[data-cy="cy-authentication-type__select"]').select('None').trigger('click');
        cy.get('[data-cy="cy-endpoint-authentication-continue__button"]').click();
        //change to management rights panel and submit
        cy.get('[data-cy="cy-input-owner-0"]').clear();
        cy.get('[data-cy="cy-alert"]').find('.chi-alert').contains('At least one owner is required to proceed.');
        cy.get('[data-cy="cy-mrights_finish__button"]').click();

        cy.get('[data-cy="cy-button-add-owner"]').find('.chi-button').click();
        cy.get('[data-cy="cy-input-owner-1"]').type(data.owner, { delay: 0 });
        cy.get('[data-cy="cy-button-remove-owner"]').find('.chi-button').click();
        cy.get('[data-cy="cancel_remove_owner_button"]').click();
        cy.get('[data-cy="cy-button-remove-owner"]').find('.chi-button').click();
        cy.get('[data-cy="confirm_remove_owner_button"]').click();
        cy.get('[data-cy="cy-input-owner-1"]').should('not.exist');

        cy.get('[data-cy="cy-button-add-owner"]').find('.chi-button').click();
        cy.get('[data-cy="cy-button-add-owner"]').find('.chi-button').click();
        cy.get('[data-cy="cy-button-add-owner"]').find('.chi-button').should('be.disabled');

        cy.get('[data-cy="cy-endPoint__epanel"]').children().find('button').contains('Change').click();
        cy.get('[data-cy="cy-endpoint-authentication-continue__button"]').click();

        cy.get('[data-cy="cy-button-add-admin"]').find('.chi-button').click();
        cy.get('[data-cy="cy-input-admin-0"]').type(data.admin, { delay: 0 });
        cy.get('[data-cy="cy-button-remove-admin"]').find('.chi-button').click();

        cy.get('[data-cy="cy_admins__help-button"]').click();
        cy.get('[data-cy="cy_admins__help-popover"]').contains('As an Admin, an user can:');

        cy.get('[data-cy="cy_owners__help-button"]').click();
        cy.get('[data-cy="cy_owners__help-popover"]').contains('As an Owner, an user can:');

        cy.get('[data-cy="cy-input-owner-1"]').type('notDefaultowner', { delay: 0 });
        postAPIProxyDeploy('', 'apbSuccessResponse.json', 200);
        postServiceNowGroupRequest(data.requestNumber, 200).as('groupRequest');
        cy.get('[data-cy="cy-mrights_finish__button"]').click();
        cy.get('#modal-1').contains('OK');
    });
});
