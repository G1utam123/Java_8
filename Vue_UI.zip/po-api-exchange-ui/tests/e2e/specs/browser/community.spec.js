/// <reference types='Cypress'/>

const viewPort = require('../../fixtures/viewPort.json');

describe('Community page working', function () {
    beforeEach(function () {
        cy.mockLogin();
    });

    viewPort.screenSizes.forEach((size) => {
        it(`Community Page should render as per the wireframe in the ${size} screen`, () => {
            if (Cypress._.isArray(size)) {
                cy.viewport(size[0], size[1]);
            } else {
                cy.viewport(size);
            }
            cy.visit('/community');
            cy.get('[data-cy="cy-Welcome-text"]')
                .should('be.visible')
                .contains(/^Community$/);

            cy.get('[data-cy="cy-community_name"]').should('have.css', 'padding-top', '32px');
            if (size[0] > 991) {
                cy.get('[data-cy="cy-community_name"]')
                    .children('div.chi-main__content')
                    .should('have.css', 'margin-right', '64px')
                    .and('have.css', 'margin-left', '64px');
            } else if (size[0] > 767 && size[0] <= 991) {
                cy.get('[data-cy="cy-community_name"]')
                    .children('div.chi-main__content')
                    .should('have.css', 'margin-right', '32px')
                    .and('have.css', 'margin-left', '32px');
            } else {
                cy.get('[data-cy="cy-community_name"]')
                    .children('div.chi-main__content')
                    .should('have.css', 'margin-right', '16px')
                    .and('have.css', 'margin-left', '16px');
            }
            cy.get('[data-cy="cy-community_logo"]').should('have.css', 'margin-top', '64px');
            if (size[0] > 1280) {
                cy.get('[data-cy="cy-community_name"]')
                    .find('div.heroimage')
                    .invoke('width')
                    .should('be.gt', 1599)
                    .should('be.lte', 1600);
                cy.get('[data-cy="cy-community_name"]')
                    .find('div.heroimage')
                    .invoke('height')
                    .should('be.gt', 183)
                    .should('be.lte', 184);
            }
            cy.get('[data-cy="cy-community_text"]')
                .invoke('width')
                .then((contentWidth) => {
                    cy.get('[data-cy="cy-community_name"]')
                        .find('div.heroimage')
                        .invoke('width')
                        .should('not.be.greaterThan', contentWidth);
                });
            cy.get('[data-cy="cy-community_name"]')
                .find('div.heroimage')
                .should('have.css', 'background-image')
                .and('contain', 'community-kra');
            cy.get('[data-cy="cy-community_logo"]').should('be.visible');
            cy.get('[data-cy="cy-community_name"]')
                .find('.-text--boldest')
                .should('be.visible')
                .contains('COMING SOON');
            cy.get('[data-cy="cy-community_text"]')
                .find(':nth-child(2)')
                .should('be.visible')
                .and('have.text', 'We are busy building.');
            cy.get('[data-cy="cy-community_text"]').find('.-mt--2').as('communityChannel');
            if (size[1] < 672) {
                cy.get('@communityChannel')
                    .scrollIntoView()
                    .should('be.visible')
                    .contains('In the meantime, please visit our Community of Practice site in MS Teams');
            } else {
                cy.get('@communityChannel')
                    .should('be.visible')
                    .contains('In the meantime, please visit our Community of Practice site in MS Teams');
            }
            cy.get('[data-cy="cy-en-footer"]')
                .parent()
                .scrollIntoView()
                .should('be.visible')
                .and('have.css', 'margin-top', '56px');
        });
    });
});
