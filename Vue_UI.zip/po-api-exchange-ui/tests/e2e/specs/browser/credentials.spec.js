/// <reference types='Cypress'/>

import { featureFlagMenuActive } from '../../utils/utility.js';
import {
    getAPIProductLists,
    getAllComponentList,
    getApiProxyDetails,
    getAppDetailsOfUsers,
} from '../../utils/index.js';

const viewPort = require('../../fixtures/viewPort.json');

describe('Credential Tab working', function () {
    beforeEach(function () {
        cy.mockLogin('', featureFlagMenuActive());
        getAllComponentList('', 200);
        getApiProxyDetails([], '', 200);
        getAppDetailsOfUsers('', 200);
        getAPIProductLists([], '', 200).as('prodList');
    });

    viewPort.screenSizes.forEach((size) => {
        it(`check the credential page in ${size} screen`, () => {
            if (Cypress._.isArray(size)) {
                cy.viewport(size[0], size[1]);
            } else {
                cy.viewport(size);
            }
            cy.visit('/credentials');
            cy.get('.chi-main__title-heading').should('be.visible').and('have.text', ' Credentials ');
            cy.get('[data-cy="cy-create-new-app__btn"]').should('be.visible').and('have.text', ' Create New ');
            cy.get('[data-cy="cy-manage__label"]').should('be.visible').and('have.text', 'Manage');
            cy.get('[data-cy="cy-shell-content"]')
                .find('.chi-footer')
                .should('be.visible')
                .and('have.css', 'margin-top', '56px');
        });
    });
});
