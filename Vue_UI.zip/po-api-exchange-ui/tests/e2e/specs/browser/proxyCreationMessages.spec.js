/// <reference types='Cypress'/>

import data from '../../fixtures/variables.json';
import { getTaxonomy, getAppKeyDetails, getESPHealthStatus, postAPIProxyDeploy } from '../../utils/index';

describe('external and internal path', function () {
    beforeEach(function () {
        cy.mockLogin();
        getTaxonomy('taxonomies.json', 200).as('taxonomies');
        getAppKeyDetails('applicationkeys.json', 200);
        getESPHealthStatus('', 200);
        cy.visit('/proxy');
        cy.wait('@taxonomies');
    });

    it('proxy has been successfully deployed in one environment', () => {
        cy.fixture('singleProxyCreationResponse').then((resp_payload) => {
            cy.get('[data-cy="cy-app-key__input"]').click().type(`${data.applicationKey}`, { delay: 0 });
            cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });
            cy.get('[data-cy="cy-service-type__select"]').select('Inbound').trigger('click');
            cy.get('[data-cy="cy-SOAP-checkbox"]').find('label[for="checkbox-ba1"]').click();
            cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
            cy.get('[data-cy="cy-external__checkbox"]').click({ force: true });
            cy.get('[data-cy="cy-general-continue__button"]').click();

            cy.get('[data-cy="cy-service-category__select"]').type(`${data.taxonomy}`, { delay: 0 });
            cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
            cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
            cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();

            cy.get('[data-cy="cy-dev1-host__input"]').type(`${data.dev1HostName}`, {
                delay: 0,
            });
            cy.get('[data-cy="cy-resource-path__input"]').type(`${data.resourcePath}`, { delay: 0 });
            cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();

            cy.get('[data-cy="cy-appln-key__checkbox"]').click();
            cy.get('[data-cy="cy-checkbox-enforceTaxonamy"]').find('label[for="checkbox-enforce-ba1"]').click();
            cy.get('[data-cy="cy-checkbox-enforceDigest"]').find('label[for="checkbox-enforce-ba2"]').click();
            cy.get('[data-cy="cy-internal-continue__button"]').click();

            cy.get('[data-cy="cy-extActive__epanel"]').find("label[for='checkbox-ch7']").click();

            cy.get('[data-cy="cy-extoAuth__checkbox"]').click();
            cy.get('[data-cy="cy-extportalJwt__checkbox"]').click();
            cy.get('[data-cy="cy-ext-continue__button"]').click();

            cy.get('[data-cy="cy-authentication-type__select"]').select('JWT').trigger('click');
            postAPIProxyDeploy(resp_payload, '', 200);
            cy.get('[data-cy="cy-endpoint_finish__button"]').click();
            cy.get('[data-cy="cy-title-api-proxy-builder"]', { timeout: Cypress.config('defaultTimeout') })
                .find('h2.chi-modal__title')
                .contains(`${data.successAlertHeader}`);
            cy.get('[data-cy="cy-endPoint__epanel"]')
                .next('div.chi-backdrop')
                .find('i.-icon--success')
                .should('be.visible');
            cy.get('[data-cy="cy-endPoint__epanel"]')
                .next('div.chi-backdrop')
                .find('div.-w--100')
                .find('p')
                .as('alertMessages');
            cy.get('@alertMessages').should('have.length.gte', 2);
            cy.get('@alertMessages').first().contains(`${data.successAlertMessage}`);
            cy.get('@alertMessages')
                .eq(1)
                .contains(`${resp_payload.proxy} is now deployed in ${resp_payload.proxyBuiltInEnvironments[0]}.`);
            cy.get('[data-cy="cy-title-api-proxy-builder"]').find('button.chi-button').contains('OK');
        });
    });

    it('proxy has been successfully deployed in multiple environments', () => {
        cy.fixture('multipleProxyCreationResponse').then((resp_payload) => {
            cy.get('[data-cy="cy-app-key__input"]').click().type(`${data.applicationKey}`, { delay: 0 });
            cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });
            cy.get('[data-cy="cy-service-type__select"]').select('Inbound').trigger('click');
            cy.get('[data-cy="cy-SOAP-checkbox"]').find('label[for="checkbox-ba1"]').click();
            cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
            cy.get('[data-cy="cy-external__checkbox"]').click({ force: true });
            cy.get('[data-cy="cy-general-continue__button"]').click();

            cy.get('[data-cy="cy-service-category__select"]').type(`${data.taxonomy}`, { delay: 0 });
            cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
            cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
            cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();

            cy.get('[data-cy="cy-dev1-host__input"]').type(`${data.dev1HostName}`, {
                delay: 0,
            });
            cy.get('[data-cy="cy-dev2-host__input"]').type(`${data.dev2HostName}`, {
                delay: 0,
            });
            cy.get('[data-cy="cy-dev3-host__input"]').type(`${data.dev3HostName}`, {
                delay: 0,
            });
            cy.get('[data-cy="cy-dev4-host__input"]').type(`${data.dev4HostName}`, {
                delay: 0,
            });
            cy.get('[data-cy="cy-test1-host__input"]').type(`${data.test1HostName}`, {
                delay: 0,
            });
            cy.get('[data-cy="cy-test2-host__input"]').type(`${data.test2HostName}`, {
                delay: 0,
            });
            cy.get('[data-cy="cy-test3-host__input"]').type(`${data.test3HostName}`, {
                delay: 0,
            });
            cy.get('[data-cy="cy-test4-host__input"]').type(`${data.test4HostName}`, {
                delay: 0,
            });
            cy.get('[data-cy="cy-resource-path__input"]').type(`${data.resourcePath}`, { delay: 0 });
            cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();

            cy.get('[data-cy="cy-appln-key__checkbox"]').click();
            cy.get('[data-cy="cy-checkbox-enforceTaxonamy"]').find('label[for="checkbox-enforce-ba1"]').click();
            cy.get('[data-cy="cy-checkbox-enforceDigest"]').find('label[for="checkbox-enforce-ba2"]').click();
            cy.get('[data-cy="cy-internal-continue__button"]').click();

            cy.get('[data-cy="cy-extActive__epanel"]').find("label[for='checkbox-ch7']").click();
            cy.get('[data-cy="cy-extoAuth__checkbox"]').click();
            cy.get('[data-cy="cy-extportalJwt__checkbox"]').click();
            cy.get('[data-cy="cy-ext-continue__button"]').click();

            cy.get('[data-cy="cy-authentication-type__select"]').select('JWT').trigger('click');
            postAPIProxyDeploy(resp_payload, '', 200);
            cy.get('[data-cy="cy-endpoint_finish__button"]').click();
            cy.get('[data-cy="cy-title-api-proxy-builder"]', { timeout: Cypress.config('defaultTimeout') })
                .find('h2.chi-modal__title')
                .contains(`${data.successAlertHeader}`);
            cy.get('[data-cy="cy-endPoint__epanel"]')
                .next('div.chi-backdrop')
                .find('i.-icon--success')
                .should('be.visible');
            cy.get('[data-cy="cy-endPoint__epanel"]')
                .next('div.chi-backdrop')
                .find('div.-w--100')
                .find('p')
                .as('alertMessages');
            cy.get('@alertMessages').should('have.length.gte', 2);
            cy.get('@alertMessages').first().contains(`${data.successAlertMessage}`);
            cy.get('@alertMessages')
                .eq(1)
                .contains(
                    `${resp_payload.proxy} is now deployed in ${resp_payload.proxyBuiltInEnvironments[0]}, ${resp_payload.proxyBuiltInEnvironments[1]}, ${resp_payload.proxyBuiltInEnvironments[2]}, ${resp_payload.proxyBuiltInEnvironments[3]}, ${resp_payload.proxyBuiltInEnvironments[4]}, ${resp_payload.proxyBuiltInEnvironments[5]}, ${resp_payload.proxyBuiltInEnvironments[6]}, ${resp_payload.proxyBuiltInEnvironments[7]}.`
                );
            cy.get('[data-cy="cy-title-api-proxy-builder"]').find('button.chi-button').contains('OK');
        });
    });

    it('proxy already exists ', () => {
        cy.get('[data-cy="cy-app-key__input"]').click().type(`${data.applicationKey}`, { delay: 0 });
        cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });
        cy.get('[data-cy="cy-service-type__select"]').select('Inbound').trigger('click');
        cy.get('[data-cy="cy-SOAP-checkbox"]').find('label[for="checkbox-ba1"]').click();
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        cy.get('[data-cy="cy-external__checkbox"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();

        cy.get('[data-cy="cy-service-category__select"]').type(`${data.taxonomy}`, { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();

        cy.get('[data-cy="cy-dev1-host__input"]').type(`${data.dev1HostName}`, {
            delay: 0,
        });
        cy.get('[data-cy="cy-resource-path__input"]').type(`${data.resourcePath}`, { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();

        cy.get('[data-cy="cy-appln-key__checkbox"]').click();
        cy.get('[data-cy="cy-checkbox-enforceTaxonamy"]').find('label[for="checkbox-enforce-ba1"]').click();
        cy.get('[data-cy="cy-checkbox-enforceDigest"]').find('label[for="checkbox-enforce-ba2"]').click();
        cy.get('[data-cy="cy-internal-continue__button"]').click();

        cy.get('[data-cy="cy-extActive__epanel"]').find("label[for='checkbox-ch7']").click();
        cy.get('[data-cy="cy-extoAuth__checkbox"]').click();
        cy.get('[data-cy="cy-extportalJwt__checkbox"]').click();
        cy.get('[data-cy="cy-ext-continue__button"]').click();

        cy.get('[data-cy="cy-authentication-type__select"]').select('JWT').trigger('click');
        postAPIProxyDeploy(`${data.errorResponse}`, '', 400);
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('[data-cy="cy-title-api-proxy-builder"]', { timeout: Cypress.config('defaultTimeout') })
            .find('h2.chi-modal__title')
            .contains(`${data.failedAlertHeader}`);
        cy.get('[data-cy="cy-endPoint__epanel"]').next('div.chi-backdrop').find('i.-icon--danger').should('be.visible');
        cy.get('[data-cy="cy-endPoint__epanel"]')
            .next('div.chi-backdrop')
            .find('div.-w--100')
            .find('p')
            .as('alertMessages');
        cy.get('@alertMessages').should('have.length.gte', 3);
        cy.get('@alertMessages').first().contains(`${data.failedAlertMessage}`);
        cy.get('@alertMessages').eq(1).contains(`Error: "${data.errorResponse}"`);
        cy.get('@alertMessages').last().contains(`${data.contactMessage}`);
        cy.get('@alertMessages').last().should('have.class', '-mt--1');
        cy.get('[data-cy="cy-title-api-proxy-builder"]').find('button.chi-button').contains('OK');
    });

    it('if proxy is already existing for one env but not existing for other environments', () => {
        cy.get('[data-cy="cy-app-key__input"]').click().type(`${data.applicationKey}`, { delay: 0 });
        cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });
        cy.get('[data-cy="cy-service-type__select"]').select('Inbound').trigger('click');
        cy.get('[data-cy="cy-SOAP-checkbox"]').find('label[for="checkbox-ba1"]').click();
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        cy.get('[data-cy="cy-external__checkbox"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();

        cy.get('[data-cy="cy-service-category__select"]').type(`${data.taxonomy}`, { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();

        cy.get('[data-cy="cy-dev2-host__input"]').type(`${data.dev2HostName}`, {
            delay: 0,
        });
        cy.get('[data-cy="cy-dev3-host__input"]').type(`${data.dev3HostName}`, {
            delay: 0,
        });
        cy.get('[data-cy="cy-dev4-host__input"]').type(`${data.dev4HostName}`, {
            delay: 0,
        });
        cy.get('[data-cy="cy-test1-host__input"]').type(`${data.test1HostName}`, {
            delay: 0,
        });
        cy.get('[data-cy="cy-test2-host__input"]').type(`${data.test2HostName}`, {
            delay: 0,
        });
        cy.get('[data-cy="cy-test3-host__input"]').type(`${data.test3HostName}`, {
            delay: 0,
        });
        cy.get('[data-cy="cy-test4-host__input"]').type(`${data.test4HostName}`, {
            delay: 0,
        });
        cy.get('[data-cy="cy-resource-path__input"]').type(`${data.resourcePath}`, { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();

        cy.get('[data-cy="cy-appln-key__checkbox"]').click();
        cy.get('[data-cy="cy-checkbox-enforceTaxonamy"]').find('label[for="checkbox-enforce-ba1"]').click();
        cy.get('[data-cy="cy-checkbox-enforceDigest"]').find('label[for="checkbox-enforce-ba2"]').click();
        cy.get('[data-cy="cy-internal-continue__button"]').click();

        cy.get('[data-cy="cy-extActive__epanel"]').find("label[for='checkbox-ch7']").click();
        cy.get('[data-cy="cy-extoAuth__checkbox"]').click();
        cy.get('[data-cy="cy-extportalJwt__checkbox"]').click();
        cy.get('[data-cy="cy-ext-continue__button"]').click();

        cy.get('[data-cy="cy-authentication-type__select"]').select('JWT').trigger('click');
        postAPIProxyDeploy(`${data.errorResponse}`, '', 400);
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('[data-cy="cy-title-api-proxy-builder"]', { timeout: Cypress.config('defaultTimeout') })
            .find('h2.chi-modal__title')
            .contains(`${data.failedAlertHeader}`);
        cy.get('[data-cy="cy-endPoint__epanel"]').next('div.chi-backdrop').find('i.-icon--danger').should('be.visible');
        cy.get('[data-cy="cy-endPoint__epanel"]')
            .next('div.chi-backdrop')
            .find('div.-w--100')
            .find('p')
            .as('alertMessages');
        cy.get('@alertMessages').should('have.length.gte', 3);
        cy.get('@alertMessages').first().contains(`${data.failedAlertMessage}`);
        cy.get('@alertMessages').eq(1).contains(`Error: "${data.errorResponse}"`);
        cy.get('@alertMessages').last().contains(`${data.contactMessage}`);
        cy.get('@alertMessages').last().should('have.class', '-mt--1');
        cy.get('[data-cy="cy-title-api-proxy-builder"]').find('button.chi-button').contains('OK');
    });

    it('proxy creation failed for the unknown error', () => {
        cy.get('[data-cy="cy-app-key__input"]').click().type(`${data.applicationKey}`, { delay: 0 });
        cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });
        cy.get('[data-cy="cy-service-type__select"]').select('Inbound').trigger('click');
        cy.get('[data-cy="cy-SOAP-checkbox"]').find('label[for="checkbox-ba1"]').click();
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        cy.get('[data-cy="cy-external__checkbox"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();

        cy.get('[data-cy="cy-service-category__select"]').type(`${data.taxonomy}`, { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();

        cy.get('[data-cy="cy-dev1-host__input"]').type(`${data.dev1HostName}`, {
            delay: 0,
        });
        cy.get('[data-cy="cy-resource-path__input"]').type(`${data.resourcePath}`, { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();

        cy.get('[data-cy="cy-appln-key__checkbox"]').click();
        cy.get('[data-cy="cy-checkbox-enforceTaxonamy"]').find('label[for="checkbox-enforce-ba1"]').click();
        cy.get('[data-cy="cy-checkbox-enforceDigest"]').find('label[for="checkbox-enforce-ba2"]').click();
        cy.get('[data-cy="cy-internal-continue__button"]').click();

        cy.get('[data-cy="cy-extActive__epanel"]').find("label[for='checkbox-ch7']").click();
        cy.get('[data-cy="cy-extoAuth__checkbox"]').click();
        cy.get('[data-cy="cy-extportalJwt__checkbox"]').click();
        cy.get('[data-cy="cy-ext-continue__button"]').click();

        cy.get('[data-cy="cy-authentication-type__select"]').select('JWT').trigger('click');
        postAPIProxyDeploy('', '', 400);
        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('[data-cy="cy-title-api-proxy-builder"]', { timeout: Cypress.config('defaultTimeout') })
            .find('h2.chi-modal__title')
            .contains(`${data.failedAlertHeader}`);
        cy.get('[data-cy="cy-endPoint__epanel"]').next('div.chi-backdrop').find('i.-icon--danger').should('be.visible');
        cy.get('[data-cy="cy-endPoint__epanel"]')
            .next('div.chi-backdrop')
            .find('div.-w--100')
            .find('p')
            .as('alertMessages');
        cy.get('@alertMessages').should('have.length.gte', 3);
        cy.get('@alertMessages').first().contains(`${data.failedAlertMessage}`);
        cy.get('@alertMessages').eq(1).contains(`Error: Request failed with status code 400`);
        cy.get('@alertMessages').last().contains(`${data.contactMessage}`);
        cy.get('@alertMessages').last().should('have.class', '-mt--1');
        cy.get('[data-cy="cy-title-api-proxy-builder"]').find('button.chi-button').contains('OK');
    });
});
