/// <reference types='Cypress'/>

import data from '../../fixtures/variables.json';
import { featureFlagMenuActive } from '../../utils/utility.js';
import { getAPIProductLists, getAppDetailsOfUsers, postCreateUserApps } from '../../utils/index';

describe('Create New App page Tests - I', () => {
    beforeEach(() => {
        cy.mockLogin('', featureFlagMenuActive());
        getAppDetailsOfUsers('multiDevApp.json', 200).as('appsList');
        getAPIProductLists('', 'APIProductsResponse.json', 200).as('prodList');
        cy.visit('/credentials');
        cy.wait(['@appsList'], Cypress.config('defaultTimeout'));
        cy.get('[data-cy="cy-en-menu-laptop"]')
            .find('.chi-sidenav__list')
            .find('.-active')
            .contains('Credentials')
            .click();
        cy.get('[data-cy="cy-create-new-app__btn"]').click();
        cy.wait(['@prodList'], Cypress.config('defaultTimeout'));
        cy.location('href').should('include', '/addnew');
    });

    it('Create New App page is rendered as per the provided wireframe', () => {
        cy.get('[data-cy="cy-createPageStep__lbl"]')
            .scrollIntoView()
            .should('be.visible')
            .within(($stepsElement) => {
                cy.wrap($stepsElement).children().should('have.length', 3);
                cy.wrap($stepsElement).find('li.-active').should('include.text', 'Create');
            });

        cy.get('[data-cy="cy-create_apptitle"]').should('be.visible');
        cy.get('[data-cy="cy-details__lbl"]').should('be.visible');
        cy.get('[data-cy="cy-appName__tbx"]').should('be.visible');
        cy.get('[data-cy="cy-environment__picker"]').should('be.visible');
        cy.get('[data-cy="cy-selectProducts__lbl"]').should('be.visible');
        cy.get('[data-cy="cy-search__tbx"]').should('be.visible');
        cy.get('[data-cy="cy-selProdCount__lbl"]').should('be.visible');
        cy.get('[data-cy="cy-showSelectedOnly__cbx"]').should('be.visible');
        cy.get('[data-cy="cy-showSelectedOnly__lbl"]').should('be.visible');
        cy.get('[data-cy="cy-selectProducts__tbl"]')
            .should('be.visible')
            .and('contain.text', 'API Name')
            .and('contain.text', 'Description');

        cy.get('[data-cy="cy-step1Cancel__btn"]')
            .scrollIntoView()
            .within(($cancelElement) => {
                cy.wrap($cancelElement).should('be.visible').and('include.text', 'CANCEL');
            });
        cy.get('[data-cy="cy-next__btn"]').within(($nextElement) => {
            cy.wrap($nextElement).should('be.visible').and('include.text', 'NEXT');
        });
    });

    it('API Products unavailable in the selected environment are grayed out, not selectable and has information message in description', () => {
        cy.log('Selecting the dev environment...');
        cy.contains('label', 'dev', { matchCase: true }).click({ force: true });

        cy.contains('div', 'TestAPIProductDelta', { matchCase: true })
            .parents()
            .find('[data-label="API Name"]')
            .find('div')
            .should('have.class', 'disable_text');
        cy.contains('div', 'TestAPIProductDelta', { matchCase: true })
            .parents()
            .find('input[type="checkbox"]')
            .should('be.disabled');
        cy.contains('div', 'TestAPIProductDelta', { matchCase: true })
            .parents()
            .find('[data-label="Description"]')
            .find('div')
            .should('have.class', 'disable_text')
            .and('include.text', ' Product currently unavailable in selected environment. ');
    });

    it('Error message shown when user has not selected any API Product on Create New App page', () => {
        cy.get('[data-cy="cy-next__btn"]').click();
        cy.get('[data-cy="cy-minProdErr__lbl"]')
            .scrollIntoView()
            .should('be.visible')
            .and('include.text', 'You must select at least one product.')
            .find('chi-alert[color="danger"]');
    });

    it('Error message shown when user has not given an App name', () => {
        cy.get('[data-cy="cy-appName__tbx"]').focus().type('a').clear();
        cy.get('[data-cy="cy-name__required__error"]')
            .should('be.visible')
            .and('include.text', ' You must enter a name ')
            .find('i.icon-circle-warning');
    });

    it('Error message shown when user gives already existing name for the App', () => {
        cy.get('[data-cy="cy-appName__tbx"]').focus().type('App 1');
        cy.get('[data-cy="cy-name__unique__error"]')
            .should('be.visible')
            .and('include.text', 'An App with this name already exists. Please try another name.')
            .find('i.icon-circle-warning');
    });

    it('Cancel button click on Create page returns user to the My Apps dashboard', () => {
        getAppDetailsOfUsers('multiDevApp.json', 200).as('appsList');
        getAPIProductLists('', 'APIProductsResponse.json', 200).as('prodList');
        cy.get('[data-cy="cy-step1Cancel__btn"]').click();
        cy.wait(['@appsList', '@prodList'], Cypress.config('defaultTimeout'));
        cy.location('href').should('include', '/credentials');
    });

    it('User not able to navigate to Review App page until all details are provided', () => {
        cy.get('[data-cy="cy-appName__tbx"]').focus().type('New Test App', { delay: 0 });
        cy.get('[data-cy="cy-next__btn"]').click();
        cy.get('[data-cy="cy-create_apptitle"]', { timeout: Cypress.config('defaultTimeout') }).should('be.visible');
        cy.get('[data-cy="cy-appName__tbx"]').focus().clear();
        cy.contains('div', 'TestAPIProductBeta', { matchCase: true })
            .parent()
            .prev()
            .find('input[type="checkbox"]')
            .click({ force: true });
        cy.get('[data-cy="cy-next__btn"]').click();
        cy.get('[data-cy="cy-create_apptitle"]', { timeout: Cypress.config('defaultTimeout') }).should('be.visible');
    });

    it('Switching environment resets the selected API Products', () => {
        cy.contains('label', 'test1', { matchCase: true }).click({ force: true });
        cy.contains('div', 'TestAPIProductBeta', { matchCase: true })
            .parent()
            .siblings()
            .eq(0)
            .find('input')
            .should('not.be.checked');
        cy.contains('label', 'dev', { matchCase: true }).click({ force: true });
    });

    it('Clicking on My Apps back-link navigates back to My Apps dashboard', () => {
        getAppDetailsOfUsers('', 200).as('appsList');
        getAPIProductLists([], '', 200).as('prodList');
        cy.get('[data-cy="cy-myAppsBack__lnk"]').click({ force: true });
        cy.location('href').should('include', '/credentials');
    });
});

describe('Review New App page Tests', () => {
    beforeEach(() => {
        cy.mockLogin('', featureFlagMenuActive());
        getAppDetailsOfUsers('multiDevApp.json', 200).as('appsList');
        getAPIProductLists('', 'APIProductsResponse.json', 200).as('prodList');
        cy.visit('/credentials');
        cy.wait(['@appsList'], Cypress.config('defaultTimeout'));
        cy.get('[data-cy="cy-en-menu-laptop"]')
            .find('.chi-sidenav__list')
            .find('.-active')
            .contains('Credentials')
            .click();
        cy.log('Navigating to Create New App page...');
        cy.get('[data-cy="cy-create-new-app__btn"]').click();
        cy.wait(['@prodList'], Cypress.config('defaultTimeout'));
        cy.log('Entering App Details...');
        cy.get('[data-cy="cy-appName__tbx"]').focus().type('New Test App', { delay: 0 });
        cy.contains('label', 'dev', { matchCase: true }).click({ force: true });
        cy.contains('div', 'TestAPIProductAlpha', { matchCase: true })
            .parents('div.chi-data-table__row')
            .find('input[type="checkbox"]')
            .click({ force: true });
        cy.contains('div', 'TestAPIProductBeta', { matchCase: true })
            .parents('div.chi-data-table__row')
            .find('input[type="checkbox"]')
            .click({ force: true });
        getAppDetailsOfUsers('', 200).as('appsList');
        cy.get('[data-cy="cy-next__btn"]').click();
    });

    it('Review App page is rendered as per the provided wireframe', () => {
        cy.get('[data-cy="cy-review_apptitle"]', { timeout: Cypress.config('defaultTimeout') }).should('be.visible');
        cy.get('[data-cy="cy-reviewPageSteps__lbl"]')
            .should('be.visible')
            .within(($stepsElement) => {
                cy.wrap($stepsElement).find('li.-active').should('include.text', 'Review');
                cy.wrap($stepsElement).find('li.-completed').should('include.text', 'Create');
            });

        cy.get('[data-cy="cy-reviewAppName__tbx"]').within(($appNameElement) => {
            cy.wrap($appNameElement)
                .should('be.visible')
                .and('include.text', 'New Test App')
                .siblings()
                .should('include.text', 'Credential Name');
        });

        cy.get('[data-cy="cy-review_apptitle"]').within(($titleElement) => {
            cy.wrap($titleElement).should('be.visible').and('include.text', 'Review');
        });

        cy.get('[data-cy="cy-appEnv__name"]').within(($envElement) => {
            cy.wrap($envElement)
                .should('be.visible')
                .and('include.text', 'dev')
                .siblings()
                .should('include.text', 'Environment');
        });

        cy.get('[data-cy="cy-apiProducts__lbl"]').within(($productsLabelElement) => {
            cy.wrap($productsLabelElement)
                .should('be.visible')
                .and('include.text', 'API Products')
                .and('include.text', '2');
        });

        cy.get('[data-cy="cy-apiProducts__tbl"]').within(($productsTableElement) => {
            cy.wrap($productsTableElement)
                .should('be.visible')
                .and('include.text', 'API Name')
                .and('include.text', 'Description');
        });

        cy.get('[data-cy="cy-reviewBack__btn"]').should('be.visible').and('include.text', 'BACK');
        cy.get('[data-cy="cy-cancelApp__btn"]').should('be.visible').and('include.text', 'CANCEL');
        cy.get('[data-cy="cy-createApp__btn"]').should('be.visible').and('include.text', 'CREATE');
    });

    it('Clicking Back button navigates back to the Create App page', () => {
        cy.get('[data-cy="cy-reviewBack__btn"]').click();
        cy.get('[data-cy="cy-createPageStep__lbl"]')
            .find('.-active')
            .should('be.visible')
            .within(($stepsElement) => {
                cy.wrap($stepsElement).children().should('have.length', 2);
                cy.wrap($stepsElement).should('include.text', 'Create');
            });

        cy.get('[data-cy="cy-create_apptitle"]').should('be.visible');
        cy.get('[data-cy="cy-appName__tbx"]').within(($appNameElement) => {
            cy.wrap($appNameElement).should('be.visible').and('include.value', 'New Test App');
        });
        cy.contains('label', 'dev', { matchCase: true }).siblings().should('be.checked');
        cy.contains('div', 'TestAPIProductBeta', { matchCase: true })
            .parent()
            .siblings()
            .eq(0)
            .find('input')
            .should('be.checked');
        cy.contains('div', 'TestAPIProductAlpha', { matchCase: true })
            .parent()
            .siblings()
            .eq(0)
            .find('input')
            .should('be.checked');

        cy.get('[data-cy="cy-next__btn"]').click();
    });

    it('Removing a product and clicking Back button should reflect on Create New App page', () => {
        cy.contains('div', 'TestAPIProductAlpha', { matchCase: true })
            .parents('div.chi-data-table__row')
            .eq(0)
            .find('[data-cy="cy-removeProduct__btn"]')
            .click();
        cy.get('[data-cy="cy-reviewBack__btn"]').click();
        cy.get('[data-cy="cy-selProdCount__lbl"]').should('include.text', '1');
        cy.contains('div', 'TestAPIProductAlpha', { matchCase: true })
            .parent()
            .siblings()
            .eq(0)
            .find('input')
            .should('not.be.checked');
        cy.get('[data-cy="cy-next__btn"]').click();
    });

    it('Clicking on Create back-link navigates back to Create New App page', () => {
        cy.get('[data-cy="cy-createBack__lnk"]').click();
        cy.get('[data-cy="cy-createPageStep__lbl"]')
            .find('.-active')
            .should('be.visible')
            .within(($stepsElement) => {
                cy.wrap($stepsElement).children().should('have.length', 2);
                cy.wrap($stepsElement).should('include.text', 'Create');
            });

        cy.get('[data-cy="cy-create_apptitle"]').should('be.visible');
        cy.get('[data-cy="cy-appName__tbx"]', { timeout: Cypress.config('defaultTimeout') }).within(
            ($appNameElement) => {
                cy.wrap($appNameElement).should('be.visible').and('include.value', 'New Test App');
            }
        );
        cy.contains('label', 'dev', { matchCase: true }).siblings().should('be.checked');
        cy.contains('div', 'TestAPIProductBeta', { matchCase: true })
            .parent()
            .siblings()
            .eq(0)
            .find('input')
            .should('be.checked');
        cy.get('[data-cy="cy-next__btn"]').click();
    });

    it('Clicking on Cancel button navigates back to My Apps dashboard without creating an app', () => {
        getAppDetailsOfUsers('', 200).as('appsList');
        getAPIProductLists('', 'APIProductsResponse.json', 200).as('prodList');
        cy.get('[data-cy="cy-cancelApp__btn"]').click();
        cy.wait(['@appsList', '@prodList'], Cypress.config('defaultTimeout'));
        cy.location('href').should('include', '/credentials');
    });

    it('Clicking on Create App Button navigates to My Apps dashboard on failure of creation of App', () => {
        postCreateUserApps({ error: 'Internal Server Error' }, '', 500).as('createNewAppReq');
        getAppDetailsOfUsers('multiDevApp.json', 200).as('appsList');
        getAPIProductLists('', 'APIProductsResponse.json', 200).as('prodList');

        cy.log('Navigating to Create New App page...');
        cy.get('[data-cy="cy-createApp__btn"]').find('.chi-button').should('include.text', 'CREATE').click();
        cy.wait(['@prodList'], Cypress.config('defaultTimeout'));
        cy.location('href').should('include', '/credentials');
        cy.get('[data-cy="cy-alert__lbl"]')
            .should('be.visible')
            .and('have.class', '-danger')
            .and('include.text', 'Internal server error')
            .find('i')
            .should('have.class', 'icon-circle-warning');
    });
});

describe('Complete New App page Tests', () => {
    beforeEach(() => {
        cy.mockLogin('', featureFlagMenuActive());
        getAppDetailsOfUsers('multiDevApp.json', 200).as('appsList');
        getAPIProductLists('', 'APIProductsResponse.json', 200).as('prodList');
        postCreateUserApps('', 'createNewAppStub.json', 200).as('createNewAppReq');
        cy.visit('/credentials');
        cy.wait(['@appsList'], Cypress.config('defaultTimeout'));
        cy.get('[data-cy="cy-en-menu-laptop"]').find('.chi-sidenav__list').find('.-active').click();
        cy.log('Navigating to Create New App page...');
        cy.get('[data-cy="cy-create-new-app__btn"]').should('include.text', 'Create New').click();
        cy.wait(['@prodList'], Cypress.config('defaultTimeout'));
        cy.log('Entering App Details...');
        cy.get('[data-cy="cy-appName__tbx"]').focus().type('New Test App', { delay: 0 });
        cy.contains('label', 'dev', { matchCase: true }).click({ force: true });
        cy.contains('div', 'TestAPIProductAlpha', { matchCase: true })
            .parents('div.chi-data-table__row')
            .find('input[type="checkbox"]')
            .click({ force: true });
        cy.contains('div', 'TestAPIProductBeta', { matchCase: true })
            .parents('div.chi-data-table__row')
            .find('input[type="checkbox"]')
            .click({ force: true });
        cy.get('[data-cy="cy-next__btn"]').click();
        cy.get('[data-cy="cy-createApp__btn"]').click();
        cy.wait('@createNewAppReq', Cypress.config('defaultTimeout'));
    });

    it('Complete New App is rendered as per the provided wireframe', () => {
        cy.get('[data-cy="cy-completePageSteps__lbl"]')
            .should('be.visible')
            .within(($stepsElement) => {
                cy.wrap($stepsElement).find('li.-active').should('include.text', 'Complete');
                cy.wrap($stepsElement).find('li.-completed').eq(0).should('include.text', 'Create');
                cy.wrap($stepsElement).find('li.-completed').eq(1).should('include.text', 'Review');
            });
        cy.get('[data-cy="cy-completeApp__title"]').should('be.visible').and('include.text', 'Complete');
        cy.get('[data-cy="cy-createSuccess__alert"]')
            .should('be.visible')
            .and('have.class', '-success')
            .and('include.text', 'Success')
            .and('include.text', 'New Test App Credential has been created.')
            .find('i.icon-circle-check');
        cy.get('[data-cy="cy-credentials__label"]').should('be.visible').and('include.text', 'Your Credentials');

        cy.get('[data-cy="cy-note__lbl"]')
            .should('be.visible')
            .and('include.text', `${data.noteMessage}`)
            .and('have.class', '-warning')
            .find('i.icon-warning');
        cy.contains('label', 'Consumer Key', { matchCase: true })
            .should('be.visible')
            .siblings()
            .find('input')
            .invoke('val')
            .should('not.be.empty');
        cy.contains('label', 'Consumer Key', { matchCase: true })
            .siblings()
            .find('i')
            .should('have.class', 'icon-copy');

        cy.contains('label', 'Consumer Secret', { matchCase: true })
            .should('be.visible')
            .siblings()
            .find('input')
            .invoke('val')
            .should('not.be.empty');
        cy.contains('label', 'Consumer Secret', { matchCase: true })
            .siblings()
            .find('i')
            .should('have.class', 'icon-copy');

        cy.get('[data-cy="cy-done__btn"]').should('be.visible').and('include.text', 'DONE');
    });

    it('Clicking on Done button navigates to My Apps dashboard', () => {
        getAppDetailsOfUsers('', 200).as('appsList');
        getAPIProductLists([], '', 200).as('prodList');
        cy.get('[data-cy="cy-done__btn"]').click();
        cy.wait(['@appsList', '@prodList'], Cypress.config('defaultTimeout'));
        cy.location('href').should('include', '/credentials');
    });
});

describe('Create New App page Tests - II', () => {
    beforeEach(() => {
        cy.mockLogin('', featureFlagMenuActive());
        getAppDetailsOfUsers('multiDevApp.json', 200).as('appsList');
        getAPIProductLists('', 'APIProductsResponse.json', 200).as('prodList');
        cy.visit('/credentials');
        cy.wait(['@appsList'], Cypress.config('defaultTimeout'));
        cy.get('[data-cy="cy-en-menu-laptop"]')
            .find('.chi-sidenav__list')
            .find('.-active')
            .contains('Credentials')
            .click();
        cy.get('[data-cy="cy-create-new-app__btn"]', { timeout: Cypress.config('defaultTimeout') }).click();
        cy.wait(['@prodList'], Cypress.config('defaultTimeout'));
        cy.contains('label', 'dev', { matchCase: true }).click({ force: true });
        cy.contains('div', 'TestAPIProductAlpha', { matchCase: true })
            .parents('div.chi-data-table__row')
            .find('input[type="checkbox"]')
            .click({ force: true });
        cy.contains('div', 'TestAPIProductBeta', { matchCase: true })
            .parents('div.chi-data-table__row')
            .find('input[type="checkbox"]')
            .click({ force: true });
    });

    it('Show Selected Only functionality', () => {
        cy.get('[data-cy="cy-showSelectedOnly__lbl"]').contains('Show Selected Only').click();
        // Check that only two selected API Products are shown for App 1 app
        cy.get('[data-cy="cy-selectProducts__tbl"]')
            .find('.chi-data-table__body')
            .find('[data-label="API Name"]')
            .should('have.length', 2);
    });

    it('Search availability for both API Product Name and API Product Description', () => {
        cy.get('[data-cy="cy-search__tbx"]').focus().clear().type('TestAPIProductBeta', { delay: 0 });
        cy.get('[data-cy="cy-selectProducts__tbl"]')
            .find('.chi-data-table__body')
            .find('[data-label="API Name"]')
            .should('have.length', 1)
            .and('have.text', ' TestAPIProductBeta ');
        cy.get('[data-cy="cy-search__tbx"]').focus().clear().type(`${data.searchText1}`, { delay: 0 });
        cy.get('[data-cy="cy-selectProducts__tbl"]')
            .find('.chi-data-table__body')
            .find('[aria-label="Description"]')
            .should('have.length', 1)
            .and('include.text', `${data.searchText1}`);
    });

    it('Search results are case insensitive', () => {
        cy.get('[data-cy="cy-search__tbx"]').focus().clear().type('testApIprOducTBETA', { delay: 0 });
        cy.get('[data-cy="cy-selectProducts__tbl"]')
            .find('.chi-data-table__body')
            .find('[data-label="API Name"]')
            .should('have.length', 1)
            .and('have.text', ' TestAPIProductBeta ');
    });

    it('Search results includes API Product Names and Descriptions even if unavailable in specified App Environment', () => {
        cy.get('[data-cy="cy-search__tbx"]').focus().clear().type('TestAPIProductDelta', { delay: 0 });
        cy.get('[data-cy="cy-selectProducts__tbl"]')
            .find('.chi-data-table__body')
            .find('[data-label="API Name"]')
            .should('have.length', 1)
            .and('have.text', ' TestAPIProductDelta ');

        cy.get('[data-cy="cy-search__tbx"]').focus().clear().type(`${data.searchText2}`, { delay: 0 });
        cy.get('[data-cy="cy-selectProducts__tbl"]')
            .find('.chi-data-table__body')
            .find('[aria-label="Description"]')
            .should('have.length', 1)
            .and('include.text', 'Product currently unavailable in selected environment.');
    });

    it('Search results are displayed as characters are entered', () => {
        cy.get('[data-cy="cy-search__tbx"]').focus().clear().type('T');
        // Verify that search results are narrowing down on each keypress. 34 Products in total
        cy.get('[data-cy="cy-selectProducts__tbl"]', {
            timeout: Cypress.config('defaultTimeout'),
        })
            .find('.chi-data-table__body')
            .find('[data-label="API Name"]')
            .should('have.length.lt', 34);

        // Verify that search results are narrowing down on each keypress (less than previous products count)
        cy.get('[data-cy="cy-search__tbx"]').focus().type('a');
        cy.get('[data-cy="cy-selectProducts__tbl"]')
            .find('.chi-data-table__body')
            .find('[data-label="API Name"]')
            .should('have.length.lt', 34);
        // Verify that search results are narrowing down on each keypress (less than previous products count)
        cy.get('[data-cy="cy-search__tbx"]').focus().type('p');
        cy.get('[data-cy="cy-selectProducts__tbl"]')
            .find('.chi-data-table__body')
            .find('[data-label="API Name"]')
            .should('have.length', 3);
    });

    it('Message displayed if searched item is not found', () => {
        cy.get('[data-cy="cy-search__tbx"]').focus().clear().type('PqwJdk', { delay: 0 });
        cy.get('div.chi-data-table__row-empty').should('include.text', 'No API Product(s)');
    });
});
