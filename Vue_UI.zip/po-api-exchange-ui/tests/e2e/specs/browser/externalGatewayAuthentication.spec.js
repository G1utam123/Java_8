/// <reference types='Cypress'/>

import data from '../../fixtures/variables.json';
import { validateDDLWithoutLIAMJwt, validateDDLWithLIAMJwt } from '../../utils/utility';
import { getTaxonomy, getAppKeyDetails, getESPHealthStatus } from '../../utils/index';

describe('External Gateway Authentication', function () {
    beforeEach(function () {
        cy.mockLogin();
        getTaxonomy('taxonomies.json', 200).as('taxonomies');
        getAppKeyDetails('applicationkeys.json', 200);
        getESPHealthStatus('', 200);
        cy.visit('/proxy');
        cy.wait('@taxonomies');
    });

    it('Check the warning message for BasicAuth details', () => {
        cy.get('[data-cy="cy-app-key__input"]').click().type(`${data.applicationKey}`, { delay: 0 });
        cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });
        cy.get('[data-cy="cy-SOAP-checkbox"]').click();
        cy.get('[data-cy="cy-service-type__select"]').select('Inbound').trigger('click');
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        cy.get('[data-cy="cy-external__checkbox"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();

        cy.get('[data-cy="cy-service-category__select"]').type(`${data.taxonomy}`, { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();

        cy.get('[data-cy="cy-dev1-host__input"]').type(`${data.dev1HostName}`, { delay: 0 });
        cy.get('[data-cy="cy-resource-path__input"]').type(`${data.resourcePath}`, { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();

        cy.get('[data-cy="cy-basicAuth__checkbox"]').click();
        cy.get('[data-cy="cy-intLdapUser_textInput"]').type(`${data.ldapUser1}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapUser_button"]').click();
        cy.get('[data-cy="cy-intLdapGroup_textInput"]').type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapGroup_button"]').click();
        cy.get('[data-cy="cy-internal-continue__button"]').click();

        cy.get('[data-cy="cy-basicAuthExternal__checkbox"]').click();
        cy.get('[data-cy="cy-extActive__epanel"]').find('.-danger').should('not.exist');

        cy.get('[data-cy="cy-extLdapUser_textInput"]').children('input').as('extLdapUserClass');
        cy.get('@extLdapUserClass').should('not.have.class', '-danger');
        cy.get('[data-cy="cy-extLdapGroup_textInput"]').children('input').as('extLdapGroupClass');
        cy.get('@extLdapGroupClass').should('not.have.class', '-danger');
        cy.get('[data-cy="cy-extLdapUser_textInput"]').type(`${data.ldapUser1}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapUser_button"]').click();
        cy.get('[data-cy="cy-extldapUserlist_grid"]').should('be.visible');
        cy.get('[data-cy="cy-extActive__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('[icon="circle-warning"]')
            .should('not.exist');
        cy.get('@extLdapUserClass').should('not.have.class', '-danger');
        cy.get('@extLdapGroupClass').should('not.have.class', '-danger');
        cy.get('[data-cy="cy-extLdapUser_delbutton"]').click();
        cy.get('[data-cy="cy-extActive__epanel"]').find('.-danger').should('not.exist');

        cy.get('@extLdapUserClass').should('not.have.class', '-danger');
        cy.get('@extLdapGroupClass').should('not.have.class', '-danger');

        cy.get('[data-cy="cy-extLdapGroup_textInput"]').type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapGroup_button"]').click();
        cy.get('[data-cy="cy-extldapGrouplist_grid"]').should('be.visible');
        cy.get('[data-cy="cy-extActive__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('[icon="circle-warning"]')
            .should('not.exist');
        cy.get('@extLdapUserClass').should('not.have.class', '-danger');
        cy.get('@extLdapGroupClass').should('not.have.class', '-danger');
        cy.get('[data-cy="cy-extLdapGroup_delbutton"]').click();
        cy.get('[data-cy="cy-extActive__epanel"]').find('.-danger').should('not.exist');

        cy.get('@extLdapUserClass').should('not.have.class', '-danger');
        cy.get('@extLdapGroupClass').should('not.have.class', '-danger');

        cy.get('[data-cy="cy-extLdapUser_textInput"]').type(`${data.ldapUser1}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapUser_button"]').click();
        cy.get('[data-cy="cy-extLdapGroup_textInput"]').type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapGroup_button"]').click();
        cy.get('[data-cy="cy-extActive__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('[icon="circle-warning"]')
            .should('not.exist');
        cy.get('@extLdapUserClass').should('not.have.class', '-danger');
        cy.get('@extLdapGroupClass').should('not.have.class', '-danger');
        cy.get('[data-cy="cy-extLdapGroup_delbutton"]').click();
        cy.get('[data-cy="cy-extActive__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('[icon="circle-warning"]')
            .should('not.exist');
        cy.get('@extLdapUserClass').should('not.have.class', '-danger');
        cy.get('@extLdapGroupClass').should('not.have.class', '-danger');

        cy.get('[data-cy="cy-extLdapGroup_textInput"]').type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapGroup_button"]').click();
        cy.get('[data-cy="cy-extLdapUser_delbutton"]').click();
        cy.get('[data-cy="cy-extActive__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('[icon="circle-warning"]')
            .should('not.exist');
        cy.get('@extLdapUserClass').should('not.have.class', '-danger');
        cy.get('@extLdapGroupClass').should('not.have.class', '-danger');

        cy.get('[data-cy="cy-extLdapGroup_textInput"]').type(`${data.ldapGroup2}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapGroup_button"]').click();
        cy.get('[data-cy="cy-extLdapGroup_delbutton"]').last().click();
        cy.get('[data-cy="cy-extActive__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('[icon="circle-warning"]')
            .should('not.exist');
        cy.get('@extLdapUserClass').should('not.have.class', '-danger');
        cy.get('@extLdapGroupClass').should('not.have.class', '-danger');
        cy.get('[data-cy="cy-extLdapGroup_delbutton"]').click();

        cy.get('[data-cy="cy-extLdapUser_textInput"]').type(`${data.ldapUser1}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapUser_button"]').click();
        cy.get('[data-cy="cy-extLdapUser_textInput"]').type(`${data.ldapUser2}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapUser_button"]').click();
        cy.get('[data-cy="cy-extLdapUser_delbutton"]').last().click();
        cy.get('[data-cy="cy-extActive__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('[icon="circle-warning"]')
            .should('not.exist');
        cy.get('@extLdapUserClass').should('not.have.class', '-danger');
        cy.get('@extLdapGroupClass').should('not.have.class', '-danger');
        cy.get('[data-cy="cy-ext-continue__button"]').click();
    });

    it('Warning message for basic auth should not appear while clicking on previous button in endpoint authentication panel', () => {
        cy.get('[data-cy="cy-app-key__input"]').click().type(`${data.applicationKey}`, { delay: 0 });
        cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });
        cy.get('[data-cy="cy-SOAP-checkbox"]').click();
        cy.get('[data-cy="cy-service-type__select"]').select('Inbound').trigger('click');
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        cy.get('[data-cy="cy-external__checkbox"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').click();

        cy.get('[data-cy="cy-service-category__select"]').type(`${data.taxonomy}`, { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').click();

        cy.get('[data-cy="cy-dev1-host__input"]').type(`${data.dev1HostName}`, { delay: 0 });
        cy.get('[data-cy="cy-resource-path__input"]').type(`${data.resourcePath}`, { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').click();

        cy.get('[data-cy="cy-basicAuth__checkbox"]').click();
        cy.get('[data-cy="cy-intLdapUser_textInput"]').type(`${data.ldapUser1}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapUser_button"]').click();
        cy.get('[data-cy="cy-intLdapGroup_textInput"]').type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapGroup_button"]').click();
        cy.get('[data-cy="cy-internal-continue__button"]').click();

        cy.get('[data-cy="cy-basicAuthExternal__checkbox"]').click();
        cy.get('[data-cy="cy-extLdapUser_textInput"]').type(`${data.ldapUser1}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapUser_button"]').click();
        cy.get('[data-cy="cy-extLdapGroup_textInput"]').type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapGroup_button"]').click();
        cy.get('[data-cy="cy-ext-continue__button"]').click();

        //previous to external gateway authentication
        cy.get('[data-cy="cy-endPoint__epanel"]').contains('Previous').click();
        cy.get('[data-cy="cy-extActive__epanel"]').should('be.class', '-active');
        cy.get('[data-cy="cy-gatewayEndpoint__epanel"]').should('be.class', '-done');
        //previous to internal gateway authentication
        cy.get('[data-cy="cy-extActive__epanel"]').contains('Previous').click();
        cy.get('[data-cy="cy-intActive__epanel"]').should('be.class', '-active');
        cy.get('[data-cy="cy-extActive__epanel"]').should('be.class', '-done');
        cy.get('[data-cy="cy-internal-continue__button"]').click();

        cy.get('[data-cy="cy-extActive__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('[icon="circle-warning"]')
            .should('not.exist');

        cy.get('[data-cy="cy-ext-continue__button"]').click({ force: true });
        cy.get('[data-cy="cy-extActive__epanel"]').contains('Change').click();
        cy.get('[data-cy="cy-extActive__epanel"]')
            .children('div.chi-epanel__collapse')
            .find('[icon="circle-warning"]')
            .should('not.exist');
    });

    it('LIAMJwt option should not be visible in Endpoint auth-type drop down list if user selects Legacy OAuth', () => {
        cy.get('[data-cy="cy-app-key__input"]')
            .click()
            .type(`${data.applicationKey}`, { delay: 0 })
            .click({ force: true });
        cy.get('[data-cy="cy-app-key__select"]').type(`${data.sysgenId}`, { delay: 0 });
        cy.get('[data-cy="cy-SOAP-checkbox"]').click();
        cy.get('[data-cy="cy-service-type__select"]').select('Inbound').trigger('click');
        cy.get('[data-cy="cy-external__checkbox"]').click({ force: true });
        cy.get('[data-cy="cy-general-continue__button"]').as('generalSection_continue_btn');
        cy.get('@generalSection_continue_btn').click();

        cy.get('[data-cy="cy-service-category__select"]').type(`${data.taxonomy}`, { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').as('endpointSection_continue_btn');
        cy.get('@endpointSection_continue_btn').click();

        cy.get('[data-cy="cy-dev1-host__input"]').type(`${data.dev1HostName}`, { delay: 0 });
        cy.get('[data-cy="cy-resource-path__input"]').type(`${data.resourcePath}`, { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').as('targetEndpoint_continue_btn');
        cy.get('@targetEndpoint_continue_btn').click();

        cy.get('[data-cy="cy-extActive__epanel"]').find('input#checkbox-ch7').as('ext_appKey_checkBox');
        cy.get('@ext_appKey_checkBox').click({ force: true });
        cy.get('[data-cy="cy-ext-continue__button"]').as('extGateway_continue_btn');
        cy.get('@extGateway_continue_btn').click();
        cy.get('[data-cy="cy-authentication-type__select"]').children('option').as('endpoint_authType_ddl');
        cy.get('@endpoint_authType_ddl').then(validateDDLWithoutLIAMJwt());

        cy.get('[data-cy="cy-extActive__epanel"]')
            .find('button.-primary')
            .contains('Change')
            .as('extGatewayAuth_panel_change_btn');
        cy.get('@extGatewayAuth_panel_change_btn').click();

        cy.get('@ext_appKey_checkBox').click({ force: true });
        cy.get('[data-cy="cy-basicAuthExternal__checkbox"]').find('input').as('ext_basicAuth_checkBox');
        cy.get('@ext_basicAuth_checkBox').click({ force: true });
        cy.get('[data-cy="cy-extLdapUser_textInput"]').find('input').as('ext_ldapUser_txtBox');
        cy.get('@ext_ldapUser_txtBox').type(`${data.ldapUser1}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapUser_button"]').find('button').as('ext_ldapUserAdd_btn');
        cy.get('@ext_ldapUserAdd_btn').click();
        cy.get('[data-cy="cy-extLdapGroup_textInput"]').find('input').as('ext_ldapUserAdd_btn');
        cy.get('@ext_ldapUserAdd_btn').type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapGroup_button"]').find('button').as('ext_ldapGroupAdd_btn');
        cy.get('@ext_ldapGroupAdd_btn').click();
        cy.get('@extGateway_continue_btn').click();
        cy.get('@endpoint_authType_ddl').then(validateDDLWithoutLIAMJwt());

        cy.get('@extGatewayAuth_panel_change_btn').click();
        cy.get('@ext_basicAuth_checkBox').click({ force: true });
        cy.get('[data-cy="cy-portalJwt"]').as('ext_portalJwt_checkBox');
        cy.get('@ext_portalJwt_checkBox').click({ force: true });
        cy.get('@extGateway_continue_btn').click();
        cy.get('@endpoint_authType_ddl').then(validateDDLWithoutLIAMJwt());

        cy.get('@extGatewayAuth_panel_change_btn').click();
        cy.get('@ext_portalJwt_checkBox').click({ force: true });
        cy.get('[data-cy="cy-extoAuth__checkbox"]').find('input').as('ext_oAuth_checkBox');
        cy.get('@ext_oAuth_checkBox').click({ force: true });

        cy.get('[data-cy="cy-extoAuth__checkbox"]').next('div').should('be.visible');
        cy.get('[for="legacyOAuthId"]').find('div.chi-picker-label').should('be.visible').as('legacy_oAuth_picker');
        cy.get('@legacy_oAuth_picker').first().and('have.text', 'Legacy OAuth');
        cy.get('@legacy_oAuth_picker').last().should('have.text', 'Apigee or AzureB2C Only');

        cy.get('[for="liamJwtId"]').find('div.chi-picker-label').should('be.visible').as('liam_oAuth_picker');
        cy.get('@liam_oAuth_picker').first().and('have.text', 'LIAM OAuth');
        cy.get('@liam_oAuth_picker')
            .last()
            .should('have.text', ' Apigee or Azure B2C with LIAM JWT Token Authorization ');
        cy.get('@extGateway_continue_btn').click();
        cy.get('@endpoint_authType_ddl').then(validateDDLWithoutLIAMJwt());

        cy.get('@extGatewayAuth_panel_change_btn').click();
        cy.get('[for="liamJwtId"]').click();
        cy.get('@extGateway_continue_btn').click();
        cy.get('@endpoint_authType_ddl').then(validateDDLWithLIAMJwt());
        cy.get('[data-cy="cy-authentication-type__select"]').select('LIAMJwt').trigger('click');

        cy.get('@extGatewayAuth_panel_change_btn').click();
        cy.get('[for="legacyOAuthId"]').click();
        cy.get('@extGateway_continue_btn').click();

        cy.get('@extGatewayAuth_panel_change_btn').click();
        cy.get('@ext_appKey_checkBox').click({ force: true });
        cy.get('@ext_basicAuth_checkBox').click({ force: true });
        cy.get('@ext_ldapUser_txtBox').type(`${data.ldapUser1}`, { delay: 0 });
        cy.get('@ext_ldapUserAdd_btn').type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('@ext_portalJwt_checkBox').click({ force: true });
        cy.get('[for="legacyOAuthId"]').click();
        cy.get('@extGateway_continue_btn').click();
        cy.get('@endpoint_authType_ddl').then(validateDDLWithoutLIAMJwt());
        cy.get('[data-cy="cy-general__epanel"]').find('button.-primary').contains('Change').as('generalChangeBtn');
        cy.get('@generalChangeBtn').click();
        cy.get('[data-cy="cy-internal__checkbox"]').click({ force: true });
        cy.get('@generalSection_continue_btn').click();
        cy.get('[data-cy="cy-basicAuth__checkbox"]').click();
        cy.get('[data-cy="cy-intLdapUser_textInput"]').type(`${data.ldapUser1}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapUser_button"]').click();
        cy.get('[data-cy="cy-intLdapGroup_textInput"]').type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapGroup_button"]').click();
        cy.get('[data-cy="cy-internal-continue__button"]').as('intGateway_continue_btn');
        cy.get('@intGateway_continue_btn').click();
        cy.get('@endpoint_authType_ddl').then(validateDDLWithoutLIAMJwt());
        cy.get('@extGatewayAuth_panel_change_btn').click();
        cy.get('[for="liamJwtId"]').click();
        cy.get('@extGateway_continue_btn').click();
        cy.get('@endpoint_authType_ddl').then(validateDDLWithLIAMJwt());
        cy.get('[data-cy="cy-authentication-type__select"]').select('LIAMJwt').trigger('click');
        cy.get('@generalChangeBtn').click();
        cy.get('[data-cy="cy-external__checkbox_div"]').children('label.chi-checkbox__label').click();
        cy.get('@generalSection_continue_btn').click();
        cy.get('@endpoint_authType_ddl').then(validateDDLWithoutLIAMJwt());
        cy.get('[data-cy="cy-authentication-type__select"]').select('jwt').trigger('click');

        cy.get('[data-cy="cy-endpoint_finish__button"]').click();
        cy.get('[data-cy="cy-title-api-proxy-builder"]').find('h2.chi-modal__title').should('be.visible');
    });
});
