/// <reference types='Cypress'/>

import { featureFlagMenuActive } from '../../utils/utility';
import { getAllComponentList, getApiProxyDetails } from '../../utils/index.js';

describe('Products page is working', function () {
    beforeEach(function () {
        cy.mockLogin('', featureFlagMenuActive());
        getAllComponentList('products.json', 200).as('products');
        getApiProxyDetails([], '', 200);
        cy.visit('/exchange');
        cy.wait('@products', Cypress.config('defaultTimeout'));
    });

    it('Search tab is visible', () => {
        cy.get('[data-cy="cy-products_tab"]').click({ force: true });
        cy.get('[data-cy="cy-product__search-input"]').find('input').as('product__search-input');
        cy.get('@product__search-input').should('be.visible');
        cy.get('@product__search-input').type('ntfwfSrvcImpPort', { delay: 0 });
        cy.get('@product__search-input').clear();
        cy.get('@product__search-input').type('Adaptive/Inventory', { delay: 0 });
        cy.get('@product__search-input').clear();
        cy.get('[data-cy="cy-product-chi-data-table"]').as('product_data-table');
        cy.get('@product_data-table').contains('Name');
        cy.get('@product_data-table').contains('Created Date');
        cy.get('@product_data-table').contains('Updated By');
        cy.get('@product_data-table').contains('Last Updated Date');
        cy.get('@product_data-table').should('be.visible');
        cy.get('@product_data-table').find('a').should('not.exist');
    });
});
