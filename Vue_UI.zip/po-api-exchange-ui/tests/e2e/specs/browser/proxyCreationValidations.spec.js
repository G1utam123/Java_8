/// <reference types='Cypress'/>

import data from '../../fixtures/variables.json';
import { featureFlagApiOwnership } from '../../utils/utility';
import {
    getTaxonomy,
    getAppKeyDetails,
    getESPHealthStatus,
    postAPIProxyDeploy,
    getOwnershipDetails,
    postServiceNowGroupRequest,
} from '../../utils/index';

describe('validate all mandatory fields before proxy creation', function () {
    beforeEach(function () {
        cy.mockLogin('', featureFlagApiOwnership());
        getTaxonomy('taxonomies.json', 200).as('taxonomies');
        getAppKeyDetails('applicationkeys.json', 200);
        getESPHealthStatus('', 200);
        cy.visit('/proxy');
        cy.wait('@taxonomies');
    });

    it('Application key text field should appear as per the wireframe', () => {
        cy.get('[data-cy="cy-app-key__input"]').as('appkeyTxtField');
        cy.get('@appkeyTxtField').should('have.value', '');
        cy.get('@appkeyTxtField').should('not.be.disabled');
        cy.get('[data-cy="cy-app-key__select"]').as('cmstagTxtField');
        cy.get('@cmstagTxtField').should('have.value', '');
        cy.get('[data-cy="cy-general__epanel"]').find('i.icon-x').should('not.exist');
        cy.get('@appkeyTxtField').next('button').as('searchIcon');
        cy.get('@searchIcon').find('i.icon-search').and('have.css', 'color', 'rgb(49, 51, 54)');
        cy.get('@searchIcon').should('be.visible').and('be.enabled');

        cy.get('@appkeyTxtField').type(`${data.applicationKey}`, { delay: 0 });
        cy.get('@appkeyTxtField').should('be.disabled');
        cy.get('@searchIcon').should('be.visible').and('be.enabled');
        cy.get('[data-cy="cy-app-key__input"]').should('have.css', 'background-color', 'rgb(248, 249, 249)');
        cy.get('@cmstagTxtField').invoke('val').should('not.be.empty');
        cy.get('@cmstagTxtField').should('not.be.disabled');
        cy.get('[data-cy="cy-general__epanel"]').find('i.icon-x').should('be.visible').and('not.be.disabled').click();
        cy.get('@appkeyTxtField').should('have.value', '');
        cy.get('@appkeyTxtField').should('not.be.disabled');
        cy.get('@cmstagTxtField').invoke('val').should('be.empty');
        cy.get('[data-cy="cy-general__epanel"]').find('i.icon-x').should('not.exist');
        cy.get('@searchIcon').should('be.visible').and('be.enabled');
    });

    it('Do not allow proxy creation if mandatory fields are empty', () => {
        getOwnershipDetails(data.malCode, '', 404).as('ownerships');
        cy.get('[data-cy="cy-app-key__input"]').as('appKey_input_ele');
        cy.get('@appKey_input_ele').clear().type(`${data.applicationKey}`, { delay: 0 });
        cy.wait('@ownerships');
        cy.get('[data-cy="cy-managementRights__epanel"]').should('exist');

        cy.get('[data-cy="cy-app-key__select"]').as('sysgen_id_ele');
        cy.get('@sysgen_id_ele').clear().type(`${data.sysgenId}`, { delay: 0 });
        cy.get('[data-cy="cy-service-type__select"]').as('serviceType_ele');
        cy.get('@serviceType_ele').select('Inbound').trigger('click');
        cy.get('[data-cy="cy-internal-checkbox__div"]').as('internal_CheckBox_ele');
        cy.get('@internal_CheckBox_ele').click();
        cy.get('[data-cy="cy-external__checkbox_div"]').as('external_CheckBox_ele');
        cy.get('@external_CheckBox_ele').click();
        cy.get('[data-cy="cy-general-continue__button"]').as('general-continue__button');
        cy.get('@general-continue__button').click();

        cy.get('[data-cy="cy-service-category__select"]').as('taxonomy_textBox_ele');
        cy.get('@taxonomy_textBox_ele').type(`${data.taxonomy}`, { delay: 0 });
        cy.get('[data-cy="cy-version__select"]').as('appVersion_dropDown_ele');
        cy.get('@appVersion_dropDown_ele').select('1').trigger('click');
        cy.get('[data-cy="cy-resourcename__input"]').as('resourceName_textBox_ele');
        cy.get('@resourceName_textBox_ele').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-gatewayEndpoint-continue__button"]').as('gatewayEndpoint-continue__button');
        cy.get('@gatewayEndpoint-continue__button').click();

        cy.get('[data-cy="cy-dev1-host__input"]').as('dev1_textBox_ele');
        cy.get('@dev1_textBox_ele').type(`${data.dev1HostName}`, { delay: 0 });
        cy.get('[data-cy="cy-resource-path__input"]').type(`${data.resourcePath}`, { delay: 0 });
        cy.get('[data-cy="cy-target-Endpoint-continue__button"]').as('target-Endpoint-continue__button');
        cy.get('@target-Endpoint-continue__button').click();

        cy.get('[data-cy="cy-int-appln-key_label"]').as('int_appkey_chkbox_ele');
        cy.get('@int_appkey_chkbox_ele').click();
        cy.get('[data-cy="cy-checkbox-enforceTaxonamy"]').find('.chi-checkbox__label').click();
        cy.get('[data-cy="cy-checkbox-enforceDigest"]').find('.chi-checkbox__label').click();
        cy.get('[data-cy="cy-internal-continue__button"]').as('internal-continue__button');
        cy.get('@internal-continue__button').click();

        cy.get('[data-cy="cy-extoAuth__checkbox"]').click();
        cy.get('[data-cy="cy-ext-continue__button"]').as('external_Section_Countinue-btn');
        cy.get('@external_Section_Countinue-btn').click();

        cy.get('[data-cy="cy-endpoint-authentication-continue__button"]')
            .parents()
            .find('.-active')
            .contains('Continue')
            .as('endpoint-authentication-continue__button');
        cy.get('@endpoint-authentication-continue__button').click();

        cy.get('.-status').contains('Please select Authentication Type').should('be.visible');
        cy.get('.-active').find('[data-cy="cy-authentication-type__select"]').select('JWT').trigger('click');
        cy.get('@endpoint-authentication-continue__button').click();

        cy.get('[data-cy="cy-mrights_finish__button"]')
            .parents()
            .find('.-active')
            .contains('Create Proxy')
            .as('createProxy-Btn');

        cy.get('[data-cy="cy-general__epanel"]')
            .find('.chi-epanel__header')
            .find('.chi-epanel__action')
            .find('.chi-button')
            .click();

        cy.get('[data-cy="cy-general__epanel"]').find('i.icon-x').click();
        cy.get('@general-continue__button').click();
        cy.get('.chi-modal__header').should('not.exist');
        cy.get('[data-cy="cy-general-error_Applicationkey"]')
            .contains('Please select an Application Key from the list')
            .scrollIntoView()
            .should('be.visible');

        cy.get('@appKey_input_ele').clear().type(`${data.applicationKey}`, { delay: 0 });
        cy.get('@sysgen_id_ele').clear();
        cy.get('@general-continue__button').click();
        cy.get('.chi-modal__header').should('not.exist');
        cy.get('[data-cy="cy-general-error_MalId"]')
            .scrollIntoView()
            .contains('Please provide CMS Asset Tag / ID #')
            .should('be.visible');

        cy.get('@sysgen_id_ele').clear().type(`${data.sysgenId}`, { delay: 0 });
        cy.get('@serviceType_ele').select('Select').trigger('click');
        cy.get('@general-continue__button').click();
        cy.get('.chi-modal__header').should('not.exist');
        cy.get('[data-cy="cy-general-error_Service"]')
            .contains('Please select a Service Type')
            .scrollIntoView()
            .should('be.visible');

        cy.get('@serviceType_ele').select('Outbound').trigger('click');
        cy.get('@internal_CheckBox_ele').click();
        cy.get('@external_CheckBox_ele').click();
        cy.get('@general-continue__button').click();
        cy.get('.chi-modal__header').should('not.exist');
        cy.get('.-status').contains(`${data.general_checkBox_error_message}`).scrollIntoView().should('be.visible');

        cy.get('@internal_CheckBox_ele').click();
        cy.get('@external_CheckBox_ele').click();
        cy.get('[data-cy="cy-gatewayEndpoint__epanel"]').children().find('button').contains('Change').click();
        cy.get('@taxonomy_textBox_ele').clear();
        cy.get('@gatewayEndpoint-continue__button').click();
        cy.get('.chi-modal__header').should('not.exist');
        cy.get('[data-cy="cy-gatewayEndpoint-error_Taxonamy"]')
            .contains('Please select a Taxonomy from the list')
            .scrollIntoView()
            .should('be.visible');

        cy.get('@taxonomy_textBox_ele').type(`${data.taxonomy}`, { delay: 0 });
        cy.get('@appVersion_dropDown_ele').select('Select').trigger('click');
        cy.get('@gatewayEndpoint-continue__button').click();
        cy.get('.chi-modal__header').should('not.exist');
        cy.get('[data-cy="cy-gatewayEndpoint-error_Version"]')
            .contains('Please select a Version')
            .scrollIntoView()
            .should('be.visible');

        cy.get('@appVersion_dropDown_ele').select('1').trigger('click');
        cy.get('@resourceName_textBox_ele').clear();
        cy.get('@gatewayEndpoint-continue__button').click();
        cy.get('.chi-modal__header').should('not.exist');
        cy.get('[data-cy="cy-resourcename__err"]')
            .contains('Please provide a Resource')
            .scrollIntoView()
            .should('be.visible');

        cy.get('@resourceName_textBox_ele').type(`${data.resourceName}`, { delay: 0 });
        cy.get('[data-cy="cy-targetEndpoint__epanel"]').children().find('button').contains('Change').click();

        cy.get('@dev1_textBox_ele').clear();
        cy.get('@target-Endpoint-continue__button').click();
        cy.get('.chi-modal__header').should('not.exist');
        cy.get('[data-cy="cy-test1-host__input"]').type(`${data.dev1HostName}`, { delay: 0 });

        cy.get('@target-Endpoint-continue__button').click();
        cy.get('@int_appkey_chkbox_ele').click().click();
        cy.get('@internal-continue__button').click();
        cy.get('.chi-modal__header').should('not.exist');
        cy.get('[data-cy="cy-internal-error__checkbox"]')
            .scrollIntoView()
            .contains(`${data.intExt_checkBox_error_message}`)
            .should('be.visible');
        cy.get('[data-cy="cy-int-basAuth_label"]').click();
        cy.get('@internal-continue__button').click();
        cy.get('.chi-modal__header').should('not.exist');
        cy.get('[data-cy="cy-intLdapUser&Group-enforce"]')
            .scrollIntoView()
            .contains(`${data.basicAuth_error_message}`)
            .should('be.visible');
        cy.get('#ldap_users_1-control').type(`${data.ldapUser}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapUser_button"]').find('.chi-button').click();
        cy.get('#ldap_group-control').type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('[data-cy="cy-intLdapGroup_button"]').find('.chi-button').click();

        cy.get('@internal-continue__button').click();
        cy.get('[data-cy="cy-extoAuth__checkbox"]').find('label').click();
        cy.get('[data-cy="cy-extoAuth__checkbox"]').find('label').click();
        cy.get('[data-cy="cy-endPoint__epanel"]').children().find('button').contains('Change').click();
        cy.get('[data-cy="cy-endpoint-authentication-continue__button"]').click();
        cy.get('@external_Section_Countinue-btn').click();
        cy.get('.chi-modal__header').should('not.exist');
        cy.get('[data-cy="cy-ext-error__checkbox"]')
            .scrollIntoView()
            .contains(`${data.intExt_checkBox_error_message}`)
            .should('be.visible');
        cy.get('[data-cy="cy-basicAuthExternal__checkbox"]').find('.chi-checkbox__label').click();
        cy.get('@external_Section_Countinue-btn').click();
        cy.get('.chi-modal__header').should('not.exist');
        cy.get('[data-cy="cy-extLdapUser&Group-enforce"]')
            .scrollIntoView()
            .contains(`${data.basicAuth_error_message}`)
            .should('be.visible');
        cy.get('#ldap_users-control').type(`${data.ldapUser}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapUser_button"]').find('.chi-button').click();
        cy.get('@external_Section_Countinue-btn').click();

        cy.get('[data-cy="cy-extActive__epanel"]').children().find('button').contains('Change').click();
        cy.get('[data-cy="cy-extLdapUser_delbutton"]').click();
        cy.get('[data-cy="cy-endPoint__epanel"]').children().find('button').contains('Change').click();
        cy.get('[data-cy="cy-endpoint-authentication-continue__button"]').click();
        cy.get('@external_Section_Countinue-btn').click();
        cy.get('.chi-modal__header').should('not.exist');
        cy.get('[data-cy="cy-extLdapUser&Group-enforce"]')
            .scrollIntoView()
            .contains(`${data.basicAuth_error_message}`)
            .should('be.visible');

        cy.get('[data-cy="cy-extLdapGroup_textInput"]')
            .find('#ldap_group-control')
            .type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapGroup_button"]').find('.chi-button').click();
        cy.get('@external_Section_Countinue-btn').click();
        cy.get('[data-cy="cy-extActive__epanel"]').children().find('button').contains('Change').click();
        cy.get('[data-cy="cy-extLdapGroup_delbutton"]').click();
        cy.get('[data-cy="cy-endPoint__epanel"]').children().find('button').contains('Change').click();
        cy.get('[data-cy="cy-endpoint-authentication-continue__button"]').click();
        cy.get('@external_Section_Countinue-btn').click();
        cy.get('.chi-modal__header').should('not.exist');
        cy.get('[data-cy="cy-extLdapUser&Group-enforce"]')
            .scrollIntoView()
            .contains(`${data.basicAuth_error_message}`)
            .should('be.visible');

        cy.get('#ldap_users-control').type(`${data.ldapUser}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapUser_button"]').find('.chi-button').click();
        cy.get('[data-cy="cy-extLdapGroup_textInput"]')
            .find('#ldap_group-control')
            .type(`${data.ldapGroup1}`, { delay: 0 });
        cy.get('[data-cy="cy-extLdapGroup_button"]').find('.chi-button').click();
        cy.get('@external_Section_Countinue-btn').click();

        postAPIProxyDeploy('', 'apbSuccessResponse.json', 200).as('proxyBuild');
        postServiceNowGroupRequest('RITM4506288', 200).as('groupRequest');
        cy.get('[data-cy="cy-mrights_finish__button"]').click();
        cy.get('[data-cy="cy-common__loader"]').should('be.visible');
    });
});
