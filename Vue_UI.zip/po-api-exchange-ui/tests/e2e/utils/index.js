import config from '../../../public/config-dev.json';

// ***** GET Calls ***** //
export function getAllComponentList(fixture, status) {
    return cy.intercept('GET', `${config.base_url}/v1/products/apigee?planet=PROD&internalExternal=EXTERNAL`, {
        fixture: fixture,
        statusCode: status,
    });
}

export function getAPIDocumentation(body, fixture, status) {
    return cy.intercept('GET', `${config.base_url}/v1/documentation/*`, {
        body: body,
        fixture: fixture,
        statusCode: status,
    });
}

export function getApiProxyDetails(body, fixture, status) {
    return cy.intercept('GET', `${config.base_url}/v1/apiProxyDetails*`, {
        body: body,
        fixture: fixture,
        statusCode: status,
    });
}

export function getAPIProductLists(body, fixture, status) {
    return cy.intercept('GET', `${config.base_url}/v1/apiproducts`, {
        body: body,
        fixture: fixture,
        statusCode: status,
    });
}

export function getAppDetailsOfUsers(fixture, status) {
    return cy.intercept('GET', `${config.base_url}/v1/userapps`, {
        fixture: fixture,
        statusCode: status,
    });
}

export function getAppKeyDetails(fixture, status) {
    return cy.intercept('GET', `${config.base_url}/v1/applicationKeys`, {
        fixture: fixture,
        statusCode: status,
    });
}

export function getDocumentationWithProxy(body, fixture, status) {
    return cy.intercept('GET', `${config.base_url}/v1/documentationwithproxy/*`, {
        body: body,
        fixture: fixture,
        statusCode: status,
    });
}

export function getDocFileDetailsOfProxies(fixture, status) {
    return cy.intercept('GET', `${config.base_url}/v1/docFile/*`, {
        fixture: fixture,
        statusCode: status,
    });
}

export function getEnvironmentDetailsOfProxies(body, fixture, status) {
    return cy.intercept('GET', `${config.base_url}/v1/apiEnvironments?resourceGuid=*`, {
        body: body,
        fixture: fixture,
        statusCode: status,
    });
}

export function getESPHealthStatus(fixture, status) {
    return cy.intercept('GET', `${config.base_url}/v1/health/esp`, {
        fixture: fixture,
        statusCode: status,
    });
}

export function getTaxonomy(fixture, status) {
    return cy.intercept('GET', `${config.base_url}/v1/taxonomies`, {
        fixture: fixture,
        statusCode: status,
    });
}

export function getOwnershipDetails(malCode, fixture, status) {
    return cy.intercept('GET', `${config.base_url}/v1/ownerships/${malCode}`, {
        fixture: fixture,
        statusCode: status,
    });
}

// ***** POST Calls ***** //
export function postAddNewDocForProxy(body, status) {
    return cy.intercept('POST', `${config.base_url}/v1/newdoc`, {
        body: body,
        statusCode: status,
    });
}

export function postAPIProxyDeploy(body, fixture, status) {
    return cy.intercept('POST', `${config.base_url}/v1/postProxyBuildDeploy`, {
        body: body,
        fixture: fixture,
        statusCode: status,
    });
}

export function postCreateNewApi(fixture, status) {
    return cy.intercept('POST', `${config.base_url}/v1/addnewapi`, {
        fixture: fixture,
        statusCode: status,
    });
}

export function postCreateUserApps(body, fixture, status) {
    return cy.intercept('POST', `${config.base_url}/v1/createuserapps`, {
        body: body,
        fixture: fixture,
        statusCode: status,
    });
}

export function postFeedback(status) {
    return cy.intercept('POST', `${config.base_url}/v1/feedback`, {
        statusCode: status,
    });
}

export function postMigrateApiProxies(body, status) {
    return cy.intercept('POST', `${config.base_url}/v1/migrateApiProxies`, {
        body: body,
        statusCode: status,
    });
}

export function postSaveAPIProxyDetails(fixture, status) {
    return cy.intercept('POST', `${config.base_url}/v1/saveApiProxies`, {
        fixture: fixture,
        statusCode: status,
    });
}

export function postServiceNowGroupRequest(body, status) {
    return cy.intercept('POST', `${config.base_url}/v1/servicenow/grouprequest`, {
        body: body,
        statusCode: status,
    });
}

export function postUpdateUserApps(body, fixture, status) {
    return cy.intercept('POST', `${config.base_url}/v1/updateuserapps`, {
        body: body,
        fixture: fixture,
        statusCode: status,
    });
}

// ***** PUT calls ***** //
export function putEditAPIDocuments(status) {
    return cy.intercept('PUT', `${config.base_url}/v1/editdoc`, {
        statusCode: status,
    });
}

export function putUpdateAPIDocuments(status) {
    return cy.intercept('PUT', `${config.base_url}/v1/updateapi/*`, {
        statusCode: status,
    });
}

export function putUpdateAPIDocSequence(status) {
    return cy.intercept('PUT', `${config.base_url}/v1/updatesequence`, {
        statusCode: status,
    });
}

// ***** DELETE calls ***** //
export function deleteAPIs(status) {
    return cy.intercept('DELETE', `${config.base_url}/v1/deleteapi/*`, {
        statusCode: status,
    });
}

export function deleteAPIProxies(status) {
    return cy.intercept('DELETE', `${config.base_url}/v1/deleteapiProxies/*`, {
        statusCode: status,
    });
}

export function deleteDocumentDetailsOfAPIs(docId, status) {
    return cy.intercept('DELETE', `${config.base_url}/v1/documentation/${docId}`, {
        statusCode: status,
    });
}

export function deleteUserApps(data, status, message) {
    return cy.intercept('DELETE', `${config.base_url}/v1/deleteuserapp/*`, {
        data: data,
        statusCode: status,
        message: message,
    });
}
