import sinon from 'sinon';
import { mount } from '@vue/test-utils';

export function destroyStub() {
    const spy = sinon.stub();
    mount({
        template: '<div></div>',
        destroyed() {
            spy();
        },
    }).destroy();
    expect(spy.calledOnce).to.be.true;
}

export function featureFlagMenuActive() {
    return {
        flags: {
            apienable_apihub_menu_active: true,
        },
    };
}

export function featureFlagApiOwnership() {
    return {
        flags: {
            apienable_apihub_api_ownership: true,
        },
    };
}

export function validateDDLWithLIAMJwt() {
    return (options) => {
        expect([...options].map((option) => option.value)).to.be.deep.equal([
            '',
            'none',
            'authHeaderPassThrough',
            'basicAuth',
            'jwt',
            'LIAMJwt',
            'oAuth',
            'x509Cert',
        ]);
    };
}

export function validateDDLWithoutLIAMJwt() {
    return (options) => {
        expect([...options].map((option) => option.value)).to.be.deep.equal([
            '',
            'none',
            'authHeaderPassThrough',
            'basicAuth',
            'jwt',
            'oAuth',
            'x509Cert',
        ]);
    };
}
