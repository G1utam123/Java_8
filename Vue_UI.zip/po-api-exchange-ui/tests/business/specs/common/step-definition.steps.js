import { Given } from 'cypress-cucumber-preprocessor/steps';

Given('I test condition one', () => {
    cy.mockLogin();
    cy.visit('/');
    cy.window().its('chi').should('exist');
});
