// Import commands.js using ES2015 syntax:
import '../../common/commands';

// For accesibility tests
import 'cypress-axe';

// Code coverage
import '@cypress/code-coverage/support';
