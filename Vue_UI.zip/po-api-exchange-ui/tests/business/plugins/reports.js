const report = require('multiple-cucumber-html-reporter');

report.generate({
    jsonDir: 'tests/business/reports/cucumber-json/',
    reportPath: 'tests/business/reports/cucumber-html/',
    hideMetadata: true,
    pageTitle: 'Business tests report',
    reportName: 'Business tests report',
    displayDuration: true,
    displayReportTime: true,
});
