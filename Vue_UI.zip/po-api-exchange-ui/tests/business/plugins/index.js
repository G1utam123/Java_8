const cucumber = require('cypress-cucumber-preprocessor').default;

module.exports = (on, config) => {
    require('@cypress/code-coverage/task')(on, config);
    on('file:preprocessor', require('@cypress/code-coverage/use-babelrc'));
    on('file:preprocessor', cucumber());

    require('dotenv').config();
    config.env.VUE_APP_CUSTOMIZE = process.env.VUE_APP_CUSTOMIZE;

    config.fixturesFolder = 'tests/business/fixtures';
    config.integrationFolder = 'tests/business/specs';
    config.screenshotsFolder = 'tests/business/screenshots';
    config.videosFolder = 'tests/business/videos';
    config.supportFile = 'tests/business/support/index.js';

    return config;
};
