/* import { expect } from 'chai';
import { shallowMount, Wrapper } from '@vue/test-utils';
import Reports from '@/components/Reports.vue';

describe('Reports.vue', () => {
    let wrapper: Wrapper<Reports>;
    beforeEach(async () => {
        wrapper = shallowMount(Reports, {
            propsData: {
                location: ['madrid', 'Madrid'],
                token:
                    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ',
            },
        });
    });
    it('render reports component should contain reports class', () => {
        expect(wrapper.classes()).to.include('reports');
    });
    it('check selectReport function invoked', () => {
        wrapper.find('[data-ut="ut-select-report-1"]').trigger('click');
        expect(wrapper.vm.reportSelected).to.equals(1);
    });
});
 */
