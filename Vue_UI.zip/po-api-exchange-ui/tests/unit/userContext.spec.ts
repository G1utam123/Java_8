import { createLocalVue } from '@vue/test-utils';
import Vuex from 'vuex';
import { getModule } from 'vuex-module-decorators';
import sinon from 'sinon';
import { expect } from 'chai';
import Store from '@/_store';

describe('utils', () => {
    let store: any;

    before(() => {
        const localVue = createLocalVue();
        localVue.use(Vuex);
        store = new Vuex.Store({
            getters: {
                userContext: () => {
                    return {
                        groups: ['APIHUB PRODUCT_1', 'APIHUB PRODUCT_2', 'test1', 'test2'],
                    };
                },
            },
            actions: {
                userContext: sinon.spy(),
            },
        });
        Store.register(store);
    });

    after(() => {
        Store.unregister(store);
    });

    afterEach(() => {
        sinon.reset();
    });

    it('loadUserContext', async () => {
        const module = getModule(Store, store);
        module.loadUserContext(store.getters.userContext);
        const userContext = module.getUserContext;
        expect(userContext.groups.length).to.equal(2);
    });

    it('setUserContext', async () => {
        const module = getModule(Store, store);
        module.setUserContext(store.getters.userContext);
        const userContext = module.getUserContext;
        expect(userContext.groups.length).to.equal(2);
    });
});
