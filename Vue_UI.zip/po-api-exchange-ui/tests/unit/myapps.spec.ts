// import { mount, createLocalVue, Wrapper } from '@vue/test-utils';
// import sinon from 'sinon';
// import { expect } from 'chai';
// import Myapps from "@/modules/myapps/_components/MyAppLayout.vue";

// const localVue = createLocalVue();

// describe('My Apps Unit Tests', () => {
//     let wrapper: Wrapper<Myapps>;
//     beforeEach(async () => {
//         wrapper = mount(Myapps, {
//             localVue,
//         });
//     });

//     it('renders My Apps header', () => {
//         expect(wrapper.find('h2')).to.have.string('My Apps');
//     })
// })
