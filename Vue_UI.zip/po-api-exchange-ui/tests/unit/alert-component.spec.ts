import { expect } from 'chai';
import { shallowMount } from '@vue/test-utils';
import AlertComponent from '@/modules/common/_components/AlertComponent.vue';
import { Alert } from '@/models/alert';
import sinon from 'sinon';

describe('Alert Component test', () => {
    afterEach(() => {
        sinon.restore();
    });

    it('Custom type apb + click', () => {
        const stub = sinon.stub(window, 'open');
        const alertObject: Alert = new Alert('MessageTest', {
            custom: 'apb',
        });
        const component = shallowMount(AlertComponent, {
            propsData: {
                alertObject: alertObject,
            },
        });
        const link = component.find('[data-cy="cy-alert_link_apb"]');
        expect(link.isVisible()).to.equal(true);
        link.trigger('click');
        expect(stub.calledOnce).to.be.true;
    });

    it('Custom type groupRequest + click', () => {
        const stub = sinon.stub(window, 'open');
        const alertObject: Alert = new Alert('MessageTest', {
            custom: 'groupRequest',
        });
        const component = shallowMount(AlertComponent, {
            propsData: {
                alertObject: alertObject,
            },
        });
        const linkTrackIt = component.find('[data-cy="cy-alert_link_track_it"]');
        expect(linkTrackIt.isVisible()).to.equal(true);
        linkTrackIt.trigger('click');
        expect(stub.calledOnce).to.be.true;

        sinon.reset();

        const linkManagementRights = component.find('[data-cy="cy-alert_link_management_rights"]');
        expect(linkManagementRights.isVisible()).to.equal(true);
        linkManagementRights.trigger('click');
        expect(stub.calledOnce).to.be.true;

        sinon.reset();

        const linkAudio = component.find('[data-cy="cy-alert_link_audio"]');
        expect(linkAudio.isVisible()).to.equal(true);
        linkAudio.trigger('click');
        expect(stub.calledOnce).to.be.true;
    });
});
