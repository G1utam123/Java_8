/* import { expect } from 'chai';
import { shallowMount, createLocalVue, Wrapper } from '@vue/test-utils';
import Proxy from '@/modules/proxy/Proxy.vue';

describe('Proxy', () => {
    it('renders a div', () => {
        const wrapper = shallowMount(Proxy);
        expect(wrapper.contains('div')).equals(true);
    });
});
 */
