import { createLocalVue } from '@vue/test-utils';
import Vuex from 'vuex';
import { getModule } from 'vuex-module-decorators';

import sinon from 'sinon';
import { expect } from 'chai';

import ProxyStore from '@/modules/proxy/_store';
import { registerProxy } from '@/modules/proxy/_api/proxy';

describe('home store', () => {
    let store: any;

    before(() => {
        const localVue = createLocalVue();
        localVue.use(Vuex);
        store = new Vuex.Store({});
        ProxyStore.register(store);
    });

    after(() => {
        ProxyStore.unregister(store);
    });

    afterEach(() => {
        sinon.reset();
    });

    it('loadProxiesOwnership', async () => {
        const module = getModule(ProxyStore, store);
        let stub = sinon.stub(registerProxy, 'getOwnershipDetails').resolves({
            data: {
                UUID: '5034e58b-8a6d-4ed5-a754-1dd47b5a1a23',
                id: 'TESTELEMENTNAME5',
                type: 'PROXY',
                request: 'RITM4506288',
                status: 'PROVISIONING',
                requester: 'AD22342',
            },
        });
        await module.loadProxiesOwnership('TESTELEMENTNAME5');
        expect(stub.calledOnce).to.be.true;
        expect(module.getProxiesOwnership[0].ownershipId).to.contains('TESTELEMENTNAME5');
        expect(module.getProxiesOwnership[0].ownershipDetails?.status).to.contains('PROVISIONING');

        sinon.restore();

        stub = sinon.stub(registerProxy, 'getOwnershipDetails').rejects();
        await module.loadProxiesOwnership('TESTELEMENTNAME5');
        expect(stub.calledOnce).to.be.true;
        expect(module.getProxiesOwnership[0].ownershipId).to.contains('TESTELEMENTNAME5');
        expect(module.getProxiesOwnership[0].ownershipDetails).to.be.undefined;
    });
});
