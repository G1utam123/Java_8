/* import { expect } from 'chai';
import { shallowMount, createLocalVue, Wrapper } from '@vue/test-utils';
import HomeLayout from '@/modules/home/_components/HomeLayout.vue';
import Vuex, { Store } from 'vuex';
import sinon from 'sinon';
import { RouterLinkStub } from '@vue/test-utils';
import { USER_SESSION } from './api-mock/userdata';
const localVue = createLocalVue();
localVue.use(Vuex);
describe('HomeLayout', () => {
    let wrapper: Wrapper<HomeLayout>;
    let vuexStore: Store<any>;
    let actions: any;
    beforeEach(async () => {
        actions = {
            '$_api_exchange_home/loadMicroappData1': sinon.spy(),
        };
        vuexStore = new Vuex.Store({
            getters: {
                userContext: () => {
                    return {
                        session: {
                            enterprise: USER_SESSION.enterprise,
                        },
                    };
                },
            },
            actions: actions,
        });
        wrapper = shallowMount(HomeLayout, {
            store: vuexStore,
            localVue,
            stubs: {
                RouterLink: RouterLinkStub,
            },
        });
        wrapper.setData({ url: 'http://localhost:8080' });
    });
    it('render homelayout', () => {
        expect(wrapper.find('[data-ut="ut-home"]').isVisible()).to.equal(true);
    });
});
 */
