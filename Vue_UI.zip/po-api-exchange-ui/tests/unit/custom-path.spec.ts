import { expect } from 'chai';
import sinon from 'sinon';
import { getPublicPath } from '@/utils/constants';

describe('custom path', () => {
    it('default mode', () => {
        const publicPath: string = getPublicPath();
        expect(publicPath).to.eq('/');
    });
    it('traditional mode', () => {
        const traditionalMode: string = '';

        const publicPath: string = getPublicPath(traditionalMode);
        expect(publicPath).to.eq('/enterprise');
    });
    it('standalone mode', () => {
        const standaloneMode: string = 'enterprise-nav,shell';

        const publicPath: string = getPublicPath(standaloneMode);
        expect(publicPath).to.eq('/');
    });
});
