export default [
    [
        {
            data: null,
            status: 0,
            message: null,
            cachedResponse: false,
            responseTime: 0,
            networkResponseTime: 0,
            result: null,
            addlResults: null,
            queriedOnCache: false,
            createDate: '2021-03-24T17:28:14',
            updateDate: '2021-04-26T09:48:49',
            secondaryKey: null,
            supplementalInfo: null,
            reqText: null,
            enterpriseId: null,
            avgResponseTime: 0,
            alertType: null,
            activityType: null,
            viewName: 'TestviewName',
            viewData:
                '{"columnResize":true,"noResultsMessage":"No Results Found....NONO....","activePage":1,"resultsPerPage":10,"selectable":true,"style":{"portal":false,"bordered":false,"noBorder":true,"hover":false,"striped":true,"size":"xs"},"pagination":{"compact":false,"firstLast":true,"pageJumper":true},"columnSizes":{"xs":["0","5","15","5","5","5","5","5"],"sm":["10","0","5","15","5","5","5","5"],"md":["5","10","0","5","15","5","5","5"],"lg":["10","5","10","0","5","15","5","5"],"xl":["0","5","5","10","0","5","15","5"]}}',
            isDefault: false,
            isSticky: false,
        },
    ],
];
