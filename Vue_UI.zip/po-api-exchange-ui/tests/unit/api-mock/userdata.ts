export const USER_SESSION = { enterprise: 11332267433 };
