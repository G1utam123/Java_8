import { expect } from 'chai';

describe('Placeholder prod test', () => {
    it('Placeholder passes', () => {
        expect('a').to.not.be.null;
    });
});
