const prepare = require('mocha-prepare');

const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
const { JSDOM } = require('jsdom');

const { APP_CUSTOMIZE, isAppCustomized } = require('../../src/utils/constants');

prepare(async (done) => {
    let chiUrl = '';

    if (isAppCustomized(APP_CUSTOMIZE.SHELL)) {
        let importedShell = require('@centurylink/po-enterprise-shell');
        chiUrl = importedShell.library.chiUrl;
    } else {
        const https = require('https');
        const agent = new https.Agent({
            rejectUnauthorized: false,
        });

        const options = [{}, { agent }];
        const urls = [];

        urls.push(process.env.VUE_APP_VUE_VERSION);
        urls.push(process.env.VUE_APP_SHELL + 'shell.umd.js');

        const responses = await Promise.all(urls.map(async (u, index) => await fetch(u, options[index])));
        const scripts = await Promise.all(responses.map((res) => res.text()));
        const content = `<script>${scripts[0]}</script><script>${scripts[1]}</script>`;

        let dom = new JSDOM(content, { runScripts: 'dangerously' });
        chiUrl = dom.window.shell.library.chiUrl;
    }

    let res = await fetch(`${chiUrl}js/chi.js`);
    res = await res.text();
    window.eval(res);

    done();
});
