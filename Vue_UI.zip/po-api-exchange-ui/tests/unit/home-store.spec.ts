import { createLocalVue } from '@vue/test-utils';
import Vuex from 'vuex';
import { getModule } from 'vuex-module-decorators';

import sinon from 'sinon';
import { expect } from 'chai';

import HomeStore from '@/modules/exchange/_store';
import { homeApi } from '@/modules/exchange/_api/home';
import { UUID } from '@/utils/uuid';

describe('home store', () => {
    let store: any;

    before(() => {
        const localVue = createLocalVue();
        localVue.use(Vuex);
        store = new Vuex.Store({});
        HomeStore.register(store);
    });

    after(() => {
        HomeStore.unregister(store);
    });

    afterEach(() => {
        sinon.reset();
    });

    it('deleteApi', async () => {
        const module = getModule(HomeStore, store);

        let stub = sinon.stub(homeApi, 'deleteApi').resolves();
        await module.deleteApi({ apiId: UUID.newUuid(), apiName: 'api-name' });
        expect(stub.calledOnce).to.be.true;
        expect(module.successResponse.deleteSuccess).to.contains('api-name deleted successfully');

        sinon.restore();

        stub = sinon.stub(homeApi, 'deleteApi').rejects('error-value');
        await module.deleteApi({ apiId: UUID.newUuid(), apiName: 'api-name' });
        expect(stub.calledOnce).to.be.true;
        expect(module.errorDetails.deleteError.name).to.contains('error-value');
    });
    it('getDocumentData', async () => {
        const module = getModule(HomeStore, store);

        let stub = sinon.stub(homeApi, 'getDocuments').resolves({ data: 'value-returned' });
        await module.getDocumentData(UUID.newUuid());
        expect(stub.calledOnce).to.be.true;
        expect(module.documentData).to.contains('value-returned');

        sinon.restore();

        stub = sinon.stub(homeApi, 'getDocuments').rejects('error-value');
        await module.getDocumentData(UUID.newUuid());
        expect(stub.calledOnce).to.be.true;
        expect(module.errorDetails.documentError.name).to.contains('error-value');
    });
    it('deleteDocuments', async () => {
        const module = getModule(HomeStore, store);

        let stub = sinon.stub(homeApi, 'deleteDocument').resolves();
        await module.deleteDocuments(0);
        expect(stub.calledOnce).to.be.true;
        expect(module.successResponse.deleteSuccess).to.contains('ok');

        sinon.restore();

        stub = sinon.stub(homeApi, 'deleteDocument').rejects('error-value');
        await module.deleteDocuments(0);
        expect(stub.calledOnce).to.be.true;
        expect(module.errorDetails.deleteError.name).to.contains('error-value');
    });
    it('addApi', async () => {
        const module = getModule(HomeStore, store);

        let stub = sinon.stub(homeApi, 'addApi').resolves({ data: 'value-returned' });
        await module.addApi({});
        expect(stub.calledOnce).to.be.true;
        expect(module.successResponse.addSuccess).to.contains('ok');
        expect(module.apiData).to.contains('value-returned');

        sinon.restore();

        stub = sinon.stub(homeApi, 'addApi').rejects('error-value');
        await module.addApi({});
        expect(stub.calledOnce).to.be.true;
        expect(module.errorDetails.addError.name).to.contains('error-value');
    });
    it('addTextSection', async () => {
        const module = getModule(HomeStore, store);

        let stub = sinon.stub(homeApi, 'addTextSection').resolves();
        await module.addTextSection({ data: {}, type: 'add' });
        expect(stub.calledOnce).to.be.true;
        expect(module.successResponse.addTextSuccess).to.contains('ok');

        sinon.restore();

        stub = sinon.stub(homeApi, 'addTextSection').rejects('error-value');
        await module.addTextSection({ data: {}, type: 'add' });
        expect(stub.calledOnce).to.be.true;
        expect(module.errorDetails.addTextError.name).to.contains('error-value');
    });
});
