/* import { expect } from 'chai';
import { shallowMount, createLocalVue, Wrapper, mount } from '@vue/test-utils';
import overview from '@/modules/apiDetail/overview.vue';
const localVue = createLocalVue();
describe('overview', () => {
    let wrapper: Wrapper<overview>;
    beforeEach(async () => {
        wrapper = shallowMount(overview, {
            mocks: {
                $route: {
                    params: {
                        API: { id: 33, name: 'dynamic connections', category: 'Category', desc: 'dynamic connections' },
                    },
                },
            },
        });
    });
    it('should check the overview is mounted', () => {
        expect(wrapper.find('[data-ut="overview"]').isVisible()).to.equal(true);
    });
});
 */
