import JwtDecode from 'jwt-decode';

let sign = require('jwt-encode');
let merge = require('lodash.merge');
let clonedeep = require('lodash.clonedeep');
const { v4: uuidv4 } = require('uuid');

const SECRET_KEY = 'teu8bAjCwNjbh+jQ8wvARtCEnk/BQ0+qMzGfHh73ll02En6A25F+L7cGk6ohq7ga\n';
const REFRESH_DURATION_SECS = 43200;
const ACCESS_DURATION_SECS = 300;
const ACCESS_ISS = 'APPKEY1234520210510122145656453533';

const PROFILE = {
    name: 'sdl',
    last_name: 'plc',
    email: 'psankee@centurylink.com',
    principal: '12197661',
    cid: 'BMG',
    details: {
        alertsUnreadCount: 19,
        channelId: 'BMG',
        customerNumbers: ['1-96SPIN'],
        defLabels: [
            '/billing',
            '/billing/autopay/autopay-management',
            '/billing/billingrequest',
            '/billing/billingrequest/accountselection',
            '/billing/billingrequest/billingrequestdetails',
            '/billing/billpdfready',
            '/billing/payment',
            '/billing/payment/makepayment-smb',
            '/billing/payment/makepayment',
            '/billing/paymenthistory/CTLPaymentHistory',
            '/billing/paymenthistory/paymenthistory-smb',
            '/commercialAlertCenter',
            '/home',
            '/home/my-profile',
            '/inventory',
            '/inventory/Inventory',
            '/janus/jweb/private/JanusRelocateServlet',
            '/nibs',
            '',
        ],
        displayUsername: 'sdlplc',
        emailAddress: 'psankee@centurylink.com',
        enterpriseName: 'LEVEL3A-VALIDATIONS',
        enterpriseProducts: [
            'ACCESS CIRCUIT',
            'ACCESS CIRCUIT UNPROTECTED',
            'CPE',
            'CPE UNPROTECTED',
            'DSL',
            'INTERNET ADVANTAGE (IA)',
            'IP VPN',
        ],
        firstName: 'sdl',
        is2faUser: 'false',
        isCalnetGlobalUserPresent: 'false',
        isVoipUser: 'false',
        jobTitle: 'QA',
        lastName: 'plc',
        phone: '3029902390',
        portalSiteId: 'qportal',
        realm: 'PARTNER',
        remoteETFIUser: 'sdlplc',
        rogue: {},
        setUpRequired: 'null',
        timeZone: 'GMT',
        userApplicableSrcSystem: 'KENAN',
        userId: 12197661,
        username: 'sdlplc@env1.com',
        userProducts: ['IP VPN', 'INTERNET ADVANTAGE (IA)', 'ACCESS CIRCUIT UNPROTECTED', 'CPE UNPROTECTED'],
        userType: 'PORTAL',
        uuid: '3a61a6e2-4989-414a-9114-b1e238fc4ce3',
        vapDomain: 'https://controlcenter-test1.lumen.com',
        xctCookieName: 'APPSEC_PARTNER_SESSION',
    },
    groups: [
        'Billing Payments Write Role',
        'Billing Read Role',
        'Billing Requests Write Role',
        'CC Portal Role',
        'Data Read Role',
        'Data Write Role',
        'DHS Custom Metrics Role',
        'Globys Read Role',
        'Globys Write Role',
        'Internet Read Role',
        'Internet Write Role',
        'IP Configuration Read Role',
        'L3PP APM Manage Monitor Write Role',
        'L3PP DDoS Self Service Read Role',
        'L3PP DDoS Self Service Write Role',
        'L3PP DoS Protection Write Role',
        'L3PP ELS Write Role',
        'L3PP Elynk Write Role',
        'L3PP Email and Web Security Write Role',
        'L3PP Encrypted Wave Write Role',
        'L3PP LD/TF Write Role',
        'L3PP LI Write Role',
        'Network Visibility Dashboard Read Role',
        'Ordering Read Role',
        'Ordering Write Role',
        'Portal End User Role',
        'QCONTROL_CSA',
        'Repair Read Role',
        'User Management Role',
        'Voice Read Role',
        'Voice Write Role',
        'Billing Write Role',
    ],
    enterprises: [
        {
            defaultPortalCode: 'MY_LEVEL_3',
            defaultPortalOptions: ['CONTROL_CENTER', 'MY_LEVEL_3'],
            defaultIndicator: false,
            enterpriseChannelId: 'BMG',
            enterpriseId: '11172405',
            enterpriseName: 'LEVEL3A-VALIDATIONS',
            visited: false,
        },
        {
            defaultPortalCode: 'CONTROL_CENTER',
            defaultPortalOptions: ['CONTROL_CENTER', 'MY_LEVEL_3'],
            defaultIndicator: true,
            enterpriseChannelId: 'BMG',
            enterpriseId: '11167508',
            enterpriseName: 'LEVEL3B-VALIDATIONS',
            enterpriseAliasName: '-',
            visited: true,
        },
    ],
    menus: [],
    accounts: [{ accountId: '478136695', accountName: 'TEAL SERVICES LLC', customerNumber: null }],
    account_groups: [
        {
            entitlementId: 3342721,
            entitlementTypeCode: 'EG',
            groupId: '12117753',
            groupDescription: null,
            groupName: '12117753',
            srcGroupId: null,
            enterpriseId: 12117753,
            allKenanIndicator: false,
            directAssignedIndicator: true,
            inheritedIndicator: false,
            unassignedIndicator: false,
        },
    ],
    flags: { isNotificationSettingsAvailable: true },
};

const getEntepriseId = profile => {
    const enterprise =
        !!profile && !!profile.enterprises
            ? profile.enterprises.find(enterprise => enterprise.enterpriseName === profile.details.enterpriseName)
            : undefined;
    return !!enterprise ? enterprise.enterpriseId : undefined;
};

const getEnv = env => {
    return !!env ? env : 'test1';
};

const hasCcmaDetails = sessionType => {
    return ['asUser', 'asEnterprise', 'enterpriseAsUser', 'employee'].includes(sessionType);
};

const getSessionId = env => {
    return uuidv4().substring(0, 8) + `22lt4gtxsYr2RCwfHN-iHQDhCSswbp.janus-${env}_0-lxomavmtceap697`;
};

class TokenMocker {
    profile;
    enterpriseId;
    env;
    sessionType;
    ccmaDetails;
    refreshToken;
    accessToken;
    issuedAt = Math.floor(Date.now() / 1000);
    sessionId;
    refreshDuration = REFRESH_DURATION_SECS;
    accessDuration = ACCESS_DURATION_SECS;
    secret = SECRET_KEY;

    tokenMockerFromPartialProfile(baseProfile, env) {
        this.profile = this.buildProfile(baseProfile);
        this.enterpriseId = getEntepriseId(this.profile);
        this.env = getEnv(env);
        this.sessionType = 'enterprise';
        this.ccmaDetails = undefined;
        this.sessionId = getSessionId(env);

        return this;
    }

    tokenMockerFromFullProfile(baseProfile, env, sessionType, ccmaDetails) {
        this.profile = clonedeep(baseProfile);
        this.enterpriseId = getEntepriseId(this.profile);
        this.env = getEnv(env);
        this.sessionType = !!sessionType ? sessionType : 'enterprise';
        this.ccmaDetails = hasCcmaDetails(this.sessionType) ? ccmaDetails : undefined;
        this.sessionId = getSessionId(env);

        return this;
    }

    tokenMockerFromJwt(jwt) {
        return this.tokenMockerFromRefresh(JwtDecode(jwt));
    }

    tokenMockerFromRefresh(refreshToken) {
        this.refreshToken = refreshToken;
        this.enterpriseId = refreshToken.enterprise;
        this.sessionType = refreshToken.type;
        this.env = refreshToken.env;
        this.sessionId = refreshToken.sid;
        return this;
    }

    signToken(token) {
        return sign(token, this.secret);
    }

    getBaseToken() {
        const token = {
            jti: uuidv4(),
            sid: this.sessionId,
            sub: this.profile.details.username,
            enterprise: this.enterpriseId,
            uid: this.profile.details.userId,
            username: this.profile.details.username,
            name: this.profile.name + ' ' + this.profile.last_name,
            realm: this.profile.details.realm,
            ouid: !!this.ccmaDetails ? this.ccmaDetails.ouid : this.profile.details.userId,
            ousername: !!this.ccmaDetails ? this.ccmaDetails.ousername : this.profile.details.username,
            oname: !!this.ccmaDetails ? this.ccmaDetails.oname : this.profile.name + ' ' + this.profile.last_name,
            orealm: !!this.ccmaDetails ? this.ccmaDetails.orealm : this.profile.details.realm,
            type: this.sessionType,
            mfa: this.profile.details.is2faUser,
            env: this.env,
            iat: this.issuedAt,
        };

        return token;
    }

    getAccessToken() {
        const token = this.getBaseToken();
        token.exp = token.iat + this.accessDuration;
        token.iss = ACCESS_ISS;
        token.access_type = 'access_token';
        return token;
    }

    getRefreshToken() {
        const token = this.getBaseToken();
        token.exp = token.iat + this.refreshDuration;
        token.access_type = 'refresh_token';
        token.cid = this.profile.cid;
        token.vdomain = this.profile.details.vapDomain;
        return token;
    }

    renewAccessToken() {
        const token = clonedeep(this.refreshToken);
        token.jti = uuidv4();
        token.iat = this.issuedAt;
        token.exp == token.iat + this.accessDuration;
        return token;
    }

    renewRefreshToken() {
        const token = clonedeep(this.refreshToken);
        delete token.vdomain;
        delete token.cid;
        token.iss = ACCESS_ISS;
        token.jti = uuidv4();
        token.iat = this.issuedAt;
        token.exp == token.iat + this.refreshDuration;
        return token;
    }

    buildNewTokens() {
        this.accessToken = this.getAccessToken();
        this.refreshToken = this.getRefreshToken();
        return this;
    }

    renewTokens() {
        this.accessToken = this.renewAccessToken();
        this.refreshToken = this.renewRefreshToken();
        return this;
    }

    tokenResponse() {
        return {
            access_token: this.signToken(this.accessToken),
            access_expires_in: this.accessDuration,
            refresh_token: this.signToken(this.refreshToken),
            refresh_expires_in: this.refreshDuration,
        };
    }

    getSampleProfile() {
        return clonedeep(PROFILE);
    }

    buildProfile(baseProfile) {
        return merge(this.getSampleProfile(), baseProfile);
    }
}

export class TokenMockerAnon extends TokenMocker {
    profile = { details: {} };
    sessionType = 'anon';

    getBaseToken() {
        return {
            jti: uuidv4(),
            username: 'anon',
            name: 'anon',
            type: 'anon',
            env: this.env,
            iat: this.issuedAt,
        };
    }
}

export default TokenMocker;
