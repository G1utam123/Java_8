import TokenMocker from './token-mocker';

let visitTimeout = 60000; // default value in cypress
let responseTimeout = 30000; // default value in cypress
let requestTimeout = 15000; // increased to avoid network issues (5000)
let commandTimeout = 15000; // increased to avoid network issues (4000)

const doNotContact = {
    data: null,
    status: 0,
    message: null,
    cachedResponse: false,
    responseTime: 0,
    networkResponseTime: 0,
    result: null,
    addlResults: null,
    queriedOnCache: false,
    customerNumbers: [],
    domains: ['@LUMEN.COM'],
    doNotContact: true,
};
const entitledMenu = [
    {
        'Control Center': {
            origin: [
                {
                    PF: 'https://controlcenter-test1.lumen.com/enterprise/',
                },
            ],
            menu: [],
        },
    },
];

const persistSession = 'CY_PERSIST_SESSION';
const persistRefreshTokenName = 'token';
const persistAccesssTokenName = 'accessToken';
let persistRefreshToken;
let persistAccessToken;

beforeEach(() => {
    if (Cypress.env(persistSession)) {
        if (!!persistRefreshToken) {
            localStorage.setItem(persistRefreshTokenName, persistRefreshToken);
        }
        if (!!persistAccessToken) {
            localStorage.setItem(persistAccesssTokenName, persistAccessToken);
        }
    }
});

afterEach(() => {
    if (Cypress.env(persistSession)) {
        persistRefreshToken = localStorage.getItem(persistRefreshTokenName);
        persistAccessToken = localStorage.getItem(persistAccesssTokenName);
    }
});

after(() => {
    Cypress.env(persistSession, false);
    persistRefreshToken = undefined;
    persistAccessToken = undefined;
});

Cypress.Commands.add('persistSession', () => {
    Cypress.env(persistSession, true);
});

const skipStubSharedResources = 'CY_SKIP_STUB_SHARED_RESOURCES';
const ALERTS = 'alerts';
const MENUS = 'menus';
const DO_NOT_CONTACT = 'donotcontact';

Cypress.Commands.add('skipStubSharedResources', resourceList => {
    let resourcesToSkip = [];
    if (resourceList.includes(ALERTS)) resourcesToSkip.push(ALERTS);
    if (resourceList.includes(MENUS)) resourcesToSkip.push(MENUS);
    if (resourceList.includes(DO_NOT_CONTACT)) resourcesToSkip.push(DO_NOT_CONTACT);
    Cypress.env(skipStubSharedResources, resourcesToSkip.join(','));
});

function stubResource(resource) {
    const skippedStubs = Cypress.env(skipStubSharedResources);
    return !skippedStubs || !skippedStubs.includes(resource);
}

function getDefaultTestData(uid, env) {
    var user_id, env_label;

    if (!!uid && !!env) {
        return cy.wrap({ uid: uid, env: env });
    } else {
        return cy
            .request({
                method: 'GET',
                url: 'https://po-auth-master.kubeodc-test.corp.intranet/backdoor/default_test_user',
            })
            .then(response => {
                user_id = !!uid ? uid : response.body.uid;
                env_label = !!env ? env : response.body.env;
                return { uid: user_id, env: env_label };
            });
    }
}

function definingTimeouts(timeouts) {
    visitTimeout = timeouts.visitTimeout || visitTimeout;
    requestTimeout = timeouts.requestTimeout || requestTimeout;
    responseTimeout = timeouts.responseTimeout || responseTimeout;
    commandTimeout = timeouts.commandTimeout || commandTimeout;

    cy.log(
        `Using [ visitTimeout: ${visitTimeout}, requestTimeout: ${requestTimeout}, responseTimeout: ${responseTimeout}, commandTimeout: ${commandTimeout} ]`
    );
}

function mockLogin(path, tokenMocker) {
    const tokenResponse = tokenMocker.buildNewTokens().tokenResponse();
    cy.log('Using refresh token: ' + tokenResponse.refresh_token);
    cy.log('Using access token: ' + tokenResponse.access_token);

    cy.intercept('POST', '/services/security/token', { body: tokenResponse }).as('token');
    cy.intercept('GET', '/Enterprise/v1/Security/portalIdentity/validateToken', {
        body: {},
        statusCode: 200,
    }).as('validateToken');

    cy.window().then($window => {
        $window.localStorage.setItem('token', tokenResponse.refresh_token);
    });

    cy.intercept('/Enterprise/v1/Security/portalIdentity/profile', { body: tokenMocker.profile }).as('profile');
    cy.intercept('/Enterprise/v1/Security/portalIdentity/accounts?**', { body: tokenMocker.profile.accounts }).as(
        'accounts'
    );
    cy.intercept('/Enterprise/v1/Security/portalIdentity/accountGroups', {
        body: tokenMocker.profile.account_groups,
    }).as('accountGroups');
    cy.intercept('/Enterprise/v1/Security/portalIdentity/preferences', { body: {} }).as('preferences');

    cy.intercept('/janus/jweb/protected/aliveServlet', { body: {}, statusCode: 200 });
    cy.intercept('/services/security/session_token', {
        body: { access_token: tokenResponse.access_token, access_expires_in: tokenResponse.access_expires_in },
    });
    if (stubResource(DO_NOT_CONTACT)) {
        cy.intercept('/Channel/v1/Portal/admin/donotcontact', { body: doNotContact });
    }
    if (stubResource(ALERTS)) {
        cy.intercept('/Channel/v1/Portal/alertNotification/alerts*', { body: {}, statusCode: 200 });
    }
    if (!Cypress.env('VUE_APP_CUSTOMIZE') && stubResource(MENUS)) {
        cy.intercept('/Application/v1/Portal/navigation/entitledMenus', {
            body: entitledMenu,
            statusCode: 200,
        }).as('entitledMenus');
    }

    cy.fixture('endpoints.json').then(endpoints => {
        endpoints[path] &&
            Object.keys(endpoints[path]).forEach(type => {
                Object.keys(endpoints[path][type]).forEach(endpoint => {
                    if (endpoints[path][type][endpoint].response) {
                        cy.intercept(type.toUpperCase(), endpoints[path][type][endpoint].path, {
                            body: endpoints[path][type][endpoint].response,
                        }).as(endpoint);
                    } else {
                        cy.intercept(type.toUpperCase(), endpoints[path][type][endpoint].path).as(endpoint);
                    }
                });
            });
    });

    if (!!path) {
        cy.visit(path, { timeout: visitTimeout })
            .injectAxe()
            .then(() => {
                cy.log(`session type is ${tokenMocker.sessionType}`);
                const sessionWaits =
                    tokenMocker.sessionType === 'anon' ? ['@token'] : ['@token', '@profile', '@preferences'];
                cy.wait(sessionWaits, { requestTimeout, responseTimeout });

                cy.getStore('userContext').then(userContext => {
                    if (isEnterpriseSelectedAndNotEmployee(userContext)) {
                        cy.wait(['@accounts', '@accountGroups'], { requestTimeout, responseTimeout });
                    }
                });

                if (!Cypress.env('VUE_APP_CUSTOMIZE') && stubResource(MENUS)) {
                    cy.wait('@entitledMenus', { requestTimeout, responseTimeout });
                }

                cy.fixture('endpoints.json').then(endpoints => {
                    endpoints[path] &&
                        Object.keys(endpoints[path]).forEach(type => {
                            Object.keys(endpoints[path][type]).forEach(endpoint => {
                                cy.wait(`@${endpoint}`, { requestTimeout, responseTimeout });
                            });
                        });
                });

                cy.get('[data-cy=cy-parent-router__element]', { timeout: commandTimeout }).should('be.visible');
            });
    }
}

function terminalLog(violations) {
    cy.task(
        'log',
        `${violations.length} accessibility violation${violations.length === 1 ? '' : 's'} ${
            violations.length === 1 ? 'was' : 'were'
        } detected`
    );

    const violationData = violations.map(({ id, impact, description, nodes }) => ({
        id,
        impact,
        description,
        nodes: nodes.length,
    }));

    cy.task('table', violationData);
}

function isEnterpriseSelectedAndNotEmployee(userContext) {
    return (
        !!userContext &&
        !!userContext.enterprises &&
        userContext.enterprises.length > 0 &&
        !!userContext.session &&
        !!userContext.session.enterprise &&
        !['employee', 'internal'].includes(userContext.session.sessionType)
    );
}

Cypress.Commands.add(
    'backdoorLogin',
    (path, uid, env, timeouts = { visitTimeout, requestTimeout, responseTimeout, commandTimeout }) => {
        definingTimeouts(timeouts);
        getDefaultTestData(uid, env).then(testData => {
            cy.request({
                method: 'PUT',
                url: 'https://po-auth-master.kubeodc-test.corp.intranet/backdoor/token?dont-verify&env=' + testData.env,
                body: {
                    uid: testData.uid,
                    type: 'enterprise',
                    schema: 'http://elasticbox.net/schemas/token-request',
                },
                headers: {
                    'Content-Type': 'application/json',
                    Host: 'po-auth-master.kubeodc-test.corp.intranet',
                },
            }).then(response => {
                window.localStorage.setItem('token', response.body.refresh_token);

                cy.intercept('/Enterprise/v1/Security/portalIdentity/profile').as('profile');
                cy.intercept('/Enterprise/v1/Security/portalIdentity/accounts?**').as('accounts');
                cy.intercept('/Enterprise/v1/Security/portalIdentity/accountGroups').as('accountGroups');
                cy.intercept('/Enterprise/v1/Security/portalIdentity/preferences').as('preferences');

                cy.intercept('/services/security/session_token', {
                    body: {
                        access_token: response.body.access_token,
                        access_expires_in: response.body.access_expires_in,
                    },
                });

                if (stubResource(DO_NOT_CONTACT)) {
                    cy.intercept('/Channel/v1/Portal/admin/donotcontact', { body: doNotContact });
                }
                if (stubResource(ALERTS)) {
                    cy.intercept('/Channel/v1/Portal/alertNotification/alerts*', { body: {}, statusCode: 200 });
                }
                if (!Cypress.env('VUE_APP_CUSTOMIZE') && stubResource(MENUS)) {
                    cy.intercept('/Application/v1/Portal/navigation/entitledMenus', {
                        body: entitledMenu,
                        statusCode: 200,
                    }).as('entitledMenus');
                }

                cy.fixture('endpoints.json').then(endpoints => {
                    endpoints[path] &&
                        Object.keys(endpoints[path]).forEach(type => {
                            Object.keys(endpoints[path][type]).forEach(endpoint => {
                                cy.intercept(type.toUpperCase(), endpoints[path][type][endpoint].path).as(endpoint);
                            });
                        });
                });

                if (!!path) {
                    cy.visit(path, { timeout: visitTimeout })
                        .injectAxe()
                        .then(() => {
                            cy.wait(['@profile', '@preferences'], { requestTimeout, responseTimeout });

                            cy.getStore('userContext').then(userContext => {
                                if (isEnterpriseSelectedAndNotEmployee(userContext)) {
                                    cy.wait(['@accounts', '@accountGroups'], { requestTimeout, responseTimeout });
                                }
                            });

                            if (!Cypress.env('VUE_APP_CUSTOMIZE') && stubResource(MENUS)) {
                                cy.wait('@entitledMenus', { requestTimeout, responseTimeout });
                            }

                            cy.fixture('endpoints.json').then(endpoints => {
                                endpoints[path] &&
                                    Object.keys(endpoints[path]).forEach(type => {
                                        Object.keys(endpoints[path][type]).forEach(endpoint => {
                                            cy.wait(`@${endpoint}`, { requestTimeout, responseTimeout });
                                        });
                                    });
                            });

                            cy.get('[data-cy=cy-parent-router__element]', { timeout: commandTimeout }).should(
                                'be.visible'
                            );
                        });
                }
            });
        });
    }
);

Cypress.Commands.add(
    'mockLogin',
    (path, baseProfile, env, timeouts = { visitTimeout, requestTimeout, responseTimeout, commandTimeout }) => {
        const mocker = new TokenMocker().tokenMockerFromPartialProfile(baseProfile, env);

        definingTimeouts(timeouts);
        mockLogin(path, mocker);
    }
);

Cypress.Commands.add(
    'mockLoginRaw',
    (path, tokenMocker, timeouts = { visitTimeout, requestTimeout, responseTimeout, commandTimeout }) => {
        definingTimeouts(timeouts);
        mockLogin(path, tokenMocker);
    }
);

Cypress.Commands.add('getStore', getterName => {
    if (!!getterName) {
        cy.window({ timeout: commandTimeout }).then($window => {
            cy.wrap($window.app.$store.getters[getterName]);
        });
    } else {
        cy.window({ timeout: commandTimeout }).then($window => {
            cy.wrap($window.app.$store);
        });
    }
});

Cypress.Commands.add('testAccessibility', () => {
    cy.configureAxe({
        // more info at https://github.com/avanslaars/cypress-axe#cyconfigureaxe (cypress-axe)
        // and at https://www.deque.com/axe/core-documentation/api-documentation/#api-name-axeconfigure (axe)
    });
    cy.checkA11y(
        // more info at https://github.com/avanslaars/cypress-axe#cychecka11y (cypress-axe)
        // and at https://www.deque.com/axe/core-documentation/api-documentation/#api-name-axerun (axe)
        {
            // context settings
        },
        {
            // options
            rules: {
                'page-has-heading-one': { enabled: false },
                'color-contrast': { enabled: false }, // Active link on red background
                region: { enabled: false }, // Ensures all page content is contained by landmarks
                'duplicate-id': { enabled: false }, // Ensures that each id of only used once
                bypass: { enabled: false }, // Ensures that there is no way to skip one page
                'frame-title': { enabled: false }, // Ensures that all frames have a title
                'landmark-one-main': { enabled: false }, // Ensures that there is only one main landmark
                'heading-order': { enabled: false }, // Ensures that the order of the headings is correct
                'image-alt': { enabled: false }, // Ensures that all images have an alt with info
                'skip-link': { enabled: false },
                label: { enabled: false }, // Ensures that there is label for each input '#search-location' is giving trouble
            },
            // includedImpacts: ['serious', 'critical'],
            iframes: false,
            reporter: 'v2',
            elementRef: true,
            xpath: true,
        },
        // print more data to terminal
        terminalLog
    );
});
