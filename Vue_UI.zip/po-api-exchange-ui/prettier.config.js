module.exports = {
    ...require('@centurylink/po-microapp-base'),
};
