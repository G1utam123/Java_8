# API Hub backend

## Development

This application stores information in a Cassandra instance. The best way to start developing is to spin up a local Cassandra by executing the following command:

```code
$ docker compose up
```

Now the application can be started normally (the existing [application.properties](./src/main/resources/application.properties) is already pointing to a local Cassandra).

## OpenAPI descriptor

The API Hub OpenAPI descriptor has been published to SwaggerHub and it's available [here](https://app.swaggerhub.com/apis/CenturyLink_APIs/api-hub).

Because the application was created before an API-First strategy was fully developed it follows a Code-First approach instead. In order to recreate the descriptor from the implemented code the following command can be executed:

```code
$ mvn -Pgenerate-openapi
```

Please keep in mind this is temporary, and the goal is to move to a Code-First approach where this step won't be needed.