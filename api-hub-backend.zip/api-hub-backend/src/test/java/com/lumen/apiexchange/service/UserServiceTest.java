package com.lumen.apiexchange.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import com.lumen.apiexchange.client.LiamSyncClient;
import com.lumen.apiexchange.exception.CustomStatusResponse;
import com.lumen.apiexchange.model.myapps.MediationHeaderUtil;
import com.lumen.apiexchange.model.userprofile.CreateUserRequest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

/**
 * All tests for the UserService Implementation.
 */
@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

  @Mock
  MediationHeaderUtil mediationHeaderUtil;

  @Mock
  LiamSyncClient liamSyncClient;

  @InjectMocks
  private UserServiceImpl userService;

  /**
   * <p>
   * Test where to verify ResponseEntity with CustomStatusResponse returned when Developer already exists in APIGEE.
   * Check for Conflict status and custom response message
   * </p>
   */
  @Test
  @DisplayName("Should return ResponseEntity with CustomStatusResponse if Developer Already Exists")
  void createUser_DeveloperAlreadyExistsTest() throws Exception {

    //given
    CreateUserRequest createUserRequest = new CreateUserRequest();
    ResponseEntity<CustomStatusResponse> conflictResponse = new ResponseEntity<>(
        new CustomStatusResponse("Error", HttpStatus.CONFLICT), HttpStatus.CONFLICT);

    doReturn(conflictResponse).when(liamSyncClient).createUserInApigee(createUserRequest);

    //when
    ResponseEntity<CustomStatusResponse> response =
        (ResponseEntity<CustomStatusResponse>) userService.createUserInApigee(createUserRequest);

    //then
    assertEquals(HttpStatus.CONFLICT, response.getStatusCode(), "Status Codes do not match!");

  }

  /**
   * <p>
   * Test where to verify ResponseEntity with CustomStatusResponse returned when Internal Server Error occurs.
   * Check for Internal Server Error status
   * </p>
   */
  @Test
  void createUser_InternalServerErrorTest() throws Exception {

    //given
    CreateUserRequest createUserRequest = new CreateUserRequest();
    ResponseEntity<CustomStatusResponse> conflictResponse = new ResponseEntity<>(
        new CustomStatusResponse("Error", HttpStatus.INTERNAL_SERVER_ERROR), HttpStatus.INTERNAL_SERVER_ERROR);

    doReturn(conflictResponse).when(liamSyncClient).createUserInApigee(createUserRequest);

    //when
    ResponseEntity<CustomStatusResponse> response =
        (ResponseEntity<CustomStatusResponse>) userService.createUserInApigee(createUserRequest);

    //then
    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode(), "Status Codes do not match!");

  }

}
