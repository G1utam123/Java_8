package com.lumen.apiexchange.util;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo;
import static org.assertj.core.api.Assertions.assertThat;

import com.lumen.apiexchange.IntegrationTestBase;
import com.lumen.apiexchange.config.ApiHubConfig;
import com.lumen.apiexchange.model.ApiMigrateRequest;
import com.lumen.apiexchange.model.InputApiRequest;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("it")
@AutoConfigureWireMock(port = 0)
public class ValidationHandlerTests extends IntegrationTestBase {

//  @Autowired
//  private ApiHubConfig apiHubConfig;
//  
  @Autowired
  private ValidationHandler valH;
  //private ValidationHandler valH = new ValidationHandler(null);

  @Test
  public void contextLoads() {
    assertThat(valH).isNotNull();
  }

  @Test
  public void testErrMessage() {

    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/taxonomy"))
        .withHeader("X-Application-Key", containing("APPKEY966252019031223364839633907"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-get-taxonomies-response.json")
            .withHeader("Content-Type", "application/json")));

    InputApiRequest inputRes = new InputApiRequest();
    String errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).isNotEmpty();

    inputRes.setTaxonomy("Application/Apigee");
    inputRes.setResourceName("test");
    inputRes.setVersion("v1");
    inputRes.setOwningAppAppkey("AppKey");
    inputRes.setMalId("1234");
    inputRes.setDev1EndpointHostname("http://test.com");
    inputRes.setEndpointPath("/doSomething");
    inputRes.setEndpointAuth("none");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).isEmpty();
  }

  @Test
  public void testValidateTaxonomy() {
    
    InputApiRequest inputRes = new InputApiRequest();    

    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/taxonomy"))
        .withHeader("X-Application-Key", containing("APPKEY966252019031223364839633907"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-get-taxonomies-response.json")
            .withHeader("Content-Type", "application/json")));

    inputRes.setTaxonomy(null);
    String errMessage = valH.validateTaxonomy(inputRes);
    assertThat(errMessage).contains("Taxonomy is missing");

    inputRes.setTaxonomy("");
    errMessage = valH.validateTaxonomy(inputRes);
    assertThat(errMessage).contains("Taxonomy is missing");

    inputRes.setTaxonomy("Application/Apigee");
    errMessage = valH.validateTaxonomy(inputRes);
    assertThat(errMessage).doesNotContain("Taxonomy");

    inputRes.setTaxonomy("Application/apigee");
    errMessage = valH.validateTaxonomy(inputRes);
    assertThat(errMessage).contains("Taxonomy is invalid");

    inputRes.setTaxonomy("DoesNotExist");
    errMessage = valH.validateTaxonomy(inputRes);
    assertThat(errMessage).contains("Taxonomy is invalid");
    
    inputRes.setSkipTaxonomyValidation(true);
    inputRes.setTaxonomy("DoesNotExist");
    errMessage = valH.validateTaxonomy(inputRes);
    assertThat(errMessage).doesNotContain("Taxonomy is invalid");
    

  }

  @Test
  public void testValidateResourceName() {

    String errMessage = valH.validateResourceName(null);
    assertThat(errMessage).contains("Resource Name is missing");

    errMessage = valH.validateResourceName("");
    assertThat(errMessage).contains("Resource Name is missing");

    errMessage = valH.validateResourceName("resourceName");
    assertThat(errMessage).doesNotContain("Resource Name");

    errMessage = valH.validateResourceName("/resourceName");
    assertThat(errMessage).contains("Resource Name cannot start with /");

  }

  @Test
  public void testVersion() {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setVersion(null);
    String errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).contains("Version is missing");

    inputRes.setVersion("");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).contains("Version is missing");

    inputRes.setVersion("v1");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).doesNotContain("Version is missing");

    inputRes.setVersion("v");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).contains("Version syntax invalid, should be a lowercase v followed by a number");

    inputRes.setVersion("v1");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).doesNotContain("Version syntax invalid, should be a lowercase v followed by a number");

  }

  @Test
  public void testOwningAppAppkey() {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setOwningAppAppkey(null);
    String errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).contains("Owning Application AppKey is missing");

    inputRes.setOwningAppAppkey("");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).contains("Owning Application AppKey is missing");

    inputRes.setOwningAppAppkey("AppKey");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).doesNotContain("Owning Application AppKey is missing");
  }

  @Test
  public void testMalId() {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setMalId(null);
    String errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).contains("Mal ID is missing");

    inputRes.setMalId("");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).contains("Mal ID is missing");

    inputRes.setMalId("Apigee");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).doesNotContain("Mal ID is missing");
  }

  @Test
  public void testEndpointHostname() {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setDev1EndpointHostname(null);
    inputRes.setDev2EndpointHostname(null);
    inputRes.setDev3EndpointHostname(null);
    inputRes.setDev4EndpointHostname(null);
    inputRes.setTest1EndpointHostname(null);
    inputRes.setTest2EndpointHostname(null);
    inputRes.setTest3EndpointHostname(null);
    inputRes.setTest4EndpointHostname(null);
    inputRes.setMockEndpointHostname(null);
    inputRes.setSandboxEndpointHostname(null);
    inputRes.setProdEndpointHostname(null);
    String errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).contains("At least 1 endpoint hostname must be populated");

    inputRes.setDev1EndpointHostname("");
    inputRes.setDev2EndpointHostname("");
    inputRes.setDev3EndpointHostname("");
    inputRes.setDev4EndpointHostname("");
    inputRes.setTest1EndpointHostname("");
    inputRes.setTest2EndpointHostname("");
    inputRes.setTest3EndpointHostname("");
    inputRes.setTest4EndpointHostname("");
    inputRes.setMockEndpointHostname("");
    inputRes.setSandboxEndpointHostname("");
    inputRes.setProdEndpointHostname("");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).contains("At least 1 endpoint hostname must be populated");

    inputRes.setDev1EndpointHostname("https://hostname.com");
    inputRes.setDev2EndpointHostname("");
    inputRes.setDev3EndpointHostname("");
    inputRes.setDev4EndpointHostname("");
    inputRes.setTest1EndpointHostname("");
    inputRes.setTest2EndpointHostname("");
    inputRes.setTest3EndpointHostname("");
    inputRes.setTest4EndpointHostname("");
    inputRes.setMockEndpointHostname("");
    inputRes.setSandboxEndpointHostname("");
    inputRes.setProdEndpointHostname("");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).doesNotContain("At least 1 endpoint hostname must be populated");

    inputRes.setDev1EndpointHostname("");
    inputRes.setDev2EndpointHostname("https://hostname.com");
    inputRes.setDev3EndpointHostname("");
    inputRes.setDev4EndpointHostname("");
    inputRes.setTest1EndpointHostname("");
    inputRes.setTest2EndpointHostname("");
    inputRes.setTest3EndpointHostname("");
    inputRes.setTest4EndpointHostname("");
    inputRes.setMockEndpointHostname("");
    inputRes.setSandboxEndpointHostname("");
    inputRes.setProdEndpointHostname("");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).doesNotContain("At least 1 endpoint hostname must be populated");

    inputRes.setDev1EndpointHostname("");
    inputRes.setDev2EndpointHostname("");
    inputRes.setDev3EndpointHostname("https://hostname.com");
    inputRes.setDev4EndpointHostname("");
    inputRes.setTest1EndpointHostname("");
    inputRes.setTest2EndpointHostname("");
    inputRes.setTest3EndpointHostname("");
    inputRes.setTest4EndpointHostname("");
    inputRes.setMockEndpointHostname("");
    inputRes.setSandboxEndpointHostname("");
    inputRes.setProdEndpointHostname("");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).doesNotContain("At least 1 endpoint hostname must be populated");

    inputRes.setDev1EndpointHostname("");
    inputRes.setDev2EndpointHostname("");
    inputRes.setDev3EndpointHostname("");
    inputRes.setDev4EndpointHostname("https://hostname.com");
    inputRes.setTest1EndpointHostname("");
    inputRes.setTest2EndpointHostname("");
    inputRes.setTest3EndpointHostname("");
    inputRes.setTest4EndpointHostname("");
    inputRes.setMockEndpointHostname("");
    inputRes.setSandboxEndpointHostname("");
    inputRes.setProdEndpointHostname("");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).doesNotContain("At least 1 endpoint hostname must be populated");

    inputRes.setDev1EndpointHostname("");
    inputRes.setDev2EndpointHostname("");
    inputRes.setDev3EndpointHostname("");
    inputRes.setDev4EndpointHostname("");
    inputRes.setTest1EndpointHostname("https://hostname.com");
    inputRes.setTest2EndpointHostname("");
    inputRes.setTest3EndpointHostname("");
    inputRes.setTest4EndpointHostname("");
    inputRes.setMockEndpointHostname("");
    inputRes.setSandboxEndpointHostname("");
    inputRes.setProdEndpointHostname("");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).doesNotContain("At least 1 endpoint hostname must be populated");

    inputRes.setDev1EndpointHostname("");
    inputRes.setDev2EndpointHostname("");
    inputRes.setDev3EndpointHostname("");
    inputRes.setDev4EndpointHostname("");
    inputRes.setTest1EndpointHostname("");
    inputRes.setTest2EndpointHostname("https://hostname.com");
    inputRes.setTest3EndpointHostname("");
    inputRes.setTest4EndpointHostname("");
    inputRes.setMockEndpointHostname("");
    inputRes.setSandboxEndpointHostname("");
    inputRes.setProdEndpointHostname("");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).doesNotContain("At least 1 endpoint hostname must be populated");

    inputRes.setDev1EndpointHostname("");
    inputRes.setDev2EndpointHostname("");
    inputRes.setDev3EndpointHostname("");
    inputRes.setDev4EndpointHostname("");
    inputRes.setTest1EndpointHostname("");
    inputRes.setTest2EndpointHostname("");
    inputRes.setTest3EndpointHostname("https://hostname.com");
    inputRes.setTest4EndpointHostname("");
    inputRes.setMockEndpointHostname("");
    inputRes.setSandboxEndpointHostname("");
    inputRes.setProdEndpointHostname("");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).doesNotContain("At least 1 endpoint hostname must be populated");

    inputRes.setDev1EndpointHostname("");
    inputRes.setDev2EndpointHostname("");
    inputRes.setDev3EndpointHostname("");
    inputRes.setDev4EndpointHostname("");
    inputRes.setTest1EndpointHostname("");
    inputRes.setTest2EndpointHostname("");
    inputRes.setTest3EndpointHostname("");
    inputRes.setTest4EndpointHostname("https://hostname.com");
    inputRes.setMockEndpointHostname("");
    inputRes.setSandboxEndpointHostname("");
    inputRes.setProdEndpointHostname("");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).doesNotContain("At least 1 endpoint hostname must be populated");

    inputRes.setDev1EndpointHostname("");
    inputRes.setDev2EndpointHostname("");
    inputRes.setDev3EndpointHostname("");
    inputRes.setDev4EndpointHostname("");
    inputRes.setTest1EndpointHostname("");
    inputRes.setTest2EndpointHostname("");
    inputRes.setTest3EndpointHostname("");
    inputRes.setTest4EndpointHostname("");
    inputRes.setMockEndpointHostname("https://hostname.com");
    inputRes.setSandboxEndpointHostname("");
    inputRes.setProdEndpointHostname("");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).doesNotContain("At least 1 endpoint hostname must be populated");

    inputRes.setDev1EndpointHostname("");
    inputRes.setDev2EndpointHostname("");
    inputRes.setDev3EndpointHostname("");
    inputRes.setDev4EndpointHostname("");
    inputRes.setTest1EndpointHostname("");
    inputRes.setTest2EndpointHostname("");
    inputRes.setTest3EndpointHostname("");
    inputRes.setTest4EndpointHostname("");
    inputRes.setMockEndpointHostname("");
    inputRes.setSandboxEndpointHostname("https://hostname.com");
    inputRes.setProdEndpointHostname("");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).doesNotContain("At least 1 endpoint hostname must be populated");

    inputRes.setDev1EndpointHostname("");
    inputRes.setDev2EndpointHostname("");
    inputRes.setDev3EndpointHostname("");
    inputRes.setDev4EndpointHostname("");
    inputRes.setTest1EndpointHostname("");
    inputRes.setTest2EndpointHostname("");
    inputRes.setTest3EndpointHostname("");
    inputRes.setTest4EndpointHostname("");
    inputRes.setMockEndpointHostname("");
    inputRes.setSandboxEndpointHostname("");
    inputRes.setProdEndpointHostname("https://hostname.com");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).doesNotContain("At least 1 endpoint hostname must be populated");

    inputRes.setDev1EndpointHostname("hostname.com");
    inputRes.setDev2EndpointHostname("hostname.com");
    inputRes.setDev3EndpointHostname("hostname.com");
    inputRes.setDev4EndpointHostname("hostname.com");
    inputRes.setTest1EndpointHostname("hostname.com");
    inputRes.setTest2EndpointHostname("hostname.com");
    inputRes.setTest3EndpointHostname("hostname.com");
    inputRes.setTest4EndpointHostname("hostname.com");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).contains("Dev1 Hostname hostname.com must start with http:// or https://.");
    assertThat(errMessage).contains("Dev2 Hostname hostname.com must start with http:// or https://.");
    assertThat(errMessage).contains("Dev3 Hostname hostname.com must start with http:// or https://.");
    assertThat(errMessage).contains("Dev4 Hostname hostname.com must start with http:// or https://.");
    assertThat(errMessage).contains("Test1 Hostname hostname.com must start with http:// or https://.");
    assertThat(errMessage).contains("Test2 Hostname hostname.com must start with http:// or https://.");
    assertThat(errMessage).contains("Test3 Hostname hostname.com must start with http:// or https://.");
    assertThat(errMessage).contains("Test4 Hostname hostname.com must start with http:// or https://.");
    
    inputRes.setDev1EndpointHostname("https://hostname.com");
    inputRes.setDev2EndpointHostname("https://hostname.com");
    inputRes.setDev3EndpointHostname("https://hostname.com");
    inputRes.setDev4EndpointHostname("https://hostname.com");
    inputRes.setTest1EndpointHostname("https://hostname.com");
    inputRes.setTest2EndpointHostname("https://hostname.com");
    inputRes.setTest3EndpointHostname("https://hostname.com");
    inputRes.setTest4EndpointHostname("https://hostname.com");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).doesNotContain("must start with http:// or https://");

    inputRes.setDev1EndpointHostname("http://hostname.com");
    inputRes.setDev2EndpointHostname("http://hostname.com");
    inputRes.setDev3EndpointHostname("http://hostname.com");
    inputRes.setDev4EndpointHostname("http://hostname.com");
    inputRes.setTest1EndpointHostname("http://hostname.com");
    inputRes.setTest2EndpointHostname("http://hostname.com");
    inputRes.setTest3EndpointHostname("http://hostname.com");
    inputRes.setTest4EndpointHostname("http://hostname.com");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).doesNotContain("must start with http:// or https://");

    inputRes.setDev1EndpointHostname("http://hostname.com/");
    inputRes.setDev2EndpointHostname("http://hostname.com/");
    inputRes.setDev3EndpointHostname("http://hostname.com/");
    inputRes.setDev4EndpointHostname("http://hostname.com/");
    inputRes.setTest1EndpointHostname("http://hostname.com/");
    inputRes.setTest2EndpointHostname("http://hostname.com/");
    inputRes.setTest3EndpointHostname("http://hostname.com/");
    inputRes.setTest4EndpointHostname("http://hostname.com/");
    errMessage = valH.validateRequest(inputRes);
    assertThat(errMessage).contains("Dev1 Hostname http://hostname.com/ cannot end with /.");
    assertThat(errMessage).contains("Dev2 Hostname http://hostname.com/ cannot end with /.");
    assertThat(errMessage).contains("Dev3 Hostname http://hostname.com/ cannot end with /.");
    assertThat(errMessage).contains("Dev4 Hostname http://hostname.com/ cannot end with /.");
    assertThat(errMessage).contains("Test1 Hostname http://hostname.com/ cannot end with /.");
    assertThat(errMessage).contains("Test2 Hostname http://hostname.com/ cannot end with /.");
    assertThat(errMessage).contains("Test3 Hostname http://hostname.com/ cannot end with /.");
    assertThat(errMessage).contains("Test4 Hostname http://hostname.com/ cannot end with /.");

  }

  @Test
  public void testvalidateMigrationRequest() {
    ApiMigrateRequest apiMigReq = new ApiMigrateRequest();
    apiMigReq.setMirrorEnvironment(null);
    apiMigReq.setGuid(null);
    apiMigReq.setDev1EndpointHostname(null);
    apiMigReq.setDev2EndpointHostname(null);
    apiMigReq.setDev3EndpointHostname(null);
    apiMigReq.setDev4EndpointHostname(null);
    apiMigReq.setTest1EndpointHostname(null);
    apiMigReq.setTest2EndpointHostname(null);
    apiMigReq.setTest3EndpointHostname(null);
    apiMigReq.setTest4EndpointHostname(null);
    String errMessage = valH.validateMigrationRequest(apiMigReq);
    assertThat(errMessage).contains("The mirrorEnvironment field is required. Cannot proceed with API migration.");
    assertThat(errMessage).contains("The guid field is required. Cannot proceed with API migration.");
    assertThat(errMessage).doesNotContain("must start with http:// or https://.");
    assertThat(errMessage).doesNotContain("cannot end with /.");

    apiMigReq.setMirrorEnvironment("");
    apiMigReq.setGuid("");
    apiMigReq.setDev1EndpointHostname("");
    apiMigReq.setDev2EndpointHostname("");
    apiMigReq.setDev3EndpointHostname("");
    apiMigReq.setDev4EndpointHostname("");
    apiMigReq.setTest1EndpointHostname("");
    apiMigReq.setTest2EndpointHostname("");
    apiMigReq.setTest3EndpointHostname("");
    apiMigReq.setTest4EndpointHostname("");
    errMessage = valH.validateMigrationRequest(apiMigReq);
    assertThat(errMessage).contains("The mirrorEnvironment field is required. Cannot proceed with API migration.");
    assertThat(errMessage).contains("The guid field is required. Cannot proceed with API migration.");
    assertThat(errMessage).doesNotContain("must start with http:// or https://.");
    assertThat(errMessage).doesNotContain("cannot end with /.");

    apiMigReq.setMirrorEnvironment("dev1");
    apiMigReq.setGuid("guid");
    apiMigReq.setDev1EndpointHostname("http://api-dev1.lumen.com");
    apiMigReq.setDev2EndpointHostname("http://api-dev2.lumen.com");
    apiMigReq.setDev3EndpointHostname("http://api-dev3.lumen.com");
    apiMigReq.setDev4EndpointHostname("http://api-dev4.lumen.com");
    apiMigReq.setTest1EndpointHostname("http://api-test1.lumen.com");
    apiMigReq.setTest2EndpointHostname("http://api-test2.lumen.com");
    apiMigReq.setTest3EndpointHostname("http://api-test3.lumen.com");
    apiMigReq.setTest4EndpointHostname("http://api-test4.lumen.com");
    errMessage = valH.validateMigrationRequest(apiMigReq);
    assertThat(errMessage)
        .doesNotContain("The mirrorEnvironment field is required. Cannot proceed with API migration.");
    assertThat(errMessage).doesNotContain("The guid field is required. Cannot proceed with API migration.");
    assertThat(errMessage).doesNotContain("must start with http:// or https://.");
    assertThat(errMessage).doesNotContain("cannot end with /.");

    apiMigReq.setDev1EndpointHostname("https://api-dev1.lumen.com");
    apiMigReq.setDev2EndpointHostname("https://api-dev2.lumen.com");
    apiMigReq.setDev3EndpointHostname("https://api-dev3.lumen.com");
    apiMigReq.setDev4EndpointHostname("https://api-dev4.lumen.com");
    apiMigReq.setTest1EndpointHostname("https://api-test1.lumen.com");
    apiMigReq.setTest2EndpointHostname("https://api-test2.lumen.com");
    apiMigReq.setTest3EndpointHostname("https://api-test3.lumen.com");
    apiMigReq.setTest4EndpointHostname("https://api-test4.lumen.com");
    errMessage = valH.validateMigrationRequest(apiMigReq);
    assertThat(errMessage).doesNotContain("must start with http:// or https://.");
    assertThat(errMessage).doesNotContain("cannot end with /.");

    apiMigReq.setDev1EndpointHostname("http://api-dev1.lumen.com");
    apiMigReq.setDev2EndpointHostname("http://api-dev2.lumen.com");
    apiMigReq.setDev3EndpointHostname("http://api-dev3.lumen.com");
    apiMigReq.setDev4EndpointHostname("http://api-dev4.lumen.com");
    apiMigReq.setTest1EndpointHostname("http://api-test1.lumen.com");
    apiMigReq.setTest2EndpointHostname("http://api-test2.lumen.com");
    apiMigReq.setTest3EndpointHostname("http://api-test3.lumen.com");
    apiMigReq.setTest4EndpointHostname("http://api-test4.lumen.com");
    errMessage = valH.validateMigrationRequest(apiMigReq);
    assertThat(errMessage).doesNotContain("must start with http:// or https://.");

    apiMigReq.setDev1EndpointHostname("api-dev1.lumen.com");
    apiMigReq.setDev2EndpointHostname("api-dev2.lumen.com");
    apiMigReq.setDev3EndpointHostname("api-dev3.lumen.com");
    apiMigReq.setDev4EndpointHostname("api-dev4.lumen.com");
    apiMigReq.setTest1EndpointHostname("api-test1.lumen.com");
    apiMigReq.setTest2EndpointHostname("api-test2.lumen.com");
    apiMigReq.setTest3EndpointHostname("api-test3.lumen.com");
    apiMigReq.setTest4EndpointHostname("api-test4.lumen.com");
    errMessage = valH.validateMigrationRequest(apiMigReq);
    assertThat(errMessage).contains("Hostname api-dev1.lumen.com must start with http:// or https://.");
    assertThat(errMessage).contains("Hostname api-dev2.lumen.com must start with http:// or https://.");
    assertThat(errMessage).contains("Hostname api-dev3.lumen.com must start with http:// or https://.");
    assertThat(errMessage).contains("Hostname api-dev4.lumen.com must start with http:// or https://.");
    assertThat(errMessage).contains("Hostname api-test1.lumen.com must start with http:// or https://.");
    assertThat(errMessage).contains("Hostname api-test2.lumen.com must start with http:// or https://.");
    assertThat(errMessage).contains("Hostname api-test3.lumen.com must start with http:// or https://.");
    assertThat(errMessage).contains("Hostname api-test4.lumen.com must start with http:// or https://.");

    apiMigReq.setDev1EndpointHostname("https://api-dev1.lumen.com/");
    apiMigReq.setDev2EndpointHostname("https://api-dev2.lumen.com/");
    apiMigReq.setDev3EndpointHostname("https://api-dev3.lumen.com/");
    apiMigReq.setDev4EndpointHostname("https://api-dev4.lumen.com/");
    apiMigReq.setTest1EndpointHostname("https://api-test1.lumen.com/");
    apiMigReq.setTest2EndpointHostname("https://api-test2.lumen.com/");
    apiMigReq.setTest3EndpointHostname("https://api-test3.lumen.com/");
    apiMigReq.setTest4EndpointHostname("https://api-test4.lumen.com/");
    errMessage = valH.validateMigrationRequest(apiMigReq);
    assertThat(errMessage).contains("Hostname https://api-dev1.lumen.com/ cannot end with /.");
    assertThat(errMessage).contains("Hostname https://api-dev2.lumen.com/ cannot end with /.");
    assertThat(errMessage).contains("Hostname https://api-dev3.lumen.com/ cannot end with /.");
    assertThat(errMessage).contains("Hostname https://api-dev4.lumen.com/ cannot end with /.");
    assertThat(errMessage).contains("Hostname https://api-test1.lumen.com/ cannot end with /.");
    assertThat(errMessage).contains("Hostname https://api-test2.lumen.com/ cannot end with /.");
    assertThat(errMessage).contains("Hostname https://api-test3.lumen.com/ cannot end with /.");
    assertThat(errMessage).contains("Hostname https://api-test4.lumen.com/ cannot end with /.");

  }

  @Test
  public void testValidateEndpointPath() {
    String errMessage = valH.validateEndpointPath(null);
    assertThat(errMessage).doesNotContain("Resource Path");

    errMessage = valH.validateEndpointPath("");
    assertThat(errMessage).doesNotContain("Resource Path");

    errMessage = valH.validateEndpointPath("/dosomething");
    assertThat(errMessage).doesNotContain("Resource Path");

    errMessage = valH.validateEndpointPath("/");
    assertThat(errMessage).contains("Resource Path cannot equal /, for no Resource Path leave blank");

    errMessage = valH.validateEndpointPath("dosomething");
    assertThat(errMessage).contains("If Resource Path is populated, it must start with /");

    errMessage = valH.validateEndpointPath("dosomething*");
    assertThat(errMessage).contains("If Resource Path is populated, it cannot contain an asterisk *");

  }

  @Test
  public void testValidateProxyAuthBasicAuth() {

    String errMessage;

    errMessage = valH.validateProxyAuthBasicAuth(null, null, null, null);
    assertThat(errMessage).doesNotContain("Basic Authentication");

    errMessage = valH.validateProxyAuthBasicAuth("appkey", null, null, null);
    assertThat(errMessage).doesNotContain("Basic Authentication");

    errMessage = valH.validateProxyAuthBasicAuth("basicAuth", null, "LDAP Group", null);
    assertThat(errMessage).doesNotContain("Basic Authentication");

    errMessage = valH.validateProxyAuthBasicAuth("basicAuth", null, null, "user");
    assertThat(errMessage).doesNotContain("Basic Authentication");

    errMessage = valH.validateProxyAuthBasicAuth(null, "basicAuth", "LDAP Group", null);
    assertThat(errMessage).doesNotContain("Basic Authentication");

    errMessage = valH.validateProxyAuthBasicAuth(null, "basicAuth", null, "user");
    assertThat(errMessage).doesNotContain("Basic Authentication");

    errMessage = valH.validateProxyAuthBasicAuth("appkey,basicAuth", "appkey,basicAuth", "LDAP Group", "user");
    assertThat(errMessage).doesNotContain("Basic Authentication");

    errMessage = valH.validateProxyAuthBasicAuth("appkey,basicAuth", null, null, null);
    assertThat(errMessage).contains("Basic Authentication");

    errMessage = valH.validateProxyAuthBasicAuth("appkey,basicAuth", null, null, null);
    assertThat(errMessage).contains("Basic Authentication");

    errMessage = valH.validateProxyAuthBasicAuth("appkey,basicAuth", "appkey,basicAuth", null, null);
    assertThat(errMessage).contains("Basic Authentication");

    errMessage = valH.validateProxyAuthBasicAuth("appkey,basicAuth", "appkey,basicAuth", "", "");
    assertThat(errMessage).contains("Basic Authentication");

    errMessage = valH.validateProxyAuthBasicAuth("appkey,basicAuth", "appkey,basicAuth", " ", " ");
    assertThat(errMessage).contains("Basic Authentication");

  }
  
  @Test
  public void testValidateAuthTypes_ValidInternal() {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setInternal("true");
    inputRes.setProxyAuthInternal("basicAuth");

    String errorMessage = valH.validateAuthTypes(inputRes);

    assertEquals("", errorMessage, "Expected no error message for valid auth types.");
  }

  @Test
  public void testValidateAuthTypes_ValidInternalCombination() {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setInternal("true");
    inputRes.setProxyAuthInternal("appkey,basicAuth");

    String errorMessage = valH.validateAuthTypes(inputRes);

    assertEquals("", errorMessage, "Expected no error message for valid auth types.");
  }

  @Test
  public void testValidateAuthTypes_ValidExternal() {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setExternal("true");
    inputRes.setProxyAuthExternal("basicAuth");

    String errorMessage = valH.validateAuthTypes(inputRes);

    assertEquals("", errorMessage, "Expected no error message for valid auth types.");
  }

  @Test
  public void testValidateAuthTypes_ValidExternalCombination() {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setExternal("true");
    inputRes.setProxyAuthExternal("oAuth,basicAuth,jwt");

    String errorMessage = valH.validateAuthTypes(inputRes);

    assertEquals("", errorMessage, "Expected no error message for valid auth types.");
  }

  @Test
  public void testValidateAuthTypes_InvalidInternal() {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setInternal("true");
    // Set invalid auth types, should trigger error
    inputRes.setProxyAuthInternal("invalidType");

    String errorMessage = valH.validateAuthTypes(inputRes);

    assertEquals("ProxyAuthInternal must contain 'basicAuth', 'oAuth', or 'appkey' when internally available is true\n",
        errorMessage, "Expected error message for invalid auth types.");
  }
  
  @Test
  public void testValidateAuthTypes_InvalidExternal() {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setExternal("true");
    // Set invalid auth types, should trigger error
    inputRes.setProxyAuthExternal("invalidType");

    String errorMessage = valH.validateAuthTypes(inputRes);

    assertEquals("ProxyAuthExternal must contain 'oAuth', 'basicAuth', 'appkey', 'LIAMOAuth', or 'jwt' when externally available is true\n",
        errorMessage, "Expected error message for invalid auth types.");
  }
  
  @Test
  public void testValidateAuthTypes_InvalidCombination() {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setExternal("true");
      // Set an invalid combination of endpointAuthType, should trigger error
    inputRes.setProxyAuthExternal("oAuth,LIAMOauth");

      String errorMessage = valH.validateAuthTypes(inputRes);

      assertEquals("ProxyAuthExternal cannot contain both 'oAuth' and 'LIAMOauth'\n",
              errorMessage, "Expected error message for invalid endpointAuthType combination.");
  }

  @Test
  public void testValidateEndpointAuthType_Valid() {
    InputApiRequest inputRes = new InputApiRequest();
      // Set a valid endpointAuthType, should trigger no error
    inputRes.setEndpointAuth("jwt");

      String errorMessage = valH.validateEndpointAuthType(inputRes);

      assertEquals("", errorMessage, "Expected no error message for valid endpointAuthType.");
  }

  @Test
  public void testValidateEndpointAuthType_Invalid() {
    InputApiRequest inputRes = new InputApiRequest();
      // Set an invalid endpointAuthType, should trigger error
    inputRes.setEndpointAuth("invalidAuthType");

      String errorMessage = valH.validateEndpointAuthType(inputRes);

      assertEquals("EndpointAuth must be 'none', 'jwt', 'basicAuth', 'authHeaderPassThrough', 'x509Cert', 'oAuth', or 'LIAMJwt'\n",
              errorMessage, "Expected error message for invalid endpointAuthType.");
  }

  @Test
  public void testValidateB2bAuthentication_Invalid() {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setProxyAuthExternal("LIAMOauth");
    inputRes.setB2bAuthRequired("true");
    inputRes.setB2bBillingAccountNumberRequired("true");
    inputRes.setB2bCustomerNumberRequired("true");

      String errorMessage = valH.validateB2bAuthentication(inputRes.getProxyAuthExternal(), inputRes.getB2bAuthRequired(),
          inputRes.getB2bBillingAccountNumberRequired(), inputRes.getB2bCustomerNumberRequired());

      assertThat(errorMessage).contains("b2bAuthRequired can't be true if proxyAuthExternal contains LIAMOauth");
      assertThat(errorMessage).contains("b2bCustomerNumberRequired can't be true if proxyAuthExternal contains LIAMOauth");
      assertThat(errorMessage).contains("b2bBillingAccountNumberRequired can't be true if proxyAuthExternal contains LIAMOauth");
  }
  
  @Test
  public void testValidateB2bAuthentication_Valid() {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setProxyAuthExternal("LIAMOauth");
    inputRes.setB2bAuthRequired("false");
    inputRes.setB2bBillingAccountNumberRequired("false");
    inputRes.setB2bCustomerNumberRequired("false");

      String errorMessage = valH.validateB2bAuthentication(
          inputRes.getProxyAuthExternal(), inputRes.getB2bAuthRequired(),
          inputRes.getB2bBillingAccountNumberRequired(), inputRes.getB2bCustomerNumberRequired());

      assertThat(errorMessage).doesNotContain(
          "b2bAuthRequired can't be true if proxyAuthExternal contains LIAMOauth");
      assertThat(errorMessage).doesNotContain(
          "b2bCustomerNumberRequired can't be true if proxyAuthExternal contains LIAMOauth");
      assertThat(errorMessage).doesNotContain(
          "b2bBillingAccountNumberRequired can't be true if proxyAuthExternal contains LIAMOauth");
  }
  
  @Test
  public void testValidateB2bAuthentication_ProxyAuthExternalNotLIAMOauth() {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setProxyAuthExternal("oAuth");
    inputRes.setB2bAuthRequired("true");
    inputRes.setB2bBillingAccountNumberRequired("true");
    inputRes.setB2bCustomerNumberRequired("true");

      String errorMessage = valH.validateB2bAuthentication(
          inputRes.getProxyAuthExternal(), inputRes.getB2bAuthRequired(),
          inputRes.getB2bBillingAccountNumberRequired(), inputRes.getB2bCustomerNumberRequired());

      assertThat(errorMessage).isEmpty();
  }
  
  @Test
  public void testOauthTokenServiceHost_Invalid() {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setOauthTokenServiceHost("https://OauthTokenHost.com");

      String errorMessage = valH.validateOauthTokenServiceHost(inputRes.getOauthTokenServiceHost());

      assertThat(errorMessage).contains(
          "oauthTokenServiceHost can't contain http:// or https://");
  }

  @Test
  public void testOauthTokenServiceHost_Valid() {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setOauthTokenServiceHost("OauthTokenHost.com");

      String errorMessage = valH.validateOauthTokenServiceHost(inputRes.getOauthTokenServiceHost());

      assertThat(errorMessage).isEmpty();
  }
}
