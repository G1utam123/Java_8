package com.lumen.apiexchange.service;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo;
import static org.assertj.core.api.Assertions.assertThat;

import com.lumen.apiexchange.IntegrationTestBase;
import com.lumen.apiexchange.model.ApiMediatedResource;
import java.util.concurrent.Future;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.test.context.ActiveProfiles;


@SpringBootTest
@ActiveProfiles("it")
@AutoConfigureWireMock(port = 0)
class AsyncProxyServiceImplIntegrationTest extends IntegrationTestBase {

  @Autowired
  AsyncProxyService asyncProxyService;

  @Value("${wiremock.server.port}")
  String wiremockPort;

  @Test
  void getApiProxyEnvDetails() throws Exception {

    // given
    String guid = "6ce67bee-66c3-4007-be6a-73c5691339f8";
    String host = "http://localhost:" + wiremockPort;

    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing("apigee"))
        .withQueryParam("resourceGuid", equalTo(guid))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-mediated-resources-response.json")
            .withHeader("Content-Type", "application/json")));

    // when
    Future<ApiMediatedResource> details = asyncProxyService.getApiProxyEnvDetails(guid, host);

    // then
    assertThat(details.get().getActive()).isEqualTo("true");
    assertThat(details.get().getMediatedResourceId()).isEqualTo(54584);
    assertThat(details.get().getResourceTaxonomy()).isEqualTo("Application/CIPS");
    assertThat(details.get().getVersion()).isEqualTo("v1");
  }

  @Test
  void shouldGetApiProxyDetailsSingleProxy() throws Exception {

    //getApiProxyDetails(String env, String taxonomy, String resourceName, String version)
    // given
    String env = "test1";
    String taxonomy = "Application/Apigee"; 
    String resourceName = "troyTest001";
    String version = "v1";

    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing("apigee"))
        .withQueryParam("resourceName", equalTo(resourceName))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-mediated-api-lookup-api-exist-single-response.json")
            .withHeader("Content-Type", "application/json")));

    // when
    Future<ApiMediatedResource> details = asyncProxyService.getApiProxyDetails(env, taxonomy, resourceName, version);

    // then
    assertThat(details.get().getActive()).isEqualTo("true");
    assertThat(details.get().getMediatedResourceId()).isEqualTo(59698);
    assertThat(details.get().getResourceTaxonomy()).isEqualTo(taxonomy);
    assertThat(details.get().getVersion()).isEqualTo(version);
  }

  @Test
  void shouldGetApiProxyDetailsMultiProxy() throws Exception {

    //getApiProxyDetails(String env, String taxonomy, String resourceName, String version)
    // given
    String env = "test1";
    String taxonomy = "Partner/jeaglem"; 
    String resourceName = "basicAuth1";
    String version = "v1";

    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing("apigee"))
        .withQueryParam("resourceName", equalTo(resourceName))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-mediated-api-lookup-api-exist-multi-response.json")
            .withHeader("Content-Type", "application/json")));

    // when
    Future<ApiMediatedResource> details = asyncProxyService.getApiProxyDetails(env, taxonomy, resourceName, version);

    // then
    assertThat(details.get().getActive()).isEqualTo("true");
    assertThat(details.get().getMediatedResourceId()).isEqualTo(64798);
    assertThat(details.get().getResourceTaxonomy()).isEqualTo(taxonomy);
    assertThat(details.get().getVersion()).isEqualTo(version);
  }

  @Test
  void shouldGetApiProxyDetailsNoProxy() throws Exception {

    //getApiProxyDetails(String env, String taxonomy, String resourceName, String version)
    // given
    String env = "test1";
    String taxonomy = "Partner/jeaglem"; 
    String resourceName = "basicAuth1";
    String version = "v1";

    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing("apigee"))
        .withQueryParam("resourceName", equalTo(resourceName))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-mediated-api-lookup-api-does-not-exist-response.json")
            .withHeader("Content-Type", "application/json")));

    // when
    Future<ApiMediatedResource> details = asyncProxyService.getApiProxyDetails(env, taxonomy, resourceName, version);

    // then
    assertThat(details.get()).isNull();
  }

}
