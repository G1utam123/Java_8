package com.lumen.apiexchange.configuration.test;

import com.github.tomakehurst.wiremock.client.ResponseDefinitionBuilder;
import com.github.tomakehurst.wiremock.common.FileSource;
import com.github.tomakehurst.wiremock.extension.Parameters;
import com.github.tomakehurst.wiremock.extension.ResponseDefinitionTransformer;
import com.github.tomakehurst.wiremock.http.Request;
import com.github.tomakehurst.wiremock.http.ResponseDefinition;
import org.apache.http.HttpHeaders;
import org.springframework.cloud.contract.wiremock.WireMockConfigurationCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class WiremockConfig {

  @Bean
  WireMockConfigurationCustomizer optionsCustomizer() {
    return options -> options.extensions(ConnectionCloseExtension.class);
  }

  public static class ConnectionCloseExtension extends ResponseDefinitionTransformer {
    @Override
    public ResponseDefinition transform(Request request, ResponseDefinition responseDefinition, FileSource files,
                                        Parameters parameters) {
      return ResponseDefinitionBuilder.like(responseDefinition)
          .withHeader(HttpHeaders.CONNECTION, "close")
          .build();
    }

    @Override
    public String getName() {
      return "keep-alive-disabler";
    }

    public ConnectionCloseExtension() {
    }
  }

}
