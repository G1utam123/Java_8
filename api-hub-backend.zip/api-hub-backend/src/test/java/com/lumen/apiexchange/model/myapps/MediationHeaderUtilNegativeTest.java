package com.lumen.apiexchange.model.myapps;

import static org.junit.Assert.assertThrows;

import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.myapps.MediationHeaderUtil;
import com.lumen.apiexchange.service.MyAppServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;


/**
 * All Negative Tests for the MediationHeaderUtil.
 * 
 */
@ExtendWith(MockitoExtension.class)
public class MediationHeaderUtilNegativeTest {


  @Mock
  MediationHeaderUtil mediationHeaderUtil;

  @InjectMocks
  private MyAppServiceImpl myAppsService;

  @BeforeEach
  public void setup() {
    //ReflectionTestUtils.setField(myAppsService, "appKey", "");
    //ReflectionTestUtils.setField(myAppsService, "secret", "");
  }

  /**
   * <p>
   * Test where to verify Internal Server Exception thrown when appKey and secret are not Set.
   * </p>
   */
  @Test
  @DisplayName("Should throw Internal Server Exception when trying appKey and secret are not set")
  @Disabled("This is not testing MediationHeaderUtil ...")
  void mediationHeaderNegativeTest() throws Exception {

    String email = "test@example.com";

    Exception exception = assertThrows(InternalServerException.class, () -> {
      myAppsService.getApigeeApiClientForEnterpriseId(email);
    });
  }

}
