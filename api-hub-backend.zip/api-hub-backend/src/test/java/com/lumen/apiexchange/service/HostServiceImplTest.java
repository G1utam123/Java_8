package com.lumen.apiexchange.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.lumen.apiexchange.config.ApigeeConfigProperties;
import com.lumen.apiexchange.config.MediationResourceConfigProperties;
import com.lumen.apiexchange.exception.InternalServerException;

public class HostServiceImplTest {
  
  private HostServiceImpl hostServiceImpl;
  private MediationResourceConfigProperties medResourceConfigProp;
  private ApigeeConfigProperties apigeeConfigProp;
  
  private final String DEV1_HOSTNAME = "http://api-dev1.test.intranet";
  private final String DEV2_HOSTNAME = "http://api-dev2.test.intranet";
  private final String DEV3_HOSTNAME = "http://api-dev3.test.intranet";
  private final String DEV4_HOSTNAME = "http://api-dev4.test.intranet";
  private final String TEST1_HOSTNAME = "http://api-test1.test.intranet";
  private final String TEST2_HOSTNAME = "http://api-test2.test.intranet";
  private final String TEST3_HOSTNAME = "http://api-test3.test.intranet";
  private final String TEST4_HOSTNAME = "http://api-test4.test.intranet";
  private final String PROD_HOSTNAME = "http://api.corp.intranet";

  @BeforeEach
  void setUp() {
    medResourceConfigProp = new MediationResourceConfigProperties();
    medResourceConfigProp.setHostnameDev1(DEV1_HOSTNAME);
    medResourceConfigProp.setHostnameDev2(DEV2_HOSTNAME);
    medResourceConfigProp.setHostnameDev3(DEV3_HOSTNAME);
    medResourceConfigProp.setHostnameDev4(DEV4_HOSTNAME);
    medResourceConfigProp.setHostnameTest1(TEST1_HOSTNAME);
    medResourceConfigProp.setHostnameTest2(TEST2_HOSTNAME);
    medResourceConfigProp.setHostnameTest3(TEST3_HOSTNAME);
    medResourceConfigProp.setHostnameTest4(TEST4_HOSTNAME);
    medResourceConfigProp.setHostnameProd(PROD_HOSTNAME);
    
    apigeeConfigProp = new ApigeeConfigProperties();
    apigeeConfigProp.setApigeeHostnameDev1(DEV1_HOSTNAME);
    apigeeConfigProp.setApigeeHostnameDev2(DEV2_HOSTNAME);
    apigeeConfigProp.setApigeeHostnameDev3(DEV3_HOSTNAME);
    apigeeConfigProp.setApigeeHostnameDev4(DEV4_HOSTNAME);
    apigeeConfigProp.setApigeeHostnameTest1(TEST1_HOSTNAME);
    apigeeConfigProp.setApigeeHostnameTest2(TEST2_HOSTNAME);
    apigeeConfigProp.setApigeeHostnameTest3(TEST3_HOSTNAME);
    apigeeConfigProp.setApigeeHostnameTest4(TEST4_HOSTNAME);
    apigeeConfigProp.setApigeeHostnameProd(PROD_HOSTNAME);

    hostServiceImpl = new HostServiceImpl(medResourceConfigProp, apigeeConfigProp);
  }
  
  @Test
  void getEnvHostnameTest () {

    assertThat(hostServiceImpl.getEnvHostname("dev1")).isEqualTo(DEV1_HOSTNAME);
    assertThat(hostServiceImpl.getEnvHostname("dev2")).isEqualTo(DEV2_HOSTNAME);
    assertThat(hostServiceImpl.getEnvHostname("dev3")).isEqualTo(DEV3_HOSTNAME);
    assertThat(hostServiceImpl.getEnvHostname("dev4")).isEqualTo(DEV4_HOSTNAME);
    assertThat(hostServiceImpl.getEnvHostname("test1")).isEqualTo(TEST1_HOSTNAME);
    assertThat(hostServiceImpl.getEnvHostname("test2")).isEqualTo(TEST2_HOSTNAME);
    assertThat(hostServiceImpl.getEnvHostname("test3")).isEqualTo(TEST3_HOSTNAME);
    assertThat(hostServiceImpl.getEnvHostname("test4")).isEqualTo(TEST4_HOSTNAME);
    assertThat(hostServiceImpl.getEnvHostname("prod")).isEqualTo(PROD_HOSTNAME);

  }

  @Test
  void getEnvHostnameSadTest () throws InternalServerException {

    InternalServerException exception = assertThrows(InternalServerException.class, () -> {
      hostServiceImpl.getEnvHostname("sad");
      });
    
    assertTrue(exception.getMessage().contains("Invalid environment"));
  }

}
