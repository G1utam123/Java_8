package com.lumen.apiexchange.service;

import com.lumen.apiexchange.entity.OwnershipStatus;
import com.lumen.apiexchange.exception.OwnershipStatusAlreadyExistsException;
import com.lumen.apiexchange.model.snow.ServiceNowRequest;
import com.lumen.apiexchange.repository.OwnershipRepository;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.ArgumentMatchers.anyString;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
public class ServiceNowServiceTest {

//  @InjectMocks
//  OwnershipStatusServiceImpl service;

  @InjectMocks
  ServiceNowServiceImpl service;
  @Mock
  OwnershipRepository repository;

  @Mock
  OwnershipStatusService ownershipStatusService;

  public ServiceNowServiceTest() {
      MockitoAnnotations.initMocks(this);
  }


  @Test
  void returnExceptionDueToOwnershipExists() throws Exception {
    // Arrange
    String[] ownersArray = {"owner1", "owner2", "owner3"};
    List<String> owners = Arrays.asList(ownersArray);
    String[] adminsArray = {"admin1", "admin2", "admin3"};
    List<String> admins = Arrays.asList(adminsArray);

    ServiceNowRequest servicenowrequest = ServiceNowRequest.builder()
        .elementName("SYSGEN12345")
        .requester("ad22342")
        .owners(owners)
        .admins(admins)
        .elementType("proxy").build();

    OwnershipStatus statusResponse = OwnershipStatus.builder()
        .status("PROVISIONING")
        .requestNo("RITM1234567")
        .elementId("SYSGEN12345")
        .requester("ad22342")
        .elementType("proxy").build();

    //when(repository.findByElementId(anyString())).thenReturn(Optional.ofNullable(statusResponse));
    when(ownershipStatusService.getOwnershipStatus(anyString())).thenReturn(statusResponse);

    // Act & Assert
    assertThrows(OwnershipStatusAlreadyExistsException.class, () -> service.createGroup(servicenowrequest));

  }

}
