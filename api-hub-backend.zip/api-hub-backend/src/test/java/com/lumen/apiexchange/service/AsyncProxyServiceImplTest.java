package com.lumen.apiexchange.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.AssertionsForClassTypes.assertThatExceptionOfType;
import static org.awaitility.Awaitility.await;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.mock;

import com.lumen.apiexchange.client.ESPClient;
import com.lumen.apiexchange.config.MediationResourceConfigProperties;
import com.lumen.apiexchange.exception.ForbiddenException;
import com.lumen.apiexchange.exception.PartnerProxyBuildException;
import com.lumen.apiexchange.exception.PartnerProxyDeployException;
import com.lumen.apiexchange.model.AsyncBuildDeployResult;
import com.lumen.apiexchange.model.BuildDeployResult;
import com.lumen.apiexchange.model.InputApiRequest;
import java.util.ArrayList;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class AsyncProxyServiceImplTest {

  private ESPClient espClient;
  private MediationResourceConfigProperties mediationResourceConfigProp;
  private BuildServiceImpl buildServiceImpl;
  private DeployServiceImpl deployServiceImpl;
  
  @BeforeEach
  void setUp() {
    espClient = mock(ESPClient.class);
    mediationResourceConfigProp = mock(MediationResourceConfigProperties.class);
    buildServiceImpl = mock(BuildServiceImpl.class);
    deployServiceImpl = mock(DeployServiceImpl.class);
  }
  
  @Test
  public void shouldThrowPartnerProxyBuildExceptionFromEmptyAsyncResult() {
    // Create a mock for the buildDeployApi method
    AsyncProxyServiceImpl service = new AsyncProxyServiceImpl(espClient, mediationResourceConfigProp, buildServiceImpl, deployServiceImpl);
    AsyncProxyServiceImpl spyService = Mockito.spy(service);

    InputApiRequest request = new InputApiRequest();
     
    CompletableFuture<AsyncBuildDeployResult> asyncResult = null;
      
    Mockito.doReturn(asyncResult).when(spyService).buildDeployApi(request);

    // Use Awaitility to wait for the exception
    await().atMost(5, TimeUnit.SECONDS).until(() -> {
        try {
            spyService.buildDeployAsync(request, new BuildDeployResult());
            return false; // No exception was thrown, continue waiting
        } catch (PartnerProxyBuildException e) {
            // Exception was thrown, the condition is met
            return true;
        }
    });
    
    // If the exception is not thrown within the specified time, the test will fail
    assertThatThrownBy(() -> spyService.buildDeployAsync(request, new BuildDeployResult()))
            .isInstanceOf(PartnerProxyBuildException.class);
  }

  @Test
  public void shouldThrowPartnerProxyBuildException() {
    // Create a mock for the buildDeployApi method
    AsyncProxyServiceImpl service = new AsyncProxyServiceImpl(espClient, mediationResourceConfigProp, buildServiceImpl, deployServiceImpl);
    AsyncProxyServiceImpl spyService = Mockito.spy(service);

    InputApiRequest request = new InputApiRequest();
     
    AsyncBuildDeployResult asyncBuildDeployResult = AsyncBuildDeployResult.builder()
        .proxyBuiltInEnvironments("")
        .proxyNotBuiltInEnvironments("")
        .proxyDeployedToEnvironments(new ArrayList<>())
        .proxyNotDeployedToEnvironments(new ArrayList<>())
        .build();
     
    asyncBuildDeployResult.setProxyNotBuiltInEnvironments("test1");
     
    CompletableFuture<AsyncBuildDeployResult> asyncResult = CompletableFuture.completedFuture(asyncBuildDeployResult);
      
    Mockito.doReturn(asyncResult).when(spyService).buildDeployApi(request);

    // Use Awaitility to wait for the exception
    await().atMost(5, TimeUnit.SECONDS).until(() -> {
        try {
            spyService.buildDeployAsync(request, new BuildDeployResult());
            return false; // No exception was thrown, continue waiting
        } catch (PartnerProxyBuildException e) {
            // Exception was thrown, the condition is met
            return true;
        }
    });
    
    // If the exception is not thrown within the specified time, the test will fail
    assertThatThrownBy(() -> spyService.buildDeployAsync(request, new BuildDeployResult()))
            .isInstanceOf(PartnerProxyBuildException.class);
  }
  
  @Test
  public void shouldThrowPartnerProxyDeployException() {
    // Create a mock for the buildDeployApi method
    AsyncProxyServiceImpl service = new AsyncProxyServiceImpl(espClient, mediationResourceConfigProp, buildServiceImpl, deployServiceImpl);
    AsyncProxyServiceImpl spyService = Mockito.spy(service);

    InputApiRequest request = new InputApiRequest();
     
    AsyncBuildDeployResult asyncBuildDeployResult = AsyncBuildDeployResult.builder()
        .proxyBuiltInEnvironments("")
        .proxyNotBuiltInEnvironments("")
        .proxyDeployedToEnvironments(new ArrayList<>())
        .proxyNotDeployedToEnvironments(new ArrayList<>())
        .build();
     
    asyncBuildDeployResult.getProxyNotDeployedToEnvironments().add("test1");
     
    CompletableFuture<AsyncBuildDeployResult> asyncResult = CompletableFuture.completedFuture(asyncBuildDeployResult);
      
    Mockito.doReturn(asyncResult).when(spyService).buildDeployApi(request);

    // Use Awaitility to wait for the exception
    await().atMost(5, TimeUnit.SECONDS).until(() -> {
        try {
            spyService.buildDeployAsync(request, new BuildDeployResult());
            return false; // No exception was thrown, continue waiting
        } catch (PartnerProxyDeployException e) {
            // Exception was thrown, the condition is met
            return true;
        }
    });
    
    // If the exception is not thrown within the specified time, the test will fail
    assertThatThrownBy(() -> spyService.buildDeployAsync(request, new BuildDeployResult()))
            .isInstanceOf(PartnerProxyDeployException.class);
  }
  
  @Test
  public void shouldNotThrowPartnerProxyDeployException() {
    // Create a mock for the buildDeployApi method
    AsyncProxyServiceImpl service = new AsyncProxyServiceImpl(espClient, mediationResourceConfigProp, buildServiceImpl, deployServiceImpl);
    AsyncProxyServiceImpl spyService = Mockito.spy(service);

    InputApiRequest request = new InputApiRequest();
     
    AsyncBuildDeployResult asyncBuildDeployResult = AsyncBuildDeployResult.builder()
        .proxyBuiltInEnvironments("")
        .proxyNotBuiltInEnvironments("")
        .proxyDeployedToEnvironments(new ArrayList<>())
        .proxyNotDeployedToEnvironments(new ArrayList<>())
        .build();
     
    //asyncBuildDeployResult.getProxyNotDeployedToEnvironments().add("test1");
     
    CompletableFuture<AsyncBuildDeployResult> asyncResult = CompletableFuture.completedFuture(asyncBuildDeployResult);
      
    Mockito.doReturn(asyncResult).when(spyService).buildDeployApi(request);

    // Use Awaitility to wait for the exception
    await().atMost(5, TimeUnit.SECONDS).until(() -> {
        try {
            spyService.buildDeployAsync(request, new BuildDeployResult());
            return true; // No exception was thrown, test passed
        } catch (PartnerProxyDeployException e) {
            // Exception was thrown, test failed
            return false;
        }
    });
  } 
}
