package com.lumen.apiexchange.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.ProductNotFoundException;
import com.lumen.apiexchange.entity.ApiProduct;
import com.lumen.apiexchange.service.ApiProductsServiceImpl;
import com.lumen.apiexchange.service.ProfileService;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

@WebMvcTest(controllers = { ProductsController.class }) 
@AutoConfigureMockMvc(addFilters = false)
class ProductsControllerTest {

  @Autowired
  private MockMvc mockMvc;

  @MockBean
  private ApiProductsServiceImpl apiProductsService;

  @MockBean
  private ProfileService profileService;

  @MockBean
  SecurityContext securityContext;

  protected static final Logger log = LoggerFactory.getLogger(ApiProductsServiceImpl.class);

  static JwtAuthenticationToken getMockJwtToken(String subject) {
    final Jwt jwt = Jwt.withTokenValue("token")
        .header("alg", "none")
        .subject(subject)
        .build();
    final Collection<GrantedAuthority> authorities = Collections.EMPTY_LIST;
    return new JwtAuthenticationToken(jwt, authorities);
  }
  
  @Test
  void shouldReturnProductList() throws Exception {
    
    //given
    UUID id = UUID.randomUUID();
    Timestamp time = new Timestamp(System.currentTimeMillis());
    ApiProduct apiProduct = buildTestProduct(id, "1", time, true, "Prod");
    List<ApiProduct> productList = new ArrayList<ApiProduct>();
    productList.add(apiProduct);
    
    String planet = "Prod";
    Boolean external = true;

    //when    
    Mockito.when(apiProductsService.getProductsInternalOrExternalByPlanet(planet, external)).thenReturn(productList);

    //then    
    MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
    params.put("planet", Collections.singletonList("PROD"));
    params.put("internalExternal", Collections.singletonList("EXTERNAL"));

    MvcResult mvcResult = this.mockMvc.perform(get("/v1/products").contentType(MediaType.APPLICATION_JSON)
        .params(params)).andExpect(status().isOk()).andReturn();
    
  }

  @Test
  void shouldReturnBadInputForBadPlanet() throws Exception {

    //given
    MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
    params.put("planet", Collections.singletonList("badplanet"));
    params.put("internalExternal", Collections.singletonList("EXTERNAL"));

    //when-then    
    MvcResult mvcResult = this.mockMvc.perform(get("/v1/products").contentType(MediaType.APPLICATION_JSON)
        .params(params)).andExpect(status().is4xxClientError()).andReturn();
    
  }

  @Test
  void shouldReturnBadInputForBadInternalOrExternal() throws Exception {

    //given
    MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
    params.put("planet", Collections.singletonList("PROD"));
    params.put("internalExternal", Collections.singletonList("INVALID"));

    //when-then    
    MvcResult mvcResult = this.mockMvc.perform(get("/v1/products").contentType(MediaType.APPLICATION_JSON)
        .params(params)).andExpect(status().is4xxClientError()).andReturn();
    
  }

  @Test
  void shouldReturnProduct() throws Exception {

    //given
    UUID id = UUID.randomUUID();
    Timestamp time = new Timestamp(System.currentTimeMillis());
    ApiProduct apiProduct = buildTestProduct(id, "1", time, true, "Prod");

    //when    
    Mockito.when(apiProductsService.getProduct(id)).thenReturn(apiProduct);

    //then    
    MvcResult mvcResult = this.mockMvc.perform(get("/v1/products/" + id).contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(apiProduct))).andExpect(status().isOk()).andReturn();
    
  }

  @Test
  void shouldReturnProductNotFound() throws Exception {

    //given
    ApiProduct apiProduct = new ApiProduct();
    UUID id = UUID.randomUUID();

    //when    
    Mockito.when(apiProductsService.getProduct(id)).thenThrow(ProductNotFoundException.class);

    //then
    MvcResult mvcResult = this.mockMvc.perform(get("/v1/products/" + id).contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(apiProduct))).andExpect(status().isNotFound()).andReturn();
    
  }

  @Test
  void shouldSaveProduct() throws Exception {

    //given
    UUID id = UUID.randomUUID();
    Timestamp time = new Timestamp(System.currentTimeMillis());
    ApiProduct apiProduct = buildTestProduct(id, "1", time, true, "Prod");

    given(securityContext.getAuthentication())
        .willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);

    //when    
    Mockito.when(apiProductsService.saveProduct(apiProduct)).thenReturn(apiProduct);

    //Then    
    MvcResult mvcResult = this.mockMvc.perform(post("/v1/products").contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(apiProduct))).andExpect(status().isCreated()).andReturn();
    
  }

  @Test
  void shouldRejectIfRequiredDataIsMissing() throws Exception {

    //given
    ApiProduct apiProduct = new ApiProduct();
    
    //when    
    Mockito.when(apiProductsService.saveProduct(apiProduct)).thenReturn(apiProduct);

    //then    
    MvcResult mvcResult = this.mockMvc.perform(post("/v1/products").contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(apiProduct))).andExpect(status().is4xxClientError()).andReturn();
    
  }

  @Test
  void shouldUpdateProduct() throws Exception {

    //given
    given(securityContext.getAuthentication()).willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);
    UUID id = UUID.randomUUID();
    Timestamp time = new Timestamp(System.currentTimeMillis());
    ApiProduct apiProduct = buildTestProduct(id, "1", time, true, "Prod");
    Mockito.when(profileService.getEmailFromProfile(any(Jwt.class))).thenReturn("test@lumen.com");

    //when    
    Mockito.when(apiProductsService.updateProduct(apiProduct, "test@lumen.com")).thenReturn(apiProduct);

    //Then    
    MvcResult mvcResult = this.mockMvc.perform(put("/v1/products").contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(apiProduct))).andExpect(status().isOk()).andReturn();
    
  }

  @Test
  void shouldRejectUpdateIfRequiredDataIsMissing() throws Exception {

    //given
    given(securityContext.getAuthentication()).willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);
    ApiProduct apiProduct = new ApiProduct();

    //when    
    Mockito.when(profileService.getEmailFromProfile(any(Jwt.class))).thenReturn("test@lumen.com");
    Mockito.when(apiProductsService.updateProduct(apiProduct, "test@lumen.com")).thenReturn(apiProduct);

    //Then    
    MvcResult mvcResult = this.mockMvc.perform(put("/v1/products").contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(apiProduct))).andExpect(status().is4xxClientError()).andReturn();
    
  }

  @Test
  void shouldDeleteProduct() throws Exception {

    //given
    UUID id = UUID.randomUUID();
    given(securityContext.getAuthentication()).willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);
    ResponseEntity<String> response = new ResponseEntity<String>("Product deleted for id: " + id, HttpStatus.OK);

    //when    
    Mockito.when(profileService.getEmailFromProfile(any(Jwt.class))).thenReturn("test@lumen.com");
    Mockito.doNothing().when(apiProductsService).deleteProduct(id, "test@lumen.com");

    //then    
    MvcResult mvcResult = this.mockMvc.perform(delete("/v1/products/" + id).contentType(MediaType.TEXT_PLAIN)
        .content(new ObjectMapper().writeValueAsString(response)))
        .andExpect(status().isNoContent()).andReturn();
    
  }
  
  @Test
  void shouldReturnNotFoundForDeleteProduct() throws Exception {

    //given
    UUID id = UUID.randomUUID();
    given(securityContext.getAuthentication()).willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);
    ResponseEntity<String> response = new ResponseEntity<String>("Product not found for id: " + id,
        HttpStatus.NOT_FOUND);

    //when    
    Mockito.when(profileService.getEmailFromProfile(any(Jwt.class))).thenReturn("test@lumen.com");
    Mockito.doThrow(ProductNotFoundException.class).when(apiProductsService).deleteProduct(id, "test@lumen.com");
    
    //then    
    MvcResult mvcResult = this.mockMvc.perform(delete("/v1/products/" + id).contentType(MediaType.TEXT_PLAIN)
        .content(new ObjectMapper().writeValueAsString(response)))
        .andExpect(status().is4xxClientError()).andReturn();
    
  }
  
  @Test
  void shouldReturnInternalServerErrorForDeleteProduct() throws Exception {

    //given
    UUID id = UUID.randomUUID();
    given(securityContext.getAuthentication()).willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);
    ResponseEntity<String> response = new ResponseEntity<String>("Product not deleted for id: " + id,
        HttpStatus.INTERNAL_SERVER_ERROR);
    
    //when    
    Mockito.when(profileService.getEmailFromProfile(any(Jwt.class))).thenReturn("test@lumen.com");
    Mockito.doThrow(InternalServerException.class).when(apiProductsService).deleteProduct(id, "test@lumen.com");

    //then    
    MvcResult mvcResult = this.mockMvc.perform(delete("/v1/products/" + id).contentType(MediaType.TEXT_PLAIN)
        .content(new ObjectMapper().writeValueAsString(response)))
        .andExpect(status().is5xxServerError()).andReturn();

  }

  @Test
  void shouldReturnDataAccessExceptionForDeleteProduct() throws Exception {

    //given
    given(securityContext.getAuthentication()).willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);
    ResponseEntity<String> response = new ResponseEntity<String>("Data access exception",
        HttpStatus.INTERNAL_SERVER_ERROR);
    UUID id = UUID.randomUUID();
    
    //when    
    Mockito.when(profileService.getEmailFromProfile(any(Jwt.class))).thenReturn("test@lumen.com");
    Mockito.doThrow(Mockito.mock(DataAccessException.class)).when(apiProductsService)
        .deleteProduct(id, "test@lumen.com");

    //then    
    MvcResult mvcResult = this.mockMvc.perform(delete("/v1/products/" + id).contentType(MediaType.TEXT_PLAIN)
        .content(new ObjectMapper().writeValueAsString(response)))
        .andExpect(status().is5xxServerError()).andReturn();

  }

  private static ApiProduct buildTestProduct(UUID id, String prodInc, Timestamp time, boolean external, String planet) {
    ApiProduct apiProduct = new ApiProduct();
    apiProduct.setId(id);
    apiProduct.setName("myProductName" + prodInc);
    apiProduct.setAccess("myAccess" + prodInc);
    apiProduct.setApprovalType("myaApprovalType" + prodInc);
    apiProduct.setCreatedBy("ApiProductsServiceTest");
    apiProduct.setCreatedDate(time);
    apiProduct.setDescription("myDescription" + prodInc);
    apiProduct.setDisplayName("myDisplayName" + prodInc);
    apiProduct.setExternal(external);
    apiProduct.setLastUpdatedBy("myLastUpdatedBy" + prodInc);
    apiProduct.setLastUpdatedDate(time);
    apiProduct.setPlanet(planet);
    apiProduct.setSourceSystem("mySourceSys" + prodInc);
    apiProduct.setSourceSystemKey("mySourceSysKey" + prodInc);
    apiProduct.setVisibility("myVisibility" + prodInc);

    return apiProduct;
  
  }

}