package com.lumen.apiexchange.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lumen.apiexchange.exception.MyAppResponse;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.model.myapps.ApigeeAPIClientModel;
import com.lumen.apiexchange.model.myapps.CreateAppRequest;
import com.lumen.apiexchange.model.myapps.MyAppsModelResponse;
import com.lumen.apiexchange.model.myapps.UpdateAppRequest;
import com.lumen.apiexchange.model.myapps.api.product.ApiProductModelResponse;
import com.lumen.apiexchange.service.MyAppsService;
import com.lumen.apiexchange.service.ProfileService;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

/**
 * Tests for MyAppsController.
 */
@WebMvcTest(MyAppsController.class)
@AutoConfigureMockMvc(addFilters = false)
@DirtiesContext
public class MyAppsControllerTest {

  @Autowired
  private MockMvc mockMvc;

  @MockBean
  private MyAppsService myAppsService;

  @MockBean
  ProfileService profileService;

  @MockBean
  SecurityContext securityContext;

  protected static final Logger log = LoggerFactory.getLogger(MyAppsControllerTest.class);

  public static JwtAuthenticationToken getMockJwtToken(String subject) {
    final Jwt jwt = Jwt.withTokenValue("token")
        .header("alg", "none")
        .subject(subject)
        .build();
    final Collection<GrantedAuthority> authorities = Collections.EMPTY_LIST;
    return new JwtAuthenticationToken(jwt, authorities);
  }

  /**
   * <p>
   * Test to verify GET call responds with a json containing information of User Apps
   * </p>
   * The <b>service method response is mocked</b> to verify this case
   */
  @Test
  @DisplayName("Should respond with json content containing all app details")
  public void getAllAppsTest() throws Exception {

    String url = "/v1/userapps";

    String path = "src/test/resources/Mock_Data/MyAppsResponse.json";

    ObjectMapper objMapper = new ObjectMapper();
    MyAppsModelResponse appResponse = objMapper.readValue(new File(path), MyAppsModelResponse.class);

    Mockito.when(myAppsService.getApigeeApiClientForEnterpriseId(ArgumentMatchers.anyString())).thenReturn(appResponse);
    when(profileService.getEmailFromProfile(ArgumentMatchers.any(Jwt.class))).thenReturn("test@lumen.com");

    given(securityContext.getAuthentication())
        .willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);

    MvcResult mvcResult = mockMvc
        .perform(get(url).contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andReturn();

    assertEquals(mvcResult.getResponse().getContentType(), "application/json");
    assertNotNull(mvcResult.getResponse().getContentAsString());

  }

  @Test
  public void deleteAppTest() throws Exception {

    String userName = "pravin.chavhan@lumen.com";
    String userApp = "pc_app_test_2";
    String uri = "/v1/deleteuserapp/" + userApp;

    MyAppResponse respo = new MyAppResponse(1, 200, "Successfully deleted API Client from apigee");
    ResponseEntity<MyAppResponse> response = new ResponseEntity<MyAppResponse>(respo, HttpStatus.OK);

    when(profileService.getEmailFromProfile(any(Jwt.class))).thenReturn(userName);
    Mockito.when(myAppsService.deleteAppFromApigee(userName, userApp)).thenReturn(response);

    given(securityContext.getAuthentication())
        .willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);

    MvcResult mvcResult = this.mockMvc
        .perform(delete(uri).contentType(MediaType.APPLICATION_JSON)
            .content(new ObjectMapper().writeValueAsString(respo)))
        .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andReturn();

    assertEquals(200, mvcResult.getResponse().getStatus());
  }

  @Test
  @DisplayName("updateuserapps test ")
  public void updateAppTest() throws Exception {

    String url = "/v1/updateuserapps";

    UpdateAppRequest request = getUpdateAppRequest();
    String email = "test@test.com";

    ApigeeAPIClientModel respModel = new ApigeeAPIClientModel();

    when(profileService.getEmailFromProfile(any(Jwt.class))).thenReturn(email);
    Mockito.when(myAppsService.updateApp(request, email)).thenReturn(respModel);

    given(securityContext.getAuthentication())
        .willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);

    MvcResult mvcResult = mockMvc
        .perform(post(url).contentType(MediaType.APPLICATION_JSON)
            .content(new ObjectMapper().writeValueAsString(request)))
        .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andReturn();

    assertNotNull(mvcResult.getResponse().getContentAsString());
  }

  private UpdateAppRequest getUpdateAppRequest() {

    UpdateAppRequest request = new UpdateAppRequest();
    request.setName("test_123");
    request.setStatus("revoke");
    request.setKeyExpiresIn(0);

    return request;
  }

  @Test
  @DisplayName("Should respond with json content containing proxy details")
  public void getProxyDetailsTest() throws Exception {

    List<ApiMediatedResource> response = new ArrayList<>();
    ApiMediatedResource resp = new ApiMediatedResource();
    resp.setCreatedBy("testuser");
    resp.setResourceGuid("ae0cb758-9329-4217-b4d1-2e141d8e7f8a");
    response.add(resp);

    Mockito.when(myAppsService.getProxyDetails(UUID.randomUUID())).thenReturn(response);

    String url = "/v1/getproxydetails/" + UUID.randomUUID();
    MvcResult mvcResult =
        mockMvc.perform(get(url)).andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andReturn();


    assertEquals(mvcResult.getResponse().getContentType(), "application/json");
    assertNotNull(mvcResult.getResponse().getContentAsString());

  }

  /**
   * <p>
   * Test to verify POST call to Create an App responds with a json containing information of Created User App
   * </p>
   * The <b>service method response is mocked</b> to verify this case
   */
  @Test
  @DisplayName("Test POST request to create an app and expect json response of app details")
  void createUserAppTest() throws Exception {

    String reqPath = "src/test/resources/Mock_Data/CreateDevAppRequest.json";
    String resPath = "src/test/resources/Mock_Data/CreateDevAppResponse.json";

    String url = "/v1/createuserapps";
    String email = "test@test.com";

    ObjectMapper objMapper = new ObjectMapper();
    CreateAppRequest createAppRequest = objMapper.readValue(new File(reqPath), CreateAppRequest.class);
    ApigeeAPIClientModel createAppResponse = objMapper.readValue(new File(resPath), ApigeeAPIClientModel.class);
    when(profileService.getEmailFromProfile(any(Jwt.class))).thenReturn(email);
    when(myAppsService.createAppFromApigee(ArgumentMatchers.any(CreateAppRequest.class), ArgumentMatchers.anyString()))
        .thenReturn(createAppResponse);

    given(securityContext.getAuthentication())
        .willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);

    MvcResult mvcResult = mockMvc
        .perform(post(url).contentType(MediaType.APPLICATION_JSON)
            .content(objMapper.writeValueAsString(createAppRequest)))
        .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andReturn();

    assertEquals("application/json", mvcResult.getResponse().getContentType());
    assertNotNull(mvcResult.getResponse().getContentAsString());

  }

  /**
   * <p>
   * Test to verify POST call without Request Body responds with a 400 BAD REQUEST.
   * </p>
   */
  @Test
  @DisplayName("Test BAD REQUEST thrown when Request Body is not provided for creating app")
  void createUserAppBadRequestTest() throws Exception {
    String url = "/v1/createuserapps";

    mockMvc.perform(post(url)).andExpect(status().isBadRequest()).andDo(MockMvcResultHandlers.print()).andReturn();

  }

  /**
   * <p>
   * Test to verify GET call to get API Products and Description responds with a json containing information of all API
   * Products with their name, description and environments.
   * </p>
   * The <b>service method response is mocked</b> to verify this case
   */
  @Test
  @DisplayName("Test GET request to get json of API Products with their name, description and environments")
  void getApiProductsTest() throws Exception {
    String url = "/v1/apiproducts";

    String serviceRespPath = "src/test/resources/Mock_Data/APIProductsResponse.json";

    ObjectMapper objMapper = new ObjectMapper();
    ApiProductModelResponse serviceApiProdResponse = objMapper.readValue(new File(serviceRespPath),
        ApiProductModelResponse.class);
    ResponseEntity<ApiProductModelResponse> response = new ResponseEntity<ApiProductModelResponse>(
        serviceApiProdResponse, HttpStatus.OK);

    doReturn(response).when(myAppsService).getApiProductsFromApigee();

    MvcResult mvcResult = mockMvc.perform(get(url).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
        .andDo(MockMvcResultHandlers.print()).andReturn();

    assertEquals("application/json", mvcResult.getResponse().getContentType());
    assertNotNull(mvcResult.getResponse().getContentAsString());
  }

  /**
   * <p>
   * Test to verify POST call for getApiProducts responds with a 405 Method Not Allowed.
   * </p>
   */
  @Test
  @DisplayName("Test Method Not Allowed when POST method used to getApiProducts")
  void getApiProductsMethodNotAllowedTest() throws Exception {
    String url = "/v1/apiproducts";
    mockMvc.perform(post(url)).andExpect(status().isMethodNotAllowed()).andDo(MockMvcResultHandlers.print())
        .andReturn();
  }

}
