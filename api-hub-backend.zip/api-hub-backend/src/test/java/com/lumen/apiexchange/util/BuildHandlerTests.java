package com.lumen.apiexchange.util;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

import com.lumen.apiexchange.IntegrationTestBase;
import com.lumen.apiexchange.model.InputApiRequest;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("it")
@AutoConfigureWireMock(port = 0)
public class BuildHandlerTests extends IntegrationTestBase {

  @Autowired
  private BuildHandler buildH;

  @Test
  public void contextLoads() throws Exception {
    assertThat(buildH).isNotNull();
  }

  @Test
  public void testCreateBuildRequest() throws Exception {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setEnv("dev1");
    inputRes.setTaxonomy("Application/Apigee");
    inputRes.setResourceName("test");
    inputRes.setVersion("v1");
    inputRes.setSoap("true");
    inputRes.setType("Inbound");
    inputRes.setOwningAppAppkey("AppKey");
    inputRes.setMalId("MalID1234");
    inputRes.setDev1EndpointHostname("http://dev1.com");
    inputRes.setEndpointPath("/doSomething");
    inputRes.setInternal("true");
    inputRes.setExternal("true");
    inputRes.setProxyAuthInternal("appkey");
    inputRes.setProxyAuthExternal("basicAuth");
    inputRes.setAppkeyEnforceDigest("true");
    inputRes.setAppkeyEnforceTaxonomy("true");
    inputRes.setBasicAuthGroups("LDAP Groups");
    inputRes.setBasicAuthUsers("txwatki");
    inputRes.setEndpointAuth("basicAuth");
    inputRes.setEndpointBasicAuthUserAll("userAll");
    inputRes.setEndpointBasicAuthPwAll("pwAll");
    inputRes.setOauthGrantType("oauthGrantType");
    inputRes.setOauthGrantLocation("oauthGrantLocation");
    inputRes.setOauthTokenServiceHost("oauthTokenServiceHost");
    inputRes.setOauthTokenServiceURI("oauthTokenServiceURI");
    inputRes.setOauthClientId("oauthClientId");
    inputRes.setOauthClientIdLocation("oauthClientIdLocation");
    inputRes.setOauthSecret("oauthSecret");
    inputRes.setOauthScope("oauthScope");
    inputRes.setOauthScopeLocation("oauthScopeLocation");
    inputRes.setOauthUserName("oauthUserName");
    inputRes.setOauthpw("oauthpw");
    inputRes.setOauthCredentialsLocation("oauthCredentialsLocation");
    inputRes.setPingUrl("pingUrl");
    inputRes.setDocumentationUrl("documentationUrl");
    inputRes.setActive("true");
    inputRes.setJwtSubject("jwtSubject");
    inputRes.setX509CertAlias("X509CertAlias");
    inputRes.setThreatProtectionOverrides("ThreatProtectionOverrides");
    inputRes.setB2bAuthRequired("B2bAuthRequired");
    inputRes.setB2bCustomerNumberRequired("B2bCustomerNumberRequired");
    inputRes.setB2bBillingAccountNumberRequired("B2bBillingAccountNumberRequired");
    inputRes.setCreatedBy("CreatedBy");
    inputRes.setCreatedDate("CreatedDate");
    inputRes.setUpdatedBy("UpdatedBy");
    inputRes.setUpdatedDate("UpdatedDate");
    inputRes.setGuid("Guid");
    inputRes.setMediatedResourceId("MediatedResourceId");
    inputRes.setMediatedResourceId("MediatedResourceId");
    inputRes.setMediatedResourceId("MediatedResourceId");

    String myRequest = buildH.createBuildRequest(inputRes);

    JSONParser parser = new JSONParser();
    JSONObject responseJsonObj = null;

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("resourceTaxonomy").toString().equals(inputRes.getTaxonomy()));
    assertThat(responseJsonObj.get("resourceName").toString().equals(inputRes.getResourceName()));
    assertThat(responseJsonObj.get("version").toString().equals(inputRes.getVersion()));
    assertThat(responseJsonObj.get("serviceType").toString().equals(inputRes.getSoap()));
    assertThat(responseJsonObj.get("type").toString().equals(inputRes.getType()));
    assertThat(responseJsonObj.get("owningApplicationKey").toString().equals(inputRes.getOwningAppAppkey()));
    assertThat(responseJsonObj.get("owningApplicationId").toString().equals(inputRes.getMalId()));
    assertThat(responseJsonObj.get("endPointUrl").toString().equals(inputRes.getDev1EndpointHostname()));
    assertThat(responseJsonObj.get("replaceUrlToValue").toString().equals(inputRes.getEndpointPath()));
    assertThat(responseJsonObj.get("internallyAvailable").toString().equals(inputRes.getInternal()));
    assertThat(responseJsonObj.get("externallyAvailable").toString().equals(inputRes.getExternal()));
    assertThat(responseJsonObj.get("validAuthTypes").toString().equals(inputRes.getProxyAuthInternal()));
    assertThat(responseJsonObj.get("validAuthTypesExt").toString().equals(inputRes.getProxyAuthExternal()));
    assertThat(responseJsonObj.get("enforceDigest").toString().equals(inputRes.getAppkeyEnforceDigest()));
    assertThat(responseJsonObj.get("enforceTaxonomy").toString().equals(inputRes.getAppkeyEnforceTaxonomy()));
    assertThat(responseJsonObj.get("authorizedGroups").toString().equals(inputRes.getBasicAuthGroups()));
    assertThat(responseJsonObj.get("authorizedUsers").toString().equals(inputRes.getBasicAuthUsers()));
    assertThat(responseJsonObj.get("endpointAuthType").toString().equals(inputRes.getEndpointAuth()));
    assertThat(responseJsonObj.get("basicAuthUser").toString().equals(inputRes.getEndpointBasicAuthUserAll()));
    assertThat(responseJsonObj.get("basicAuthPassword").toString().equals(inputRes.getEndpointBasicAuthPwAll()));
    assertThat(responseJsonObj.get("oAuthGrantType").toString().equals(inputRes.getOauthGrantType()));
    assertThat(responseJsonObj.get("oAuthGrantTypeLocation").toString().equals(inputRes.getOauthGrantLocation()));
    assertThat(responseJsonObj.get("oAuthTokenServiceHost").toString().equals(inputRes.getOauthTokenServiceHost()));
    assertThat(responseJsonObj.get("oAuthTokenServiceUri").toString().equals(inputRes.getOauthTokenServiceURI()));
    assertThat(responseJsonObj.get("oAuthClientId").toString().equals(inputRes.getOauthClientId()));
    assertThat(responseJsonObj.get("oAuthClientIdLocation").toString().equals(inputRes.getOauthClientIdLocation()));
    assertThat(responseJsonObj.get("oAuthClientSecret").toString().equals(inputRes.getOauthSecret()));
    assertThat(responseJsonObj.get("oAuthScope").toString().equals(inputRes.getOauthScope()));
    assertThat(responseJsonObj.get("oAuthScopeLocation").toString().equals(inputRes.getOauthScopeLocation()));
    assertThat(responseJsonObj.get("oAuthUsername").toString().equals(inputRes.getOauthUserName()));
    assertThat(responseJsonObj.get("oAuthPassword").toString().equals(inputRes.getOauthpw()));
    assertThat(responseJsonObj.get("oAuthUsernameLocation").toString().equals(inputRes.getOauthCredentialsLocation()));
    assertThat(responseJsonObj.get("pingUrl").toString().equals(inputRes.getPingUrl()));
    assertThat(responseJsonObj.get("documentationUrl").toString().equals(inputRes.getDocumentationUrl()));
    assertThat(responseJsonObj.get("active").toString().equals(inputRes.getActive()));
    assertThat(responseJsonObj.get("jwtSubject").toString().equals(inputRes.getJwtSubject()));
    assertThat(responseJsonObj.get("x509CertAlias").toString().equals(inputRes.getGuid()));
    assertThat(
        responseJsonObj.get("threatProtectionOverrides").toString().equals(inputRes.getThreatProtectionOverrides()));
    assertThat(responseJsonObj.get("b2bAuthRequired").toString().equals(inputRes.getB2bAuthRequired()));
    assertThat(
        responseJsonObj.get("b2bCustomerNumberRequired").toString().equals(inputRes.getB2bCustomerNumberRequired()));
    assertThat(responseJsonObj.get("b2bBillingAccountNumberRequired").toString()
        .equals(inputRes.getB2bBillingAccountNumberRequired()));
    assertThat(responseJsonObj.get("createdBy").toString().equals(inputRes.getCreatedBy()));
    assertThat(responseJsonObj.get("createdDate").toString().equals(inputRes.getCreatedDate()));
    assertThat(responseJsonObj.get("updatedBy").toString().equals(inputRes.getUpdatedBy()));
    assertThat(responseJsonObj.get("updatedDate").toString().equals(inputRes.getUpdatedDate()));
    assertThat(responseJsonObj.get("resourceGuid").toString().equals(inputRes.getGuid()));
  }

  @Test
  public void testCreateBuildRequestDev1() throws Exception {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setEnv("dev1");
    inputRes.setDev1EndpointHostname("http://dev1.com");
    inputRes.setTaxonomy("Application/Apigee");

    String myRequest = buildH.createBuildRequest(inputRes);

    JSONParser parser = new JSONParser();
    JSONObject responseJsonObj = null;

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("endPointUrl").toString().equals(inputRes.getDev1EndpointHostname()));
    
    inputRes.setEndpointBasicAuthUserDev1(null);
    inputRes.setEndpointBasicAuthPwDev1(null);
    inputRes.setEndpointBasicAuthUserAll("userAll");
    inputRes.setEndpointBasicAuthPwAll("pwAll");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("basicAuthUser").toString().equals(inputRes.getEndpointBasicAuthUserAll()));
    assertThat(responseJsonObj.get("basicAuthPassword").toString().equals(inputRes.getEndpointBasicAuthPwAll()));

    inputRes.setEndpointBasicAuthUserDev1("");
    inputRes.setEndpointBasicAuthPwDev1("");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("basicAuthUser").toString().equals(inputRes.getEndpointBasicAuthUserAll()));
    assertThat(responseJsonObj.get("basicAuthPassword").toString().equals(inputRes.getEndpointBasicAuthPwAll()));

    inputRes.setEndpointBasicAuthUserDev1(null);
    inputRes.setEndpointBasicAuthPwDev1(null);
    inputRes.setEndpointBasicAuthUserAll(null);
    inputRes.setEndpointBasicAuthPwAll(null);

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("basicAuthUser") == null);
    assertThat(responseJsonObj.get("basicAuthPassword") == null);

    inputRes.setEndpointBasicAuthUserAll("");
    inputRes.setEndpointBasicAuthPwAll("");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("basicAuthUser") == null);
    assertThat(responseJsonObj.get("basicAuthPassword") == null);

  }

  @Test
  public void testCreateBuildRequestDev2() throws Exception {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setEnv("dev2");
    inputRes.setDev2EndpointHostname("http://dev2.com");
    inputRes.setTaxonomy("Application/Apigee");

    String myRequest = buildH.createBuildRequest(inputRes);

    JSONParser parser = new JSONParser();
    JSONObject responseJsonObj = null;

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("endPointUrl").toString().equals(inputRes.getDev2EndpointHostname()));
    
    inputRes.setEndpointBasicAuthUserDev2(null);
    inputRes.setEndpointBasicAuthPwDev2(null);
    inputRes.setEndpointBasicAuthUserAll("userAll");
    inputRes.setEndpointBasicAuthPwAll("pwAll");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("basicAuthUser").toString().equals(inputRes.getEndpointBasicAuthUserAll()));
    assertThat(responseJsonObj.get("basicAuthPassword").toString().equals(inputRes.getEndpointBasicAuthPwAll()));

    inputRes.setEndpointBasicAuthUserDev2("");
    inputRes.setEndpointBasicAuthPwDev2("");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("basicAuthUser").toString().equals(inputRes.getEndpointBasicAuthUserAll()));
    assertThat(responseJsonObj.get("basicAuthPassword").toString().equals(inputRes.getEndpointBasicAuthPwAll()));

    inputRes.setEndpointBasicAuthUserDev2(null);
    inputRes.setEndpointBasicAuthPwDev2(null);
    inputRes.setEndpointBasicAuthUserAll(null);
    inputRes.setEndpointBasicAuthPwAll(null);

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("basicAuthUser") == null);
    assertThat(responseJsonObj.get("basicAuthPassword") == null);

    inputRes.setEndpointBasicAuthUserAll("");
    inputRes.setEndpointBasicAuthPwAll("");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("basicAuthUser") == null);
    assertThat(responseJsonObj.get("basicAuthPassword") == null);

  }

  @Test
  public void testCreateBuildRequestDev3() throws Exception {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setEnv("dev3");
    inputRes.setDev3EndpointHostname("http://Dev3.com");
    inputRes.setTaxonomy("Application/Apigee");

    String myRequest = buildH.createBuildRequest(inputRes);

    JSONParser parser = new JSONParser();
    JSONObject responseJsonObj = null;

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("endPointUrl").toString().equals(inputRes.getDev3EndpointHostname()));
    
    inputRes.setEndpointBasicAuthUserDev3(null);
    inputRes.setEndpointBasicAuthPwDev3(null);
    inputRes.setEndpointBasicAuthUserAll("userAll");
    inputRes.setEndpointBasicAuthPwAll("pwAll");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("basicAuthUser").toString().equals(inputRes.getEndpointBasicAuthUserAll()));
    assertThat(responseJsonObj.get("basicAuthPassword").toString().equals(inputRes.getEndpointBasicAuthPwAll()));

    inputRes.setEndpointBasicAuthUserDev3("");
    inputRes.setEndpointBasicAuthPwDev3("");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("basicAuthUser").toString().equals(inputRes.getEndpointBasicAuthUserAll()));
    assertThat(responseJsonObj.get("basicAuthPassword").toString().equals(inputRes.getEndpointBasicAuthPwAll()));

    inputRes.setEndpointBasicAuthUserDev3(null);
    inputRes.setEndpointBasicAuthPwDev3(null);
    inputRes.setEndpointBasicAuthUserAll(null);
    inputRes.setEndpointBasicAuthPwAll(null);

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("basicAuthUser") == null);
    assertThat(responseJsonObj.get("basicAuthPassword") == null);

    inputRes.setEndpointBasicAuthUserAll("");
    inputRes.setEndpointBasicAuthPwAll("");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("basicAuthUser") == null);
    assertThat(responseJsonObj.get("basicAuthPassword") == null);

  }

  @Test
  public void testCreateBuildRequestDev4() throws Exception {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setEnv("dev4");
    inputRes.setDev4EndpointHostname("http://Dev4.com");
    inputRes.setTaxonomy("Application/Apigee");

    String myRequest = buildH.createBuildRequest(inputRes);

    JSONParser parser = new JSONParser();
    JSONObject responseJsonObj = null;

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("endPointUrl").toString().equals(inputRes.getDev4EndpointHostname()));
    
    inputRes.setEndpointBasicAuthUserDev4(null);
    inputRes.setEndpointBasicAuthPwDev4(null);
    inputRes.setEndpointBasicAuthUserAll("userAll");
    inputRes.setEndpointBasicAuthPwAll("pwAll");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("basicAuthUser").toString().equals(inputRes.getEndpointBasicAuthUserAll()));
    assertThat(responseJsonObj.get("basicAuthPassword").toString().equals(inputRes.getEndpointBasicAuthPwAll()));

    inputRes.setEndpointBasicAuthUserDev4("");
    inputRes.setEndpointBasicAuthPwDev4("");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("basicAuthUser").toString().equals(inputRes.getEndpointBasicAuthUserAll()));
    assertThat(responseJsonObj.get("basicAuthPassword").toString().equals(inputRes.getEndpointBasicAuthPwAll()));

    inputRes.setEndpointBasicAuthUserDev4(null);
    inputRes.setEndpointBasicAuthPwDev4(null);
    inputRes.setEndpointBasicAuthUserAll(null);
    inputRes.setEndpointBasicAuthPwAll(null);

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("basicAuthUser") == null);
    assertThat(responseJsonObj.get("basicAuthPassword") == null);

    inputRes.setEndpointBasicAuthUserAll("");
    inputRes.setEndpointBasicAuthPwAll("");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("basicAuthUser") == null);
    assertThat(responseJsonObj.get("basicAuthPassword") == null);

  }

  private JSONObject parseJson(String response, JSONParser parser) throws ParseException {
    Object responseObj = parser.parse(response);

    JSONObject responseJsonObj = (JSONObject) responseObj;

    return responseJsonObj;
  }

  @Test
  public void testCreateBuildRequestActive() throws Exception {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setEnv("dev1");
    inputRes.setTaxonomy("Application/Apigee");
    inputRes.setActive("true");

    String myRequest = buildH.createBuildRequest(inputRes);

    JSONParser parser = new JSONParser();
    JSONObject responseJsonObj = null;

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("active").toString().equals(inputRes.getActive()));

    inputRes.setActive(null);

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("active").toString().equals("true"));

    inputRes.setActive("");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("active").toString().equals("true"));

  }

  @Test
  public void testCreateBuildRequestSoap() throws Exception {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setEnv("dev1");
    inputRes.setTaxonomy("Application/Apigee");
    inputRes.setSoap("true");

    String myRequest = buildH.createBuildRequest(inputRes);

    JSONParser parser = new JSONParser();
    JSONObject responseJsonObj = null;

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("serviceType").toString().equals(inputRes.getSoap()));

    inputRes.setSoap(null);

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("serviceType").toString().isEmpty());

    inputRes.setSoap("badValue");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("serviceType").toString().isEmpty());
  }

  @Test
  public void testCreateBuildRequestTaxonomy() throws Exception {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setEnv("dev1");
    inputRes.setTaxonomy("Application/Apigee");
    inputRes.setResourceName("resourceName");
    inputRes.setVersion("v1");

    String myRequest = buildH.createBuildRequest(inputRes);

    JSONParser parser = new JSONParser();
    JSONObject responseJsonObj = null;

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("replaceUrlFromValue").toString().equals("/Application/v1/Apigee/resourceName"));

    inputRes.setTaxonomy("Apigee");
    inputRes.setResourceName("resourceName");
    inputRes.setVersion("v1");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("replaceUrlFromValue").toString().equals("/Apigee/v1/resourceName"));

  }

  @Test
  public void testCreateBuildRequestEndpointAuth() throws Exception {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setEnv("dev1");
    inputRes.setTaxonomy("Application/Apigee");
    inputRes.setEndpointAuth("EndpointAuth");

    String myRequest = buildH.createBuildRequest(inputRes);

    JSONParser parser = new JSONParser();
    JSONObject responseJsonObj = null;

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("endpointAuthType").toString().equals(inputRes.getEndpointAuth()));

    inputRes.setEndpointAuth(null);

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("endpointAuthType").toString().equals("none"));

    inputRes.setEndpointAuth("");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("endpointAuthType").toString().equals("none"));

  }

  @Test
  public void testCreateBuildRequestEndpointAuthJwt() throws Exception {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setEnv("dev4");
    inputRes.setTaxonomy("Application/Apigee");
    inputRes.setEndpointAuth("jwt");

    String myRequest = buildH.createBuildRequest(inputRes);

    JSONParser parser = new JSONParser();
    JSONObject responseJsonObj = null;

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("jwtIssuer").toString().equals("apigateway-prod"));

    inputRes.setEnv("dev1");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertThat(responseJsonObj.get("jwtIssuer").toString().equals("apigateway-nonprod"));

  }

  @Test
  public void testCreateBuildRequestOauthGrantType() throws Exception {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setEnv("dev1");
    inputRes.setTaxonomy("Application/Apigee");
    inputRes.setEndpointAuth("EndpointAuth");
    inputRes.setOauthGrantType(null);

    String myRequest = buildH.createBuildRequest(inputRes);

    JSONParser parser = new JSONParser();
    JSONObject responseJsonObj = null;

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertEquals(responseJsonObj.get("oAuthGrantType"), "");

    inputRes.setOauthGrantType("");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertEquals(responseJsonObj.get("oAuthGrantType"), "");

    inputRes.setOauthGrantType("Password");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    inputRes.setOauthGrantType("password");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertEquals(responseJsonObj.get("oAuthGrantType"), "password");

    inputRes.setOauthGrantType("client_credentials");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertEquals(responseJsonObj.get("oAuthGrantType"), "client_credentials");

    inputRes.setOauthGrantType("jwt-bearer");

    myRequest = buildH.createBuildRequest(inputRes);

    try {
      responseJsonObj = parseJson(myRequest, parser);
    } catch (ParseException e1) {
      e1.printStackTrace();
    }

    assertEquals(responseJsonObj.get("oAuthGrantType"), "jwt-bearer");

  }

  @Test
  public void shouldReturnAProxyName() throws Exception {
    
    String proxyName = buildH.buildApigeeProxyName("v1", "CompanyABC", "resource", "1234567890");
    
    assertEquals(proxyName, "Esp_IntMed_Partner_v1_CompanyABC_resource_1234567890");
    
  }
}
