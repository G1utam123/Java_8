package com.lumen.apiexchange.controller;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ESPHealthStatusResponse;
import com.lumen.apiexchange.service.ESPHealthService;
import com.lumen.apiexchange.service.ESPHealthServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.web.config.EnableSpringDataWebSupport;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.nio.file.Files;
import java.nio.file.Paths;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@WebMvcTest(controllers = {HealthController.class})
@ActiveProfiles("it")
@AutoConfigureMockMvc
@EnableSpringDataWebSupport
public class HealthControllerTest {
  @Value("${epb.status.api.url}")
  private String baseUrl;

  @Value("${epb.status.api.endpoint}")
  private String statusEndpoint;

  @Autowired
  private MockMvc mockMvc;

  @MockBean
  private ESPHealthService espHealthService;

  @Autowired
  private ObjectMapper objectMapper;


  private ESPHealthStatusResponse mockResponse;

  @BeforeEach
  public void setup() throws Exception {
    // Cargar el archivo JSON en un objeto ESPHealthStatusResponse
    String json = new String(Files.readAllBytes(Paths.get("src/test/resources/__files/apihub-heartbeat-response.json")));
    mockResponse = objectMapper.readValue(json, ESPHealthStatusResponse.class);

    // Mockear el servicio para devolver el objeto cargado desde el archivo JSON
    when(espHealthService.getESPHealthStatus()).thenReturn(mockResponse);
  }

  @Test
  public void testGetESPHealthStatus() throws Exception {
    mockMvc.perform(get("/v1/health/esp")
            .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk());
  }

  @Test
  public void testGetEmptyESPHealthStatus() throws Exception {

      // Cargar el archivo JSON en un objeto ESPHealthStatusResponse
      String json = new String(Files.readAllBytes(Paths.get("src/test/resources/__files/apihub-heartbeated-empty-response.json")));
      mockResponse = objectMapper.readValue(json, ESPHealthStatusResponse.class);

      // Mockear el servicio para devolver el objeto cargado desde el archivo JSON
      when(espHealthService.getESPHealthStatus()).thenReturn(mockResponse);


    mockMvc.perform(get("/v1/health/esp")
            .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.ESP-TEST3").value(0))
        .andExpect(jsonPath("$.ESP-TEST4").value(0));
  }

  @Test
  public void testGet500ErrorHealthStatus() throws Exception {


    when(espHealthService.getESPHealthStatus()).thenThrow(new InternalServerException("Error"));


    mockMvc.perform(get("/v1/health/esp")
            .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().is5xxServerError());
  }
}
