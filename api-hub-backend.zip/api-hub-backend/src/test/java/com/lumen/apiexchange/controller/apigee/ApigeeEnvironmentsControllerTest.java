package com.lumen.apiexchange.controller.apigee;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.lumen.apiexchange.service.ProfileService;
import com.lumen.apiexchange.service.apigee.ApigeeEnvironmentsServiceImpl;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

@WebMvcTest(controllers = { ApigeeEnvironmentsController.class }) 
@AutoConfigureMockMvc(addFilters = false)
class ApigeeEnvironmentsControllerTest {

  @Autowired
  private MockMvc mockMvc;

  @MockBean
  private ApigeeEnvironmentsServiceImpl apigeeEnvService;

  @MockBean
  private ProfileService profileService;

  @MockBean
  SecurityContext securityContext;

  protected static final Logger log = LoggerFactory.getLogger(ApigeeEnvironmentsServiceImpl.class);

  static JwtAuthenticationToken getMockJwtToken(String subject) {
    final Jwt jwt = Jwt.withTokenValue("token")
        .header("alg", "none")
        .subject(subject)
        .build();
    final Collection<GrantedAuthority> authorities = Collections.EMPTY_LIST;
    return new JwtAuthenticationToken(jwt, authorities);
  }
  
  @Test
  void shouldReturnApigeeEnvironmentList() throws Exception {
    
    //given
    List<String> envList = new ArrayList<String>(Arrays.asList("dev1", "dev2", "test1", "test2"));
    String planet = "PROD";
    String org = "EXTERNAL";

    //when    
    Mockito.when(apigeeEnvService.getEnvironments(planet, org)).thenReturn(envList);

    //then    
    MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
    params.put("planet", Collections.singletonList(planet));
    params.put("internalExternal", Collections.singletonList(org));

    MvcResult mvcResult = this.mockMvc.perform(get("/v1/environments/apigee").contentType(MediaType.APPLICATION_JSON)
        .params(params)).andExpect(status().isOk()).andReturn();
    
  }

  @Test
  void shouldReturnBadInputForBadPlanetApigee() throws Exception {

    //given
    MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
    params.put("planet", Collections.singletonList("badplanet"));
    params.put("internalExternal", Collections.singletonList("EXTERNAL"));

    //when-then    
    MvcResult mvcResult = this.mockMvc.perform(get("/v1/environments/apigee").contentType(MediaType.APPLICATION_JSON)
        .params(params)).andExpect(status().is4xxClientError()).andReturn();
    
  }

  @Test
  void shouldReturnBadInputForBadInternalOrExternalApigee() throws Exception {

    //given
    MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
    params.put("planet", Collections.singletonList("PROD"));
    params.put("internalExternal", Collections.singletonList("INVALID"));

    //when-then    
    MvcResult mvcResult = this.mockMvc.perform(get("/v1/environments/apigee").contentType(MediaType.APPLICATION_JSON)
        .params(params)).andExpect(status().is4xxClientError()).andReturn();
    
  }
  
}