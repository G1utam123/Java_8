package com.lumen.apiexchange.service;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.put;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.lumen.apiexchange.IntegrationTestBase;
import com.lumen.apiexchange.exception.AppNotFoundException;
import com.lumen.apiexchange.exception.CustomStatusResponse;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.entity.ProxyResponse;
import com.lumen.apiexchange.model.SingleMediatedResponse;
import com.lumen.apiexchange.model.myapps.ApigeeAPIClientModel;
import com.lumen.apiexchange.model.myapps.CreateAppRequest;
import com.lumen.apiexchange.model.myapps.MyAppsModelResponse;
import com.lumen.apiexchange.model.myapps.UpdateAppRequest;
import com.lumen.apiexchange.model.myapps.api.product.ApiProductModelResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.server.ResponseStatusException;

/**
 * All tests for the My Apps Service Implementation.
 */
@SpringBootTest
@ActiveProfiles("it")
@AutoConfigureWireMock(port = 0)
public class MyAppsServiceTest extends IntegrationTestBase {
  @Autowired
  private MyAppsService myAppsService;

  /**
   * <p>
   * Test where to verify Response Status Exception thrown when Email ID is null
   * </p>
   */
  @Test
  @DisplayName("Should throw Response Status Exception when Email is null")
  public void getApigeeApiClientForEnterpriseId_EmptyEmail_ExceptionTest() {

    String email = null;

    ResponseStatusException exception = assertThrows(ResponseStatusException.class,
        () -> myAppsService.getApigeeApiClientForEnterpriseId(email));

    assertEquals("Exception not working!", "400 BAD_REQUEST \"Email Id is mandatory!\"", exception.getMessage());
  }


  /**
   * <p>
   * Test where to verify Internal Server Exception thrown when APIGEE is down and no response from APIGEE
   * </p>
   * <b>APIGEE response is not mocked</b> to achieve this exception case
   */
  @Test
  @DisplayName("Should throw Server Exception when APIGEE server is down")
  public void getApigeeApiClientForEnterpriseId_ServerExceptionTest() {
    String email = "test-down@example.com";

    InternalServerException exception = assertThrows(InternalServerException.class,
        () -> myAppsService.getApigeeApiClientForEnterpriseId(email));

    boolean isExceptionThrow = exception.getMessage().contains("Unable to get API Client from apigee");
    assertTrue("Exception thrown is different!", isExceptionThrow);
  }


  /**
   * <p>
   * Test where to verify that an ApigeeAPIClientModelResponse is obtained and converted into MyAppsModelResponse on
   * successful request.
   * </p>
   * <b>APIGEE response is mocked</b> to achieve this case
   */
  @Test
  @DisplayName("Should return ApigeeAPIClientModelResponse when email is not null")
  void getApigeeApiClientForEnterpriseIDTest() throws Exception {

    //given
    String email = "test@example.com";

    stubFor(get(urlPathEqualTo("/Application/v1/Apigee/liamsync/customer/" + email + "/apiclient"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("liamsync-apiclients-response.json")
            .withHeader("Content-Type", "application/json")));

    //when
    MyAppsModelResponse actualResponse = myAppsService.getApigeeApiClientForEnterpriseId(email);

    //then
    assertThat(actualResponse.getApp().size()).isEqualTo(12);
  }

  @Test
  public void deleteAppFromApigeeTest() throws InternalServerException {
    String userName = "pradeeprai.k@lumen.com";
    String userApp = "test_with_pravin";

    myAppsService.deleteAppFromApigee(userName, userApp);
  }

  @Test
  @DisplayName("Should return AppNotFound Exception")
  void updateApp_AppNotFoundExceptionTest() {

    //given
    UpdateAppRequest request = getUpdateAppRequest();
    String email = "test-not-found@test.com";

    stubFor(put(urlPathEqualTo(
        "/Application/v1/Apigee/liamsync/customer/".concat(email) + "/apiclient/" + request.getName()))
        .withQueryParam("action", equalTo("update"))
        .willReturn(aResponse()
            .withStatus(404)
            .withBody("{\n" +
                "      \"code\": \"keymanagement.service.apiproduct_doesnot_exist\",\n" +
                "      \"message\": \"AppNotFoundException\",\n" +
                "      \"contexts\": []\n" +
                "    }")
            .withHeader("Content-Type", "application/json")));

    //when-then
    AppNotFoundException exception = assertThrows(AppNotFoundException.class, () -> {
      myAppsService.updateApp(request, email);
    });
    assertTrue(exception.getMessage().contains("AppNotFoundException"));

  }

  @Test
  @DisplayName("Should return InternalServerException")
  void updateApp_InternalServerExceptionTest() throws Exception {

    //given
    UpdateAppRequest request = getUpdateAppRequest();
    String email = "test-down@test.com";

    stubFor(put(urlPathEqualTo("/Application/v1/Apigee/liamsync/customer/" + email + "/apiclient/" + request.getName()))
        .willReturn(aResponse()
            .withStatus(500)
            .withHeader("Content-Type", "application/json")));

    //when-then
    InternalServerException exception = assertThrows(InternalServerException.class, () -> {
      myAppsService.updateApp(request, email);
    });

    assertThat(exception.getMessage()).isNotNull();

  }

  private UpdateAppRequest getUpdateAppRequest() {

    UpdateAppRequest request = new UpdateAppRequest();
    request.setName("test_123");
    request.setStatus("revoke");
    request.setKeyExpiresIn(0);

    return request;
  }

  @Test
  @DisplayName("Should return ProxyDetails")
  void getProxyDetailsTest() throws Exception {

    HttpHeaders headers = new HttpHeaders();
    headers.set("Authorization", null);

    ApiMediatedResource apiResource = new ApiMediatedResource();

    apiResource.setActive("Test");
    apiResource.setAuthorizedGroups("Test");
    apiResource.setAuthorizedUsers("Test");
    apiResource.setB2bAuthRequired("Test");
    List<ApiMediatedResource> resource = new ArrayList<>();
    resource.add(apiResource);
    List<ProxyResponse> response = getProxyRespValue();
    SingleMediatedResponse res = new SingleMediatedResponse();
    res.setMediatedResource(apiResource);
    ResponseEntity<SingleMediatedResponse> reMock = mock(ResponseEntity.class);
    when(reMock.getBody()).thenReturn(res);

    HttpEntity<String> entity = new HttpEntity<String>(headers);

    try {
      // when(apiProxyRepo.getProxyDetails(54)).thenReturn(response);
      assertNotNull(myAppsService.getProxyDetails(UUID.randomUUID()));

    } catch (Exception e) {
      e.printStackTrace();
    }

  }

  private List<ProxyResponse> getProxyRespValue() {
    List<ProxyResponse> response = new ArrayList<>();
    ProxyResponse resp1 = new ProxyResponse();
    resp1.setResourceGuuid("ef0cb758-9329-4217-b4d1-2e141d8e7f8b");
    ProxyResponse resp2 = new ProxyResponse();
    resp2.setResourceGuuid("ef0cb758-9329-4217-b4d1-2e141d8e7f8b");
    response.add(resp1);
    response.add(resp2);
    return response;
  }

  /**
   * <p>
   * Test where to verify that an ApigeeAPIClientModel is obtained when createAppFromApigee method is called.
   * </p>
   * <b>APIGEE response is mocked</b> to achieve this case
   */
  @Test
  @DisplayName("Should return ApigeeClientModel when createAppFromApigee method is called with appropriate parameters")
  void createAppFromApigeeTest() throws Exception {

    // given
    String email = "test@test.com";
    CreateAppRequest createAppRequest = new CreateAppRequest();

    stubFor(post(urlPathEqualTo("/Application/v1/Apigee/liamsync/customer/".concat(email)))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("liamsync-create-apiclient-response.json")
            .withHeader("Content-Type", "application/json")));

    // when
    ApigeeAPIClientModel actualResponse = myAppsService.createAppFromApigee(createAppRequest, email);

    // then
    assertThat(actualResponse.getStatus()).isEqualTo("approved");
  }

  /**
   * <p>
   * Test where to verify InternalServerException thrown when Exception occurs in createAppFromApigee method.
   * </p>
   */
  @Test
  @DisplayName("Should return InternalServerException when createAppFromApigee method throws 500 error")
  void createAppInternalServerExceptionTest() throws Exception {

    // given
    String email = "test-down@test.com";
    CreateAppRequest createAppRequest = new CreateAppRequest();

    stubFor(post(urlPathEqualTo("/Application/v1/Apigee/liamsync/customer/".concat(email)))
        .willReturn(aResponse()
            .withStatus(500)
            .withBody("{\n" +
                "      \"code\": \"keymanagement.service.apiproduct_doesnot_exist\",\n" +
                "      \"message\": \"InternalServerException\",\n" +
                "      \"contexts\": []\n" +
                "    }")
            .withHeader("Content-Type", "application/json")));

    // when
    InternalServerException exception = assertThrows(InternalServerException.class, () -> {
      myAppsService.createAppFromApigee(createAppRequest, email);
    });

    // then
    assertThat(exception.getMessage()).contains("InternalServerException");

  }

  /**
   * <p>
   * Test where to verify that an ApiProductModelResponse is obtained when getApiProductsFromApigee method is called
   * without errors.
   * </p>
   * <b>APIGEE response is mocked</b> to achieve this case
   */
  @Test
  @DisplayName("Should return ApiProductModelResponse when getApiProductsFromApigee is called without errors")
  void getApiProductsFromApigeeTest() throws Exception {

    //given
    stubFor(get(urlPathEqualTo("/Application/v1/Apigee/liamsync/apiproducts"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("liamsync-apiproducts-response.json")
            .withHeader("Content-Type", "application/json")));

    //when
    ResponseEntity<ApiProductModelResponse> serviceResponse = (ResponseEntity<ApiProductModelResponse>) myAppsService
        .getApiProductsFromApigee();

    //then
    assertThat(serviceResponse.getBody().getApiProduct().size()).isEqualTo(34);
  }

  /**
   * <p>
   * Test where to verify ResponseEntity with CustomStatusResponse returned when API Products are not found. Check for
   * Not Found status and custom response message
   * </p>
   */
  @Test
  @DisplayName("Should return ResponseEntity with CustomStatusResponse if API Products not found")
  void getApiProductsFromApigee_NotFoundTest() throws Exception {

    stubFor(get(urlEqualTo("/Application/v1/Apigee/liamsync/apiproducts")).willReturn(aResponse().withStatus(404)));

    ResponseEntity<CustomStatusResponse> serviceResponse = (ResponseEntity<CustomStatusResponse>) myAppsService
        .getApiProductsFromApigee();

    assertEquals("Response Status Code does not match!", HttpStatus.NOT_FOUND, serviceResponse.getStatusCode());

  }

  /**
   * <p>
   * Test where to verify ResponseEntity with CustomStatusResponse returned when Internal Server Error occurs. Check for
   * Internal Server Error Status
   * </p>
   */
  @Test
  @DisplayName("Should return ResponseEntity with CustomStatusResponse if Internal Server Error")
  void getApiProductsFromApigee_InternalServerErrorTest() throws Exception {

    stubFor(get(urlEqualTo("/Application/v1/Apigee/liamsync/apiproducts")).willReturn(aResponse().withStatus(500)));

    ResponseEntity<CustomStatusResponse> serviceResponse = (ResponseEntity<CustomStatusResponse>) myAppsService
        .getApiProductsFromApigee();

    assertEquals("Response Status Code does not match!", HttpStatus.INTERNAL_SERVER_ERROR,
        serviceResponse.getStatusCode());
  }

}