package com.lumen.apiexchange.client;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static org.assertj.core.api.Assertions.assertThat;

import com.lumen.apiexchange.IntegrationTestBase;
import com.lumen.apiexchange.exception.CustomStatusResponse;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.userprofile.CreateUserRequest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("it")
@AutoConfigureWireMock(port = 0)
class LiamSyncClientTest extends IntegrationTestBase {

  @Autowired
  private LiamSyncClient liamSyncClient;

  @Test
  void shouldCreateUserInApigee() throws InternalServerException {

    //given
    CreateUserRequest createUserRequest = new CreateUserRequest();
    createUserRequest.setEmail("test@lumen.com");
    createUserRequest.setFirstName("APITestUserFirstName");
    createUserRequest.setLastName("APITestUserLastName");
    createUserRequest.setUserName("test@lumen.com");

    stubFor(post(urlEqualTo("/Application/v1/Apigee/liamsync/customer"))
        .withHeader("X-Level3-Application-Key", containing("APPKEY736482021062922182314937525"))
        .willReturn(aResponse()
            .withStatus(201)
            .withHeader("Content-Type", "application/json")
            .withBodyFile("liamsync-create-user-response.json")));

    //when
    ResponseEntity<CustomStatusResponse> userInApigee =
        (ResponseEntity<CustomStatusResponse>) liamSyncClient.createUserInApigee(createUserRequest);

    //then
    assertThat(userInApigee.getStatusCodeValue()).isEqualTo(201);

  }
}