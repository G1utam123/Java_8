package com.lumen.apiexchange.service;

import com.lumen.apiexchange.entity.OwnershipStatus;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.OwnershipStatusUniqueRecordNotFoundException;
import com.lumen.apiexchange.repository.OwnershipRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import java.util.NoSuchElementException;
import javax.inject.Inject;
import java.util.Optional;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

@ExtendWith(MockitoExtension.class)
public class OwnershipServiceTest {

  @InjectMocks
  OwnershipStatusServiceImpl service;

  @Mock
  OwnershipRepository repository;


  @Test
  void returnOwnershipForProxy() throws Exception {
    // Arrange
    OwnershipStatus statusResponse = OwnershipStatus.builder()
        .status("PROVISIONING")
        .requestNo("RITM1234567")
        .elementId("SYSGEN12345")
        .requester("ad22342")
        .elementType("proxy").build();

    when(repository.findByElementId(anyString())).thenReturn(Optional.ofNullable(statusResponse));

    // Act
    Optional<OwnershipStatus> response = Optional.ofNullable(service.getOwnershipStatus("test"));

    // Assert
    assertNotNull(response);
    assertEquals("SYSGEN12345", response.get().getElementId());
  }


  @Test
  void whenMultipleRecordsExist_thenGetOwnershipStatusThrowsException() {
    // Arrange
    when(repository.findByElementId(anyString())).thenThrow(new IncorrectResultSizeDataAccessException(1, 2));

    // Act & Assert
    assertThrows(OwnershipStatusUniqueRecordNotFoundException.class, () -> service.getOwnershipStatus("test"));
  }


  @Test
  void whenErrorInGetOwnerships_thenThrowsException() {
    // Arrange
	  when(repository.findAll(PageRequest.of(0,10))).thenThrow(new InternalServerException(""));

    // Act & Assert
    assertThrows(InternalServerException.class, () -> service.getOwnerships(PageRequest.of(0,10)));
  }

  @Test
  void whenErrorInGetOwnershipsFilteredByStatFus_thenThrowsException() {
    // Arrange
    when(repository.getOwnershipByStatus("PROVISIONING", null)).thenThrow(new InternalServerException(""));

    // Act & Assert
    assertThrows(InternalServerException.class, () -> service.getOwnershipStatusByStatus("PROVISIONING", null));
  }

  @Test
  void whenErrorInGetOwnershiFpsFilteredByType_thenThrowsException() {
    // Arrange
    when(repository.getOwnershipByElementType("proxy", null)).thenThrow(new InternalServerException(""));

    // Act & AssertF
    assertThrows(InternalServerException.class, () -> service.getOwnershipStatusByType("proxy", null));
  }

  @Test
  void whenErrorInGetOwnershipsFilteredByTypeAndStatus_thenThrowsException() {
    // Arrange
    when(repository.getOwnershipByElementTypeAndStatus("proxy", "provisioning", null)).thenThrow(new InternalServerException(""));

    // Act & Assert
    assertThrows(InternalServerException.class, () -> service.getOwnershipStatusByTypeAndStatus("proxy", "provisioning", null));
  }

  @Test
  void whenGetList_thenEndOK() {
        assertDoesNotThrow(()-> service.getOwnerships(null));

  }

  @Test
  void whenGetProvisioning_orProvisioned_thenEndOK() {
    assertDoesNotThrow(()-> service.getOwnershipStatusByStatus("PROVISIONING", null));
    assertDoesNotThrow(()-> service.getOwnershipStatusByStatus("PROVISIONED", null));

  }
  @Test
  void shouldUpdateOwnership() throws Exception {
    OwnershipStatus ownership = new OwnershipStatus();
    ownership.setRequestNo("RITM1234567");
    ownership.setStatus("Provisioned");

    // Mock the repository
    OwnershipStatus oldOwnership = new OwnershipStatus();
    oldOwnership.setRequestNo("RITM1234567");
    oldOwnership.setStatus("Provisioning");

    when(repository.findByRequestNo(anyString())).thenReturn(Optional.of(oldOwnership));
    when(repository.save(any(OwnershipStatus.class))).thenReturn(oldOwnership);

    // Act
    OwnershipStatus updatedOwnership = service.updateOwnership(ownership);

    // Assert
    assertNotNull(updatedOwnership);
    assertEquals("RITM1234567", updatedOwnership.getRequestNo());
    assertEquals("Provisioned", updatedOwnership.getStatus());

    // Verificación de las llamadas al repositorio
    verify(repository, times(1)).findByRequestNo(anyString());
    verify(repository, times(1)).save(any(OwnershipStatus.class));
  }

  @Test
  void shouldThrowBadInputExceptionWhenInvalidStatus() throws Exception {
    OwnershipStatus ownership = new OwnershipStatus();
    ownership.setRequestNo("RITM1234567");
    ownership.setStatus("Invalid");

    // Act & Assert
    assertThrows(BadInputException.class, () -> service.updateOwnership(ownership));
  }

  @Test
  void shouldThrowNoSuchElementExceptionWhenRecordNotFound() throws Exception {
    OwnershipStatus ownership = new OwnershipStatus();
    ownership.setRequestNo("RITM1234567");
    ownership.setStatus("Provisioning");

    // Mock the repository
    when(repository.findByRequestNo(anyString())).thenReturn(Optional.empty());

    // Act & Assert
    assertThrows(NoSuchElementException.class, () -> service.updateOwnership(ownership));
  }

  @Test
  void shouldThrowOwnershipStatusUniqueRecordNotFoundExceptionWhenMultipleRecordsExist() throws Exception {
    OwnershipStatus ownership = new OwnershipStatus();
    ownership.setRequestNo("RITM1234567");
    ownership.setStatus("Provisioned");

    // Mock the repository
    when(repository.findByRequestNo(anyString())).thenThrow(new IncorrectResultSizeDataAccessException(1, 2));

    // Act & Assert
    assertThrows(OwnershipStatusUniqueRecordNotFoundException.class, () -> service.updateOwnership(ownership));
  }

}
