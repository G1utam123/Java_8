package com.lumen.apiexchange.service;

import static org.assertj.core.api.Assertions.assertThat;

import com.icegreen.greenmail.configuration.GreenMailConfiguration;
import com.icegreen.greenmail.junit5.GreenMailExtension;
import com.icegreen.greenmail.store.FolderException;
import com.icegreen.greenmail.util.GreenMailUtil;
import com.icegreen.greenmail.util.ServerSetupTest;
import com.lumen.apiexchange.IntegrationTestBase;
import com.lumen.apiexchange.model.FeedbackMessage;
import java.util.UUID;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("it")
@AutoConfigureWireMock(port = 0)
class EmailServiceTest extends IntegrationTestBase {

  @RegisterExtension
  static GreenMailExtension greenMail = new GreenMailExtension(ServerSetupTest.SMTP)
      .withConfiguration(GreenMailConfiguration.aConfig().withDisabledAuthentication())
      .withPerMethodLifecycle(true);

  @BeforeEach
  void setup() throws FolderException {
    greenMail.purgeEmailFromAllMailboxes();
  }

  @Autowired
  EmailService emailService;

  

  @Test
  void shouldSendAFeedbackEmailToApigeeDevs() throws MessagingException {

    //given
    FeedbackMessage feedbackMessage = new FeedbackMessage();
    feedbackMessage.setFirstName("John");
    feedbackMessage.setLastName("Wayne");
    feedbackMessage.setEmail("john.wayne@test.com");
    feedbackMessage.setPhoneNumber("123234345");
    feedbackMessage.setMessage("Keep pushing!");

    //when
    emailService.sendFeedbackReceivedEmail(feedbackMessage);

    //then
    MimeMessage[] receivedMessages = greenMail.getReceivedMessages();
    assertThat(receivedMessages).hasSize(1);
    MimeMessage receivedMessage = receivedMessages[0];
    assertThat(receivedMessage.getSubject()).isEqualTo("New feedback message from API-Hub");
    assertThat(GreenMailUtil.getBody(receivedMessage)).contains(feedbackMessage.getMessage());
    assertThat(receivedMessage.getAllRecipients()).hasSize(1);
  }
}