package com.lumen.apiexchange.service;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.put;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo;
import static com.lumen.apiexchange.service.ProxyCreationTest.getMockJwtToken;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertThrows;
import static org.mockito.BDDMockito.given;

import com.lumen.apiexchange.IntegrationTestBase;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ApiMigrateRequest;
import com.lumen.apiexchange.model.ApiMigrationResult;
import com.lumen.apiexchange.repository.AuditTrailRepository;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("it")
@AutoConfigureWireMock(port = 0)
public class ProxyMigrationTest extends IntegrationTestBase {

  @Autowired
  ProxyService proxyService;

  @Autowired
  AuditTrailRepository auditTrailRepository;

  @MockBean
  SecurityContext securityContext;

  @BeforeEach
  void clear() {
    auditTrailRepository.deleteAll();
  }

  @Test
  void shouldMigrateProxyAndSaveAuditTrail() throws Exception {

    //given
    String guid = UUID.randomUUID().toString();

    ApiMigrateRequest proxyMigrationRequest = new ApiMigrateRequest();
    proxyMigrationRequest.setGuid(guid);
    proxyMigrationRequest.setMirrorEnvironment("dev1");
    proxyMigrationRequest.setDev2EndpointHostname("https://test.com");

    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing("apigee"))
        .withQueryParam("resourceGuid", equalTo(guid))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-mediated-resources-response.json")
            .withHeader("Content-Type", "application/json")));

    stubFor(put(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource/58635/deployExternal"))
        .withHeader("X-Username", containing("apigee"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")));

    stubFor(post(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing("apigee"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-migrate-build-call-response.json")
            .withHeader("Content-Type", "application/json")));

    given(securityContext.getAuthentication())
        .willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);

    //when
    ApiMigrationResult result = proxyService.migrateApiProxy(proxyMigrationRequest);

    //then
    assertThat(result.getMigratedEnv()).hasSize(1);
    assertThat(auditTrailRepository.findAll()).hasSize(1);

  }

  @Test
  void migrateApiProxy() throws InternalServerException {

    //given
    ApiMigrateRequest request = new ApiMigrateRequest();
    request.setMirrorEnvironment("dev1");
    request.setDev3EndpointHostname("http://mocktarget.apigee.net");
    request.setGuid("cd0f8c4f-bf4c-473f-8e3c-0d599b1a49b4");
    request.setRequestorEmail("jeremy.eagleman@lumen.com");

    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing("apigee"))
        .withQueryParam("resourceGuid", equalTo(request.getGuid()))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-mediated-resources-response.json")
            .withHeader("Content-Type", "application/json")));

    stubFor(put(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource/58635/deployExternal"))
        .withHeader("X-Username", containing("apigee"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")));

    stubFor(put(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource/58635/deployInternal"))
        .withHeader("X-Username", containing("apigee"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")));

    stubFor(post(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing("jeremy.eagleman@lumen.com"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-migrate-build-call-response.json")
            .withHeader("Content-Type", "application/json")));

    given(securityContext.getAuthentication())
        .willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);

    //when
    ApiMigrationResult responseMsg = proxyService.migrateApiProxy(request);

    //then
    assertThat(responseMsg.getMigratedEnv().size()).isEqualTo(1);
  }

  @Test
  void testMigrateApiMirrorLookupFail() {

    // given
    ApiMigrateRequest request = new ApiMigrateRequest();
    request.setMirrorEnvironment("dev2");
    request.setDev3EndpointHostname("http://mocktarget.apigee.net");
    request.setGuid("mediated-resource-api-call-fail");

    stubFor(get(urlEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Level3-Application-Key", containing("APPKEY736482021062922182314937525"))
        .withHeader("X-Username", containing("apigee"))
        .willReturn(aResponse()
            .withStatus(500)
            .withBodyFile("apigee-mediated-resource-api-call-fail-response.json")
            .withHeader("Content-Type", "application/json")));

    given(securityContext.getAuthentication())
        .willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);

    // when
    InternalServerException exception = assertThrows(InternalServerException.class, () -> {
      proxyService.migrateApiProxy(request); });

    assertThat(exception.getMessage()).contains("Source API could not be returned.");
  }
}
