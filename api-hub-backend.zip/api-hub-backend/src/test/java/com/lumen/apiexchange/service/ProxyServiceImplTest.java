package com.lumen.apiexchange.service;

import static com.lumen.apiexchange.util.FeatureFlags.FF_SNOW_AUTHZ_ENABLED;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import com.lumen.apiexchange.client.ESPClient;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.ForbiddenException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.model.ApiMediatedResponse;
import com.lumen.apiexchange.model.ApiMigrateRequest;
import com.lumen.apiexchange.model.ApiMigrationResult;
import com.lumen.apiexchange.model.ApplicationKey;
import com.lumen.apiexchange.model.ApplicationKeyResponse;
import com.lumen.apiexchange.model.ApplicationKeyResponseData;
import com.lumen.apiexchange.model.BuildDeployResult;
import com.lumen.apiexchange.model.InputApiRequest;
import com.lumen.apiexchange.model.ProxyRequestModel;
import com.lumen.apiexchange.entity.OwnershipStatus;
import com.lumen.apiexchange.entity.ProxyResponse;
import com.lumen.apiexchange.repository.ApiProxyRepository;
import com.lumen.apiexchange.repository.OwnershipRepository;
import com.lumen.apiexchange.util.APIMigrationHandler;

import dev.openfeature.contrib.providers.envvar.EnvVarProvider;
import dev.openfeature.sdk.OpenFeatureAPI;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutionException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.jwt.Jwt;

public class ProxyServiceImplTest {

  private ProxyServiceImpl proxyServiceImpl;
  private ESPClient espClient;
  private ApiProxyRepository apiProxyRepo;
  private APIMigrationHandler apiMigrationHandler;
  private ServiceNowService serviceNow;
  private UserAuthorizationServiceImpl userAuthorization;
  private BuildDeployServiceImpl buildDeployServiceImpl;
  private HostServiceImpl hostServiceImpl;
  private OwnershipRepository ownershipRepo;
  private OpenFeatureAPI featureFlags;

  private OwnershipStatus ownershipStatus;
  @BeforeEach
  void setUp() {

    espClient = mock(ESPClient.class);
    apiProxyRepo = mock(ApiProxyRepository.class);
    apiMigrationHandler = mock(APIMigrationHandler.class);
    userAuthorization = mock(UserAuthorizationServiceImpl.class);
    AsyncProxyService asyncProxyService = mock(AsyncProxyService.class);
    serviceNow = mock(ServiceNowService.class);
    buildDeployServiceImpl = mock(BuildDeployServiceImpl.class);
    hostServiceImpl = mock(HostServiceImpl.class);
    featureFlags = OpenFeatureAPI.getInstance();
    proxyServiceImpl = new ProxyServiceImpl(espClient, null, asyncProxyService, apiProxyRepo,
       apiMigrationHandler, serviceNow, userAuthorization, buildDeployServiceImpl, hostServiceImpl, featureFlags);
  }

  static Jwt getMockJwtToken(String subject, String claim, String claimValue) {
    final Jwt jwt = Jwt.withTokenValue("token")
            .header("alg", "none")
            .claim(claim, claimValue)
            .subject(subject)
            .build();
    return jwt;
  }
  
  private InputApiRequest generateProxyRequest() {
    InputApiRequest proxyRequest = new InputApiRequest();
    List<String> admins = Arrays.asList("admin1", "admin2", "admin3");
	List<String> owners = Arrays.asList("owner1", "owner2", "owner3");
    
    proxyRequest.setTaxonomy("Application/Apigee");
    proxyRequest.setResourceName("myResourceName");
    proxyRequest.setVersion("v1");
    proxyRequest.setType("Inbound");
    proxyRequest.setOwningAppAppkey("APPKEY1037142019052317562540722002");
    proxyRequest.setMalId("SYSGEN787551898");
    proxyRequest.setProdEndpointHostname("http://mocktarget.apigee.net");
    proxyRequest.setEndpointPath("/dosomething");
    proxyRequest.setInternal("true");
    proxyRequest.setProxyAuthInternal("appkey");
    proxyRequest.setEndpointAuth("none");
    proxyRequest.setRequestorEmail("test@lumen.com");
    proxyRequest.setAdmins(admins);
    proxyRequest.setOwners(owners);
    proxyRequest.setElementType("proxy");
    return proxyRequest;
  }
  
  private BuildDeployResult createBuildDeployResult () {
    BuildDeployResult buildDeployResult = new BuildDeployResult();
    buildDeployResult = BuildDeployResult.builder()
        .proxy("/tax1/v1/tax2/resourceName")
        .guid("guid")
        .proxyBuiltInEnvironments(new ArrayList<>())
        .proxyDeployedToEnvironments(new ArrayList<>())
        .proxyNotBuiltInEnvironments(new ArrayList<>())
        .proxyNotDeployedToEnvironments(new ArrayList<>())
        .build();

    buildDeployResult.getProxyBuiltInEnvironments().add("dev1");
    buildDeployResult.getProxyDeployedToEnvironments().add("dev1");
    buildDeployResult.getProxyNotBuiltInEnvironments().add("dev2");
    buildDeployResult.getProxyNotDeployedToEnvironments().add("dev2");
    
    return buildDeployResult;
  }
  
  @Test
  public void getTaxonomiesTest() throws InternalServerException {

    //given
    ArrayList taxonomies = new ArrayList<>();

    //when
    Mockito.when(espClient.getTaxonomies()).thenReturn(taxonomies);

    //then
    assertEquals(taxonomies, proxyServiceImpl.getTaxonomies());

  }

  @Test

  public void getTaxonomiesNegativeTest1() throws InternalServerException {

    Mockito.when(espClient.getTaxonomies())
        .thenThrow(new InternalServerException("Unable to get data now. Please try again later"));

    InternalServerException exception = assertThrows(InternalServerException.class, () -> {
      proxyServiceImpl.getTaxonomies();
    });

    assertTrue(exception.getMessage().contains("Unable to get data now. Please try again later"));
  }

  @Test
  public void getApplicationKeysTest() throws InternalServerException {

    List applicationKeys = new ArrayList();

    Mockito.when(espClient.getApplicationKeys()).thenReturn(applicationKeys);

    assertEquals(applicationKeys, proxyServiceImpl.getApplicationKeys());
  }

  private ApplicationKeyResponseData getAppKeyRespData() {
    ApplicationKey appkey = getAppkey();

    List<ApplicationKey> applicationKey = new ArrayList<>();
    applicationKey.add(appkey);

    ApplicationKeyResponseData appKeyRespData = new ApplicationKeyResponseData();
    appKeyRespData.setApplicationKey(applicationKey);

    return appKeyRespData;
  }

  private ApplicationKey getAppkey() {
    ApplicationKey appkey = new ApplicationKey();

    appkey.setApplicationKeyID("Test");
    appkey.setApplicationKeyType("Test");
    appkey.setApplicationName("Test");
    appkey.setApplicationType("Test");
    appkey.setAuthorizationType("Test");
    appkey.setClientPublicKeys("Test");
    appkey.setCustomernumbers("Test");
    appkey.setCustomerType("Test");
    appkey.setItpkmServiceId("Test");
    appkey.setOwneremail("Test");
    appkey.setUser("Test");
    appkey.setUsertype("Test");

    return appkey;
  }

  private ResponseEntity<ApplicationKeyResponse> getApplicationKeyResponse() {

    ApplicationKey appkey = getAppkey();
    List<ApplicationKey> applicationKey = new ArrayList<>();
    applicationKey.add(appkey);

    ApplicationKeyResponseData appKeyRespData = getAppKeyRespData();
    appKeyRespData.setApplicationKey(applicationKey);

    ApplicationKeyResponse resp = new ApplicationKeyResponse();
    resp.setApplicationKeys(appKeyRespData);

    ResponseEntity<ApplicationKeyResponse> reMock = mock(ResponseEntity.class);
    when(reMock.getBody()).thenReturn(resp);

    return reMock;

  }


  @Test
  public void postProxyRequestTest() throws Exception {

    InputApiRequest proxyRequest = new InputApiRequest();
    
    Jwt jwt = getMockJwtToken("test", "email", "test@lumen.com");

    //Only enabling FF_SNOW_AUTHZ_ENABLED
    featureFlags.setProvider(new EnvVarProvider(flag -> flag.equals(FF_SNOW_AUTHZ_ENABLED) ? "true" : "false"));

    //OwnershipRepository ownershipRepo = Mockito.spy(OwnershipRepository.class);
    ownershipRepo = mock(OwnershipRepository.class);
    List<OwnershipStatus>  ownerships = new ArrayList<>();

    Mockito.when(ownershipRepo.save(any(OwnershipStatus.class))).thenAnswer(inv -> {
        OwnershipStatus ownership = inv.getArgument(0);
          ownerships.add(ownership);
      return null;
        });


    Mockito.when(buildDeployServiceImpl.buildDeployApi(proxyRequest)).thenReturn(createBuildDeployResult());

    assertThat(proxyServiceImpl.postProxyRequest(proxyRequest, jwt).getProxyBuiltInEnvironments()).contains("dev1");

    //assertThat(ownerships).hasSize(1);

  }

  @Test
  public void postProxyRequestNegativeTest() throws Exception {

    InputApiRequest proxyRequest = new InputApiRequest();
    
    Jwt jwt = getMockJwtToken("test", "email", "test@lumen.com");

    Mockito.when(buildDeployServiceImpl.buildDeployApi(proxyRequest)).thenReturn(createBuildDeployResult());

    assertThat(proxyServiceImpl.postProxyRequest(proxyRequest, jwt).getProxyNotBuiltInEnvironments()).contains("dev2");
  }

  @Test
  public void getCustomerNegativeTest() throws InternalServerException {

    List<ApplicationKey> keys = new ArrayList<>();

    assertTrue(proxyServiceImpl.getApplicationKeys().isEmpty());
  }

  @Test
  public void getApplicationKeyNegativeTest() throws InternalServerException {

    Mockito.when(espClient.getApplicationKeys())
        .thenThrow(new InternalServerException("Unable to get ApplicationKeys, please try later"));

    InternalServerException exception = assertThrows(InternalServerException.class, () -> {
      proxyServiceImpl.getApplicationKeys();
    });

    assertTrue(exception.getMessage().contains("Unable to get ApplicationKeys, please try later"));
  }

  @Test
  public void shouldRetrieveNoProxies() throws InternalServerException {

    //given
    //String environment = "test";
    InputApiRequest inputApiRequest = new InputApiRequest();
    inputApiRequest.setEnv("test");

    ApiMediatedResource proxy = new ApiMediatedResource();
    List proxies = new ArrayList();
    ApiMediatedResponse response = new ApiMediatedResponse();
    response.setMediatedResource(proxies);

    //when
    Mockito.when(espClient.getApiProxyDetails(inputApiRequest)).thenReturn(response);

    //then
    assertThat(proxyServiceImpl.getApiProxies(inputApiRequest)).isEmpty();
  }

  @Test
  public void shouldRetrieveOneProxy() throws InternalServerException {

    //given
    //String environment = "test";
    InputApiRequest inputApiRequest = new InputApiRequest();
    inputApiRequest.setEnv("test");

    ApiMediatedResource proxy = new ApiMediatedResource();
    List proxies = new ArrayList();
    proxies.add(proxy);
    ApiMediatedResponse response = new ApiMediatedResponse();
    response.setMediatedResource(proxies);

    //when
    Mockito.when(espClient.getApiProxyDetails(inputApiRequest)).thenReturn(response);

    //then
    assertThat(proxyServiceImpl.getApiProxies(inputApiRequest)).hasSize(1);
  }

  @Test
  public void saveApiProxiesTest() throws InternalServerException {
    ProxyRequestModel proxyReq = createApiProxyRequest();
    String userName = "pravin.chavhan@lumen.com";
    ApiProxyRepository apiProxyspy = Mockito.spy(ApiProxyRepository.class);
    when(apiProxyspy.findByApiid(UUID.randomUUID())).thenReturn(createApiProxyResponse());
    assertNotNull(proxyServiceImpl.saveApiProxies(proxyReq, userName));
  }

  @Test
  public void deleteApiProxiesTest() throws InternalServerException {
    ApiProxyRepository apiProxyspy = Mockito.spy(ApiProxyRepository.class);
    when(apiProxyspy.findByApiid(UUID.randomUUID())).thenReturn(createApiProxyResponse());
    assertNotNull(proxyServiceImpl.deleteproxiesFromDbWithApiId(UUID.randomUUID()));
  }

  @Test
  public void saveApiProxiesTest_negative_test() {
    ProxyRequestModel proxyReq = new ProxyRequestModel();
    String userName = "pravin.chavhan@lumen.com";
    InternalServerException exception = assertThrows(InternalServerException.class, () -> {
      proxyServiceImpl.saveApiProxies(proxyReq, userName);
    });
    boolean isExceptionThrow = exception.getMessage().contains("Unable to save Proxy Details. Please try later");
    assertTrue("Exception thrown is different!", isExceptionThrow);
  }

  @Test
  public void deleteproxiesFromDbWithApiIdTest() throws InternalServerException {
    ProxyRequestModel proxyReq = createApiProxyRequest();
    String userName = "pravin.chavhan@lumen.com";
    ApiProxyRepository apiProxyspy = Mockito.spy(ApiProxyRepository.class);
    when(apiProxyspy.findByApiid(UUID.randomUUID())).thenReturn(createApiProxyResponse());
    Mockito.doNothing().when(apiProxyspy).deleteById(new UUID(34, 0));
    assertTrue(proxyServiceImpl.deleteproxiesFromDbWithApiId(UUID.randomUUID()));
    //assertNull(proxyServiceImpl.deleteproxiesFromDbWithApiId(34));
  }

  private ProxyRequestModel createApiProxyRequest() {
    ProxyResponse proxyres1 = new ProxyResponse();
    proxyres1.setApiid(UUID.randomUUID());
    proxyres1.setResourceGuuid("585fe48f-104f-42ec-928c-eb3b1f911668");
    ProxyResponse proxyres2 = new ProxyResponse();
    proxyres2.setApiid(UUID.randomUUID());
    proxyres2.setResourceGuuid("b81ad891-ab6f-4ec6-9bc9-e70d5f66fd3f");
    ProxyRequestModel proxyReq = new ProxyRequestModel();
    List<ProxyResponse> listProxyRes = new ArrayList<>();
    listProxyRes.add(proxyres1);
    listProxyRes.add(proxyres2);
    proxyReq.setProxyResponse(listProxyRes);
    return proxyReq;
  }

  private List<ProxyResponse> createApiProxyResponse() {
    ProxyResponse proxyres1 = new ProxyResponse();
    proxyres1.setId(UUID.randomUUID());
    proxyres1.setApiid(UUID.randomUUID());
    proxyres1.setCreatedUserId("4310f6d8-ae12-4961-946c-d5d1c8028748");
    proxyres1.setCreatedUserName("pravin.chavhan@lumen.com");
    proxyres1.setResourceGuuid("4310f6d8-ae12-4961-946c-c4g1c8028748");
    List<ProxyResponse> listProxyRes = new ArrayList<>();
    listProxyRes.add(proxyres1);
    return listProxyRes;
  }


  @Test
  public void migrateApiProxyTest() throws InternalServerException, BadInputException {

    //String result = "ApiMigration Completed";
    ApiMigrationResult amr = new ApiMigrationResult();
    amr.setRoutingExpression("expression");

    ApiMigrateRequest apiMigrateRequest = new ApiMigrateRequest();

    //Mockito.when(espClient.migrateApiProxy(any())).thenReturn(result);
    Mockito.when(apiMigrationHandler.migrateApi(any())).thenReturn(amr);

    //assertThat(proxyServiceImpl.migrateApiProxy(apiMigrateRequest)).isEqualTo(result);
    assertThat(proxyServiceImpl.migrateApiProxy(apiMigrateRequest)).isEqualTo(amr);

  }

  @Test
  public void migrateApiProxyNegativeTest() throws InternalServerException, BadInputException {

    ApiMigrateRequest apiMigrateRequest = new ApiMigrateRequest();

    Mockito.when(apiMigrationHandler.migrateApi(any())).thenThrow(new InternalServerException(""));

    InternalServerException exception = assertThrows(InternalServerException.class, () -> {
      proxyServiceImpl.migrateApiProxy(apiMigrateRequest);
    });

  }
  
  @Test
  void shouldAllowProdCreate() throws IOException,
      InterruptedException, ExecutionException {
    
    InputApiRequest proxyRequest = generateProxyRequest();
    
    Jwt jwt = getMockJwtToken("test", "email", "test@lumen.com");

    //given-then
    Mockito.doNothing().when(userAuthorization).isOkToDeployToProd(jwt);
    Mockito.when(buildDeployServiceImpl.buildDeployApi(proxyRequest)).thenReturn(createBuildDeployResult());
    
    //when
    BuildDeployResult buildDeployResult = buildDeployServiceImpl.buildDeployApi(proxyRequest);

    //then
    assertThat(buildDeployResult).isNotNull();

  }

  @Test
  void shouldNotAllowProdCreate() throws IOException {
    
    //given
    InputApiRequest proxyRequest = generateProxyRequest();
    
    Jwt jwt = getMockJwtToken("test", "email", "test@lumen.com");

    Mockito.doThrow(new ForbiddenException("")).when(userAuthorization).isOkToDeployToProd(jwt);
    
    //when-then
    ForbiddenException exception = assertThrows(ForbiddenException.class, () -> {
      proxyServiceImpl.postProxyRequest(proxyRequest, jwt);
    });

  }

}
