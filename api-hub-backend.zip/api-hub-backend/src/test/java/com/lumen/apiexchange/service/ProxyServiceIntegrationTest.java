package com.lumen.apiexchange.service;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertThrows;

import com.lumen.apiexchange.IntegrationTestBase;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ApiMediatedResource;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.test.context.ActiveProfiles;


@SpringBootTest
@ActiveProfiles("it")
@AutoConfigureWireMock(port = 0)
class ProxyServiceIntegrationTest extends IntegrationTestBase {

  @Autowired
  ProxyService proxyService;

  @Test
  @Timeout(value = 3000, unit = TimeUnit.MILLISECONDS)
  void shouldGetApiProxyEnvDetailsInParallel() throws Exception {

    // given
    String guid = "6ce67bee-66c3-4007-be6a-73c5691339f8";

    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing("apigee"))
        .withQueryParam("resourceGuid", equalTo(guid))
        .willReturn(aResponse()
            .withStatus(200)
            .withFixedDelay(500)
            .withBodyFile("esp-mediated-resources-response.json")
            .withHeader("Content-Type", "application/json")));

    // when
    List<ApiMediatedResource> details = proxyService.getApiProxyEnvDetails(guid);

    // then
    assertThat(details).hasSize(11);
  }

  @Test
  void shouldGetAnErrorIfCantCallESP() {

    // given
    String guid = "6ce67bee-66c3-4007-be6a-73c5691339f8";

    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing("apigee"))
        .withQueryParam("resourceGuid", equalTo(guid))
        .willReturn(aResponse()
            .withStatus(500)
            .withHeader("Content-Type", "application/json")));

    // when
    InternalServerException exception = assertThrows(InternalServerException.class, () -> {
      proxyService.getApiProxyEnvDetails(guid);
    });
    assertThat(exception.getMessage()).isEqualTo("Could not check the state of the proxy in all environments");

  }

}