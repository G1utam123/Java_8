package com.lumen.apiexchange.controller;

import com.lumen.apiexchange.IntegrationTestBase;
import com.lumen.apiexchange.entity.OwnershipStatus;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.OwnershipStatusAlreadyExistsException;
import com.lumen.apiexchange.model.snow.ServiceNowRequest;
import com.lumen.apiexchange.repository.OwnershipRepository;
import com.lumen.apiexchange.service.ServiceNowService;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.test.context.ActiveProfiles;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;


@AutoConfigureWireMock(port = 0)
@SpringBootTest
@ActiveProfiles("it")
public class ServiceNowControllerTest extends IntegrationTestBase {


  @Value("${servicenow.url}")
  private String serviceNowUrl;

  @Value("${servicenow.apiservicecatalogitems}")
  private String apiServiceCatalogItems;

  @Value("${servicenow.createGroupRequestSysid}")
  private String createGroupRequestSysid;

  @Value("${servicenow.orderitem}")
  private String orderItem;

  @Value("${servicenow.requestitem}")
  private String requestitem;

  @Value("${servicenow.snApiTable}")
  private String snApiTable;


  @Autowired
  private ServiceNowController serviceNowcontroller;
  @MockBean
  OwnershipRepository ownershipRepo;

  private String createGroupUrl =  "/api/sn_sc/servicecatalog/items/457f880fdbf6670002fdd2984b9619bf/order_now";

  private String getRitmUrl =  "/api/now/table/sc_req_item?request=68b4807f1b47ad54fba021b3b24bcb1b";

  private String getUserSysIdUrl = "/api/now/table/sys_user?u_cuid=ad22342";
  private List<String> admins = new ArrayList<>(Arrays.asList
      ("admin1", "admin2", "admin3"));
  private List<String> owners = new ArrayList<>(Arrays.asList
      ("owner1", "owner2", "owner3"));


  @Test
  void createGroup_ShouldReturnResponseFromService() throws InternalServerException {

    stubFor(post(urlEqualTo(createGroupUrl))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("servicenow-response-to-create-group.json")
            .withHeader("Content-Type", "application/json")));

    stubFor(get(urlEqualTo(getRitmUrl))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("servicenow-response-to-Get-Ritm.json")
            .withHeader("Content-Type", "application/json")));

    stubFor(get(urlEqualTo(getUserSysIdUrl))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("servicenow-response-get-user-sysid.json")
            .withHeader("Content-Type", "application/json")));

    // Arrange
    ServiceNowRequest request = buildServiceNowTestRequest("proxy", "1", admins, owners, "ad22342");
    String expectedResponse = "RITM1234567";


    // Act
    String actualResponse = serviceNowcontroller.createGroup(request);

    // Assert
    assertEquals(expectedResponse, actualResponse);
  }

  private static ServiceNowRequest buildServiceNowTestRequest(String elementType, String ProxyInc, List<String> admins, List<String> owners, String requester) {
    ServiceNowRequest serviceNowRequest = new ServiceNowRequest();
    serviceNowRequest.setElementType(elementType);
    serviceNowRequest.setElementName("Test Proxy1" + ProxyInc);
    serviceNowRequest.setAdmins(admins);
    serviceNowRequest.setOwners(owners);
    serviceNowRequest.setRequester(requester);

    return serviceNowRequest;
  }

}

