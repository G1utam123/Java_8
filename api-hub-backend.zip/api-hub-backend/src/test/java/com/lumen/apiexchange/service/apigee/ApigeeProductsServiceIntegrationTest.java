package com.lumen.apiexchange.service.apigee;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.delete;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.put;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;

import com.lumen.apiexchange.IntegrationTestBase;
import com.lumen.apiexchange.client.apigee.ApigeeMgmtApiClient;
import com.lumen.apiexchange.config.ApigeeMgmtApiConfigProperties;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.ProductNotFoundException;
import com.lumen.apiexchange.exception.UnauthorizedException;
import com.lumen.apiexchange.exception.apigee.ApigeeMgmtApiClientException;
import com.lumen.apiexchange.model.apigee.ApigeeProduct;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.Access;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.AccessLocation;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.Planet;
import com.lumen.apiexchange.model.apigee.ApigeeProductRequest;
import com.lumen.apiexchange.model.apigee.ApigeeProductRequest.ApprovalType;
import com.lumen.apiexchange.model.apigee.ApigeeProductRequest.QuotaTimeUnit;
import com.lumen.apiexchange.model.apigee.ApigeeProductResponse;
import com.lumen.apiexchange.model.apigee.Attribute;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.client.HttpClientErrorException;

@SpringBootTest
@ActiveProfiles("it")
@AutoConfigureWireMock(port = 0)
class ApigeeProductsServiceIntegrationTest extends IntegrationTestBase {

  //TODO: Tried to remove "Autowired" & use AllArgsConstructor but all tests failed.
  @Autowired
  private ApigeeProductsService apigeeProductsService;

  @Mock
  ApigeeMgmtApiClient apigeeMgmtApiClient;
  
  @Autowired
  private ApigeeMgmtApiConfigProperties apigeeMgmtApiConfigProperties;

  @Test
  void shoulGetApigeeProducts() throws Exception {

    //given
    String planet = "NONPROD";
    String org = "INTERNAL";
    String productOwner = null;
    stubFor(get(urlEqualTo("/v1/o/int/apiproducts?expand=true"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(200)
                .withBodyFile("apigee-apim-getproducts-nonprod-int-response-ok.json")
                .withHeader("Content-Type", "application/json")));

    //when
    ApigeeProductResponse apiProducts = apigeeProductsService.getProducts(planet, org, productOwner); 

    //then
    assertThat(apiProducts).isNotNull();
    assertThat(apiProducts.getApiProduct()).hasSize(5);
    ApigeeProduct apiProduct1 = apiProducts.getApiProduct().get(0);
    assertThat(apiProduct1.getName()).isEqualTo("Nonprod-Internal");
  }

  @Test
  void shoulGetApigeeProductsForOwner() throws Exception {

    //given
    String planet = "NONPROD";
    String org = "EXTERNAL";
    String productOwner = "product.owner@lumen.com";
    stubFor(get(urlEqualTo("/v1/o/ext/apiproducts?expand=true"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(200)
                .withBodyFile("apigee-apim-getproducts-nonprod-ext-response-ok.json")
                .withHeader("Content-Type", "application/json")));

    //when
    ApigeeProductResponse apiProducts = apigeeProductsService.getProducts(planet, org, productOwner); 

    //then
    assertThat(apiProducts).isNotNull();
    assertThat(apiProducts.getApiProduct()).hasSize(4);
    ApigeeProduct apiProduct = apiProducts.getApiProduct().get(0);
    assertThat(apiProduct.getName()).isEqualTo("Nonprod-External1");
    apiProduct = apiProducts.getApiProduct().get(1);
    assertThat(apiProduct.getName()).isEqualTo("Nonprod-External2");
    apiProduct = apiProducts.getApiProduct().get(2);
    assertThat(apiProduct.getName()).isEqualTo("Nonprod-External3");
    apiProduct = apiProducts.getApiProduct().get(3);
    assertThat(apiProduct.getName()).isEqualTo("Nonprod-External4");
  }

  @Test
  void shouldGetProduct() throws InternalServerException {

    //given
    stubFor(get(urlEqualTo("/v1/o/int/apiproducts/OrderStatus"))
            .withHeader("Authorization",
                containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("apigee-apim-getproduct-response-ok.json")
                    .withHeader("Content-Type", "application/json")));

    //when
    ApigeeProduct product = apigeeProductsService.getProduct("OrderStatus", "NONPROD", "INTERNAL");

    //then
    assertThat(product.getName()).isEqualTo("OrderStatus");

  }

  @Test
  void shouldSaveProduct() throws InternalServerException, BadInputException {

    //given
    stubFor(post(urlEqualTo("/v1/o/int/apiproducts"))
            .withHeader("Authorization",
                containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("apigee-apim-saveproduct-response-ok.json")
                    .withHeader("Content-Type", "application/json")));
    stubFor(get(urlEqualTo("/v1/o/int/environments"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(200)
                .withBodyFile("apigee-apim-getenvironments-nonprod-int-response-ok.json")
                .withHeader("Content-Type", "application/json")));
    AccessLocation accessLocation = AccessLocation.INTERNAL;
    ApprovalType approvalType = ApprovalType.manual;
    Planet planet = Planet.NONPROD; 
    ApigeeProductHubRequest hubProductReq = buildTestApigeeProductRequest("1", approvalType, planet, accessLocation);

    //when
    ApigeeProduct product = apigeeProductsService.saveProduct(hubProductReq);

    //then
    assertThat(product.getName()).isEqualTo("OrderStatus");

  }

  @Test
  void shouldUpdateProduct() throws InternalServerException, BadInputException, UnauthorizedException {

    //given
    stubFor(get(urlEqualTo("/v1/o/int/apiproducts/OrderStatus"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(200)
                .withBodyFile("apigee-apim-getproduct-response-ok.json")
                .withHeader("Content-Type", "application/json")));
    stubFor(put(urlEqualTo("/v1/o/int/apiproducts/OrderStatus"))
            .withHeader("Authorization",
                containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("apigee-apim-updateproduct-response-ok.json")
                    .withHeader("Content-Type", "application/json")));
    AccessLocation accessLocation = AccessLocation.INTERNAL;
    ApprovalType approvalType = ApprovalType.manual;
    Planet planet = Planet.NONPROD;
    String name = "OrderStatus";
    String userEmail = "product.owner@lumen.com";
    ApigeeProductHubRequest hubProductReq = buildTestApigeeProductRequest("1", approvalType, planet, accessLocation);

    //when
    ApigeeProduct product = apigeeProductsService.updateProduct(name, hubProductReq, userEmail);

    //then
    assertThat(product.getName()).isEqualTo("OrderStatus");

  }

  @Test
  void shouldUpdatePartnerProxyProduct() {

    //given
    stubFor(get(urlEqualTo("/v1/o/int/apiproducts/OrderStatus"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(200)
                .withBodyFile("apigee-apim-getproduct-response-ok.json")
                .withHeader("Content-Type", "application/json")));
    stubFor(put(urlEqualTo("/v1/o/int/apiproducts/OrderStatus"))
            .withHeader("Authorization",
                containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("apigee-apim-updateproduct-response-ok.json")
                    .withHeader("Content-Type", "application/json")));
    Planet planet = Planet.NONPROD;

    //when
    ApigeeProduct product = apigeeProductsService.getProduct("OrderStatus", "NONPROD", "INTERNAL");
    ApigeeProduct productResponse = apigeeProductsService.updatePartnerProxyProduct(planet, product);

    //then
    assertThat(productResponse.getName()).isEqualTo("OrderStatus");

  }

  @Test
  void shouldMapApigeeProductToApigeeProductRequest() {

    //given
    stubFor(get(urlEqualTo("/v1/o/int/apiproducts/OrderStatus"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(200)
                .withBodyFile("apigee-apim-getproduct-response-ok.json")
                .withHeader("Content-Type", "application/json")));
    
    //when
    ApigeeProduct product = apigeeProductsService.getProduct("OrderStatus", "NONPROD", "INTERNAL");
    ApigeeProductRequest mappedProduct = apigeeProductsService.mapApigeeProductToApigeeProductRequest(product);

    //then
    List<String> apiResources = new ArrayList<String>();
    apiResources.add("resource1");
    apiResources.add("resource2");
    assertThat(mappedProduct.getApiResources()).isEqualTo(apiResources);
    assertThat(mappedProduct.getApprovalType()).isEqualTo(ApprovalType.manual);

    List<Attribute> attributes = new ArrayList<Attribute>();
    attributes.add(new Attribute("access", "public"));
    attributes.add(new Attribute("PRODUCT_OWNER", "product.owner@lumen.com"));
    assertThat(mappedProduct.getAttributes()).isEqualTo(attributes);

    String desc = "Order Status (Product Owner: Dexter Payne) (NONPROD/int) (Proxy should be"
        + " /Ordering/v1/productOrder)";
    assertThat(mappedProduct.getDescription()).isEqualTo(desc);
    assertThat(mappedProduct.getDisplayName()).isEqualTo("Order Status");

    List<String> envs = new ArrayList<String>();
    envs.add("dev1");
    envs.add("test1");
    assertThat(mappedProduct.getEnvironments()).isEqualTo(envs);
    assertThat(mappedProduct.getName()).isEqualTo("OrderStatus");

    List<String> proxies = new ArrayList<String>();
    proxies.add("Esp_IntMed_Customer_v1_Ordering_productOrder_6cf95b4c-baff-4349-b887-05f773e76ca5");
    assertThat(mappedProduct.getProxies()).isEqualTo(proxies);

    assertThat(mappedProduct.getQuota()).isEqualTo("100");
    assertThat(mappedProduct.getQuotaInterval()).isEqualTo("10");
    assertThat(mappedProduct.getQuotaTimeUnit()).isEqualTo(QuotaTimeUnit.minute);

    List<String> scopes = new ArrayList<String>();
    scopes.add("scope1");
    scopes.add("scope2");
    assertThat(mappedProduct.getScopes()).isEqualTo(scopes);

    //when-then
    product.setApprovalType(null);
    product.setQuotaTimeUnit(null);
    ApigeeProductRequest mappedProduct2 = apigeeProductsService.mapApigeeProductToApigeeProductRequest(product);
    assertThat(mappedProduct2.getApprovalType()).isNull();
    assertThat(mappedProduct2.getQuotaTimeUnit()).isNull();

  }

  @Test
  void shouldDeleteProduct() throws InternalServerException, ProductNotFoundException, 
      UnauthorizedException, URISyntaxException {

    //given
    String productName = "API-HUB_Products_API_Delete_Test1";
    stubFor(get(urlEqualTo("/v1/o/int/apiproducts/" + productName))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(200)
                .withBodyFile("apigee-apim-deleteproduct-response-ok.json")
                .withHeader("Content-Type", "application/json")));
    stubFor(delete(urlEqualTo("/v1/o/int/apiproducts/" + productName))
            .withHeader("Authorization",
                containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
            .willReturn(aResponse()
                    .withStatus(204)
                    .withHeader("Content-Type", "application/json")));
    AccessLocation accessLocation = AccessLocation.INTERNAL;
    Planet planet = Planet.NONPROD;
    String userEmail = "product.owner@lumen.com";

    //when
    apigeeProductsService.deleteProduct(productName, userEmail, planet.toString(), accessLocation.toString());

    //then
    assertThat(userEmail).isEqualTo("product.owner@lumen.com");

  }

  @Test
  void shouldValidateRequest() throws BadInputException {

    //given
    stubFor(get(urlEqualTo("/v1/o/int/environments"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(200)
                .withBodyFile("apigee-apim-getenvironments-nonprod-int-response-ok.json")
                .withHeader("Content-Type", "application/json")));
    ApigeeProductHubRequest hubProductReq = buildTestApigeeProductRequest("1", 
        ApprovalType.manual, Planet.NONPROD, AccessLocation.INTERNAL);

    //when-then
    apigeeProductsService.validateRequest(hubProductReq);
  }

  @Test
  void shouldGetProductNotFound() throws InternalServerException {

    //given
    stubFor(get(urlEqualTo("/v1/o/int/apiproducts/NoProductToFind"))
            .withHeader("Authorization",
                containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
            .willReturn(aResponse()
                    .withStatus(404)
                    .withBodyFile("apigee-apim-getproduct-not-found-response-404.json")
                    .withHeader("Content-Type", "application/json")));
    stubFor(put(urlEqualTo("/v1/o/int/apiproducts/NoProductToFind"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(404)
                .withBodyFile("apigee-apim-getproduct-not-found-response-404.json")
                .withHeader("Content-Type", "application/json")));
    stubFor(delete(urlEqualTo("/v1/o/int/apiproducts/NoProductToFind"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(404)
                .withBodyFile("apigee-apim-getproduct-not-found-response-404.json")
                .withHeader("Content-Type", "application/json")));
    ApigeeProductHubRequest hubProductReq = buildTestApigeeProductRequest("1", 
        ApprovalType.manual, Planet.NONPROD, AccessLocation.INTERNAL);
    String userEmail = "product.owner@lumen.com";
    String name = "NoProductToFind";
    hubProductReq.getApigeeProductRequest().setName(name);

    //when-then
    assertThatExceptionOfType(ProductNotFoundException.class)
      .isThrownBy(() -> {
        apigeeProductsService.getProduct("NoProductToFind", "NONPROD", "INTERNAL");
      })
        .withMessageContaining("Product not found for name:");
    assertThatExceptionOfType(ProductNotFoundException.class)
    .isThrownBy(() -> {
      apigeeProductsService.updateProduct(name, hubProductReq, userEmail);
    })
        .withMessageContaining("Product not found for name:");
    assertThatExceptionOfType(ProductNotFoundException.class)
    .isThrownBy(() -> {
      apigeeProductsService.deleteProduct(name, userEmail, "NONPROD", "INTERNAL");
    })
        .withMessageContaining("Product not found for name:");

  }

  @Test
  void shouldGetProductNotFoundForOwner() throws InternalServerException {

    //given
    stubFor(get(urlEqualTo("/v1/o/ext/apiproducts?expand=true"))
            .withHeader("Authorization",
                containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("apigee-apim-getproducts-nonprod-ext-response-ok.json")
                    .withHeader("Content-Type", "application/json")));
    String productOwner = "no.products.for.product.owner@lumen.com";
    String planet = "NONPROD";
    String org = "EXTERNAL";

    //when-then
    assertThatExceptionOfType(ProductNotFoundException.class)
        .isThrownBy(() -> {
          apigeeProductsService.getProducts(planet, org, productOwner);
        })
        .withMessageContaining("No products found for planet: " + planet
            + ", org: " + org + " and productOwner: " + productOwner);
    //No products found for planet: %s, org: %s and productOwner: %s

  }

  @Test
  void saveProductShouldThrowBadInputExceptionForMissingApigeeReq() throws InternalServerException, BadInputException {

    //given
    ApigeeProductHubRequest hubProductReq = new ApigeeProductHubRequest();

    //when-then
    assertThatExceptionOfType(BadInputException.class)
      .isThrownBy(() -> {
        apigeeProductsService.saveProduct(hubProductReq);
      })
        .withMessageContaining("apigeeProductRequest: Missing required request.");

  }

  @Test
  void saveProductShouldThrowBadInputExceptionForMissingEnvs() throws InternalServerException, BadInputException {

    //given
    ApigeeProductHubRequest hubProductReq = new ApigeeProductHubRequest();
    hubProductReq.setApigeeProductRequest(new ApigeeProductRequest());
    hubProductReq.setAccessLocation(AccessLocation.INTERNAL);
    hubProductReq.setPlanet(Planet.NONPROD);
    hubProductReq.setProductOwner("product_owner");
    hubProductReq.getApigeeProductRequest().setProxies(new ArrayList<String>(Arrays.asList("ProxyA", "ProxyB")));


    //when-then
    assertThatExceptionOfType(BadInputException.class)
      .isThrownBy(() -> {
        apigeeProductsService.saveProduct(hubProductReq);
      })
        .withMessageContaining("environments: At least one environment is required.");

  }

  @Test
  void saveProductShouldThrowBadInputExceptionForMissingProxies() throws InternalServerException, BadInputException {

    //given
    ApigeeProductHubRequest hubProductReq = new ApigeeProductHubRequest();
    hubProductReq.setApigeeProductRequest(new ApigeeProductRequest());
    hubProductReq.setAccessLocation(AccessLocation.INTERNAL);
    hubProductReq.setPlanet(Planet.NONPROD);
    hubProductReq.getApigeeProductRequest().setEnvironments(new ArrayList<String>(Arrays.asList("dev1", "test1")));

    //when-then
    assertThatExceptionOfType(BadInputException.class)
      .isThrownBy(() -> {
        apigeeProductsService.saveProduct(hubProductReq);
      })
        .withMessageContaining("proxies: At least one proxy is required.");

  }

  @Test
  void saveProductShouldSetProductOwner() throws InternalServerException, BadInputException {

    //given
    stubFor(post(urlEqualTo("/v1/o/int/apiproducts"))
            .withHeader("Authorization",
                containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("apigee-apim-saveproduct-response-ok.json")
                    .withHeader("Content-Type", "application/json")));
    stubFor(get(urlEqualTo("/v1/o/int/environments"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(200)
                .withBodyFile("apigee-apim-getenvironments-nonprod-int-response-ok.json")
                .withHeader("Content-Type", "application/json")));
    AccessLocation accessLocation = AccessLocation.INTERNAL;
    ApprovalType approvalType = ApprovalType.manual;
    Planet planet = Planet.NONPROD; 
    ApigeeProductHubRequest hubProductReq = buildTestApigeeProductRequest("1", approvalType, planet, accessLocation);

    //when
    ApigeeProduct product = apigeeProductsService.saveProduct(hubProductReq);

    //then
    assertThat(product.getName()).isEqualTo("OrderStatus");

  }

  @Test
  void shouldThrowUnauthorizedException() throws InternalServerException, BadInputException, 
      UnauthorizedException {

    //given
    stubFor(get(urlEqualTo("/v1/o/int/apiproducts/OrderStatus"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(200)
                .withBodyFile("apigee-apim-getproduct-response-ok.json")
                .withHeader("Content-Type", "application/json")));
    AccessLocation accessLocation = AccessLocation.INTERNAL;
    ApprovalType approvalType = ApprovalType.manual;
    Planet planet = Planet.NONPROD;
    String name = "OrderStatus";
    String userEmail = "NOT_THE_product.owner@lumen.com";
    ApigeeProductHubRequest hubProductReq = buildTestApigeeProductRequest("1", approvalType, planet, accessLocation);

    //when-then
    assertThatExceptionOfType(UnauthorizedException.class)
      .isThrownBy(() -> {
        apigeeProductsService.updateProduct(name, hubProductReq, userEmail);
      })
        .withMessageContaining("User not authorized to update this Product");
    assertThatExceptionOfType(UnauthorizedException.class)
    .isThrownBy(() -> {
      apigeeProductsService.deleteProduct(name, userEmail, "NONPROD", "INTERNAL");
    })
        .withMessageContaining("User not authorized to delete this Product:");

  }

  @Test
  void shouldThrowApigeeMgmtApiClientException() {

    //given
    stubFor(get(urlEqualTo("/v1/o/int/environments"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(200)
                .withBodyFile("apigee-apim-getenvironments-nonprod-int-response-ok.json")
                .withHeader("Content-Type", "application/json")));
    stubFor(get(urlEqualTo("/v1/o/int/apiproducts/Exception"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("apigee-apim-getproduct-response-ok.json")
                .withHeader("Content-Type", "application/json")));
    stubFor(post(urlEqualTo("/v1/o/int/apiproducts"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(400)
                .withBodyFile("apigee-apim-getproduct-not-found-response-404.json")
                .withHeader("Content-Type", "application/json")));
    stubFor(put(urlEqualTo("/v1/o/int/apiproducts/Exception"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(400)
                .withBodyFile("apigee-apim-getproduct-not-found-response-404.json")
                .withHeader("Content-Type", "application/json")));
    stubFor(delete(urlEqualTo("/v1/o/int/apiproducts/Exception"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(400)
                .withBodyFile("apigee-apim-getproduct-not-found-response-404.json")
                .withHeader("Content-Type", "application/json")));
    AccessLocation accessLocation = AccessLocation.INTERNAL;
    ApprovalType approvalType = ApprovalType.manual;
    Planet planet = Planet.NONPROD;
    String name = "Exception";
    String errorMsg = "400 Bad Request";
    String org = "INTERNAL";
    ApigeeProductHubRequest hubProductReq = buildTestApigeeProductRequest("1", approvalType, planet, accessLocation);
    hubProductReq.getApigeeProductRequest().setName(name);
    ApigeeProduct product = buildTestApigeeProduct(name, "manual", planet, accessLocation);
    String userEmail = "product.owner@lumen.com";

    //when-then
    assertThatExceptionOfType(ApigeeMgmtApiClientException.class)
        .isThrownBy(() -> {
          apigeeProductsService.saveProduct(hubProductReq);
        });
    assertThatExceptionOfType(ApigeeMgmtApiClientException.class)
        .isThrownBy(() -> {
          apigeeProductsService.updateProduct(name, hubProductReq, userEmail);
        });
    assertThatExceptionOfType(ApigeeMgmtApiClientException.class)
        .isThrownBy(() -> {
          apigeeProductsService.updatePartnerProxyProduct(planet, product);
        });
    assertThatExceptionOfType(ApigeeMgmtApiClientException.class)
        .isThrownBy(() -> {
          apigeeProductsService.deleteProduct(name, userEmail, "NONPROD", org);
        });

  }

  @Test
  void validateRequestShouldFailApigeeReq() throws BadInputException {

    //given
    ApigeeProductHubRequest hubProduct = new ApigeeProductHubRequest();

    //when-then
    assertThatExceptionOfType(BadInputException.class)
      .isThrownBy(() -> {
        apigeeProductsService.validateRequest(hubProduct);
      })
        .withMessageContaining("apigeeProductRequest: Missing required request.");
  }

  @Test
  void validateRequestShouldFailEnvs() throws BadInputException {

    //given
    stubFor(get(urlEqualTo("/v1/o/int/environments"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(200)
                .withBodyFile("apigee-apim-getenvironments-nonprod-int-response-ok.json")
                .withHeader("Content-Type", "application/json")));
    ApigeeProductHubRequest hubProductReq = buildTestApigeeProductRequest("1", 
        ApprovalType.manual, Planet.NONPROD, AccessLocation.INTERNAL);
    hubProductReq.getApigeeProductRequest().setEnvironments(null);

    //when-then
    assertThatExceptionOfType(BadInputException.class)
      .isThrownBy(() -> {
        apigeeProductsService.validateRequest(hubProductReq);
      })
        .withMessageContaining("environments: At least one environment is required.");
    
    hubProductReq.getApigeeProductRequest().setEnvironments(new ArrayList<String>());
    assertThatExceptionOfType(BadInputException.class)
      .isThrownBy(() -> {
        apigeeProductsService.validateRequest(hubProductReq);
      })
        .withMessageContaining("environments: At least one environment is required.");
    hubProductReq.getApigeeProductRequest().getEnvironments().add("badEnv");
    assertThatExceptionOfType(BadInputException.class)
      .isThrownBy(() -> {
        apigeeProductsService.validateRequest(hubProductReq);
      })
        .withMessageContaining("environments: [badEnv] not valid for NONPROD and INTERNAL");

  }

  @Test
  void validateRequestShouldFailProxies() throws BadInputException {

    //given
    ApigeeProductHubRequest hubProductReq = buildTestApigeeProductRequest("1", 
        ApprovalType.manual, Planet.NONPROD, AccessLocation.INTERNAL);
    hubProductReq.getApigeeProductRequest().setProxies(null);

    //when-then
    assertThatExceptionOfType(BadInputException.class)
      .isThrownBy(() -> {
        apigeeProductsService.validateRequest(hubProductReq);
      })
        .withMessageContaining("proxies: At least one proxy is required.");
    
    hubProductReq.getApigeeProductRequest().setProxies(new ArrayList<String>());
    assertThatExceptionOfType(BadInputException.class)
    .isThrownBy(() -> {
      apigeeProductsService.validateRequest(hubProductReq);
    })
        .withMessageContaining("proxies: At least one proxy is required.");

  }

  @Test
  void validateRequestShouldFailOnProdOwner() throws BadInputException {

    //given
    ApigeeProductHubRequest hubProductReq = buildTestApigeeProductRequest("1", 
        ApprovalType.manual, Planet.NONPROD, AccessLocation.INTERNAL);
    hubProductReq.setProductOwner(null);

    //when-then
    assertThatExceptionOfType(BadInputException.class)
      .isThrownBy(() -> {
        apigeeProductsService.validateRequest(hubProductReq);
      })
        .withMessageContaining("productOwner: Product Owner is requried.");
    
    hubProductReq.setProductOwner("");
    assertThatExceptionOfType(BadInputException.class)
    .isThrownBy(() -> {
      apigeeProductsService.validateRequest(hubProductReq);
    })
        .withMessageContaining("productOwner: Product Owner is requried.");
  }

  @Test
  void shouldSetAttributes() {

    //given
    ApigeeProductHubRequest hubProductReq = buildTestApigeeProductRequest("1", 
        ApprovalType.manual, Planet.NONPROD, AccessLocation.INTERNAL);
    Attribute poAttr = new Attribute("PRODUCT_OWNER", "product.owner@lumen.com");
    Attribute accessAttr = new Attribute("access", "private");

    //when-then
    List<Attribute> attributes = apigeeProductsService.setCustomAttributes(hubProductReq);
    
    assertThat(attributes.contains(poAttr)).isTrue();
    assertThat(attributes.contains(accessAttr)).isTrue();
  }

  @Test
  void isOwnerShouldAllowProductOwner() {

    //given
    String userEmail = "product.owner@lumen.com";
    List<Attribute> attributes = new ArrayList<>();
    attributes.add(new Attribute("PRODUCT_OWNER", "product.owner@lumen.com"));      

    //when-then
    assertThat(apigeeProductsService.isUserTheProductOwnerOrHubAdmin(attributes, userEmail)).isTrue();
  }

  @Test
  void isOwnerShouldAllowProductOwnerUc() {

    //given
    String userEmail = "product.owner@lumen.com";
    List<Attribute> attributes = new ArrayList<>();
    attributes.add(new Attribute("PRODUCT_OWNER", "Product.Owner@lumen.com"));      

    //when-then
    assertThat(apigeeProductsService.isUserTheProductOwnerOrHubAdmin(attributes, userEmail)).isTrue();
  }

  @Test
  void isOwnerShouldAllowAdminUser() {

    //given
    String userEmail = "jeremy.eagleman@lumen.com";
    List<Attribute> attributes = new ArrayList<>();
    attributes.add(new Attribute("PRODUCT_OWNER", "product.owner@lumen.com"));      

    //when-then
    assertThat(apigeeProductsService.isUserTheProductOwnerOrHubAdmin(attributes, userEmail)).isTrue();
  }

  @Test
  void isOwnerShouldAllowAdminUserUc() {

    //given
    String userEmail = "Jeremy.Eagleman@lumen.com";
    List<Attribute> attributes = new ArrayList<>();
    attributes.add(new Attribute("PRODUCT_OWNER", "product.owner@lumen.com"));      

    //when-then
    assertThat(apigeeProductsService.isUserTheProductOwnerOrHubAdmin(attributes, userEmail)).isTrue();
  }

  @Test
  void isOwnerShouldFailNotProductOwner() {

    //given
    String userEmail = "bad_email_address";
    List<Attribute> attributes = new ArrayList<>();
    attributes.add(new Attribute("PRODUCT_OWNER", "bad_email_address"));      

    //when-then
    assertThat(apigeeProductsService.isUserTheProductOwnerOrHubAdmin(attributes, userEmail)).isFalse();
  }

  @Test
  void isOwnerShouldFailBadProductOwnerEmail() {

    //given
    String userEmail = "not.owner@lumen.com";
    List<Attribute> attributes = new ArrayList<>();
    attributes.add(new Attribute("PRODUCT_OWNER", "product.owner@lumen.com"));      

    //when-then
    assertThat(apigeeProductsService.isUserTheProductOwnerOrHubAdmin(attributes, userEmail)).isFalse();
  }

  private static ApigeeProductHubRequest buildTestApigeeProductRequest(String prodInc, ApprovalType approvalType, 
      Planet planet, AccessLocation accessLocation) {
    
    ApigeeProductHubRequest hubProduct = new ApigeeProductHubRequest();
    hubProduct.setAccess(Access.PRIVATE);
    hubProduct.setAccessLocation(accessLocation);
    hubProduct.setPlanet(planet);
    hubProduct.setProductOwner("product.owner@lumen.com");
    
    ApigeeProductRequest product = new ApigeeProductRequest();
    product.setApiResources(new ArrayList<String>(Arrays.asList("/ResourceA" + prodInc, "/ResourceB" + prodInc)));
    product.setApprovalType(approvalType);
    product.setDescription("myDescription" + prodInc);
    product.setDisplayName("myDisplayName" + prodInc);
    product.setEnvironments(new ArrayList<String>(Arrays.asList("dev" + prodInc, "test" + prodInc)));
    product.setName("myProductName" + prodInc);
    product.setProxies(new ArrayList<String>(Arrays.asList("ProxyA-" + prodInc, "ProxyB-" + prodInc)));
    product.setScopes(new ArrayList<String>());
    hubProduct.setApigeeProductRequest(product);
    return hubProduct;
  
  }
  
  private static ApigeeProduct buildTestApigeeProduct(String name, String approvalType, 
      Planet planet, AccessLocation accessLocation) {
    
    ApigeeProduct product = new ApigeeProduct();
    product.setApiResources(new ArrayList<String>(Arrays.asList("/ResourceA", "/ResourceB")));
    product.setApprovalType(approvalType);
    product.setDescription("myDescription");
    product.setDisplayName(name);
    product.setEnvironments(new ArrayList<String>(Arrays.asList("dev1", "test1")));
    product.setName(name);
    product.setProxies(new ArrayList<String>(Arrays.asList("ProxyA", "ProxyB")));
    product.setScopes(new ArrayList<String>());

    return product;
  
  }
  
}
