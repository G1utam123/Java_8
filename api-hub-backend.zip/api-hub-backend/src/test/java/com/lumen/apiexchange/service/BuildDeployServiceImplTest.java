package com.lumen.apiexchange.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

import com.lumen.apiexchange.client.ESPClient;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.model.InputApiRequest;
import com.lumen.apiexchange.util.BuildHandler;
import com.lumen.apiexchange.util.ValidationHandler;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class BuildDeployServiceImplTest {

  private BuildDeployServiceImpl buildDeployServiceImpl;
  private ValidationHandler valH;
  private BuildHandler buildH;
  private HostServiceImpl hostServiceImpl;
  private AsyncProxyService asyncService;
  private ESPClient espClient;
  
  private final String DEV1_HOSTNAME = "http://api-dev1.test.intranet";
  private final String DEV2_HOSTNAME = "http://api-dev2.test.intranet";
  private final String DEV3_HOSTNAME = "http://api-dev3.test.intranet";
  private final String DEV4_HOSTNAME = "http://api-dev4.test.intranet";
  private final String TEST1_HOSTNAME = "http://api-test1.test.intranet";
  private final String TEST2_HOSTNAME = "http://api-test2.test.intranet";
  private final String TEST3_HOSTNAME = "http://api-test3.test.intranet";
  private final String TEST4_HOSTNAME = "http://api-test4.test.intranet";
  private final String MOCK_HOSTNAME = "http://api.mock.intranet";
  private final String SANDBOX_HOSTNAME = "http://api.sandbox.intranet";
  private final String PROD_HOSTNAME = "http://api.corp.intranet";
  
  private final String DEV1 = "dev1";
  private final String DEV2 = "dev2";
  private final String DEV3 = "dev3";
  private final String DEV4 = "dev4";
  private final String TEST1 = "test1";
  private final String TEST2 = "test2";
  private final String TEST3 = "test3";
  private final String TEST4 = "test4";
  private final String PROD = "prod";
  
  private static final String COULD_NOT_VALIDATE_PROXY = "Could not validate if proxy exists: ";
  private static final String PROXY_ALREADY_EXISTS = "Proxy already exists: ";
  private static final String SOME_ERROR = "Some Error";
  
  @BeforeEach
  void setUp() {

    valH = mock(ValidationHandler.class);
    buildH = mock(BuildHandler.class);
    hostServiceImpl = mock(HostServiceImpl.class);
    asyncService = mock(AsyncProxyService.class);
    espClient = mock(ESPClient.class);
   
    buildDeployServiceImpl = new BuildDeployServiceImpl(valH, buildH, hostServiceImpl, asyncService);
  }

  private InputApiRequest generateProxyRequest() {
    InputApiRequest proxyRequest = new InputApiRequest();
    proxyRequest.setTaxonomy("Application/Apigee");
    proxyRequest.setResourceName("myResourceName");
    proxyRequest.setVersion("v1");
    proxyRequest.setType("Inbound");
    proxyRequest.setOwningAppAppkey("APPKEY1037142019052317562540722002");
    proxyRequest.setMalId("SYSGEN787551898");
    proxyRequest.setDev1EndpointHostname("http://mocktarget.apigee.net");
    proxyRequest.setEndpointPath("/dosomething");
    proxyRequest.setInternal("true");
    proxyRequest.setProxyAuthInternal("appkey");
    proxyRequest.setEndpointAuth("none");
    proxyRequest.setRequestorEmail("test@lumen.com");
    return proxyRequest;
  }
  
  @Test
  void getCreateEnvironmentListTest () throws InternalServerException {
    InputApiRequest proxyRequest = new InputApiRequest();
    proxyRequest.setDev1EndpointHostname(DEV1_HOSTNAME);
    proxyRequest.setDev2EndpointHostname(DEV2_HOSTNAME);
    proxyRequest.setDev3EndpointHostname(DEV3_HOSTNAME);
    proxyRequest.setDev4EndpointHostname(DEV4_HOSTNAME);
    proxyRequest.setTest1EndpointHostname(TEST1_HOSTNAME);
    proxyRequest.setTest2EndpointHostname(TEST2_HOSTNAME);
    proxyRequest.setTest3EndpointHostname(TEST3_HOSTNAME);
    proxyRequest.setTest4EndpointHostname(TEST4_HOSTNAME);
    proxyRequest.setMockEndpointHostname(MOCK_HOSTNAME);
    proxyRequest.setSandboxEndpointHostname(SANDBOX_HOSTNAME);
    proxyRequest.setProdEndpointHostname(PROD_HOSTNAME);
    
    List<String> envList = new ArrayList<>();
    envList = buildDeployServiceImpl.getCreateEnvironmentList(proxyRequest);
    assertThat(envList.toString()).contains("dev1, dev2, dev3, dev4, test1, test2, test3, test4, mock, sandbox, prod");
  }
  
  @Test
  void validateIfProxyAlreadyExistsEspClientExceptionTest() throws IOException {
    
    InputApiRequest proxyRequest = generateProxyRequest();
    List<String> hostList = new ArrayList<>();
    hostList.add(DEV1_HOSTNAME);
     
    Mockito.when(valH.validateRequest(proxyRequest)).thenReturn("");
    Mockito.when(hostServiceImpl.getHosts()).thenReturn(hostList);
    Mockito.when(espClient.getApiProxies(DEV1, proxyRequest.getTaxonomy(), proxyRequest.getResourceName(), proxyRequest.getVersion()))
      .thenThrow(new InternalServerException(COULD_NOT_VALIDATE_PROXY));

    InternalServerException exception = assertThrows(InternalServerException.class, () -> {
      espClient.getApiProxies(DEV1, proxyRequest.getTaxonomy(), proxyRequest.getResourceName(), proxyRequest.getVersion());
    });
    
    assertTrue(exception.getMessage().contains(COULD_NOT_VALIDATE_PROXY));
  }  
  
  @Test
  void validateIfProxyAlreadyExistsApiFoundTest() throws IOException {
    InputApiRequest proxyRequest = generateProxyRequest();
    
    ApiMediatedResource apiProxyDetails = new ApiMediatedResource();
    CompletableFuture<ApiMediatedResource> apiMediatedResource = CompletableFuture.completedFuture(apiProxyDetails);
    List<String> hostList = new ArrayList<>();
    hostList.add(DEV1_HOSTNAME);
    
    Mockito.when(hostServiceImpl.getHosts()).thenReturn(hostList);
    Mockito.when(asyncService.getApiProxyDetails(DEV1, proxyRequest.getTaxonomy(), proxyRequest.getResourceName(),
        proxyRequest.getVersion())).thenReturn(apiMediatedResource);

    BadInputException exception = assertThrows(BadInputException.class, () -> {
      buildDeployServiceImpl.validateIfProxyAlreadyExists(proxyRequest);
    });
    
    assertTrue(exception.getMessage().contains(PROXY_ALREADY_EXISTS));
  }  
  
  @Test
  void getEnvTest () throws InternalServerException {
    assertThat(buildDeployServiceImpl.getEnv(DEV1_HOSTNAME)).isEqualTo(DEV1);
    assertThat(buildDeployServiceImpl.getEnv(DEV2_HOSTNAME)).isEqualTo(DEV2);
    assertThat(buildDeployServiceImpl.getEnv(DEV3_HOSTNAME)).isEqualTo(DEV3);
    assertThat(buildDeployServiceImpl.getEnv(DEV4_HOSTNAME)).isEqualTo(DEV4);
    assertThat(buildDeployServiceImpl.getEnv(TEST1_HOSTNAME)).isEqualTo(TEST1);
    assertThat(buildDeployServiceImpl.getEnv(TEST2_HOSTNAME)).isEqualTo(TEST2);
    assertThat(buildDeployServiceImpl.getEnv(TEST3_HOSTNAME)).isEqualTo(TEST3);
    assertThat(buildDeployServiceImpl.getEnv(TEST4_HOSTNAME)).isEqualTo(TEST4);
    assertThat(buildDeployServiceImpl.getEnv(PROD_HOSTNAME)).isEqualTo(PROD);
  }
  
  @Test
  void getvalidateRequestSadTest () throws InternalServerException {
    InputApiRequest proxyRequest = generateProxyRequest();
    
    Mockito.when(valH.validateRequest(proxyRequest)).thenReturn(SOME_ERROR);

    BadInputException exception = assertThrows(BadInputException.class, () -> {
      buildDeployServiceImpl.validateRequest(proxyRequest);
      });
    
    assertTrue(exception.getMessage().contains("Invalid Request: "));
  }
  
  @Test
  void shouldThrowExceptionApiAlreadyExistBypassTrue() throws IOException {
    
    InputApiRequest proxyRequest = generateProxyRequest();
    proxyRequest.setBypassApiAlreadyExists(true);
    
    ApiMediatedResource apiProxyDetails = new ApiMediatedResource();
    apiProxyDetails.setMediatedResourceId(12345);
    apiProxyDetails.setEnvironment(DEV1);
    
    CompletableFuture<ApiMediatedResource> apiMediatedResource = CompletableFuture.completedFuture(apiProxyDetails);
    
    List<String> hostList = new ArrayList<>();
    hostList.add(DEV1_HOSTNAME);
     
    Mockito.when(hostServiceImpl.getHosts()).thenReturn(hostList);
    Mockito.when(asyncService.getApiProxyDetails(DEV1, proxyRequest.getTaxonomy(), proxyRequest.getResourceName(),
        proxyRequest.getVersion())).thenReturn(apiMediatedResource);
    
    BadInputException exception = assertThrows(BadInputException.class, () -> {
      buildDeployServiceImpl.validateIfProxyAlreadyExists(proxyRequest);
    });
    
    assertTrue(exception.getMessage().contains(PROXY_ALREADY_EXISTS));
  }
  
  @Test
  void shouldThrowExceptionApiAlreadyExistBypassFalse() throws IOException {
    
    InputApiRequest proxyRequest = generateProxyRequest();
    proxyRequest.setBypassApiAlreadyExists(false);
    ApiMediatedResource apiProxyDetails = new ApiMediatedResource();
    CompletableFuture<ApiMediatedResource> apiMediatedResource = CompletableFuture.completedFuture(apiProxyDetails);
    apiProxyDetails.setMediatedResourceId(12345);
    
    List<String> hostList = new ArrayList<>();
    hostList.add(DEV1_HOSTNAME);
     
    Mockito.when(hostServiceImpl.getHosts()).thenReturn(hostList);
    Mockito.when(asyncService.getApiProxyDetails(DEV1, proxyRequest.getTaxonomy(), proxyRequest.getResourceName(),
        proxyRequest.getVersion())).thenReturn(apiMediatedResource);

    BadInputException exception = assertThrows(BadInputException.class, () -> {
      buildDeployServiceImpl.validateIfProxyAlreadyExists(proxyRequest);
    });
    
    assertTrue(exception.getMessage().contains(PROXY_ALREADY_EXISTS));
  }
}
