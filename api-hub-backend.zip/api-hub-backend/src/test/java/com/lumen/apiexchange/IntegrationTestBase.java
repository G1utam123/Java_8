package com.lumen.apiexchange;

import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.shaded.org.apache.commons.lang3.BooleanUtils;

@Testcontainers
public class IntegrationTestBase {

  private static final String DATABASE_NAME = "api_hub";

  static PostgreSQLContainer postgres = (PostgreSQLContainer) new PostgreSQLContainer("postgres:9.4")
      .withDatabaseName(DATABASE_NAME)
      .withUsername("postgres")
      .withPassword("postgres")
      .withExposedPorts(5432);

  @DynamicPropertySource
  static void registerProperties(DynamicPropertyRegistry registry) {

    if (isRunningTestContainers()) {
      postgres.start();

      registry.add("spring.datasource.url", postgres::getJdbcUrl);
      registry.add("spring.datasource.username", postgres::getUsername);
      registry.add("spring.datasource.password", postgres::getPassword);

    }
  }

  private static boolean isRunningTestContainers() {
    return BooleanUtils.toBoolean(System.getenv("TESTCONTAINERS"));
  }

}
