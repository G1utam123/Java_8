package com.lumen.apiexchange.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.lumen.apiexchange.client.ESPClient;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.entity.ApiDocumentation;
import com.lumen.apiexchange.model.ApiHomeCategoryCollection;
import com.lumen.apiexchange.entity.ApiHomeDetails;
import com.lumen.apiexchange.model.ApiHomeRequest;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.model.ApiMediatedResponse;
import com.lumen.apiexchange.repository.ApiDocumentationRepository;
import com.lumen.apiexchange.repository.ApiHomeRepository;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class ApiServiceUnitTest {

  private ApiServiceImpl apiServiceImpl;
  private ApiDocumentationRepository docRepository;
  private ApiHomeRepository homeRepostory;
  private ESPClient espClient;

  @BeforeEach
  void setup() {
    homeRepostory = mock(ApiHomeRepository.class);
    docRepository = mock(ApiDocumentationRepository.class);
    espClient = mock(ESPClient.class);
    ProxyService proxyService = mock(ProxyService.class);
    apiServiceImpl = new ApiServiceImpl(docRepository, homeRepostory, espClient, proxyService);
  }

  ApiDocumentation apiDoc1 = new ApiDocumentation(12, 1, UUID.randomUUID(), "Page Diagnostics",
      "This is the Lumen API Marketplace", "This file content is a new swagger section", "new file");

  ApiDocumentation apiDoc2 = new ApiDocumentation(13, 2, UUID.randomUUID(), "Page Diagnostics", 
      "This is the Lumen API Marketplace", "This file content is a new swagger section", "new file");

  ApiDocumentation apiDoc3 = new ApiDocumentation(14, 3, UUID.randomUUID(), "Page Diagnostics", 
      "This is the Lumen API Marketplace", "This file content is a new swagger section", "new file");

  ApiDocumentation apiDoc4 = new ApiDocumentation(15, 4, UUID.randomUUID(), "Page Diagnostics", 
      "This is the Lumen API Marketplace", "This file content is a new swagger section", "new file");


  @Test
  public void getApiHomeDetails() throws Exception {

    List<ApiHomeDetails> details = new ArrayList<>();
    UUID uuid1 = UUID.randomUUID();
    ApiHomeDetails apiHomeDetails1 = new ApiHomeDetails(uuid1, "dynamic connection", "Category", "dynamic connections");
    UUID uuid2 = UUID.randomUUID();
    ApiHomeDetails apiHomeDetails2 = new ApiHomeDetails(uuid2, "Ticketing and Scheduled Maintenance", 
        "Service Assurance", "Provides APIs to create and delete ethernet connections dynamically.");
    UUID uuid3 = UUID.randomUUID();
    ApiHomeDetails apiHomeDetails3 = new ApiHomeDetails(uuid3, "Ticketing and Scheduled Maintenance", "Category",
        "Provides APIs to create and delete ethernet connections dynamically.");
    UUID uuid4 = UUID.randomUUID();
    ApiHomeDetails apiHomeDetails4 = new ApiHomeDetails(uuid4, "Ticketing and Scheduled Maintenance", "Category",
        "Provides APIs to create and delete ethernet connections dynamically.");

    details.add(apiHomeDetails1);
    details.add(apiHomeDetails2);
    details.add(apiHomeDetails3);
    details.add(apiHomeDetails4);

    ApiHomeCategoryCollection apiList = new ApiHomeCategoryCollection();
    apiList.setApis(details);
    when(homeRepostory.findAll()).thenReturn(details);

    assertNotNull(apiServiceImpl.getApiHomeDetails());


  }

  @Test
  public void getAPIDocumentationTest() {

    List<ApiDocumentation> apiDocdetails = new ArrayList<>();

    apiDocdetails.add(apiDoc2);

    apiDocdetails.add(apiDoc4);
    UUID apiid = UUID.randomUUID();
    when(docRepository.findByApiId(apiid)).thenReturn(apiDocdetails);
    assertNotNull(apiServiceImpl.getApiDocumentation(apiid));
  }


  @Test
  public void getAPIDocumentation_Negative_Test() {

    List<ApiDocumentation> apiDocdetails = new ArrayList<>();
    UUID apiid = UUID.randomUUID();
    when(docRepository.findByApiId(apiid)).thenReturn(apiDocdetails);
    assertTrue(apiServiceImpl.getApiDocumentation(apiid).isEmpty());
  }

  @Test
  public void postAPIDocumentationTest() {

    List<ApiDocumentation> apiDocdetails = new ArrayList<>();

    apiDocdetails.add(apiDoc2);

    apiDocdetails.add(apiDoc4);
    int apiid = 30;
    when(docRepository.save(apiDoc3)).thenReturn(apiDoc3);

    assertNotNull(apiServiceImpl.postApiDocumentation(apiDoc3));

  }


  @Test
  public void updateAPIDocumentationTest() {

    List<ApiDocumentation> apiDocdetails = new ArrayList<>();

    int id = apiDoc4.getId();
    UUID apiId = apiDoc4.getApiId();

    String apiName = apiDoc4.getApiName();
    String documentation = apiDoc4.getDocumentation();
    String sectionType = apiDoc4.getSectionType();
    String filecontent = apiDoc4.getFilecontent();
    int sectionOrder = apiDoc4.getSectionOrder();
    when(docRepository.save(any()))
        .thenReturn(apiDoc4);
    assertNotNull(apiServiceImpl.updateDocumentation(apiDoc4));

  }


  @Test
  public void deleteAPIDocumentationTest() {

    List<ApiDocumentation> apiDocdetails = new ArrayList<>();

    int id = 20; // when(docRepository.deleteDocumentation(id)).thenReturn();
    apiServiceImpl.deleteDocumentation(id);

  }

  @Test
  public void postNewAPIDetailTest() {

    ApiHomeRequest homeReq = new ApiHomeRequest();
    homeReq.setId(12);
    homeReq.setApiName("Page Diagnostics");
    homeReq.setDescription("This is the Lumen API Marketplace");
    String apiName = "Dynamic Connections";
    String description = "Dynamic Connections";

    String author = "author";

    ApiHomeDetails apiHomeDetails1 = null;
    when(homeRepostory.save(apiHomeDetails1)).thenReturn(apiHomeDetails1);
    assertNotNull(apiServiceImpl.postNewApiDetail(homeReq, author));

  }


  @Test
  public void updateNewAPIDetailTest() {


    ApiHomeDetails apiDetails = new ApiHomeDetails();
    apiDetails.setId(UUID.randomUUID());
    apiDetails.setName("Page Diagnostics");
    apiDetails.setDescription("This is the Lumen API Marketplace");

    ApiHomeRequest apiHomeRequestModel = new ApiHomeRequest();
    apiHomeRequestModel.setApiName("test");
    apiHomeRequestModel.setDescription("test");
    apiHomeRequestModel.setCategory("category");
    apiHomeRequestModel.setType("Type");
    apiHomeRequestModel.setStatus("Development");
    apiHomeRequestModel.setVersion("1.0");
    apiHomeRequestModel.setOasUrl("https://api-dev1.test.intranet/oasurl");
    apiHomeRequestModel.setSourceCodeUrl("https://api-dev1.test.intranet/sourceCodeUrl");

    int id = 7;
    String apiName = "Page Diagnostics";
    String description = "This is the Lumen API Marketplace";
    String category = "category";
    String type = "Type";
    String status = "Development";
    String version = "1.0";
    String oasUrl = "https://api-dev1.test.intranet/oasurl";
    String sourceCodeUrl = "https://api-dev1.test.intranet/sourceCodeUrl";
    Timestamp updatedTime = new Timestamp(System.currentTimeMillis());

    String author = "author";
    UUID apiId = UUID.randomUUID();
    ApiHomeDetails apiHomeDetails1 = new ApiHomeDetails();
    when(homeRepostory.save(apiHomeDetails1)).thenReturn(apiDetails);
    when(homeRepostory.findById(apiId)).thenReturn(Optional.of(apiHomeDetails1));
    assertNotNull(apiServiceImpl.updateApiDetails(apiId, apiHomeRequestModel, author));

  }

  @Test
  public void getAPIDocumentationFile_Negative_Test() {

    int id = 12;

    assertNull(apiServiceImpl.getApiDocumentationFile(id));

  }

  @Test
  public void updateSequenceTest() {
    List<ApiDocumentation> apidoc = new ArrayList<>();
    apidoc.add(apiDoc1);
    apidoc.add(apiDoc4);
    for (int i = 0; i < apidoc.size(); i++) {
      when(docRepository.save(any())).thenReturn(apidoc.get(i));
    }
    assertNotNull(apiServiceImpl.updateSequence(apidoc));
  }


  @Test
  public void deleteAPIDetailsTest() throws Exception {

    UUID apiId = UUID.randomUUID(); // when(docRepository.deleteDocumentation(id)).thenReturn();
    apiServiceImpl.deleteApiDetails(apiId);

  }

  @Test
  public void getApiProxiesTest() throws InternalServerException {

    ApiMediatedResource apiMediatedResource = getApiMediatedResource();
    ApiMediatedResponse apiResources = new ApiMediatedResponse();

    List<ApiMediatedResource> mediatedResourceList = new ArrayList<ApiMediatedResource>();
    mediatedResourceList.add(apiMediatedResource);
    apiResources.setMediatedResource(mediatedResourceList);


    Mockito.when(espClient.getApiProxies()).thenReturn(apiResources);

    Assertions.assertNotNull(apiServiceImpl.getApiProxies());

  }

  private ApiMediatedResource getApiMediatedResource() {

    ApiMediatedResource apiResource = new ApiMediatedResource();

    apiResource.setActive("Test");
    apiResource.setAuthorizedGroups("Test");
    apiResource.setAuthorizedUsers("Test");
    apiResource.setB2bAuthRequired("Test");
    apiResource.setB2bBillingAccountNumberRequired("Test");
    apiResource.setB2bCustomerNumberRequired("Test");
    apiResource.setBasicAuthPassword("Test");
    apiResource.setConnectionKeepAlive("Test");
    apiResource.setCreatedBy("Test");
    apiResource.setCreatedDate("Test");
    apiResource.setEndpointAuthType("Test");
    apiResource.setEndPointUrl("Test");
    apiResource.setEnforceDigest("Test");
    apiResource.setEnforceHttps("Test");
    apiResource.setEnforceTaxonomy("Test");
    apiResource.setEnvironment("Test");
    apiResource.setExternallyAvailable("Test");
    apiResource.setInternallyAvailable("Test");
    apiResource.setMediatedResourceId(123);
    apiResource.setoAuthClientSecret("Test");
    apiResource.setoAuthGrantType("Test");
    apiResource.setoAuthGrantTypeLocation("Test");
    apiResource.setoAuthPassword("Test");
    apiResource.setoAuthTokenServiceHost("Test");
    apiResource.setoAuthTokenServiceUri("Test");
    apiResource.setOwningApplicationId("Test");
    apiResource.setReplaceUrlFromValue("Test");
    apiResource.setResourceGuid("Test");
    apiResource.setResourceName("Test");
    apiResource.setResourceTaxonomy("Test");
    apiResource.setRoutingExpression("Test");
    apiResource.setRoutingType("Test");
    apiResource.setServiceType("Test");
    apiResource.setSource("Test");
    apiResource.setThrottlingRequestsPerSec(50);
    apiResource.setTimeoutSecs(12);
    apiResource.setUpdatedBy("Test");
    apiResource.setUpdatedDate("Test");
    apiResource.setValidAuthTypes("Test");
    apiResource.setVersion("Test");
    apiResource.setServiceType("Test");

    return apiResource;
  }

}
