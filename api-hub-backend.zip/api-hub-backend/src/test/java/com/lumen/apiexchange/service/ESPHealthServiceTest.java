package com.lumen.apiexchange.service;

import com.lumen.apiexchange.api.status.model.ApihubHeartbeatResponse;
import com.lumen.apiexchange.api.status.model.ElementStatus;
import com.lumen.apiexchange.client.WebhookStatusClient;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ESPHealthStatusResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

class ESPHealthServiceTest {

  @Mock
  private WebhookStatusClient webhookStatusClient;

  private ESPHealthServiceImpl espHealthService;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    espHealthService = new ESPHealthServiceImpl(webhookStatusClient);
  }

  @Test
  void testGetESPHealthStatus() throws InternalServerException {
    // Create a sample APIhubHeartbeatResponse
    ApihubHeartbeatResponse sampleResponse = new ApihubHeartbeatResponse();
    Map<String, List<ElementStatus>> heartbeatList = new HashMap<>();
    heartbeatList.put("2", createSampleElementStatusList(1)); // ESP-DEV1
    heartbeatList.put("3", createSampleElementStatusList(2)); // ESP-DEV2
    heartbeatList.put("4", createSampleElementStatusList(3)); // ESP-DEV3
    heartbeatList.put("5", createSampleElementStatusList(4)); // ESP-DEV4
    heartbeatList.put("6", createSampleElementStatusList(5)); // ESP-TEST1
    heartbeatList.put("7", createSampleElementStatusList(6)); // ESP-TEST2
    heartbeatList.put("8", createSampleElementStatusList(7)); // ESP-TEST3
    heartbeatList.put("9", createSampleElementStatusList(8)); // ESP-TEST4
    sampleResponse.setHeartbeatList(heartbeatList);

    // Mock the behavior of the webhookStatusClient
    when(webhookStatusClient.getApihubHeartbeat()).thenReturn(new ResponseEntity<>(sampleResponse, HttpStatus.OK));

    // Call the method under test
    ESPHealthStatusResponse response = espHealthService.getESPHealthStatus();

    // Verify the expected response
    assertEquals(1, response.getEspDev1());
    assertEquals(2, response.getEspDev2());
    assertEquals(3, response.getEspDev3());
    assertEquals(4, response.getEspDev4());
    assertEquals(5, response.getEspTest1());
    assertEquals(6, response.getEspTest2());
    assertEquals(7, response.getEspTest3());
    assertEquals(8, response.getEspTest4());
  }

  private List<ElementStatus> createSampleElementStatusList(int status) {
    List<ElementStatus> list = new ArrayList<>();
    ElementStatus elementStatus = new ElementStatus();
    elementStatus.setStatus(status);
    list.add(elementStatus);
    return list;
  }
}
