package com.lumen.apiexchange.util;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.exactly;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.put;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.github.tomakehurst.wiremock.client.WireMock;
import com.lumen.apiexchange.IntegrationTestBase;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ApiMigrateRequest;
import com.lumen.apiexchange.model.ApiMigrationResult;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("it")
@AutoConfigureWireMock(port = 0)
class APIMigrationHandlerTest extends IntegrationTestBase {
  
  @Autowired
  private APIMigrationHandler apiMigrationHandler;

  @BeforeEach
  public void reset() {
    WireMock.reset();
  }

  @Test
  void testMigrateApiEnvEqualMirror() throws InternalServerException, BadInputException {

    // given
    ApiMigrateRequest request = new ApiMigrateRequest();
    request.setMirrorEnvironment("dev1");
    request.setDev3EndpointHostname("http://mocktarget.apigee.net");
    request.setGuid("cd0f8c4f-bf4c-473f-8e3c-0d599b1a49b4");
    request.setRequestorEmail("jeremy.eagleman@lumen.com");

    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        //.withHeader("X-Level3-Application-Key", containing("APPKEY736482021062922182314937525"))
        .withHeader("X-Username", containing("apigee"))
        .withQueryParam("resourceGuid", equalTo(request.getGuid()))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-mediated-resources-response2.json")
            .withHeader("Content-Type", "application/json")));

    stubFor(post(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing("apigee"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-migrate-build-call-response.json")
            .withHeader("Content-Type", "application/json")));

    // when
    apiMigrationHandler.migrateApi(request);

    // then
    verify(exactly(1), getRequestedFor(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource")));
  }

  @Test
  void testMigrateApiMirrorLookupFail() {

    // given
    ApiMigrateRequest request = new ApiMigrateRequest();
    request.setMirrorEnvironment("dev2");
    request.setDev3EndpointHostname("http://mocktarget.apigee.net");
    request.setGuid("mediated-resource-api-call-fail");

    stubFor(get(urlEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Level3-Application-Key", containing("APPKEY736482021062922182314937525"))
        .withHeader("X-Username", containing("apigee"))
        .willReturn(aResponse()
            .withStatus(500)
            .withBodyFile("apigee-mediated-resource-api-call-fail-response.json")
            .withHeader("Content-Type", "application/json")));

    // when
    //MigrationException exception =
    //    assertThrows(MigrationException.class, () -> apiMigrationHandler.migrateApi(request));
    InternalServerException exception = assertThrows(InternalServerException.class, () -> {
      apiMigrationHandler.migrateApi(request); });

    //assertThat(exception.getMessage()).contains("Could not retrieve Mirror API information. "
    //    + " Please try again later.");
    assertThat(exception.getMessage()).contains("Source API could not be returned.");


  }
  
  @Test
  void testMockInternalOnly() throws Exception {

    // given
    ApiMigrateRequest request = new ApiMigrateRequest();
    request.setMirrorEnvironment("dev1");
    request.setMockEndpointHostname("http://mocktarget.apigee.net");
    request.setGuid("6b15aef1-8112-4f75-95e9-c5a5208f0e95");
    request.setRequestorEmail("test.test@lumen.com");

    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing("apigee"))
        .withQueryParam("resourceGuid", equalTo(request.getGuid()))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-migrate-get-mirror-reponse001.json")
            .withHeader("Content-Type", "application/json")));

    // when
    ApiMigrationResult amr = apiMigrationHandler.migrateApi(request);

    // then
    assertTrue(amr.getNotMigratedEnv().toString().contains("mock"));
  }

  @Test
  void testSandboxInternalOnly() throws Exception {

    // given
    ApiMigrateRequest request = new ApiMigrateRequest();
    request.setMirrorEnvironment("dev1");
    request.setSandboxEndpointHostname("http://mocktarget.apigee.net");
    request.setGuid("6b15aef1-8112-4f75-95e9-c5a5208f0e95");
    request.setRequestorEmail("test.test@lumen.com");

    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing("apigee"))
        .withQueryParam("resourceGuid", equalTo(request.getGuid()))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-migrate-get-mirror-reponse001.json")
            .withHeader("Content-Type", "application/json")));

    // when
    ApiMigrationResult amr = apiMigrationHandler.migrateApi(request);

    // then
    assertTrue(amr.getNotMigratedEnv().toString().contains("sandbox"));
  }

  @Test
  void testSandboxExternal() throws Exception {

    // given
    ApiMigrateRequest request = new ApiMigrateRequest();
    request.setMirrorEnvironment("dev1");
    request.setSandboxEndpointHostname("http://mocktarget.apigee.net");
    request.setMockEndpointHostname("http://mocktarget.apigee.net");
    request.setGuid("6b15aef1-8112-4f75-95e9-c5a5208f0e95");
    request.setRequestorEmail("test.test@lumen.com");
    //retrieve mirror
    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing("apigee"))
        .withQueryParam("resourceGuid", equalTo(request.getGuid()))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-migrate-get-mirror-reponse002.json")
            .withHeader("Content-Type", "application/json")));
    
    //build
    stubFor(post(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing("test.test@lumen.com"))
        //.withQueryParam("resourceGuid", equalTo(request.getGuid()))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-mediated-resource-build-response001.json")
            .withHeader("Content-Type", "application/json")));

    //deploy
    stubFor(put(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource/59698/deployExternal"))
        .withHeader("X-Username", containing("apigee"))
        //.withQueryParam("resourceGuid", equalTo(request.getGuid()))
        .willReturn(aResponse()
            .withStatus(200)));
    
    // when
    ApiMigrationResult amr = apiMigrationHandler.migrateApi(request);

    // then
    assertTrue(amr.getMigratedEnv().toString().contains("sandbox"));
    assertTrue(amr.getMigratedEnv().toString().contains("mock"));
  }

}
