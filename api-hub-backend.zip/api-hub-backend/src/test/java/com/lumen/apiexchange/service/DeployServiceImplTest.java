package com.lumen.apiexchange.service;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.AsyncBuildDeployResult;
import com.lumen.apiexchange.model.InputApiRequest;
import com.lumen.apiexchange.util.DeployHandler;
import java.io.IOException;
import java.util.ArrayList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class DeployServiceImplTest {

  private DeployServiceImpl deployServiceImpl;
  private DeployHandler deployH;
  
  @BeforeEach
  void setUp() {
    deployH = mock(DeployHandler.class);
   
    deployServiceImpl = new DeployServiceImpl(deployH);
  }
  
  @Test
  void validateIfProxyAlreadyExistsEspClientExceptionTest() throws IOException {
    
    AsyncBuildDeployResult asyncBuildDeployResult = AsyncBuildDeployResult.builder()
        .proxyBuiltInEnvironments("")
        .proxyNotBuiltInEnvironments("")
        .proxyDeployedToEnvironments(new ArrayList<>())
        .proxyNotDeployedToEnvironments(new ArrayList<>())
        .build();
    
    Mockito.when(deployH.deployApi("test1", "external", "123456"))
      .thenThrow(new InternalServerException("something happened"));

    asyncBuildDeployResult = deployServiceImpl.deployProxy(new InputApiRequest(), "external",
        asyncBuildDeployResult);
    
    assertTrue(!asyncBuildDeployResult.getProxyNotDeployedToEnvironments().isEmpty());
  }  
  
}
