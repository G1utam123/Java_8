package com.lumen.apiexchange.service.apigee;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.delete;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.put;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;

import com.lumen.apiexchange.IntegrationTestBase;
import com.lumen.apiexchange.config.ApigeeMgmtApiConfigProperties;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.ProductNotFoundException;
import com.lumen.apiexchange.exception.UnauthorizedException;
import com.lumen.apiexchange.model.apigee.ApigeeProduct;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.Access;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.AccessLocation;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.Planet;
import com.lumen.apiexchange.model.apigee.ApigeeProductRequest;
import com.lumen.apiexchange.model.apigee.ApigeeProductRequest.ApprovalType;
import com.lumen.apiexchange.model.apigee.ApigeeProductResponse;
import com.lumen.apiexchange.model.apigee.Attribute;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("it")
@AutoConfigureWireMock(port = 0)
class ApigeeEnvironmentsServiceTest extends IntegrationTestBase {

  @Autowired
  private ApigeeEnvironmentsServiceImpl apigeeEnvsService;

  @Autowired
  private ApigeeMgmtApiConfigProperties apigeeMgmtApiConfigProperties;

  @Test
  void shoulGetApigeeEnvironments() {

    //given
    String planet = "NONPROD";
    String org = "INTERNAL";
    stubFor(get(urlEqualTo("/v1/o/int/environments"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(200)
                .withBodyFile("apigee-apim-getenvironments-nonprod-int-response-ok.json")
                .withHeader("Content-Type", "application/json")));

    //when
    List<String> envsNonProdInt = apigeeEnvsService.getEnvironments(planet, org); 

    //then
    assertThat(envsNonProdInt).hasSize(11);

  }

  @Test
  void shouldValidateApigeeEnvironments() throws BadInputException {

    //given
    String planet = "NONPROD";
    String org = "INTERNAL";
    stubFor(get(urlEqualTo("/v1/o/int/environments"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(200)
                .withBodyFile("apigee-apim-getenvironments-nonprod-int-response-ok.json")
                .withHeader("Content-Type", "application/json")));
    List<String> goodEnvList = new ArrayList<String>(Arrays.asList("dev1", "dev2", "test1", "test2"));

    //when
    List<String> envsNonProdInt = apigeeEnvsService.getEnvironments(planet, org);
    

    //then
    assertThat(envsNonProdInt).hasSize(11);
    apigeeEnvsService.validateEnvironments(planet, org, envsNonProdInt);

  }

  @Test
  void validateApigeeEnvironmentsShouldThrowException() {

    //given
    stubFor(get(urlEqualTo("/v1/o/int/environments"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(200)
                .withBodyFile("apigee-apim-getenvironments-nonprod-int-response-ok.json")
                .withHeader("Content-Type", "application/json")));
    stubFor(get(urlEqualTo("/v1/o/ext/environments"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(200)
                .withBodyFile("apigee-apim-getenvironments-nonprod-ext-response-ok.json")
                .withHeader("Content-Type", "application/json")));
    List<String> badEnvList1 = new ArrayList<String>(Arrays.asList("dev1", "dev2", "test1", "testXX"));
    List<String> badEnvList2 = new ArrayList<String>(Arrays.asList("dev1", "dev2", "testXX", "testYY"));

    //when-then
    assertThatExceptionOfType(BadInputException.class)
      .isThrownBy(() -> {
        apigeeEnvsService.validateEnvironments("NONPROD", "INTERNAL", badEnvList1);
      })
        .withMessageContaining("environments: [testXX] not valid for NONPROD and INTERNAL");
    assertThatExceptionOfType(BadInputException.class)
      .isThrownBy(() -> {
        apigeeEnvsService.validateEnvironments("NONPROD", "INTERNAL", badEnvList2);
      })
        .withMessageContaining("environments: [testXX, testYY] not valid for NONPROD and INTERNAL");
    assertThatExceptionOfType(BadInputException.class)
      .isThrownBy(() -> {
        apigeeEnvsService.validateEnvironments("NONPROD", "EXTERNAL", badEnvList2);
      })
        .withMessageContaining("environments: [testXX, testYY] not valid for NONPROD and EXTERNAL");

  }

}