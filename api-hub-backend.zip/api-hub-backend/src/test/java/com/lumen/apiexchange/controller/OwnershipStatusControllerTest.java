package com.lumen.apiexchange.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.lumen.apiexchange.entity.OwnershipStatus;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.OwnershipStatusUniqueRecordNotFoundException;
import com.lumen.apiexchange.repository.OwnershipRepository;
import com.lumen.apiexchange.service.OwnershipStatusService;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.InjectMocks;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import static org.mockito.ArgumentMatchers.eq;
import org.springframework.data.web.config.EnableSpringDataWebSupport;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.junit.Assert.assertThrows;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.security.acl.Owner;
import java.util.Arrays;
import java.util.List;


@WebMvcTest(controllers = { OwnershipStatusController.class })
@AutoConfigureMockMvc(addFilters = false)
@EnableSpringDataWebSupport
public class OwnershipStatusControllerTest {

  @Autowired
  private MockMvc mockMvc;

  @MockBean
  private OwnershipStatusService ownershipStatusService;

  @MockBean
  private OwnershipRepository ownershipRepository;

  @InjectMocks
  private OwnershipStatusController ownershipStatusController;


  protected static final Logger log = LoggerFactory.getLogger(OwnershipStatusControllerTest.class);

  @Test
  void shouldGetOwnershipStatus() throws Exception {
    OwnershipStatus ownershipResponse = OwnershipStatus.builder()
        .elementType("proxy")
        .requestNo("RITM2345")
        .status("PROVISIONING")
        .requester("ad22342")
        .elementId("APIGEE").build();

    String elementId = "APIGEE";

    //when
    Mockito.when(ownershipStatusService.getOwnershipStatus(elementId))
        .thenReturn(ownershipResponse);

    //Then
    MvcResult mvcResult = this.mockMvc.perform(get("/v1/ownerships/APIGEE")
        .contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(ownershipResponse))).andExpect(status().isOk()).andReturn();
    assertEquals(200, mvcResult.getResponse().getStatus());
  }

  @Test
  void shouldDeleteOwnershipStatus() throws Exception {
    OwnershipStatus ownershipResponse = OwnershipStatus.builder()
        .elementType("proxy")
        .requestNo("RITM2345")
        .status("PROVISIONING")
        .requester("ad22342")
        .elementId("APIGEE").build();

    String elementId = "APIGEE";

    //when
    Mockito.when(ownershipStatusService.getOwnershipStatus(elementId))
        .thenReturn(ownershipResponse);

    //Then
    MvcResult mvcResult = this.mockMvc.perform(delete("/v1/ownerships/APIGEE")
        .contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(ownershipResponse))).andExpect(status().isOk()).andReturn();
    assertEquals(200, mvcResult.getResponse().getStatus());
  }

  @Test
  void shouldReturnOwnershipStatusNotFoundException() throws Exception {
    String elementId = "SYSGEN1234";
    OwnershipStatus ownershipResponse = null;


    //when
    Mockito.when(ownershipStatusService.getOwnershipStatus(elementId)).thenReturn(ownershipResponse);

    //Then
    mockMvc.perform(get("/v1/ownerships/SYSGEN1234"))
        .andExpect(status().isNoContent());
    mockMvc.perform(delete("/v1/ownerships/SYSGEN1234"))
        .andExpect(status().isNoContent());

  }


  @Test
  void shouldReturnUniqueRecordNotFoundException() throws Exception {
    String elementId = "SYSGEN1234";

    //when
    Mockito.when(ownershipStatusService.getOwnershipStatus(elementId)).thenThrow(
        OwnershipStatusUniqueRecordNotFoundException.class);

    ResponseEntity<String> responseGet = new ResponseEntity<String>("Unique Record Not Found", HttpStatus.NOT_FOUND);

    //Then
    MvcResult mvcResult1 = this.mockMvc.perform(get("/v1/ownerships/SYSGEN1234")
            .contentType(MediaType.APPLICATION_JSON) .content(new ObjectMapper().writeValueAsString(responseGet)))
        .andExpect(status().is5xxServerError()).andReturn();
  }

  @Test
  public void testgetOwnershipStatusByStatusEmpty() throws Exception {
    Page<OwnershipStatus> ownershipStatusPage = Page.empty();
    //When
    Mockito.when(ownershipStatusService.getOwnerships(any(PageRequest.class))).thenReturn(ownershipStatusPage);

    mockMvc.perform(get("/v1/ownerships"))
        .andExpect(status().isNoContent()); // status 204
  }

  @Test
  public void testgetOwnershipStatusByStatusWithStatusEmpty() throws Exception {
    //When
    Mockito.when(ownershipStatusService.getOwnershipStatusByStatus(Mockito.anyString(), any(PageRequest.class)))
        .thenReturn(Page.empty());

    mockMvc.perform(get("/v1/ownerships").param("status", "PROVISIONED"))
        .andExpect(status().isNoContent()); // status 204
  }
  @Test
  public void testgetOwnershipStatusByStatus() throws Exception {
    OwnershipStatus ownershipOne = OwnershipStatus.builder()
        .elementType("proxy")
        .requestNo("RITM2345671")
        .status("PROVISIONING")
        .requester("ad22342")
        .elementId("APIGEE").build();
    List<OwnershipStatus> ownershipStatusList = Arrays.asList(ownershipOne);
    Page<OwnershipStatus> response = new PageImpl<>(ownershipStatusList, PageRequest.of(0,10), ownershipStatusList.size());


    //When
    Mockito.when(ownershipStatusService.getOwnershipStatusByStatus(Mockito.anyString(), any(PageRequest.class))).thenReturn(response);


    mockMvc.perform(get("/v1/ownerships").param("status", "PROVISIONED"))
        .andExpect(status().isOk()); // status 200
  }

  @Test
  void testGetOwnershipsByTypeAndStatus() throws Exception {
    OwnershipStatus ownershipOne = OwnershipStatus.builder()
        .elementType("proxy")
        .requestNo("RITM2345671")
        .status("PROVISIONING")
        .requester("ad22342")
        .elementId("APIGEE").build();
    List<OwnershipStatus> ownershipStatusList = Arrays.asList(ownershipOne);
    Page<OwnershipStatus> response = new PageImpl<>(ownershipStatusList, PageRequest.of(0,10), ownershipStatusList.size());


    //When
    Mockito.when(ownershipStatusService.getOwnershipStatusByTypeAndStatus(Mockito.anyString(), Mockito.anyString(), any(PageRequest.class))).thenReturn(response);
        //StatusByStatus(Mockito.anyString(), any(PageRequest.class))).thenReturn(response);


    mockMvc.perform(get("/v1/ownerships").param("status", "PROVISIONED").param("type", "proxy"))
        .andExpect(status().isOk()); // status 200
  }

  @Test
  void testGetOwnershipsInvalidStatus() {
    // Arrange
    String invalidStatus = "INVALID";
    Pageable pageable = PageRequest.of(0, 10);

    // Act & Assert
    assertThrows(BadInputException.class, () -> ownershipStatusController.getOwnerships(invalidStatus, null, pageable));
  }

  @Test
  void testGetOwnershipsInvalidElementType() {
    // Arrange
    String invalidElementType = "INVALID";
    Pageable pageable = PageRequest.of(0, 10);

    // Act & Assert
    assertThrows(
        BadInputException.class, () -> ownershipStatusController.getOwnerships(null, invalidElementType, pageable));
  }

  @Test
  public void testgetOwnershipStatysByType() throws Exception {
    OwnershipStatus ownershipOne = OwnershipStatus.builder()
        .elementType("proxy")
        .requestNo("RITM2345671")
        .status("PROVISIONING")
        .requester("ad22342")
        .elementId("APIGEE").build();
    List<OwnershipStatus> ownershipStatusList = Arrays.asList(ownershipOne);
    Page<OwnershipStatus> response = new PageImpl<>(ownershipStatusList, PageRequest.of(0,10), ownershipStatusList.size());


    //When
    Mockito.when(ownershipStatusService.getOwnershipStatusByType(Mockito.anyString(), any(PageRequest.class))).thenReturn(response);


    mockMvc.perform(get("/v1/ownerships").param("status", "PROVISIONED"))
        .andExpect(status().isOk()); // status 200
  }


}
