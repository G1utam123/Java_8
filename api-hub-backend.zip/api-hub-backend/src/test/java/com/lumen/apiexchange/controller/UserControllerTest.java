package com.lumen.apiexchange.controller;

import static org.junit.Assert.assertNotNull;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doReturn;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.lumen.apiexchange.exception.CustomStatusResponse;
import com.lumen.apiexchange.model.userprofile.CreateUserRequest;
import com.lumen.apiexchange.service.ProfileService;
import com.lumen.apiexchange.service.UserService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

/**
 * Tests for UserController.
 */
@WebMvcTest(UserController.class) 
@MockitoSettings(strictness = Strictness.LENIENT) 
@AutoConfigureMockMvc(addFilters = false)
public class UserControllerTest {

  @Autowired
  private MockMvc mockMvc;

  @MockBean
  UserService userService;

  @MockBean
  ProfileService profileService;

  /**
   * <p>
   * Test to verify POST call responds with a json with details of Created User
   * </p>
   * The <b>service method response is mocked</b> to verify this case
   * 
   */
  @Test 
  @DisplayName("Should respond with json containing user information on successful creation of user")
  void createApigeeUserTest() throws Exception {

    //given
    CreateUserRequest createUserRequest = new CreateUserRequest();
    createUserRequest.setEmail("test@lumen.com");
    createUserRequest.setFirstName("APITestUserFirstName");
    createUserRequest.setLastName("APITestUserLastName");
    createUserRequest.setUserName("test@lumen.com");

    ResponseEntity<CustomStatusResponse> userCreatedResponse = new ResponseEntity<>(
        new CustomStatusResponse("Ok", HttpStatus.CREATED), HttpStatus.CREATED);

    given(profileService.getCreateUserRequestBody(ArgumentMatchers.anyString())).willReturn(createUserRequest);
    doReturn(userCreatedResponse).when(userService).createUserInApigee(createUserRequest);

    //when
    MvcResult mvcResult = mockMvc
        .perform(post("/v1/createuser").contentType(MediaType.APPLICATION_JSON)
            .header("authorization", "abcd"))
        .andExpect(status().isCreated()).andDo(MockMvcResultHandlers.print()).andReturn();

    //then
    assertNotNull(mvcResult.getResponse().getContentAsString());
  }

}
