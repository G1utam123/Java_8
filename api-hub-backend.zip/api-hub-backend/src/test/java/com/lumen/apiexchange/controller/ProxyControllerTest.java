package com.lumen.apiexchange.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.model.ApplicationKey;
import com.lumen.apiexchange.model.BuildDeployResult;
import com.lumen.apiexchange.model.InputApiRequest;
import com.lumen.apiexchange.model.ProxyRequest;
import com.lumen.apiexchange.model.snow.ServiceNowRequest;
import com.lumen.apiexchange.service.ApiAuthzService;
import com.lumen.apiexchange.service.ProfileService;
import com.lumen.apiexchange.service.ProxyService;
import com.lumen.apiexchange.service.ServiceNowService;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.*;

import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = { ProxyController.class }) 
@AutoConfigureMockMvc(addFilters = false)
class ProxyControllerTest {

  @Autowired
  private MockMvc mockMvc;

  @MockBean
  private ProxyService proxyService;

  @MockBean
  private ProfileService profileService;

  @MockBean
  private ApiAuthzService apiAuthzService;

  @MockBean
  private ServiceNowService serviceNowService;

  @MockBean
  SecurityContext securityContext;

  public static JwtAuthenticationToken getMockJwtToken(String subject, String claim, String claimValue) {
    final Jwt jwt = Jwt.withTokenValue("token")
        .header("alg", "none")
        .claim(claim, claimValue)
        .subject(subject)
        .build();
    final Collection<GrantedAuthority> authorities = Collections.EMPTY_LIST;
    return new JwtAuthenticationToken(jwt, authorities);
  }

  static ServiceNowRequest createServiceNowRequest(InputApiRequest proxyRequest){
    ServiceNowRequest serviceNowRequest = new ServiceNowRequest();
    serviceNowRequest.setElementType(proxyRequest.getElementType());
    serviceNowRequest.setElementName(proxyRequest.getMalId());
    serviceNowRequest.setAdmins(proxyRequest.getAdmins());
    serviceNowRequest.setOwners(proxyRequest.getOwners());
    return serviceNowRequest;
  }

  private BuildDeployResult createBuildDeployResult () {
    BuildDeployResult buildDeployResult = new BuildDeployResult();
    buildDeployResult = BuildDeployResult.builder()
        .proxy("/tax1/v1/tax2/resourceName")
        .guid("guid")
        .proxyBuiltInEnvironments(new ArrayList<>())
        .proxyDeployedToEnvironments(new ArrayList<>())
        .proxyNotBuiltInEnvironments(new ArrayList<>())
        .proxyNotDeployedToEnvironments(new ArrayList<>())
        .build();

    buildDeployResult.getProxyBuiltInEnvironments().add("dev1");
    buildDeployResult.getProxyDeployedToEnvironments().add("dev1");
    buildDeployResult.getProxyNotBuiltInEnvironments().add("dev2");
    buildDeployResult.getProxyNotDeployedToEnvironments().add("dev2");
    
    return buildDeployResult;
  }

  @Test
  public void getTaxonomiesTest() throws Exception {
    String uri = "/v1/taxonomies";
    ProxyRequest proxyRequest = new ProxyRequest();
    List<String> authList = new ArrayList<String>();
    Mockito.when(proxyService.getTaxonomies()).thenReturn(authList);

    MvcResult mvcResult = this.mockMvc.perform(get(uri).contentType(MediaType.APPLICATION_JSON_UTF8)
        .content(new ObjectMapper().writeValueAsString(proxyRequest))).andExpect(status().isOk()).andReturn();

    assertEquals(200, mvcResult.getResponse().getStatus());
  }

  @Test
  public void getApplicationKeysTest() throws Exception {
    String uri = "/v1/applicationKeys";
    ProxyRequest proxyRequest = new ProxyRequest();
    List<ApplicationKey> applicationKeyList = new ArrayList<ApplicationKey>();
    Mockito.when(proxyService.getApplicationKeys()).thenReturn(applicationKeyList);

    MvcResult mvcResult = this.mockMvc.perform(get(uri).contentType(MediaType.APPLICATION_JSON_UTF8)
        .content(new ObjectMapper().writeValueAsString(proxyRequest))).andExpect(status().isOk()).andReturn();

    assertEquals(200, mvcResult.getResponse().getStatus());
  }

  @Test
  public void proxyBuildDeploy_Test() throws Exception {
    
  //given
    given(securityContext.getAuthentication())
      .willReturn(getMockJwtToken("test", "email", "test@lumen.com"));
    SecurityContextHolder.setContext(securityContext);
    Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    String guid = UUID.randomUUID().toString();

    Mockito.when(proxyService.postProxyRequest(ArgumentMatchers.any(), eq(jwt))).thenReturn(createBuildDeployResult());

    //when-then
    this.mockMvc.perform(post("/v1/postProxyBuildDeploy").contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(new InputApiRequest())))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.guid", is(createBuildDeployResult().getGuid())))
            .andExpect(jsonPath("$.proxyBuiltInEnvironments[0]", is("dev1")));
  }

  @Test
  public void proxyBuildDeploy_BadRequest_Test() throws Exception {
    String uri = "/v1/postProxyBuildDeploy";
    InputApiRequest proxyRequest = new InputApiRequest();
    Jwt jwt = null;
    ServiceNowRequest servicenowRequest = createServiceNowRequest(proxyRequest);
    given(serviceNowService.createGroup(servicenowRequest)).willReturn("RIMT1234567");
    Mockito.when(proxyService.postProxyRequest(proxyRequest, jwt)).thenReturn(createBuildDeployResult());

    MvcResult mvcResult = this.mockMvc
        .perform(post(uri).contentType(MediaType.APPLICATION_XML)
            .content(new ObjectMapper().writeValueAsString(proxyRequest)))
        .andExpect(status().isUnsupportedMediaType()).andReturn();

    assertEquals(415, mvcResult.getResponse().getStatus());
  }

  @Test
  void getProxyDetails() throws Exception {
    final String uri = "/v1/apiProxyDetails";
    //final String env = "dev1";
    InputApiRequest inputApiRequest = new InputApiRequest();
    inputApiRequest.setEnv("dev1");
    
    List<ApiMediatedResource> mediatedResources = new ArrayList<>();
    ApiMediatedResource mediatedResource = new ApiMediatedResource();
    mediatedResource.setServiceType("test");
    mediatedResources.add(mediatedResource);

    given(securityContext.getAuthentication())
      .willReturn(getMockJwtToken("test", "email", "test@lumen.com"));
    SecurityContextHolder.setContext(securityContext);

    Mockito.when(proxyService.getApiProxies(inputApiRequest)).thenReturn(mediatedResources);
    Mockito.when(profileService.getEmailFromProfile(any(Jwt.class))).thenReturn("test@lumen.com");
    Mockito.when(apiAuthzService.isUserAnApiOwner("test@lumen.com", mediatedResource)).thenReturn(true);

    MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
    params.put("env", Collections.singletonList("dev1"));

//    this.mockMvc.perform(get(uri).contentType(MediaType.APPLICATION_XML).params(params))
//        .andExpect(status().isOk())
//        .andExpect(jsonPath("$[0].allowMigration", is(true)));
    
  this.mockMvc.perform(get(uri).contentType(MediaType.APPLICATION_XML).params(params))
  .andExpect(status().isOk());

  }

  @Test
  void getProxyEnvironments() throws Exception {
    final String uri = "/v1/apiEnvironments";
    String resourceGuid = "myTestGuid";

    List<ApiMediatedResource> mediatedResources = new ArrayList<>();
    ApiMediatedResource mediatedResource = new ApiMediatedResource();
    mediatedResource.setServiceType("test");
    mediatedResources.add(mediatedResource);

    Mockito.when(proxyService.getApiProxyEnvDetails(resourceGuid)).thenReturn(mediatedResources);

    MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
    params.put("resourceGuid", Collections.singletonList("myTestGuid"));

    MvcResult mvcResult = this.mockMvc.perform(get(uri).contentType(MediaType.APPLICATION_XML).params(params))
        .andExpect(status().isOk()).andReturn();
  }

}
