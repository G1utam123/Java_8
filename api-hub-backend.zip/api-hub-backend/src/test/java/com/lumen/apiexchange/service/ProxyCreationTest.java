package com.lumen.apiexchange.service;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo;
import static com.lumen.apiexchange.util.FeatureFlags.FF_SNOW_AUTHZ_ENABLED;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

import com.lumen.apiexchange.IntegrationTestBase;
import com.lumen.apiexchange.model.InputApiRequest;
import com.lumen.apiexchange.model.snow.ServiceNowRequest;
import com.lumen.apiexchange.repository.AuditTrailRepository;
import com.lumen.apiexchange.repository.OwnershipRepository;
import dev.openfeature.contrib.providers.envvar.EnvVarProvider;
import dev.openfeature.sdk.FeatureProvider;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.context.annotation.Bean;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest({"spring.main.allow-bean-definition-overriding=true"})
@ActiveProfiles("it")
@AutoConfigureWireMock(port = 0)
public class ProxyCreationTest extends IntegrationTestBase {

  @Autowired
  ProxyService proxyService;

  @MockBean
  EmailService emailService;


  @Autowired
  AuditTrailRepository auditTrailRepository;

  @Autowired
  OwnershipRepository ownershipRepo;

  @MockBean
  SecurityContext securityContext;

  @MockBean
  BuildDeployServiceImpl buildDeployServiceImpl;

  @TestConfiguration
  public static class OverrideFeatureFlags {
    @Bean
    public FeatureProvider featureFlagsProvider() {
      return new EnvVarProvider(flag -> flag.equals(FF_SNOW_AUTHZ_ENABLED) ? "true" : "false");
    }

  }

  private String createGroupUrl =  "/api/sn_sc/servicecatalog/items/457f880fdbf6670002fdd2984b9619bf/order_now";

  private String getRitmUrl =  "/api/now/table/sc_req_item?request=68b4807f1b47ad54fba021b3b24bcb1b";

  private String getUserSysIdUrl = "/api/now/table/sys_user?u_cuid=ad22342";


  static Jwt getMockJwtToken(String subject, String claim, String claimValue) {
    final Jwt jwt = Jwt.withTokenValue("token")
        .header("alg", "none")
        .claim(claim, claimValue)
        .subject(subject)
        .build();
    return jwt;
  }

  static ServiceNowRequest createServiceNowRequest(InputApiRequest proxyRequest) {
    ServiceNowRequest serviceNowRequest = new ServiceNowRequest();
    serviceNowRequest.setElementType(proxyRequest.getElementType());
    serviceNowRequest.setElementName(proxyRequest.getMalId());
    serviceNowRequest.setAdmins(proxyRequest.getAdmins());
    serviceNowRequest.setOwners(proxyRequest.getOwners());
    return serviceNowRequest;
  }

  @Test
  void shouldCreateProxyAndSaveAuditTrail() throws Exception {

    List<String> admins = Arrays.asList("admin1", "admin2", "admin3");
    List<String> owners = Arrays.asList("owner1", "owner2", "owner3");
    String requester = "ad22342";

    //given
    InputApiRequest proxyRequest = new InputApiRequest();
    proxyRequest.setVersion("v1");
    proxyRequest.setMalId("APIGEE");
    proxyRequest.setOwningAppAppkey("test");
    proxyRequest.setDev1EndpointHostname("https://test.com");
    proxyRequest.setResourceName("MyTestProxy");
    proxyRequest.setTaxonomy("ESP/ServiceTest");
    proxyRequest.setRequestorEmail("test@lumen.com");
    proxyRequest.setAdmins(admins);
    proxyRequest.setOwners(owners);
    proxyRequest.setCreatedBy(requester);
    proxyRequest.setElementType("proxy");

    stubFor(post(urlEqualTo(createGroupUrl))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("servicenow-response-to-create-group.json")
            .withHeader("Content-Type", "application/json")));

    stubFor(get(urlEqualTo(getRitmUrl))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("servicenow-response-to-Get-Ritm.json")
            .withHeader("Content-Type", "application/json")));


    Jwt jwt = getMockJwtToken("test", "email", "test@lumen.com");

    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        //.withHeader("X-Level3-Application-Key", containing("APPKEY736482021062922182314937525"))
        .withHeader("X-Username", containing("apigee"))
        .withQueryParam("resourceTaxonomy", equalTo(proxyRequest.getTaxonomy()))
        .withQueryParam("resourceName", equalTo(proxyRequest.getResourceName()))
        .withQueryParam("version", equalTo(proxyRequest.getVersion()))
        .willReturn(aResponse()
            .withStatus(200)
            .withBody("OK")
            .withHeader("Content-Type", "application/json")));

    stubFor(post(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing(proxyRequest.getRequestorEmail()))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-migrate-build-call-response.json")
            .withHeader("Content-Type", "application/json")));

    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/taxonomy"))
        .withHeader("X-Application-Key", containing("APPKEY966252019031223364839633907"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-get-taxonomies-response.json")
            .withHeader("Content-Type", "application/json")));

    stubFor(get(urlEqualTo(getUserSysIdUrl))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("servicenow-response-get-user-sysid.json")
            .withHeader("Content-Type", "application/json")));

    given(securityContext.getAuthentication())
        .willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);

    given(buildDeployServiceImpl.getEnv("host"))
        .willReturn("dev1");

    //when
    proxyService.postProxyRequest(proxyRequest, jwt);

    //then
    assertThat(auditTrailRepository.findAll()).hasSize(1);
    assertThat(ownershipRepo.findAll()).hasSize(1);
  }

  public static JwtAuthenticationToken getMockJwtToken(String subject) {
    final Jwt jwt = Jwt.withTokenValue("token")
        .header("alg", "none")
        .subject(subject)
        .build();
    final Collection<GrantedAuthority> authorities = Collections.EMPTY_LIST;
    return new JwtAuthenticationToken(jwt, authorities);
  }
}
