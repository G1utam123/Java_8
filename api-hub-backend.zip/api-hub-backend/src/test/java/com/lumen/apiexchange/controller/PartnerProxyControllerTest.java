package com.lumen.apiexchange.controller;

import static org.assertj.core.api.AssertionsForClassTypes.assertThatExceptionOfType;
import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lumen.apiexchange.api.partner.model.BasicAuth;
import com.lumen.apiexchange.api.partner.model.OAuth20;
import com.lumen.apiexchange.api.partner.model.PartnerEndpoint;
import com.lumen.apiexchange.api.partner.model.PartnerEndpoint.EnvironmentEnum;
import com.lumen.apiexchange.api.partner.model.PartnerProxy;
import com.lumen.apiexchange.exception.ForbiddenException;
import com.lumen.apiexchange.exception.PartnerProxyAddToProductException;
import com.lumen.apiexchange.service.PartnerProxyService;
import com.lumen.apiexchange.service.ProfileService;
import com.lumen.apiexchange.service.UserAuthorizationService;
import java.util.Collection;
import java.util.Collections;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.NestedServletException;

@WebMvcTest(controllers = { PartnerProxyController.class }) 
@AutoConfigureMockMvc(addFilters = false)
class PartnerProxyControllerTest {

  @Autowired
  private MockMvc mockMvc;

  @MockBean
  private PartnerProxyService partnerProxyService;

  @MockBean
  private UserAuthorizationService userAuthorizationService;

  @MockBean
  private ProfileService profileService;

  @MockBean
  SecurityContext securityContext;

  protected static final Logger log = LoggerFactory.getLogger(PartnerProxyController.class);

  static JwtAuthenticationToken getMockJwtToken(String subject) {
    String role = "API-HUB Partner Proxy";
    return getMockJwtTokenWithRole(subject, role);
  }
  
  static JwtAuthenticationToken getMockJwtTokenWithRole(String subject, String role) {
    final Jwt jwt = Jwt.withTokenValue("token")
        .header("alg", "none")
        .subject(subject)
        .claim("role", role)
        .build();
    final Collection<GrantedAuthority> authorities = Collections.EMPTY_LIST;
    return new JwtAuthenticationToken(jwt, authorities);
  }
  
  @Test
  void shouldCreatePartnerProxy() throws Exception {

    //given
    PartnerProxy partnerProxyReq = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "oauth_client_form");
    given(securityContext.getAuthentication())
        .willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);
    Jwt  jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    //when    
    Mockito.when(partnerProxyService.createProxy(partnerProxyReq, jwt)).thenReturn(partnerProxyReq);

    //Then    
    MvcResult mvcResult = this.mockMvc.perform(post("/partnerProxy").contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(partnerProxyReq))).andExpect(status().isAccepted()).andReturn();
    
  }

  @Test
  void shouldCreatePartnerProxyBasicAut() throws Exception {

    //given
    PartnerProxy partnerProxyReq = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "basic_auth");
    given(securityContext.getAuthentication())
        .willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);
    Jwt  jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    //when    
    Mockito.when(partnerProxyService.createProxy(partnerProxyReq, jwt)).thenReturn(partnerProxyReq);

    //Then    
    MvcResult mvcResult = this.mockMvc.perform(post("/partnerProxy").contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(partnerProxyReq))).andExpect(status().isAccepted()).andReturn();
    
  }

  @Test
  void shouldGetPartnerProxy() throws Exception {

    //given
    given(securityContext.getAuthentication())
        .willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);
    String proxyGateway = "ESP";
    String environment = "TEST1";
    UUID proxyGuid = UUID.randomUUID();
    PartnerProxy partnerProxy = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "basic_auth");
    String proxyUrl = "/partnerProxy/proxyGateway/{proxyGateway}/environment/{environment}/proxies/{proxyGuid}";

    //when    
    Mockito.when(partnerProxyService.getPartnerProxy(proxyGateway, environment, proxyGuid))
        .thenReturn(partnerProxy);

    //Then 
    MvcResult mvcResult = this.mockMvc.perform(get(proxyUrl, proxyGateway, environment, proxyGuid.toString())
        .contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(partnerProxy))).andExpect(status().isOk()).andReturn();
    
  }

  @Test
  void shouldDeletePartnerProxy() throws Exception {

    //given
    given(securityContext.getAuthentication())
        .willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);
    String proxyGateway = "ESP";
    String environment = "TEST1";
    UUID proxyGuid = UUID.randomUUID();
    String proxyUrl = "/partnerProxy/proxyGateway/{proxyGateway}/environment/{environment}/proxies/{proxyGuid}";

    //when    
    Mockito.doNothing().when(partnerProxyService).deletePartnerProxy(proxyGateway, environment, proxyGuid);

    //Then    
    this.mockMvc.perform(delete(proxyUrl, proxyGateway, environment, proxyGuid.toString())
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isNoContent());

  }

  @Test
  void shouldThrowBadInputForCreatePartnerProxy() throws Exception {

    //given
    given(securityContext.getAuthentication())
        .willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);
    Jwt  jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    PartnerProxy partnerProxyReq = new PartnerProxy();
    PartnerProxy partnerProxyReq2 = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "");


    //when    
    Mockito.when(partnerProxyService.createProxy(partnerProxyReq, jwt)).thenReturn(partnerProxyReq);
    Mockito.when(partnerProxyService.createProxy(partnerProxyReq2, jwt)).thenReturn(partnerProxyReq2);

    //Then    
    this.mockMvc.perform(post("/partnerProxy").contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(partnerProxyReq))).andExpect(status()
        .is4xxClientError()).andReturn();
    this.mockMvc.perform(post("/partnerProxy").contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(partnerProxyReq2))).andExpect(status()
        .is4xxClientError()).andReturn();
    
  }

  @Test
  void shouldThrowForbiddenForCreatePartnerProxy() throws Exception {

    //given
    given(securityContext.getAuthentication())
        .willReturn(getMockJwtTokenWithRole("test", "INVALID_ROLE"));
    SecurityContextHolder.setContext(securityContext);
    String partnerName = "PartnerABC";
    String partnerResource = "partnerResource";
    String proxyVersion = "v1";
    String environment = "TEST1";
    String proxyGateway = "ESP";
    MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
    params.add("partnerName", partnerName);
    params.add("partnerResource", partnerResource);
    params.add("proxyVersion", proxyVersion);
    params.add("environment", environment);
    params.add("proxyGateway", proxyGateway);
    PartnerProxy partnerProxyReq = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "basic_auth");
    Jwt  jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    //When    
    Mockito.doThrow(ForbiddenException.class).when(userAuthorizationService).isAuthorizedToUsePartnerProxy(jwt);

    //Then    
    this.mockMvc.perform(post("/partnerProxy").contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(partnerProxyReq))).andExpect(status()
        .is4xxClientError()).andReturn();
    this.mockMvc.perform(put("/partnerProxy").contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(partnerProxyReq))).andExpect(status()
        .is4xxClientError()).andReturn();
   
  }

  @Test
  void shouldThrowForbiddenForGetAndDeletePartnerProxy() throws Exception {

    //given
    given(securityContext.getAuthentication())
        .willReturn(getMockJwtTokenWithRole("test", "INVALID_ROLE"));
    SecurityContextHolder.setContext(securityContext);
    Jwt  jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    String proxyGateway = "ESP";
    String environment = "TEST1";
    UUID proxyGuid = UUID.randomUUID();
    String proxyUrl = "/partnerProxy/proxyGateway/{proxyGateway}/environment/{environment}/proxies/{proxyGuid}";

    //When    
    Mockito.doThrow(ForbiddenException.class).when(userAuthorizationService).isAuthorizedToUsePartnerProxy(jwt);

    //Then    
    this.mockMvc.perform(get(proxyUrl, proxyGateway, environment, proxyGuid.toString())
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isForbidden()).andReturn();
    this.mockMvc.perform(delete(proxyUrl, proxyGateway, environment, proxyGuid.toString())
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isForbidden()).andReturn();

    this.mockMvc.perform(get("/partnerProxy/testUserAuth")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isForbidden()).andReturn();
   
  }

  private static PartnerProxy buildTestPartnerProxyRequest(String partnerName, String partnerResource, 
      String proxyVersion, EnvironmentEnum env, String endpointHostname, String endpointPath, String auth) {
    
    PartnerProxy proxy = new PartnerProxy();
    proxy.setPartnerName(partnerName);
    proxy.setPartnerResource(partnerResource);
    proxy.setProxyVersion(proxyVersion);
    proxy.setProxyOwnerAppKey("APPKEY12345678901234567890");
    proxy.setProxyOwnerSysgen("SYSGEN787489521");
    proxy.setProxyOwnerEmail("jeremy.eagleman@lumen.com");
    proxy.setProxyGateway(PartnerProxy.ProxyGatewayEnum.ESP);
    proxy.setProxyGuid(UUID.randomUUID());
    PartnerEndpoint partnerEndpoint = new PartnerEndpoint();
    partnerEndpoint.setEnvironment(env);
    partnerEndpoint.setEndpointHostname(endpointHostname);
    partnerEndpoint.setEndpointPath(endpointPath);
    OAuth20 oauth2 = new OAuth20();
    BasicAuth basicAuth = new BasicAuth();
    
    if (auth.equals("oauth_client_form")) {
      oauth2.setOauthGrantType(OAuth20.OauthGrantTypeEnum.CLIENT_CREDENTIALS);
      oauth2.setOauthGrantLocation(OAuth20.OauthGrantLocationEnum.FORM_PARAM);
      oauth2.setOauthTokenServiceHost("https://oauthtokenhostname");
      oauth2.setOauthTokenServicePath("/oauth/v1/token");
      oauth2.setOauthClientIdLocation(OAuth20.OauthClientIdLocationEnum.FORM_PARAM);
      oauth2.setOauthClientId("oauth_clinet_id");
      oauth2.setOauthClientSecret("oauth_client_secret");
      partnerEndpoint.setAuthentication(oauth2);
      
    } else if (auth.equals("oauth_client_query")) {
      oauth2.setOauthGrantType(OAuth20.OauthGrantTypeEnum.CLIENT_CREDENTIALS);
      oauth2.setOauthGrantLocation(OAuth20.OauthGrantLocationEnum.QUERY_PARAM);
      oauth2.setOauthTokenServiceHost("https://oauthtokenhostname");
      oauth2.setOauthTokenServicePath("/oauth/v1/token");
      oauth2.setOauthClientIdLocation(OAuth20.OauthClientIdLocationEnum.QUERY_PARAM);
      oauth2.setOauthClientId("oauth_clinet_id");
      oauth2.setOauthClientSecret("oauth_client_secret");
      partnerEndpoint.setAuthentication(oauth2);
      
    } else if (auth.equals("basic_auth")) {
      basicAuth.setBasicAuthUser("ba_user");
      basicAuth.setBasicAuthPassword("ba_password");
      partnerEndpoint.setAuthentication(basicAuth);
      
    }
    
    proxy.setPartnerEndpoint(partnerEndpoint);
    return proxy;
  
  }
  
  @Test
  void shouldUpdatePartnerProxy() throws Exception {

    //given
    given(securityContext.getAuthentication())
        .willReturn(getMockJwtTokenWithRole("test", "INVALID_ROLE"));
    SecurityContextHolder.setContext(securityContext);
    String proxyGateway = "ESP";
    String environment = "TEST1";
    UUID proxyGuid = UUID.randomUUID();
    String proxyUrl = "/partnerProxy/proxyGateway/{proxyGateway}/environment/{environment}/proxies/{proxyGuid}";
    
    PartnerProxy partnerProxyReq = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "oauth_client_form");
    partnerProxyReq.setProxyGuid(proxyGuid);
    
    //when    
    Mockito.when(partnerProxyService.updateProxy(partnerProxyReq, proxyGateway, environment, proxyGuid))
        .thenReturn(partnerProxyReq);

    //Then    
    this.mockMvc.perform(put(proxyUrl, proxyGateway, environment, proxyGuid.toString())
        .contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(partnerProxyReq))).andExpect(status().isOk()).andReturn();
    
  }
  
  @Test
  void shouldThrowBadInputForUpdatePartnerProxy() throws Exception {

    //given
    given(securityContext.getAuthentication())
        .willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);
    String proxyGateway = "ESP";
    String environment = "TEST1";
    UUID proxyGuid = UUID.randomUUID();
    String proxyUrl = "/partnerProxy/proxyGateway/{proxyGateway}/environment/{environment}/proxies/{proxyGuid}";
    PartnerProxy partnerProxyReq = new PartnerProxy();
    PartnerProxy partnerProxyReq2 = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "");


    //when    
    Mockito.when(partnerProxyService.updateProxy(partnerProxyReq, proxyGateway, environment, proxyGuid))
        .thenReturn(partnerProxyReq);
    Mockito.when(partnerProxyService.updateProxy(partnerProxyReq2, proxyGateway, environment, proxyGuid))
        .thenReturn(partnerProxyReq2);

    //Then    
    this.mockMvc.perform(put(proxyUrl, proxyGateway, environment, proxyGuid.toString())
        .contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(partnerProxyReq))).andExpect(status()
        .is4xxClientError()).andReturn();
    this.mockMvc.perform(put(proxyUrl, proxyGateway, environment, proxyGuid.toString())
        .contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(partnerProxyReq2))).andExpect(status()
        .is4xxClientError()).andReturn();
    this.mockMvc.perform(put(proxyUrl, "XXX", environment, proxyGuid.toString())
        .contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(partnerProxyReq2))).andExpect(status()
        .is4xxClientError()).andReturn();
    this.mockMvc.perform(put(proxyUrl, proxyGateway, "XXXX", proxyGuid.toString())
        .contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(partnerProxyReq2))).andExpect(status()
        .is4xxClientError()).andReturn();

  }

  @Test
  void shouldThrowExceptionsToTestAppDynamics() throws Exception {

    //given
    given(securityContext.getAuthentication())
        .willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);
    String url = "/partnerProxy/testAppDynamics";

    //when-then    
    MultiValueMap<String, String> productParams = new LinkedMultiValueMap<>();
    productParams.put("exceptionToThrow", Collections.singletonList(null));
    this.mockMvc.perform(get(url).contentType(MediaType.APPLICATION_JSON).params(productParams))
        .andExpect(status().isOk());

    MultiValueMap<String, String> productParams1 = new LinkedMultiValueMap<>();
    productParams1.put("exceptionToThrow", Collections.singletonList("NoException"));
    this.mockMvc.perform(get(url).contentType(MediaType.APPLICATION_JSON).params(productParams1))
        .andExpect(status().isOk());

    MultiValueMap<String, String> productParams2 = new LinkedMultiValueMap<>();
    productParams2.put("exceptionToThrow", Collections.singletonList("PartnerProxyAddToProductException"));
    productParams2.put("optionalReason", Collections.singletonList("An optional error reason"));
    productParams2.put("optionalMessage", Collections.singletonList("An optional error message"));
    assertThatExceptionOfType(NestedServletException.class)
        .isThrownBy(() -> {
          this.mockMvc.perform(get(url).contentType(MediaType.APPLICATION_JSON).params(productParams2));
        })
        .withMessageContaining("PartnerProxyAddToProductException");
    
    
    MultiValueMap<String, String> buildParams = new LinkedMultiValueMap<>();
    buildParams.put("exceptionToThrow", Collections.singletonList("PartnerProxyBuildException"));
    assertThatExceptionOfType(NestedServletException.class)
        .isThrownBy(() -> {
          this.mockMvc.perform(get(url).contentType(MediaType.APPLICATION_JSON).params(buildParams));
        })
        .withMessageContaining("PartnerProxyBuildException");

    MultiValueMap<String, String> deployParams = new LinkedMultiValueMap<>();
    deployParams.put("exceptionToThrow", Collections.singletonList("PartnerProxyDeployException"));
    assertThatExceptionOfType(NestedServletException.class)
        .isThrownBy(() -> {
          this.mockMvc.perform(get(url).contentType(MediaType.APPLICATION_JSON).params(deployParams));
        })
        .withMessageContaining("PartnerProxyDeployException");

  }

  @Test
  void shouldThrowExceptionsToTestAppDynamicsPost() throws Exception {


    //given
    given(securityContext.getAuthentication())
        .willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);
    String url = "/partnerProxy/testAppDynamics";

    //when-then    
    MultiValueMap<String, String> productParams = new LinkedMultiValueMap<>();
    productParams.put("exceptionToThrow", Collections.singletonList(null));
    this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON).params(productParams))
        .andExpect(status().is4xxClientError());

    MultiValueMap<String, String> productParams1 = new LinkedMultiValueMap<>();
    productParams1.put("exceptionToThrow", Collections.singletonList("NoException"));
    this.mockMvc.perform(post(url, "NoException")
        .contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString("")))
        .andExpect(status().isOk());

    
    PartnerProxy partnerProxyReq = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "");
    String message = String.format("Error adding new proxy to Apigee. Partner Proxy Request: %n%s", partnerProxyReq);
    MultiValueMap<String, String> productParams2 = new LinkedMultiValueMap<>();
    productParams2.put("exceptionToThrow", Collections.singletonList("PartnerProxyAddToProductException"));
    assertThatExceptionOfType(NestedServletException.class)
        .isThrownBy(() -> {
          this.mockMvc.perform(post(url, "PartnerProxyAddToProductException")
              .contentType(MediaType.APPLICATION_JSON)
              .params(productParams2)
              .content(new ObjectMapper().writeValueAsString(message)));
        })
        .withMessageContaining("PartnerProxyAddToProductException")
        .withMessageContaining("proxyGuid: " + partnerProxyReq.getProxyGuid())
        .withMessageContaining("partnerName: PartnerABC");
   
    
    MultiValueMap<String, String> buildParams = new LinkedMultiValueMap<>();
    buildParams.put("exceptionToThrow", Collections.singletonList("PartnerProxyBuildException"));
    assertThatExceptionOfType(NestedServletException.class)
        .isThrownBy(() -> {
          this.mockMvc.perform(get(url).contentType(MediaType.APPLICATION_JSON).params(buildParams));
        })
        .withMessageContaining("PartnerProxyBuildException");

    MultiValueMap<String, String> deployParams = new LinkedMultiValueMap<>();
    deployParams.put("exceptionToThrow", Collections.singletonList("PartnerProxyDeployException"));
    assertThatExceptionOfType(NestedServletException.class)
        .isThrownBy(() -> {
          this.mockMvc.perform(get(url).contentType(MediaType.APPLICATION_JSON).params(deployParams));
        })
        .withMessageContaining("PartnerProxyDeployException");

  }
}