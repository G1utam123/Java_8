package com.lumen.apiexchange.client;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

import com.github.tomakehurst.wiremock.matching.StringValuePattern;
import com.lumen.apiexchange.IntegrationTestBase;
import com.lumen.apiexchange.model.myapps.ProfileDetailsResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("it")
@AutoConfigureWireMock(port = 0)
class PortalFrameworkAuthClientTest extends IntegrationTestBase {

  @Autowired
  private PortalFrameworkAuthClient pfAuthClient;

  @Test
  void shouldGetProfileDetails() {

    //given
    stubFor(get(urlEqualTo("/Enterprise/v1/Security/portalIdentity/profile"))
        .withHeader("Authorization", containing("Bearer ey..."))
        .willReturn(aResponse()
            .withHeader("Content-Type", "application/json")
            .withBodyFile("po-auth-identity-profile.json")));

    //when
    ProfileDetailsResponse profileDetails = pfAuthClient.getProfileDetails("ey...");

    //then
    assertThat(profileDetails.getEmail()).isEqualTo("Santiago.Cardin@lumen.com");
    assertThat(profileDetails.getDetails().getFirstName()).isEqualTo("Santiago");
  }

}