package com.lumen.apiexchange.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lumen.apiexchange.model.FeedbackMessage;
import com.lumen.apiexchange.service.EmailService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(controllers = {FeedbackController.class})
@AutoConfigureMockMvc(addFilters = false)
class FeedbackControllerTest {

  @Autowired
  private MockMvc mockMvc;

  @MockBean
  private EmailService emailService;

  @Test
  void shouldAcceptFeedbackEmail() throws Exception {

    //given
    FeedbackMessage feedbackMessage = new FeedbackMessage();
    feedbackMessage.setEmail("test@lumen.com");
    feedbackMessage.setMessage("Great tool!");
    feedbackMessage.setFirstName("John");
    feedbackMessage.setLastName("Doe");

    Mockito.doNothing().when(emailService).sendFeedbackReceivedEmail(feedbackMessage);

    //when-then
    this.mockMvc.perform(post("/v1/feedback").contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(feedbackMessage))).andExpect(status().isAccepted());

  }

  @Test
  void shouldRejectIfEmailNotProvided() throws Exception {

    //given
    FeedbackMessage feedbackMessage = new FeedbackMessage();
    feedbackMessage.setMessage("Great tool!");
    feedbackMessage.setFirstName("John");
    feedbackMessage.setLastName("Dow");

    Mockito.doNothing().when(emailService).sendFeedbackReceivedEmail(feedbackMessage);

    //when-then
    this.mockMvc.perform(post("/v1/feedback").contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(feedbackMessage))).andExpect(status().is4xxClientError());

  }

  @Test
  void shouldRejectIfEmailNotValid() throws Exception {

    //given
    FeedbackMessage feedbackMessage = new FeedbackMessage();
    feedbackMessage.setMessage("Great tool!");
    feedbackMessage.setFirstName("John");
    feedbackMessage.setLastName("Doe");
    feedbackMessage.setEmail("this-is-not-a-real-email");

    Mockito.doNothing().when(emailService).sendFeedbackReceivedEmail(feedbackMessage);

    //when-then
    this.mockMvc.perform(post("/v1/feedback").contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(feedbackMessage))).andExpect(status().is4xxClientError());

  }
}