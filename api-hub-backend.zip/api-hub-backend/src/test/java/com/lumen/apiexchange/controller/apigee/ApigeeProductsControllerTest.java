package com.lumen.apiexchange.controller.apigee;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lumen.apiexchange.model.apigee.ApigeeProduct;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.Access;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.AccessLocation;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.Planet;
import com.lumen.apiexchange.model.apigee.ApigeeProductRequest;
import com.lumen.apiexchange.model.apigee.ApigeeProductRequest.ApprovalType;
import com.lumen.apiexchange.model.apigee.ApigeeProductResponse;
import com.lumen.apiexchange.model.apigee.Attribute;
import com.lumen.apiexchange.service.ProfileService;
import com.lumen.apiexchange.service.apigee.ApigeeProductsService;
import com.lumen.apiexchange.service.apigee.ApigeeProductsService;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;

@WebMvcTest(controllers = { ApigeeProductsController.class }) 
@AutoConfigureMockMvc(addFilters = false)
class ApigeeProductsControllerTest {

  @Autowired
  private MockMvc mockMvc;

  @MockBean
  private ApigeeProductsService apigeeProductsService;

  @MockBean
  private ProfileService profileService;

  @MockBean
  SecurityContext securityContext;

  protected static final Logger log = LoggerFactory.getLogger(ApigeeProductsService.class);

  static JwtAuthenticationToken getMockJwtToken(String subject) {
    final Jwt jwt = Jwt.withTokenValue("token")
        .header("alg", "none")
        .subject(subject)
        .build();
    final Collection<GrantedAuthority> authorities = Collections.EMPTY_LIST;
    return new JwtAuthenticationToken(jwt, authorities);
  }
  
  @Test
  void shouldReturnApigeeProductList() throws Exception {
    
    //given
    ApigeeProductResponse productList = new ApigeeProductResponse();
    productList.setApiProduct(new ArrayList<ApigeeProduct>());
    ApigeeProduct apigeeProduct = buildTestApigeeProduct("1", "manual");
    productList.getApiProduct().add(apigeeProduct);
    apigeeProduct = buildTestApigeeProduct("2", "manual");
    productList.getApiProduct().add(apigeeProduct);
    
    String planet = "PROD";
    String org = "EXTERNAL";
    String productOwner = "product.owner@lumen.com";

    //when    
    Mockito.when(apigeeProductsService.getProducts(planet, org, productOwner)).thenReturn(productList);

    //then    
    MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
    params.put("planet", Collections.singletonList(planet));
    params.put("internalExternal", Collections.singletonList(org));

    MvcResult mvcResult = this.mockMvc.perform(get("/v1/products/apigee").contentType(MediaType.APPLICATION_JSON)
        .params(params)).andExpect(status().isOk()).andReturn();
    
  }

  @Test
  void shouldReturnApigeeProduct() throws Exception {
    
    //given
    ApigeeProduct apigeeProduct = buildTestApigeeProduct("1", "auto");
    String name = "myProductName1";
    String planet = "PROD";
    String org = "EXTERNAL";

    //when    
    Mockito.when(apigeeProductsService.getProduct(name, planet, org)).thenReturn(apigeeProduct);

    //then    
    MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
    params.put("planet", Collections.singletonList(planet));
    params.put("internalExternal", Collections.singletonList(org));

    MvcResult mvcResult = this.mockMvc.perform(get("/v1/products/apigee/myProductName1")
        .contentType(MediaType.APPLICATION_JSON).params(params)).andExpect(status().isOk()).andReturn();
    
  }

  @Test
  void shouldSaveProduct() throws Exception {

    //given
    AccessLocation accessLocation = AccessLocation.INTERNAL;
    ApprovalType approvalType = ApprovalType.manual;
    Planet planet = Planet.NONPROD; 
    ApigeeProductHubRequest hubProductReq = buildTestApigeeHubProductRequest("1", approvalType, planet, accessLocation);
    ApigeeProduct apigeeProductReq = buildTestApigeeProduct("1", "auto");
    given(securityContext.getAuthentication())
        .willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);


    //when    
    Mockito.when(apigeeProductsService.saveProduct(hubProductReq)).thenReturn(apigeeProductReq);

    //Then    
    MvcResult mvcResult = this.mockMvc.perform(post("/v1/products/apigee").contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(hubProductReq))).andExpect(status().isCreated()).andReturn();
    
  }

  @Test
  void shouldUpdateProduct() throws Exception {

    //given
    given(securityContext.getAuthentication()).willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);
    AccessLocation accessLocation = AccessLocation.INTERNAL;
    ApprovalType approvalType = ApprovalType.manual;
    Planet planet = Planet.NONPROD;
    String userEmail = "product.owner@lumen.com";
    String name = "myProductName1";
    ApigeeProductHubRequest hubProductReq = buildTestApigeeHubProductRequest("1", approvalType, planet, accessLocation);
    ApigeeProduct apigeeProductReq = buildTestApigeeProduct("1", "auto");

    //when    
    Mockito.when(profileService.getEmailFromProfile(any(Jwt.class))).thenReturn(userEmail);
    Mockito.when(apigeeProductsService.updateProduct(name, hubProductReq, userEmail)).thenReturn(apigeeProductReq);

    //Then    
    MvcResult mvcResult = this.mockMvc.perform(put("/v1/products/apigee/myProductName1")
        .contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(hubProductReq))).andExpect(status().isOk()).andReturn();
    
  }

  @Test
  void shouldDeleteProduct() throws Exception {

    //given
    given(securityContext.getAuthentication())
        .willReturn(getMockJwtToken("test"));
    SecurityContextHolder.setContext(securityContext);
    AccessLocation accessLocation = AccessLocation.INTERNAL;
    Planet planet = Planet.NONPROD;
    String userEmail = "product.owner@lumen.com";
    String productName = "myProductName1";

    //when    
    Mockito.when(profileService.getEmailFromProfile(any(Jwt.class))).thenReturn(userEmail);
    Mockito.doNothing().when(apigeeProductsService).deleteProduct(productName, planet.toString(), 
        accessLocation.toString(), userEmail);

    //Then    
    MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
    params.put("planet", Collections.singletonList(planet.toString()));
    params.put("internalExternal", Collections.singletonList(accessLocation.toString()));
    MvcResult mvcResult = this.mockMvc.perform(delete("/v1/products/apigee/" + productName)
        .contentType(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON).params(params)).andExpect(status().is2xxSuccessful()).andReturn();
    
  }

  @Test
  void shouldReturnBadInputForBadPlanetApigee() throws Exception {

    //given
    MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
    params.put("planet", Collections.singletonList("badplanet"));
    params.put("internalExternal", Collections.singletonList("EXTERNAL"));

    //when-then    
    MvcResult mvcResult = this.mockMvc.perform(get("/v1/products/apigee").contentType(MediaType.APPLICATION_JSON)
        .params(params)).andExpect(status().is4xxClientError()).andReturn();
    mvcResult = this.mockMvc.perform(post("/v1/products/apigee").contentType(MediaType.APPLICATION_JSON)
        .params(params)).andExpect(status().is4xxClientError()).andReturn();
    mvcResult = this.mockMvc.perform(put("/v1/products/apigee/anyProductName").contentType(MediaType.APPLICATION_JSON)
        .params(params)).andExpect(status().is4xxClientError()).andReturn();
    mvcResult = this.mockMvc.perform(delete("/v1/products/apigee/anyProductName")
        .contentType(MediaType.APPLICATION_JSON)
        .params(params)).andExpect(status().is4xxClientError()).andReturn();
    
  }

  @Test
  void shouldReturnBadInputForBadInternalOrExternalApigee() throws Exception {

    //given
    MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
    params.put("planet", Collections.singletonList("PROD"));
    params.put("internalExternal", Collections.singletonList("INVALID"));

    //when-then    
    MvcResult mvcResult = this.mockMvc.perform(get("/v1/products/apigee").contentType(MediaType.APPLICATION_JSON)
        .params(params)).andExpect(status().is4xxClientError()).andReturn();
    mvcResult = this.mockMvc.perform(post("/v1/products/apigee").contentType(MediaType.APPLICATION_JSON)
        .params(params)).andExpect(status().is4xxClientError()).andReturn();
    mvcResult = this.mockMvc.perform(put("/v1/products/apigee/anyProductName").contentType(MediaType.APPLICATION_JSON)
        .params(params)).andExpect(status().is4xxClientError()).andReturn();
    mvcResult = this.mockMvc.perform(delete("/v1/products/apigee/anyProductName")
        .contentType(MediaType.APPLICATION_JSON)
        .params(params)).andExpect(status().is4xxClientError()).andReturn();
    
  }

  @Test
  void shouldReturnApigeeProductNotPround() throws Exception {
    
    //given
    String name = "NoProductToFind";
    String planet = "PROD";
    String org = "INTERNAL";
    MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
    params.put("planet", Collections.singletonList(planet));
    params.put("internalExternal", Collections.singletonList(org));
    ApigeeProductHubRequest hubProduct = buildTestApigeeHubProductRequest("1", ApprovalType.manual, 
        Planet.NONPROD, AccessLocation.INTERNAL);
    String userEmail = hubProduct.getProductOwner();

    //when    
    Mockito.doThrow(HttpClientErrorException.class).when(apigeeProductsService).getProduct(name, planet, org);
    ResponseEntity<String> responseGet = new ResponseEntity<String>("404 Not Found",
        HttpStatus.NOT_FOUND);
    Mockito.doThrow(HttpClientErrorException.class).when(apigeeProductsService)
        .updateProduct(name, hubProduct, userEmail);
    ResponseEntity<String> responsePut = new ResponseEntity<String>("404 Not Found",
        HttpStatus.NOT_FOUND);
    Mockito.doThrow(HttpClientErrorException.class).when(apigeeProductsService)
        .deleteProduct(name, userEmail, planet, org);
    ResponseEntity<String> responseDelete = new ResponseEntity<String>("404 Not Found",
        HttpStatus.NOT_FOUND);

    //then    
    MvcResult mvcResult1 = this.mockMvc.perform(get("/v1/products/apigee/myProductName1")
        .contentType(MediaType.APPLICATION_JSON).content(new ObjectMapper().writeValueAsString(responseGet)))
        .andExpect(status().is4xxClientError()).andReturn();
    MvcResult mvcResult2 = this.mockMvc.perform(get("/v1/products/apigee/myProductName1")
        .contentType(MediaType.APPLICATION_JSON).content(new ObjectMapper().writeValueAsString(responsePut)))
        .andExpect(status().is4xxClientError()).andReturn();
    MvcResult mvcResult3 = this.mockMvc.perform(get("/v1/products/apigee/myProductName1")
        .contentType(MediaType.APPLICATION_JSON).content(new ObjectMapper().writeValueAsString(responseDelete)))
        .andExpect(status().is4xxClientError()).andReturn();

  }

  @Test
  void shouldReturnApigeeListProductNotPround() throws Exception {
    
    //given
    String planet = "PROD";
    String org = "INTERNAL";
    String productOwner = "NoProductsToFind";
    MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
    params.put("planet", Collections.singletonList(planet));
    params.put("internalExternal", Collections.singletonList(org));
    params.put("productOwner", Collections.singletonList(productOwner));

    //when    
    Mockito.doThrow(HttpClientErrorException.class).when(apigeeProductsService).getProducts(planet, org, productOwner);
    ResponseEntity<String> responseGet = new ResponseEntity<String>("404 Not Found",
        HttpStatus.NOT_FOUND);

    //then    
    MvcResult mvcResult1 = this.mockMvc.perform(get("/v1/products/apigee")
        .contentType(MediaType.APPLICATION_JSON).content(new ObjectMapper().writeValueAsString(responseGet)))
        .andExpect(status().is4xxClientError()).andReturn();

  }

  private static ApigeeProduct buildTestApigeeProduct(String prodInc, String approvalType) {
    
    ApigeeProduct product = new ApigeeProduct();
    product.setApiResources(new ArrayList<String>(Arrays.asList("/ResourceA" + prodInc, "/ResourceB" + prodInc)));
    product.setApprovalType(approvalType);
    List<Attribute> attributes = new ArrayList<>();
    attributes.add(new Attribute("access", "private"));
    product.setAttributes(attributes);
    product.setCreatedBy("ApiProductsServiceTest");
    product.setCreatedAt((long) Instant.now().getEpochSecond());
    product.setDescription("myDescription" + prodInc);
    product.setDisplayName("myDisplayName" + prodInc);
    product.setEnvironments(new ArrayList<String>(Arrays.asList("Dev" + prodInc, "Test" + prodInc)));
    product.setLastModifiedBy("myLastUpdatedBy" + prodInc);
    product.setLastModifiedAt((long) Instant.now().getEpochSecond());
    product.setName("myProductName" + prodInc);
    product.setProxies(new ArrayList<String>(Arrays.asList("ProxyA-" + prodInc, "ProxyB-" + prodInc)));
    product.setScopes(new ArrayList<String>());

    return product;
  
  }

  private static ApigeeProductHubRequest buildTestApigeeHubProductRequest(String prodInc, ApprovalType approvalType, 
      Planet planet, AccessLocation accessLocation) {
    
    ApigeeProductHubRequest hubProduct = new ApigeeProductHubRequest();
    hubProduct.setAccess(Access.PRIVATE);
    hubProduct.setAccessLocation(accessLocation);
    hubProduct.setPlanet(planet);
    hubProduct.setProductOwner("product.owner@lumen.com");
    
    ApigeeProductRequest product = new ApigeeProductRequest();
    product.setApiResources(new ArrayList<String>(Arrays.asList("/ResourceA" + prodInc, "/ResourceB" + prodInc)));
    product.setApprovalType(approvalType);
    List<Attribute> attributes = new ArrayList<>();
    attributes.add(new Attribute("access", "private"));
    product.setAttributes(attributes);
    product.setDescription("myDescription" + prodInc);
    product.setDisplayName("myDisplayName" + prodInc);
    product.setEnvironments(new ArrayList<String>(Arrays.asList("Dev" + prodInc, "Test" + prodInc)));
    product.setName("myProductName" + prodInc);
    product.setProxies(new ArrayList<String>(Arrays.asList("ProxyA-" + prodInc, "ProxyB-" + prodInc)));
    product.setScopes(new ArrayList<String>());
    hubProduct.setApigeeProductRequest(product);
    return hubProduct;
  
  }
  
}