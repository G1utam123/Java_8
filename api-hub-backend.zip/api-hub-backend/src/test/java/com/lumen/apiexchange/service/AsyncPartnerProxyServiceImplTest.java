package com.lumen.apiexchange.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.AssertionsForClassTypes.assertThatExceptionOfType;
import static org.awaitility.Awaitility.await;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.mock;

import com.lumen.apiexchange.api.partner.model.BasicAuth;
import com.lumen.apiexchange.api.partner.model.OAuth20;
import com.lumen.apiexchange.api.partner.model.PartnerEndpoint;
import com.lumen.apiexchange.api.partner.model.PartnerProxy;
import com.lumen.apiexchange.api.partner.model.PartnerEndpoint.EnvironmentEnum;
import com.lumen.apiexchange.client.ESPClient;
import com.lumen.apiexchange.client.apigee.ApigeeMgmtApiClient;
import com.lumen.apiexchange.config.ApigeeMgmtApiConfigProperties;
import com.lumen.apiexchange.config.MediationResourceConfigProperties;
import com.lumen.apiexchange.config.PartnerProxyConfigProperties;
import com.lumen.apiexchange.exception.ForbiddenException;
import com.lumen.apiexchange.exception.PartnerProxyBuildException;
import com.lumen.apiexchange.exception.PartnerProxyDeployException;
import com.lumen.apiexchange.model.AsyncBuildDeployResult;
import com.lumen.apiexchange.model.BuildDeployResult;
import com.lumen.apiexchange.model.InputApiRequest;
import com.lumen.apiexchange.model.apigee.ApigeeProduct;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.AccessLocation;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.Planet;
import com.lumen.apiexchange.service.apigee.ApigeeEnvironmentsServiceImpl;
import com.lumen.apiexchange.service.apigee.ApigeeProductsService;
import com.lumen.apiexchange.util.BuildHandler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class AsyncPartnerProxyServiceImplTest {

  private AsyncPartnerProxyServiceImpl asyncPartnerProxyServiceImpl;
  private ApigeeMgmtApiConfigProperties apigeeMgmtApiConfigProperties;
  private PartnerProxyConfigProperties partnerProxyConfigProperties;
  private ApigeeMgmtApiClient apigeeMgmtApiClient;
  private EmailBasedAuthzServiceImpl emailBasedAuthzSvc;
  private ApigeeEnvironmentsServiceImpl apigeeEnvService;
  private BuildHandler buildHandler;
  private ApigeeProductsService apigeeProductsService;
  
  @BeforeEach
  void setUp() {
    apigeeMgmtApiConfigProperties = mock(ApigeeMgmtApiConfigProperties.class);
    partnerProxyConfigProperties = mock(PartnerProxyConfigProperties.class);
    apigeeMgmtApiClient = mock(ApigeeMgmtApiClient.class);
    emailBasedAuthzSvc = mock(EmailBasedAuthzServiceImpl.class);
    apigeeEnvService = mock(ApigeeEnvironmentsServiceImpl.class);
    buildHandler = mock(BuildHandler.class);
    apigeeProductsService = mock(ApigeeProductsService.class);
    
    //apigeeProductsService = new ApigeeProductsService(apigeeMgmtApiClient, emailBasedAuthzSvc, apigeeEnvService, partnerProxyConfigProperties, buildHandler);
    asyncPartnerProxyServiceImpl = new AsyncPartnerProxyServiceImpl(apigeeProductsService);
  }
  
  private static PartnerProxy buildTestPartnerProxyRequest(String partnerName, String partnerResource, 
      String proxyVersion, EnvironmentEnum env, String endpointHostname, String endpointPath, String auth) {
    
    PartnerProxy proxy = new PartnerProxy();
    proxy.setPartnerName(partnerName);
    proxy.setPartnerResource(partnerResource);
    proxy.setProxyVersion(proxyVersion);
    proxy.setProxyOwnerAppKey("APPKEY12345678901234567890");
    proxy.setProxyOwnerSysgen("SYSGEN787489521");
    proxy.setProxyOwnerEmail("jeremy.eagleman@lumen.com");
    proxy.setProxyGateway(PartnerProxy.ProxyGatewayEnum.ESP);
    PartnerEndpoint partnerEndpoint = new PartnerEndpoint();
    partnerEndpoint.setEnvironment(env);
    partnerEndpoint.setEndpointHostname(endpointHostname);
    partnerEndpoint.setEndpointPath(endpointPath);
    OAuth20 oauth2 = new OAuth20();
    BasicAuth basicAuth = new BasicAuth();
    
    if (auth.equals("oauth_client_form")) {
      oauth2.setOauthGrantType(OAuth20.OauthGrantTypeEnum.CLIENT_CREDENTIALS);
      oauth2.setOauthGrantLocation(OAuth20.OauthGrantLocationEnum.FORM_PARAM);
      oauth2.setOauthTokenServiceHost("https://oauthtokenhostname");
      oauth2.setOauthTokenServicePath("/oauth/v1/token");
      oauth2.setOauthClientIdLocation(OAuth20.OauthClientIdLocationEnum.FORM_PARAM);
      oauth2.setOauthClientId("oauth_clinet_id");
      oauth2.setOauthClientSecret("oauth_client_secret");
      oauth2.setOauthScopeLocation(OAuth20.OauthScopeLocationEnum.FORM_PARAM);
      oauth2.setOauthScope("oauth_scope");
      partnerEndpoint.setAuthentication(oauth2);
      
    } else if (auth.equals("oauth_client_query")) {
      oauth2.setOauthGrantType(OAuth20.OauthGrantTypeEnum.CLIENT_CREDENTIALS);
      oauth2.setOauthGrantLocation(OAuth20.OauthGrantLocationEnum.QUERY_PARAM);
      oauth2.setOauthTokenServiceHost("https://oauthtokenhostname");
      oauth2.setOauthTokenServicePath("/oauth/v1/token");
      oauth2.setOauthClientIdLocation(OAuth20.OauthClientIdLocationEnum.QUERY_PARAM);
      oauth2.setOauthClientId("oauth_clinet_id");
      oauth2.setOauthClientSecret("oauth_client_secret");
      oauth2.setOauthScopeLocation(OAuth20.OauthScopeLocationEnum.QUERY_PARAM);
      oauth2.setOauthScope("oauth_scope");
      partnerEndpoint.setAuthentication(oauth2);
      
    } else if (auth.equals("basic_auth")) {
      basicAuth.setBasicAuthUser("ba_user");
      basicAuth.setBasicAuthPassword("ba_password");
      partnerEndpoint.setAuthentication(basicAuth);
      
    }
    
    proxy.setPartnerEndpoint(partnerEndpoint);
    return proxy;
  
  }
  
  private static ApigeeProduct buildTestApigeeProduct(String name, String approvalType, 
      Planet planet, AccessLocation accessLocation) {
    
    ApigeeProduct product = new ApigeeProduct();
    product.setApiResources(new ArrayList<String>(Arrays.asList("/ResourceA", "/ResourceB")));
    product.setApprovalType(approvalType);
    product.setDescription("myDescription");
    product.setDisplayName(name);
    product.setEnvironments(new ArrayList<String>(Arrays.asList("test1")));
    product.setName(name);
    product.setProxies(new ArrayList<String>(Arrays.asList("ProxyA", "ProxyB")));
    product.setScopes(new ArrayList<String>());

    return product;
  
  }
  
  @Test
  public void shouldAddNewProxyToApiProduct() {
    //given
    PartnerProxy partnerProxy = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "oauth_client_form");

    AsyncPartnerProxyServiceImpl service = new AsyncPartnerProxyServiceImpl(apigeeProductsService);
    AsyncPartnerProxyServiceImpl spyService = Mockito.spy(service);
    
    Mockito.when(partnerProxyConfigProperties.getApiProductName()).thenReturn("API-HUB Partner Proxy");
    ApigeeProduct product = buildTestApigeeProduct(partnerProxyConfigProperties.getApiProductName(), "manual", 
        Planet.NONPROD, AccessLocation.INTERNAL);
    ApigeeProduct updatedProduct = buildTestApigeeProduct(partnerProxyConfigProperties.getApiProductName(), "manual", 
        Planet.NONPROD, AccessLocation.INTERNAL);
    Mockito.when(apigeeProductsService.getProduct(product.getName(), Planet.NONPROD.toString(), "INTERNAL")).thenReturn(product);
    Mockito.when(apigeeProductsService.updatePartnerProxyProduct(Planet.NONPROD, product))
        .thenReturn(updatedProduct);
    
    await().atMost(5, TimeUnit.SECONDS).until(() -> {
    try {
        spyService.asyncAddNewProxyToApiProduct(partnerProxy, "guid");
        return true; // No exception was thrown, test passed
    } catch (PartnerProxyDeployException e) {
        // Exception was thrown, test failed
        return false;
    }
  });
    
  }

}
