package com.lumen.apiexchange.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lumen.apiexchange.entity.ApiDocumentation;
import com.lumen.apiexchange.entity.ApiHomeDetails;
import com.lumen.apiexchange.model.ApiHomeRequest;
import com.lumen.apiexchange.model.ApiMediatedResponse;
import com.lumen.apiexchange.model.ApplicationKey;
import com.lumen.apiexchange.model.ApplicationKeyResponse;
import com.lumen.apiexchange.model.ApplicationKeyResponseData;
import com.lumen.apiexchange.model.AuthorizationResponse;
import com.lumen.apiexchange.model.AuthorizationResponseData;
import com.lumen.apiexchange.model.Category;
import com.lumen.apiexchange.repository.ApiDocumentationRepository;
import com.lumen.apiexchange.repository.ApiHomeRepository;
import com.lumen.apiexchange.service.ApiService;
import com.lumen.apiexchange.service.ApiServiceImpl;
import com.lumen.apiexchange.service.MyAppsService;
import com.lumen.apiexchange.service.ProfileService;
import com.lumen.apiexchange.service.ProxyService;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@WebMvcTest(controllers = {ApiController.class})
@AutoConfigureMockMvc(addFilters = false)
@DirtiesContext
public class ApiControllerTest {

  @Autowired
  private MockMvc mockMvc;

  @InjectMocks
  private ApiController apiController;

  @MockBean
  private ApiService apiService;

  @MockBean
  private MyAppsService myAppService;

  @Mock
  private ApiServiceImpl apiServiceImpl;

  @Mock
  RestTemplate restTemplate;

  @Mock
  Authentication auth;

  @Mock
  Jwt jwt;

  @MockBean
  private ApiDocumentationRepository docRepository;

  @MockBean
  private ApiHomeRepository homeRepostory;

  @MockBean
  private ProxyService proxyService;

  @MockBean
  ProfileService profileService;

  @Test
  public void createNewDocumentTest() throws Exception {

    String uri = "/v1/newdoc";


    ApiDocumentation apiDoc = new ApiDocumentation(12, 100, UUID.randomUUID(), "Page Diagnostics",
        "This is the Lumen API Marketplace",

        "This file content is a new swagger section", "new file");
    MvcResult mvcResult = this.mockMvc
        .perform(
            post(uri).contentType(MediaType.APPLICATION_JSON).content(new ObjectMapper().writeValueAsString(apiDoc)))
        .andExpect(status().isOk()).andReturn();

    assertEquals(200, mvcResult.getResponse().getStatus());
  }

  @Test
  public void createNewDocument_WrongRequestMethodTest() throws Exception {

    String uri = "/v1/newdoc";

    ApiDocumentation apiDoc = new ApiDocumentation();
    apiDoc.setApiId(UUID.randomUUID());
    apiDoc.setApiId(UUID.randomUUID());
    apiDoc.setApiName("Page Diagnostics");
    apiDoc.setDocumentation("This is the Lumen API marketplace ");
    apiDoc.setFilecontent("This file content is a new swagger section");
    apiDoc.setSectionType(" Swagger");

    MvcResult mvcResult = this.mockMvc
        .perform(
            get(uri).contentType(MediaType.APPLICATION_JSON).content(new ObjectMapper().writeValueAsString(apiDoc)))
        .andExpect(status().isMethodNotAllowed()).andReturn();
    assertEquals(405, mvcResult.getResponse().getStatus());
  }

  @Test
  public void getAPIDocumentationBasedOnIdBadRequestTest() throws Exception {
    String uri = "/v1/documentation/";
    String id = "apiId";
    List<ApiDocumentation> apiDocList = new ArrayList<ApiDocumentation>();

    MvcResult mvcResult =
        this.mockMvc
            .perform(get(uri + id).contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(apiDocList)))
            .andExpect(status().isBadRequest()).andReturn();
    assertEquals(400, mvcResult.getResponse().getStatus());
  }

  @Test
  public void getAPIDocumentationBasedOnIdTest() throws Exception {
    String uri = "/v1/documentation/";
    UUID apiId = UUID.randomUUID();


    ApiDocumentation apiDocumentation1 = new ApiDocumentation(89, 1, UUID.randomUUID(), "<p>description</p>",
        null, null, null);
    ApiDocumentation apiDocumentation2 =
        new ApiDocumentation(97, 2, UUID.randomUUID(), "<p>Getting Started</p>", "Content", null, null);
    ApiDocumentation apiDocumentation3 = new ApiDocumentation(12, 3, UUID.randomUUID(), "getting started12345",
        "Content", null, null);


    List<ApiDocumentation> apiDocList = new ArrayList<ApiDocumentation>();

    apiDocList.add(apiDocumentation1);
    apiDocList.add(apiDocumentation2);
    apiDocList.add(apiDocumentation3);

    MvcResult mvcResult = this.mockMvc.perform(get(uri + apiId).contentType(MediaType.APPLICATION_JSON)
        .content(new ObjectMapper().writeValueAsString(apiDocList))).andExpect(status().isOk()).andReturn();
    assertEquals(200, mvcResult.getResponse().getStatus());
  }

  @Test
  public void updateAPIDocumentationTest() throws Exception {
    String uri = "/v1/editdoc/";

    ApiDocumentation inputDoc = new ApiDocumentation();

    inputDoc.setId(12);
    inputDoc.setApiId(UUID.randomUUID());
    inputDoc.setApiName("Page Diagnostics");
    inputDoc.setDocumentation("This is the Lumen API marketplace ");
    inputDoc.setFilecontent("This file content is a new swagger section");
    inputDoc.setSectionType(" Swagger");

    inputDoc.setApiId(UUID.randomUUID());

    MvcResult mvcResult = this.mockMvc
        .perform(
            put(uri).contentType(MediaType.APPLICATION_JSON).content(new ObjectMapper().writeValueAsString(inputDoc)))
        .andExpect(status().isOk()).andReturn();
    assertEquals(200, mvcResult.getResponse().getStatus());
  }

  @Test
  public void updateAPIDocument_BadData_Test() throws Exception {
    String uri = "/v1/editdoc/";

    ApiDocumentation inputDoc = new ApiDocumentation();

    inputDoc.setId(12);
    inputDoc.setApiId(UUID.randomUUID());
    inputDoc.setApiName("Page Diagnostics");
    inputDoc.setDocumentation("This is the Lumen API marketplace ");
    inputDoc.setFilecontent("This file content is a new swagger section");
    inputDoc.setSectionType(" Swagger");

    inputDoc.setApiId(UUID.randomUUID());

    ApiDocumentation updatedDoc = apiService.updateDocumentation(inputDoc);

    MvcResult mvcResult = this.mockMvc
        .perform(
            put(uri).contentType(MediaType.TEXT_PLAIN_VALUE).content(new ObjectMapper().writeValueAsString(updatedDoc)))
        .andExpect(status().isUnsupportedMediaType()).andReturn();
    assertEquals(415, mvcResult.getResponse().getStatus());
  }

  @Test
  public void deleteAPIDocumentation_BasedOnIdTest() throws Exception {

    String uri = "/v1/documentation/";
    int id = 1;

    MvcResult mvcResult = this.mockMvc.perform(delete(uri + id).contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk()).andReturn();

    assertEquals(200, mvcResult.getResponse().getStatus());
  }

  @Test
  public void deleteAPIDocumentation_BasedOn_WrongId_Type_Test() throws Exception {

    String uri = "/v1/documentation/";
    String id = "docId";
    // this has to be integer data type.

    MvcResult mvcResult = this.mockMvc.perform(delete(uri + id).contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest()).andReturn();
    assertEquals(400, mvcResult.getResponse().getStatus());
  }

  @Test
  public void getAPIHome_Test() throws Exception {

    String uri = "/v1/homedetails";

    MvcResult mvcResult =
        this.mockMvc.perform(get(uri).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();

    assertEquals(200, mvcResult.getResponse().getStatus());
  }

  @Test
  public void getAPIHome_Wrong_Test() throws Exception {

    String uri = "/v1/homedetails";

    MvcResult mvcResult = this.mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isMethodNotAllowed()).andReturn();
    assertEquals(405, mvcResult.getResponse().getStatus());
  }

  @Test
  public void addNewAPI_BadRequest_Test() throws Exception {

    String uri = "/v1/addnewapi";
    ApiHomeRequest homeReq = new ApiHomeRequest();
    homeReq.setId(123);
    homeReq.setApiName("Page Diagnostics");
    homeReq.setDescription("This is the Lumen API Marketplace");
    final String apiName = "Page Diagnostics";
    final String description = "This is the Lumen API Marketplace";

    String author = "author";

    MvcResult mvcResult = this.mockMvc
        .perform(post(uri).contentType(MediaType.APPLICATION_JSON)
            .content(new ObjectMapper().writeValueAsString(apiService.postNewApiDetail(homeReq, author))))
        .andExpect(status().isBadRequest()).andReturn();

    assertEquals(400, mvcResult.getResponse().getStatus());
  }

  @Test
  public void addNewAPI_Test() throws Exception {

    ApiHomeRequest homeReq1 = null;
    ApiHomeRequest homeReq = new ApiHomeRequest();
    homeReq.setId(123);
    homeReq.setApiName("Page Diagnostics");
    homeReq.setDescription("This is the Lumen API Marketplace");
    String apiName = "Page Diagnostics";
    String description = "This is the Lumen API Marketplace";

    String author = "author";

    ApiHomeDetails apiHomeDetails = apiService.postNewApiDetail(homeReq1, author);
    apiHomeDetails = homeRepostory.save(apiHomeDetails);

    Mockito.when(apiService.postNewApiDetail(homeReq, author)).thenReturn(apiHomeDetails);
  }

  @Test
  public void updateAPIDetail_WrongData_Test() throws Exception {

    ApiHomeRequest apiHomeRequestModel = new ApiHomeRequest();
    apiHomeRequestModel.setApiName("test");
    apiHomeRequestModel.setDescription("test");
    apiHomeRequestModel.setCategory("category");
    apiHomeRequestModel.setType("Type");
    apiHomeRequestModel.setStatus("Development");
    apiHomeRequestModel.setVersion("1.0");
    apiHomeRequestModel.setOasUrl("https://api-dev1.test.intranet/oasurl");
    apiHomeRequestModel.setSourceCodeUrl("https://api-dev1.test.intranet/sourceCodeUrl");
    Timestamp updatedTime = new Timestamp(System.currentTimeMillis());

    String uri = "/v1/updateapi/id"; // String id = "id";
    String apiName = "Page Diagnostics";
    String description = "This is the Lumen API Marketplace";
    String author = "author";
    UUID apiId = UUID.randomUUID();

    MvcResult mvcResult = this.mockMvc
        .perform(put(uri, 1, apiName, description).contentType(MediaType.APPLICATION_JSON).content(
            new ObjectMapper().writeValueAsString(apiService.updateApiDetails(apiId, apiHomeRequestModel, author))))
        .andExpect(status().isBadRequest()).andReturn();

    assertEquals(400, mvcResult.getResponse().getStatus());

  }

  @Test
  public void getAPIDocumentationFile_Test() throws Exception {
    Integer id = 35;
    ApiDocumentation apiDoc = new ApiDocumentation();

    Optional<ApiDocumentation> docFile = docRepository.findById(id);

    if (docFile.isPresent()) {
      apiDoc = docFile.get();
    }
    Mockito.when(apiService.getApiDocumentationFile(id)).thenReturn(apiDoc);

  }

  @Test
  public void getAPIDocumentationFile_NullID_Test() throws Exception {
    Integer id = -1;
    ApiDocumentation apiDoc = null;

    Optional<ApiDocumentation> docFile = docRepository.findById(id);

    if (docFile.isPresent()) {
      apiDoc = docFile.get();
    }
    Mockito.when(apiService.getApiDocumentationFile(id)).thenReturn(apiDoc);
  }


  @Test
  public void getTaxonomies_Test() throws Exception {

    String proxybuildKey = "Basic YXV0b0FwaUd1aU5QOndEUDA3MFFrTFBGVFBubXRUbVZHIQ==";

    HttpHeaders headers = new HttpHeaders();
    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
    headers.set("X-Application-Key", proxybuildKey);
    HttpEntity<String> entity = new HttpEntity<String>(headers);

    List<String> authList = new ArrayList<String>();
    Mockito.when(proxyService.getTaxonomies()).thenReturn(authList);

    ResponseEntity<AuthorizationResponse> authorizationResponse = getAuthResponse();

    String proxybuildUrl = "https://api-dev1.test.intranet/Application/v1/Apigee/proxyBuildDeploy";
    when(restTemplate.exchange(proxybuildUrl, HttpMethod.GET, entity, AuthorizationResponse.class))
        .thenReturn(authorizationResponse);

    assertNotNull(authorizationResponse);
  }


  private ResponseEntity<AuthorizationResponse> getAuthResponse() {

    String categoryservice = "Finance/AccountsReceivable";

    Category cs = new Category();
    cs.setCategoryservice(categoryservice);

    List<Category> authorization = new ArrayList<>();
    authorization.add(cs);

    AuthorizationResponseData ard = new AuthorizationResponseData();

    ard.setAuthorization(authorization);

    AuthorizationResponse authorizations = new AuthorizationResponse();
    authorizations.setAuthorizations(ard);

    ResponseEntity<AuthorizationResponse> reMock = mock(ResponseEntity.class);
    when(reMock.getBody()).thenReturn(authorizations);

    return reMock;
  }

  @Test
  public void getTax_Test() throws Exception {
    String custbuildKey = "APPKEY966252019031223364839633907";

    HttpHeaders headers = new HttpHeaders();
    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
    headers.set("X-Application-Key", custbuildKey);
    HttpEntity<String> entity = new HttpEntity<String>(headers);

    List<ApplicationKey> custList = new ArrayList<ApplicationKey>();
    // CustomerList customerList = new CustomerList(custList);

    Mockito.when(proxyService.getApplicationKeys()).thenReturn(custList);

    ResponseEntity<ApplicationKeyResponse> applicationDetailsResponse = getApplicationKeyResponse();

    String custBuildUrl = "https://api-dev1.test.intranet/Enterprise/v1/Security/espCustomer?customerType=Interna";
    when(restTemplate.exchange(custBuildUrl, HttpMethod.GET, entity, ApplicationKeyResponse.class))
        .thenReturn(applicationDetailsResponse);

    assertNotNull(applicationDetailsResponse);

  }

  private ResponseEntity<ApplicationKeyResponse> getApplicationKeyResponse() {

    ApplicationKey appkey = new ApplicationKey();

    appkey.setApplicationKeyID("Test");
    appkey.setApplicationKeyType("Test");
    appkey.setApplicationName("Test");
    appkey.setApplicationType("Test");
    appkey.setAuthorizationType("Test");
    appkey.setClientPublicKeys("Test");
    appkey.setCustomernumbers("Test");
    appkey.setCustomerType("Test");
    appkey.setItpkmServiceId("Test");
    appkey.setOwneremail("Test");
    appkey.setUser("Test");
    appkey.setUsertype("Test");

    List<ApplicationKey> applicationKey = new ArrayList<>();
    applicationKey.add(appkey);

    ApplicationKeyResponseData appKeyRespData = new ApplicationKeyResponseData();
    appKeyRespData.setApplicationKey(applicationKey);

    ApplicationKeyResponse resp = new ApplicationKeyResponse();
    resp.setApplicationKeys(appKeyRespData);

    ResponseEntity<ApplicationKeyResponse> reMock = Mockito.mock(ResponseEntity.class);
    when(reMock.getBody()).thenReturn(resp);

    return reMock;

  }

  @Test
  public void getTax_Bad_Request_Test() throws Exception {
    String custbuildKey = "APPKEY966252019031223364839633907";

    HttpHeaders headers = new HttpHeaders();
    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
    headers.set("X-Application-Key", custbuildKey);
    HttpEntity<String> entity = new HttpEntity<String>(headers);

    List<ApplicationKey> custList = new ArrayList<ApplicationKey>();

    Mockito.when(proxyService.getApplicationKeys()).thenReturn(custList);

    ResponseEntity<ApplicationKeyResponse> applicationDetailsResponse = getApplicationKeyFalseResponseData();

    String custBuildUrl = "https://api-dev1.test.intranet/Enterprise/v1/Security/espCustomer?customerType=Interna";
    when(restTemplate.exchange(custBuildUrl, HttpMethod.GET, entity, ApplicationKeyResponse.class))
        .thenReturn(applicationDetailsResponse);

    assertNull(applicationDetailsResponse);

  }

  private ResponseEntity<ApplicationKeyResponse> getApplicationKeyFalseResponseData() {
    ResponseEntity<ApplicationKeyResponse> reMock = null;
    return reMock;
  }


  @Test
  public void getTaxonomies_Wrong_Test() throws Exception {
    String proxybuildKey = "Basic YXV0b0FwaUd1aU5QOndEUDA3MFFrTFBGVFBubXRUbVZHIQ==";

    HttpHeaders headers = new HttpHeaders();
    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
    headers.set("X-Application-Key", proxybuildKey);
    HttpEntity<String> entity = new HttpEntity<String>(headers);

    List<String> authList = new ArrayList<String>();
    Mockito.when(proxyService.getTaxonomies()).thenReturn(authList);

    ResponseEntity<AuthorizationResponse> authorizationResponse = getAuthFalseResponse();

    String proxybuildUrl = "https://api-dev1.test.intranet/Application/v1/Apigee/proxyBuildDeploy";
    when(restTemplate.exchange(proxybuildUrl, HttpMethod.GET, entity, AuthorizationResponse.class))
        .thenReturn(authorizationResponse);

    assertNull(authorizationResponse);


  }

  private ResponseEntity<AuthorizationResponse> getAuthFalseResponse() {
    ResponseEntity<AuthorizationResponse> reMock = null;
    return reMock;
  }

  @Test
  public void updateHomeAPITest() throws Exception {

    String uri = "/v1/updateapi/";
    int id = 1;

    MvcResult mvcResult = this.mockMvc.perform(put(uri + id + ",test" + ",test")
            .contentType(MediaType.APPLICATION_JSON))
        .andReturn();

    assertEquals(400, mvcResult.getResponse().getStatus());
  }

  @Before
  public void setup() {
    apiController = new ApiController(apiService);
    mockMvc = MockMvcBuilders.standaloneSetup(apiController).build();
    when(jwt.getClaimAsString("name")).thenReturn("test");
    when(auth.getPrincipal()).thenReturn(jwt);
    SecurityContextHolder.getContext().setAuthentication(auth);
  }

  @Test
  public void updateAPIDetail_Test() throws JsonMappingException, JsonProcessingException {

    apiController = new ApiController(apiService);

    String uri = "/v1/updateapi/id";
    int id = 12;
    String apiName = "Page Diagnostics";
    String description = "This is the Lumen API Marketplace";

    ApiHomeRequest apiHomeRequestModel = new ApiHomeRequest();
    apiHomeRequestModel.setApiName("test");
    apiHomeRequestModel.setDescription("test");
    apiHomeRequestModel.setCategory("category");
    apiHomeRequestModel.setType("Type");
    apiHomeRequestModel.setStatus("Development");
    apiHomeRequestModel.setVersion("1.0");
    apiHomeRequestModel.setOasUrl("https://api-dev1.test.intranet/oasurl");
    apiHomeRequestModel.setSourceCodeUrl("https://api-dev1.test.intranet/sourceCodeUrl");
    Timestamp updatedTime = new Timestamp(System.currentTimeMillis());

    String author = "author";
    UUID apiId = UUID.randomUUID();
    ApiHomeDetails apiHomeDetails = new ApiHomeDetails(apiId, "category", "test", "test");

    MockHttpServletRequest request = new MockHttpServletRequest();
    RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

    when(homeRepostory.save(any())).thenReturn(apiHomeDetails);

    when(apiService.updateApiDetails(apiId, apiHomeRequestModel, author)).thenReturn(apiHomeDetails);

    when(apiServiceImpl.updateApiDetails(apiId, apiHomeRequestModel, author)).thenReturn(apiHomeDetails);

    ApiHomeDetails api = apiController.updateApiDetail(apiId, jwt, apiHomeRequestModel);

  }

  @Test
  public void addNewAPIDetail_Test() throws JsonMappingException, JsonProcessingException {

    String uri = "/v1/addnewapi";
    ApiHomeRequest homeReq = new ApiHomeRequest();
    homeReq.setId(12);
    homeReq.setApiName("Page Diagnostics");
    homeReq.setDescription("This is the Lumen API Marketplace");
    int id = 12;
    String apiName = "Page Diagnostics";
    String description = "This is the Lumen API Marketplace";
    String author = "author";
    UUID createdUserId = UUID.randomUUID();
    ApiHomeDetails apiHomeDetails = new ApiHomeDetails(createdUserId, "category", "test", "test");

    MockHttpServletRequest request = new MockHttpServletRequest();
    RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

    when(homeRepostory.save(apiHomeDetails)).thenReturn(apiHomeDetails);
    when(apiService.postNewApiDetail(homeReq, author)).thenReturn(apiHomeDetails);
    when(apiServiceImpl.postNewApiDetail(homeReq, author)).thenReturn(apiHomeDetails);

    apiController = new ApiController(apiService);

    ApiHomeDetails api = apiController.addNewApi(jwt, homeReq);

  }

  private HttpHeaders getHeader() {
    HttpHeaders httpHeaders = new HttpHeaders();

    httpHeaders.add("authorization",
        "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IjdmNTRkMjcxLTU5N2YtNDQ3ZS04YzJlLTRiYTY4MjU1YmMzMSJ9"
            + ".eyJpc3MiOiJBUFBLRVk3NTY3NTIwMjAwMTEwMTU1OTQ5NTg2MTExMjc0IiwianRpIjoiYWJkYzU3NWUtMWFkZS00OTFkLWE0YmEtYmJ"
            + "kZTNmZjJkNWJlIiwic3ViIjoiYjMzZmVlYmYtZmRjMy00YTU2LTlkM2EtMjJhZDgyZmFlNGExIiwidXNlcm5hbWUiOiJiMzNmZWViZi1"
            + "mZGMzLTRhNTYtOWQzYS0yMmFkODJmYWU0YTEiLCJuYW1lIjoiSmVuaXR0IEpvc2UiLCJhY2Nlc3NfdHlwZSI6ImFjY2Vzc190b2tlbiI"
            + "sInR5cGUiOiJpbnRlcm5hbCIsImlhdCI6MTY0MzEwMzM1OSwiZXhwIjoxNjQzMTAzNjU5fQ.Y9obLvH52tgszQVhfMD7FM5-I7Md5M7-"
            + "rvW703bJ2bN6J81TQ3WAM1UT4Xy6I1cTIvALrLJ8eWEQzd2dpDkDh4X6jkNBZS8CiYipD4WwzbzSi5eYoWxze54fgcXUxo04SIipVn1l"
            + "EYibZQvXxBFuOjSmFG3VDtyEqsayMwynKPCXbsKmlYDvQH9Tq5oIyZ5qqRu5fw53dY9ftmey6J-zODtSIQZs2B9-qItOhmOOF8xl80V6"
            + "iyXUTK5Jvbb7TdYumy-L0HajrpAUMM0Z2ITHFWAsyJvSieLugr72k0Sm7pNDs34-3DVKK891a5_JcNJV__fJggPu63tkM-KLnP_tmhbZ"
            + "LP6Uzjt2nyZsUgOe3ei-g_8Lp7h9dcUuiSHVOe8aqdrkETRr1W_r1ivMUAs6GLoozurwwUEUsOdslxtOmXIDXRVUQ7LNhibYGm-dAiyP"
            + "iakspyyV2l27-_breNgZs5YCgfSB7H2HMrx6taCNb1eX8ifxyv1NJ-oRp1EnKrUKPcN3wp_ce0IqiX-d-kn8mk-zA0hihqLK7LdPLTkU"
            + "h99VOnizLMziqMbC-3yjilVqp_gtj4y6pqmC1hOxbDhD3lbBuJvUXJnucvLYBaLj23KnufrTdCkXmN4ghtyuFCcnnPAYp5PjnrACBkaE"
            + "17GZDX-HCQaY1V9KP-FxxOrBLPI");

    return httpHeaders;
  }

  @Test
  public void getAPIDocumentationFile_positiveTest() {

    String uri = "/v1/docFile/{id}";
    int id = 1;

    ApiDocumentation docFile = new ApiDocumentation(12, 1, UUID.randomUUID(), "Page Diagnostics",
        "This is the Lumen API Marketplace",
        "This file content is a new swagger section", "new file");

    MockHttpServletRequest request = new MockHttpServletRequest();
    RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

    // when(homeRepostory.save(apiHomeDetails)).thenReturn(apiHomeDetails);

    when(apiService.getApiDocumentationFile(id)).thenReturn(docFile);


    when(apiServiceImpl.getApiDocumentationFile(id)).thenReturn(docFile);

    ResponseEntity<Resource> api = apiController.getApiDocumentationFile(id);

    // assertThat(responseEntity.getStatusCodeValue()).isEqualTo(201);
    assertNotNull(api);
  }

  @Test
  public void getAPIDocumentationFile_negativeTest() throws Exception {

    // given
    String uri = "/v1/docFile/1";
    int id = 1;
    given(apiServiceImpl.getApiDocumentationFile(id)).willReturn(null);

    // when
    MvcResult mvcResult = this.mockMvc.perform(get(uri + id).contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk()).andReturn();

    // then
    assertThat(mvcResult.getResponse().getContentAsString()).contains("Network Diagnostics");
  }

  @Test
  public void deleteAPIDetails_BasedOnApiIdTest() throws Exception {

    String uri = "/v1/deleteapi/";
    UUID id = UUID.randomUUID();

    MvcResult mvcResult = this.mockMvc.perform(delete(uri + id).contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk()).andReturn();

    assertEquals(200, mvcResult.getResponse().getStatus());
  }

  @Test
  public void getapiproxies() throws Exception {

    String url = "/v1/apiproxies";

    ApiMediatedResponse respModel = new ApiMediatedResponse();

    Mockito.when(apiService.getApiProxies()).thenReturn(respModel);

    MvcResult mvcResult =
        mockMvc.perform(get(url).contentType(MediaType.APPLICATION_JSON).header("authorization", "abcd"))
            .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andReturn();

    assertNotNull(mvcResult.getResponse().getContentAsString());
  }

  @Test
  public void getApiDocumentationProxyTest() throws Exception {

    String url = "/v1/documentationwithproxy/" + UUID.randomUUID();

    //ApiMediatedResponse respModel = new ApiMediatedResponse();

    Mockito.when(apiService.getApiDocumentation(UUID.randomUUID())).thenReturn(null);
    Mockito.when(myAppService.getProxyDetails(UUID.randomUUID())).thenReturn(null);

    MvcResult mvcResult =
        mockMvc.perform(get(url).contentType(MediaType.APPLICATION_JSON).header("authorization", "abcd"))
            .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andReturn();

    assertNotNull(mvcResult.getResponse().getContentAsString());
  }

}
