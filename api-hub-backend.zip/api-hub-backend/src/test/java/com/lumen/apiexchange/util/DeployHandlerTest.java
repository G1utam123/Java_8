package com.lumen.apiexchange.util;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.exactly;
import static com.github.tomakehurst.wiremock.client.WireMock.put;
import static com.github.tomakehurst.wiremock.client.WireMock.putRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.assertj.core.api.Assertions.assertThat;

import com.lumen.apiexchange.IntegrationTestBase;
import com.lumen.apiexchange.exception.InternalServerException;
import java.io.IOException;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("it")
@AutoConfigureWireMock(port = 0)
class DeployHandlerTest extends IntegrationTestBase {

  @Autowired
  private DeployHandler deployHandler;

  @Test
  void deployInternalApiToDev1() throws IOException, InternalServerException {

    stubFor(put(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource/test/deployInternal"))
        .withHeader("X-Username", containing("apigee"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")));

    ResponseEntity<String> response = deployHandler.deployApi("dev1", "internal", "test");
    assertThat(response).isNotNull();

    verify(1, putRequestedFor(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource/test/deployInternal")));
  }

  @Test
  void deployExternalApiToDev1() throws IOException, InternalServerException {

    stubFor(put(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource/test/deployExternal"))
        .withHeader("X-Username", containing("apigee"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")));

    ResponseEntity<String> response = deployHandler.deployApi("dev1", "external", "test");
    assertThat(response).isNotNull();

    verify(1, putRequestedFor(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource/test/deployExternal")));
  }

  @Test
  void deployInternalApiToDev2() throws IOException, InternalServerException {
    ResponseEntity<String> response = deployHandler.deployApi("dev2", "internal", "test");
    assertThat(response).isNotNull();
  }

  @Test
  void deployInternalApiToDev3() throws IOException, InternalServerException {
    ResponseEntity<String> response = deployHandler.deployApi("dev3", "internal", "test");
    assertThat(response).isNotNull();
  }

  @Test
  void deployInternalApiToDev4() throws IOException, InternalServerException {
    ResponseEntity<String> response = deployHandler.deployApi("dev4", "internal", "test");
    assertThat(response).isNotNull();
  }

  @Test
  void deployInternalApiToTest1() throws IOException, InternalServerException {
    ResponseEntity<String> response = deployHandler.deployApi("test1", "internal", "test");
    assertThat(response).isNotNull();
  }

  @Test
  void deployInternalApiToTest2() throws IOException, InternalServerException {
    ResponseEntity<String> response = deployHandler.deployApi("test2", "internal", "test");
    assertThat(response).isNotNull();
  }

  @Test
  void deployInternalApiToTest3() throws IOException, InternalServerException {
    ResponseEntity<String> response = deployHandler.deployApi("test3", "internal", "test");
    assertThat(response).isNotNull();
  }

  @Test
  void deployInternalApiToTest4() throws IOException, InternalServerException {
    ResponseEntity<String> response = deployHandler.deployApi("test4", "internal", "test");
    assertThat(response).isNotNull();
  }
}