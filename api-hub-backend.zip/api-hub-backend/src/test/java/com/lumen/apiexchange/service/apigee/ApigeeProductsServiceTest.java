package com.lumen.apiexchange.service.apigee;

import static org.assertj.core.api.AssertionsForClassTypes.assertThatExceptionOfType;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

import com.lumen.apiexchange.api.partner.model.BasicAuth;
import com.lumen.apiexchange.api.partner.model.OAuth20;
import com.lumen.apiexchange.api.partner.model.PartnerEndpoint;
import com.lumen.apiexchange.api.partner.model.PartnerEndpoint.EnvironmentEnum;
import com.lumen.apiexchange.api.partner.model.PartnerProxy;
import com.lumen.apiexchange.client.apigee.ApigeeMgmtApiClient;
import com.lumen.apiexchange.config.PartnerProxyConfigProperties;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.NotFoundException;
import com.lumen.apiexchange.exception.PartnerProxyAddToProductException;
import com.lumen.apiexchange.exception.ProductNotFoundException;
import com.lumen.apiexchange.exception.apigee.ApigeeMgmtApiClientException;
import com.lumen.apiexchange.model.apigee.ApigeeProduct;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.AccessLocation;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.Planet;
import com.lumen.apiexchange.service.EmailBasedAuthzServiceImpl;
import com.lumen.apiexchange.util.BuildHandler;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;

public class ApigeeProductsServiceTest {
  private ApigeeProductsService apigeeProductsService;

  private PartnerProxyConfigProperties partnerProxyConfigProperties;
  private ApigeeMgmtApiClient apigeeMgmtApiClient;
  private EmailBasedAuthzServiceImpl emailBasedAuthzSvc;
  private ApigeeEnvironmentsServiceImpl apigeeEnvService;
  
  private static final String testGuid = UUID.randomUUID().toString();
  
  @BeforeEach
  void setUp() {

    partnerProxyConfigProperties = mock(PartnerProxyConfigProperties.class);
    apigeeMgmtApiClient = mock(ApigeeMgmtApiClient.class);
    emailBasedAuthzSvc = mock(EmailBasedAuthzServiceImpl.class);
    apigeeEnvService = mock(ApigeeEnvironmentsServiceImpl.class);

    apigeeProductsService = new ApigeeProductsService(apigeeMgmtApiClient, emailBasedAuthzSvc, apigeeEnvService,
        partnerProxyConfigProperties);
  }
  
  private static PartnerProxy buildTestPartnerProxyRequest(String partnerName, String partnerResource, 
      String proxyVersion, EnvironmentEnum env, String endpointHostname, String endpointPath, String auth) {
    
    PartnerProxy proxy = new PartnerProxy();
    proxy.setPartnerName(partnerName);
    proxy.setPartnerResource(partnerResource);
    proxy.setProxyVersion(proxyVersion);
    proxy.setProxyOwnerAppKey("APPKEY12345678901234567890");
    proxy.setProxyOwnerSysgen("SYSGEN787489521");
    proxy.setProxyOwnerEmail("jeremy.eagleman@lumen.com");
    proxy.setProxyGateway(PartnerProxy.ProxyGatewayEnum.ESP);
    proxy.setProxyGuid(UUID.fromString(testGuid));
    PartnerEndpoint partnerEndpoint = new PartnerEndpoint();
    partnerEndpoint.setEnvironment(env);
    partnerEndpoint.setEndpointHostname(endpointHostname);
    partnerEndpoint.setEndpointPath(endpointPath);
    OAuth20 oauth2 = new OAuth20();
    BasicAuth basicAuth = new BasicAuth();
    
    if (auth.equals("oauth_client_form")) {
      oauth2.setOauthGrantType(OAuth20.OauthGrantTypeEnum.CLIENT_CREDENTIALS);
      oauth2.setOauthGrantLocation(OAuth20.OauthGrantLocationEnum.FORM_PARAM);
      oauth2.setOauthTokenServiceHost("https://oauthtokenhostname");
      oauth2.setOauthTokenServicePath("/oauth/v1/token");
      oauth2.setOauthClientIdLocation(OAuth20.OauthClientIdLocationEnum.FORM_PARAM);
      oauth2.setOauthClientId("oauth_clinet_id");
      oauth2.setOauthClientSecret("oauth_client_secret");
      oauth2.setOauthScopeLocation(OAuth20.OauthScopeLocationEnum.FORM_PARAM);
      oauth2.setOauthScope("oauth_scope");
      partnerEndpoint.setAuthentication(oauth2);
      
    } else if (auth.equals("oauth_client_query")) {
      oauth2.setOauthGrantType(OAuth20.OauthGrantTypeEnum.CLIENT_CREDENTIALS);
      oauth2.setOauthGrantLocation(OAuth20.OauthGrantLocationEnum.QUERY_PARAM);
      oauth2.setOauthTokenServiceHost("https://oauthtokenhostname");
      oauth2.setOauthTokenServicePath("/oauth/v1/token");
      oauth2.setOauthClientIdLocation(OAuth20.OauthClientIdLocationEnum.QUERY_PARAM);
      oauth2.setOauthClientId("oauth_clinet_id");
      oauth2.setOauthClientSecret("oauth_client_secret");
      oauth2.setOauthScopeLocation(OAuth20.OauthScopeLocationEnum.QUERY_PARAM);
      oauth2.setOauthScope("oauth_scope");
      partnerEndpoint.setAuthentication(oauth2);
      
    } else if (auth.equals("basic_auth")) {
      basicAuth.setBasicAuthUser("ba_user");
      basicAuth.setBasicAuthPassword("ba_password");
      partnerEndpoint.setAuthentication(basicAuth);
      
    }
    
    proxy.setPartnerEndpoint(partnerEndpoint);
    return proxy;
  
  }
  
  private static ApigeeProduct buildTestApigeeProduct(String name, String approvalType, 
      Planet planet, AccessLocation accessLocation) {
    
    ApigeeProduct product = new ApigeeProduct();
    product.setApiResources(new ArrayList<String>(Arrays.asList("/ResourceA", "/ResourceB")));
    product.setApprovalType(approvalType);
    product.setDescription("myDescription");
    product.setDisplayName(name);
    product.setEnvironments(new ArrayList<String>(Arrays.asList("test1")));
    product.setName(name);
    product.setProxies(new ArrayList<String>(Arrays.asList("ProxyA", "ProxyB")));
    product.setScopes(new ArrayList<String>());

    return product;
  
  }

  @Test
  public void shouldAddNewProxyToApiProduct() throws InternalServerException {
    
    boolean exceptionThown = false;
    
    PartnerProxy partnerProxy = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "basic_auth");
    
    String productName = "API-HUB Partner Proxy";
    Mockito.when(partnerProxyConfigProperties.getApiProductName()).thenReturn(productName);
    
    ApigeeProduct product = buildTestApigeeProduct(productName, "manual", 
        Planet.NONPROD, AccessLocation.INTERNAL);
    Mockito.when(apigeeMgmtApiClient.getProduct(productName, Planet.NONPROD.toString(), "INTERNAL"))
        .thenReturn(product);
    
    String apigeeProxyName = BuildHandler.buildApigeeProxyName(partnerProxy.getProxyVersion(),
        partnerProxy.getPartnerName(), partnerProxy.getPartnerResource(), testGuid);
    
    product.getProxies().add(apigeeProxyName);
    
    ApigeeProductHubRequest hubProduct = new ApigeeProductHubRequest();
    hubProduct.setAccessLocation(AccessLocation.INTERNAL);
    hubProduct.setPlanet(Planet.NONPROD);
    hubProduct.setApigeeProductRequest(apigeeProductsService.mapApigeeProductToApigeeProductRequest(product));
    ApigeeProduct updatedProduct = buildTestApigeeProduct(productName, "manual", 
        Planet.NONPROD, AccessLocation.INTERNAL);
    Mockito.when(apigeeMgmtApiClient.updateProduct(productName, hubProduct))
        .thenReturn(updatedProduct);
    
    try {
      apigeeProductsService.addNewProxyToApiProduct(partnerProxy, testGuid);
    } catch (Exception e) {
      exceptionThown = true;
    }
    
    assertTrue(exceptionThown == false);
  }
  
  @Test
  void shouldThrowPartnerProxyAddToProductExceptionForNotFound() throws Exception {
    
    PartnerProxy partnerProxy = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "basic_auth");
   
    String productName = "API-HUB Partner Proxy";
    String reason = String.format("Product not found for name: %s in planet: %s and org: %s", productName,
        Planet.NONPROD, AccessLocation.INTERNAL);
    String message = String.format("Error adding new proxy to Apigee. Partner Proxy Request: %n%s", partnerProxy);

    Mockito.when(partnerProxyConfigProperties.getApiProductName()).thenReturn(productName);
    
    
    Mockito.when(apigeeMgmtApiClient.getProduct(productName, Planet.NONPROD.toString(), "INTERNAL"))
        .thenThrow(new ProductNotFoundException(reason));
  
    assertThatExceptionOfType(PartnerProxyAddToProductException.class)
    .isThrownBy(() -> {
      apigeeProductsService.addNewProxyToApiProduct(partnerProxy, testGuid);
    }).withMessageContaining(message);

  }

  @Test
  void shouldThrowPartnerProxyAddToProductExceptionForHttpClientErrorException() throws Exception {
    
    //Given
    PartnerProxy partnerProxy = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "basic_auth");
    PartnerProxy partnerProxyProd = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.PRODUCTION, "https://hostname.com", "partnerPath", "basic_auth");
    String apigeeProxyName = BuildHandler.buildApigeeProxyName(partnerProxy.getProxyVersion(),
        partnerProxy.getPartnerName(), partnerProxy.getPartnerResource(), testGuid);
    String message = String.format("Error adding new proxy to Apigee. Partner Proxy Request: %n%s", partnerProxyProd);
    
    //When
    Mockito.when(apigeeMgmtApiClient.getProxy(apigeeProxyName, Planet.NONPROD.toString(), "INTERNAL"))
        .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));
    Mockito.when(apigeeMgmtApiClient.getProxy(apigeeProxyName, Planet.PROD.toString(), "INTERNAL"))
        .thenThrow(new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR));
  
    //Then
    assertThatExceptionOfType(NotFoundException.class)
        .isThrownBy(() -> {
          apigeeProductsService.addNewProxyToApiProduct(partnerProxy, testGuid);
        }).withMessageContaining("Still waiting for proxy to be deployed");
    
    assertThatExceptionOfType(PartnerProxyAddToProductException.class)
        .isThrownBy(() -> {
          apigeeProductsService.addNewProxyToApiProduct(partnerProxyProd, testGuid);
        }).withMessageContaining(message);

  }

  @Test
  void shouldThrowPartnerProxyAddToProductExceptionForApiClientException() throws Exception {
    
    PartnerProxy partnerProxy = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.PRODUCTION, "https://hostname.com", "partnerPath", "basic_auth");
    
    String productName = "API-HUB Partner Proxy";
    Mockito.when(partnerProxyConfigProperties.getApiProductName()).thenReturn(productName);
   
    String reason = String.format("Unable to update product: %s in planet: %s and org: %s", productName,
        Planet.PROD, AccessLocation.INTERNAL);
    String message = String.format("Error adding new proxy to Apigee. Partner Proxy Request: %n%s", partnerProxy);

    Mockito.when(apigeeMgmtApiClient.getProduct(productName, Planet.PROD.toString(), "INTERNAL"))
        .thenThrow(new ApigeeMgmtApiClientException(reason));
  
    assertThatExceptionOfType(PartnerProxyAddToProductException.class)
    .isThrownBy(() -> {
      apigeeProductsService.addNewProxyToApiProduct(partnerProxy, testGuid);
    }).withMessageContaining(message);

  }
}
