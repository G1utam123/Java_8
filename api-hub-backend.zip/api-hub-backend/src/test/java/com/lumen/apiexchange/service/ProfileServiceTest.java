package com.lumen.apiexchange.service;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.BDDMockito.given;

import com.lumen.apiexchange.client.PortalFrameworkAuthClient;
import com.lumen.apiexchange.exception.UnauthorizedException;
import com.lumen.apiexchange.model.myapps.Details;
import com.lumen.apiexchange.model.myapps.ProfileDetailsResponse;
import com.lumen.apiexchange.model.userprofile.CreateUserRequest;
import java.time.Instant;
import java.util.Arrays;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.oauth2.jwt.Jwt;


@ExtendWith(MockitoExtension.class)
public class ProfileServiceTest {

  @InjectMocks
  ProfileService profileService;

  @Mock
  PortalFrameworkAuthClient portalFrameworkAuthClient;

  @Test
  void shouldGetEmailFromProfileServiceTest() {

    //given
    Jwt token = getToken().build(); //No "email" claim

    given(portalFrameworkAuthClient.getProfileDetails(token.getTokenValue()))
        .willReturn(getResponseData());

    //when
    String email = profileService.getEmailFromProfile(token);

    //then
    assertThat(email).isEqualTo("test.test@test.com");

  }

  @Test
  void shouldGetEmailFromClaimTest() {

    //given
    Jwt token = getToken()
        .claim("email", "claim@test.com")
        .build();

    //when
    String email = profileService.getEmailFromProfile(token);

    //then
    assertThat(email).isEqualTo("claim@test.com");

  }

  @Test
  void shouldThrowExceptionIfNotEmailFound() {

    //given
    Jwt token = getToken()
        .build();

    given(portalFrameworkAuthClient.getProfileDetails(token.getTokenValue()))
        .willReturn(new ProfileDetailsResponse());

    //when-then
    Assertions.assertThrows(UnauthorizedException.class, () -> {
      profileService.getEmailFromProfile(token);
    });

  }

  @Test
  void shouldRetrieveUserRequestDetails() {

    //given
    Jwt token = getToken()
        .build();

    given(portalFrameworkAuthClient.getProfileDetails(token.getTokenValue()))
        .willReturn(getResponseData());

    //when
    CreateUserRequest data = profileService.getCreateUserRequestBody(token.getTokenValue());

    //then
    assertThat(data.getEmail()).isEqualTo("test.test@test.com");
    assertThat(data.getFirstName()).isEqualTo("firstName");
    assertThat(data.getLastName()).isEqualTo("lastName");
    assertThat(data.getUserName()).isEqualTo("test.test@test.com");
  }

  private static Jwt.Builder getToken() {
    return Jwt.withTokenValue("token")
        .header("alg", "none")
        .audience(Arrays.asList("https://audience.example.org"))
        .expiresAt(Instant.MAX)
        .issuedAt(Instant.MIN)
        .issuer("https://issuer.example.org")
        .jti("jti")
        .notBefore(Instant.MIN)
        .subject("mock-test-subject");
  }

  private ProfileDetailsResponse getResponseData() {

    ProfileDetailsResponse response = new ProfileDetailsResponse();

    response.setId("b33feebf-fdc3-4a56-9d3a-22ad82fae4a1");
    response.setEmail("Test.Test@test.com");
    response.setCuid("MD11223344");
    response.setLastName("LastName");
    response.setName("name");
    response.setUpdated("2022-04-13 06:47:26.109389");

    Details details = new Details();
    details.setDisplayUsername("displayUsername");
    details.setEmailAddress("Test.Test@test.com");
    details.setFirstName("firstName");
    details.setLastName("lastName");
    details.setPhone("6895442");

    response.setDetails(details);

    return response;
  }

}
