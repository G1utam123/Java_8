package com.lumen.apiexchange.client;

import static org.assertj.core.api.Assertions.assertThat;

import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.model.ApiMediatedResponse;
import com.lumen.apiexchange.model.InputApiRequest;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest 
@ActiveProfiles("e2e")
class ESPClientE2E {

  @Autowired
  private ESPClient espClient;

  @Test
  void getApiProxies() throws InternalServerException {

    ApiMediatedResponse apiProxies = espClient.getApiProxies();

    assertThat(apiProxies.getMediatedResource().size()).isGreaterThan(500);
  }

  @Test
  void testGetApiProxiesByGuid() throws InternalServerException {

    ApiMediatedResource apiProxy = espClient.getApiProxies("6ce67bee-66c3-4007-be6a-73c5691339f8");

    assertThat(apiProxy.getResourceName()).isEqualTo("brightspeed");

  }

  @Test
  void postProxyRequest() {
  }

  @Test
  void getApiProxyDetailsOnTest1() throws InternalServerException {

    InputApiRequest inputApiRequest = new InputApiRequest();
    inputApiRequest.setEnv("test1");

    ApiMediatedResponse apiProxies = espClient.getApiProxyDetails(inputApiRequest);

    assertThat(apiProxies.getMediatedResource().size()).isGreaterThan(500);

  }

  @Test
  void migrateApiProxy() {
  }
}