package com.lumen.apiexchange.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;

import com.lumen.apiexchange.IntegrationTestBase;
import com.lumen.apiexchange.entity.ApiProduct;
import com.lumen.apiexchange.exception.ProductNotFoundException;
import com.lumen.apiexchange.exception.UnauthorizedException;
import com.lumen.apiexchange.repository.ApiProductsRepository;
import java.sql.Timestamp;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.dao.DataAccessException;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("it")
@AutoConfigureWireMock(port = 0)
class ApiProductsServiceTest extends IntegrationTestBase {

  @Autowired
  private ApiProductsService apiProductsService;

  @Autowired
  private ApiProductsRepository apiProductsRepository;

  final UUID id1 = UUID.randomUUID();
  final UUID id2 = UUID.randomUUID();
  final UUID id3 = UUID.randomUUID();
  final Timestamp time1 = new Timestamp(System.currentTimeMillis());
  final Timestamp time2 = new Timestamp(System.currentTimeMillis() + 1);
  final Timestamp time3 = new Timestamp(System.currentTimeMillis() + 2);

  @BeforeEach
  public void cleanupProductsTable() {

    // As a safety valve in case this ever got accidently run against the real DB, check that  
    // the data in the table is just data created by this test class and only delete that data.  
    List<ApiProduct> testProducts = apiProductsRepository.findByCreatedBy("ApiProductsServiceTest");
    if (testProducts.size() > 0) {
      testProducts.forEach(list -> {
        UUID id = list.getId();
        apiProductsRepository.deleteById(id);
      });
    }

  }

  @Test
  public void shoulGetProductNotFound() throws Exception {

    //given
    UUID id = UUID.randomUUID();

    //when-then
    assertThatExceptionOfType(ProductNotFoundException.class)
        .isThrownBy(() -> {
          apiProductsService.getProduct(id);
        })
        .withMessage("Product not found for id: " + id);

  }

  @Test
  public void shoulGetDataAccessException() throws Exception {

    //given
    UUID id = null;

    //when-then
    assertThatExceptionOfType(DataAccessException.class)
        .isThrownBy(() -> {
          apiProductsService.getProduct(id);
        });
  }

  @Test
  public void shouldSaveProduct() throws Exception {

    //given
    ApiProduct savedApiProduct1 = apiProductsService.saveProduct(buildTestProduct("1", time1, true, "PROD"));

    //when
    ApiProduct apiProduct1 = apiProductsService.getProduct(savedApiProduct1.getId());

    assertThat(apiProduct1).isNotNull();
    assertThat(apiProduct1.getAccess()).isEqualTo("myAccess1");
    assertThat(apiProduct1.getApprovalType()).isEqualTo("myaApprovalType1");
    assertThat(apiProduct1.getCreatedBy()).isEqualTo("ApiProductsServiceTest");
    assertThat(apiProduct1.getCreatedDate()).isNotEqualTo(time1);
    assertThat(apiProduct1.getDescription()).isEqualTo("myDescription1");
    assertThat(apiProduct1.getDisplayName()).isEqualTo("myDisplayName1");
    assertThat(apiProduct1.getExternal()).isTrue();
    assertThat(apiProduct1.getLastUpdatedBy()).isEqualTo("myLastUpdatedBy1");
    assertThat(apiProduct1.getLastUpdatedDate()).isNotEqualTo(time1);
    assertThat(apiProduct1.getPlanet()).isEqualTo("PROD");
    assertThat(apiProduct1.getSourceSystem()).isEqualTo("mySourceSys1");
    assertThat(apiProduct1.getSourceSystemKey()).isEqualTo("mySourceSysKey1");
    assertThat(apiProduct1.getVisibility()).isEqualTo("myVisibility1");

  }

  @Test
  public void shouldSaveProductWithNullIdProvided() throws Exception {

    //given
    ApiProduct savedApiProduct1 = apiProductsService.saveProduct(buildTestProduct("1", time1, true, "PROD"));

    //when
    ApiProduct apiProduct1 = apiProductsService.getProduct(savedApiProduct1.getId());

    //then
    assertThat(apiProduct1).isNotNull();
    assertThat(apiProduct1.getAccess()).isEqualTo("myAccess1");
    assertThat(apiProduct1.getApprovalType()).isEqualTo("myaApprovalType1");
    assertThat(apiProduct1.getCreatedBy()).isEqualTo("ApiProductsServiceTest");
    assertThat(apiProduct1.getCreatedDate()).isNotEqualTo(time1);
    assertThat(apiProduct1.getDescription()).isEqualTo("myDescription1");
    assertThat(apiProduct1.getDisplayName()).isEqualTo("myDisplayName1");
    assertThat(apiProduct1.getExternal()).isTrue();
    assertThat(apiProduct1.getLastUpdatedBy()).isEqualTo("myLastUpdatedBy1");
    assertThat(apiProduct1.getLastUpdatedDate()).isNotEqualTo(time1);
    assertThat(apiProduct1.getPlanet()).isEqualTo("PROD");
    assertThat(apiProduct1.getSourceSystem()).isEqualTo("mySourceSys1");
    assertThat(apiProduct1.getSourceSystemKey()).isEqualTo("mySourceSysKey1");
    assertThat(apiProduct1.getVisibility()).isEqualTo("myVisibility1");

  }

  @Test
  void shouldGetProductsInternalOrExternalByPlanet() throws Exception {

    //given
    apiProductsService.saveProduct(buildTestProduct("1", time1, true, "PROD"));
    apiProductsService.saveProduct(buildTestProduct("2", time2, true, "Non-Prod"));
    apiProductsService.saveProduct(buildTestProduct("3", time3, false, "PROD"));

    //when
    List<ApiProduct> apiProducts1 = apiProductsService.getProductsInternalOrExternalByPlanet("PROD", true);
    List<ApiProduct> apiProducts2 = apiProductsService.getProductsInternalOrExternalByPlanet("Non-Prod", true);
    List<ApiProduct> apiProducts3 = apiProductsService.getProductsInternalOrExternalByPlanet("PROD", false);

    //then
    assertThat(apiProducts1).isNotNull().hasSize(1);
    ApiProduct apiProduct1 = apiProducts1.get(0);
    assertThat(apiProduct1.getAccess()).isEqualTo("myAccess1");

    assertThat(apiProducts2).isNotNull().hasSize(1);
    ApiProduct apiProduct2 = apiProducts2.get(0);
    assertThat(apiProduct2.getAccess()).isEqualTo("myAccess2");

    assertThat(apiProducts3).isNotNull().hasSize(1);
    ApiProduct apiProduct3 = apiProducts3.get(0);
    assertThat(apiProduct3.getAccess()).isEqualTo("myAccess3");

  }

  @Test
  void shouldGetNoProductsFound() {

    //given-when-then
    assertThatExceptionOfType(ProductNotFoundException.class)
        .isThrownBy(() -> {
          apiProductsService.getProductsInternalOrExternalByPlanet("notfound", true);
        })
        .withMessage("No products found.");

  }

  @Test
  void shouldUpdateProduct() throws Exception {

    //given
    ApiProduct product = apiProductsService.saveProduct(buildTestProduct("1", time1, true, "PROD"));
    product.setDisplayName("myDisplayNameUpdated");

    //when
    ApiProduct updatedProductResponse = apiProductsService.updateProduct(product, "ApiProductsServiceTest");

    //then
    assertThat(updatedProductResponse).isNotNull();
    assertThat(updatedProductResponse.getLastUpdatedBy()).isEqualTo("ApiProductsServiceTest");
    assertThat(updatedProductResponse.getLastUpdatedDate()).isNotNull();
    assertThat(updatedProductResponse.getDisplayName()).isEqualTo("myDisplayNameUpdated");

    ApiProduct updatedProductFromDb = apiProductsService.getProduct(product.getId());
    assertThat(updatedProductFromDb).isNotNull();
    assertThat(updatedProductFromDb.getLastUpdatedBy()).isEqualTo("ApiProductsServiceTest");
    assertThat(updatedProductFromDb.getLastUpdatedDate()).isNotNull();
    assertThat(updatedProductFromDb.getDisplayName()).isEqualTo("myDisplayNameUpdated");
  }

  @Test
  void shouldReturnNotFoundForUpdateProduct() throws Exception {

    //given
    ApiProduct product = buildTestProduct("1", time1, true, "PROD");
    product.setId(UUID.randomUUID());

    //when-then
    assertThatExceptionOfType(ProductNotFoundException.class)
        .isThrownBy(() -> {
          apiProductsService.updateProduct(product, "ApiProductsServiceTest");
        })
        .withMessage("Product not found for id: " + product.getId());

  }

  @Test
  void shouldReturnUnauthorizedForUpdateProduct() throws Exception {

    //given
    ApiProduct savedApiProduct1 = apiProductsService.saveProduct(buildTestProduct("1", time1, true, "PROD"));

    //when-then
    assertThatExceptionOfType(UnauthorizedException.class)
        .isThrownBy(() -> {
          apiProductsService.updateProduct(savedApiProduct1, "notTheCreatedBy");
        })
        .withMessage("User not authorized to update this resource. User must be the resource owner.");

  }

  @Test
  void shouldDeleteProduct() throws Exception {

    //given
    ApiProduct savedApiProduct1 = apiProductsService.saveProduct(buildTestProduct("1", time1, true, "PROD"));

    //when
    UUID id = savedApiProduct1.getId();
    apiProductsService.deleteProduct(id, "ApiProductsServiceTest");

    //then
    assertThatExceptionOfType(ProductNotFoundException.class)
        .isThrownBy(() -> {
          apiProductsService.getProduct(id);
        })
        .withMessage("Product not found for id: " + id);

  }

  @Test
  void shouldReturnNotFoundForDeleteProduct() throws Exception {

    //given
    final UUID id = UUID.randomUUID();

    //when-then
    assertThatExceptionOfType(ProductNotFoundException.class)
        .isThrownBy(() -> {
          apiProductsService.deleteProduct(id, "doesntMatter");
        })
        .withMessage("Product not found for id: " + id);

  }

  @Test
  void shouldReturnUnauthorizedForDeleteProduct() throws Exception {

    //given
    final UUID id = UUID.randomUUID();

    //when
    ApiProduct savedApiProduct1 = apiProductsService.saveProduct(buildTestProduct("1", time1, true, "PROD"));

    //then
    assertThatExceptionOfType(UnauthorizedException.class)
        .isThrownBy(() -> {
          apiProductsService.deleteProduct(savedApiProduct1.getId(), "notTheCreatedBy");
        })
        .withMessage("User not authorized to delete this resource. User must be the resource owner.");
  }


  private static ApiProduct buildTestProduct(String prodInc, Timestamp time, boolean external, String planet) {
    ApiProduct apiProduct = new ApiProduct();
    apiProduct.setName("myProductName" + prodInc);
    apiProduct.setAccess("myAccess" + prodInc);
    apiProduct.setApprovalType("myaApprovalType" + prodInc);
    apiProduct.setCreatedBy("ApiProductsServiceTest");
    apiProduct.setDescription("myDescription" + prodInc);
    apiProduct.setDisplayName("myDisplayName" + prodInc);
    apiProduct.setExternal(external);
    apiProduct.setLastUpdatedBy("myLastUpdatedBy" + prodInc);
    apiProduct.setLastUpdatedDate(time);
    apiProduct.setPlanet(planet);
    apiProduct.setSourceSystem("mySourceSys" + prodInc);
    apiProduct.setSourceSystemKey("mySourceSysKey" + prodInc);
    apiProduct.setVisibility("myVisibility" + prodInc);

    return apiProduct;
  }

}
