package com.lumen.apiexchange.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class InputApiRequestTests {

  @Test
  public void testSetInputApiRequest() throws Exception {
    InputApiRequest inputRes = new InputApiRequest();

    inputRes.setBypassApiAlreadyExists(true);
    inputRes.setCallAsyncBuildDeploy(true);
    inputRes.setSkipTaxonomyValidation(true);
    inputRes.setEnv("setEnv");
    inputRes.setMigrationRequest(true);
    inputRes.setTaxonomy("setTaxonomy");
    inputRes.setResourceName("setResourceName");
    inputRes.setVersion("setVersion");
    inputRes.setRoutingExpression("setRoutingExpression");
    inputRes.setSoap("setSoap");
    inputRes.setType("setType");
    inputRes.setOwningAppAppkey("setOwningAppAppkey");
    inputRes.setMalId("setMalId");
    inputRes.setDev1EndpointHostname("setDev1EndpointHostname");
    inputRes.setDev2EndpointHostname("setDev2EndpointHostname");
    inputRes.setDev3EndpointHostname("dev3endpoint");
    inputRes.setDev4EndpointHostname("setDev3EndpointHostname");
    inputRes.setTest1EndpointHostname("setTest1EndpointHostname");
    inputRes.setTest2EndpointHostname("setTest2EndpointHostname");
    inputRes.setTest3EndpointHostname("setTest3EndpointHostname");
    inputRes.setTest4EndpointHostname("setTest4EndpointHostname");
    inputRes.setMockEndpointHostname("setMockEndpointHostname");
    inputRes.setSandboxEndpointHostname("setSandboxEndpointHostname");
    inputRes.setProdEndpointHostname("setProdEndpointHostname");
    inputRes.setEndpointPath("setEndpointPath");
    inputRes.setInternal("setInternal");
    inputRes.setExternal("setExternal");
    inputRes.setProxyAuthInternal("setProxyAuthInternal");
    inputRes.setProxyAuthExternal("setProxyAuthExternal");
    inputRes.setAppkeyEnforceDigest("setAppkeyEnforceDigest");
    inputRes.setAppkeyEnforceTaxonomy("setAppkeyEnforceTaxonomy");
    inputRes.setBasicAuthGroups("setBasicAuthGroups");
    inputRes.setBasicAuthUsers("setBasicAuthUsers");
    inputRes.setEndpointAuth("setEndpointAuth");
    inputRes.setEndpointBasicAuthUserAll("setEndpointBasicAuthUserAll");
    inputRes.setEndpointBasicAuthPwAll("setEndpointBasicAuthPwAll");
    inputRes.setEndpointBasicAuthUserDev1("setEndpointBasicAuthUserDev1");
    inputRes.setEndpointBasicAuthPwDev1("setEndpointBasicAuthPwDev1");
    inputRes.setEndpointBasicAuthUserDev2("setEndpointBasicAuthUserDev2");
    inputRes.setEndpointBasicAuthPwDev2("setEndpointBasicAuthPwDev2");
    inputRes.setEndpointBasicAuthUserDev3("setEndpointBasicAuthUserDev3");
    inputRes.setEndpointBasicAuthPwDev3("setEndpointBasicAuthPwDev3");
    inputRes.setEndpointBasicAuthUserDev4("setEndpointBasicAuthUserDev4");
    inputRes.setEndpointBasicAuthPwDev4("setEndpointBasicAuthPwDev4");
    inputRes.setOauthGrantType("setOauthGrantType");
    inputRes.setOauthGrantLocation("setOauthGrantLocation");
    inputRes.setOauthTokenServiceHost("setOauthTokenServiceHost");
    inputRes.setOauthTokenServiceURI("setOauthTokenServiceURI");
    inputRes.setOauthClientId("setOauthClientId");
    inputRes.setOauthClientIdLocation("setOauthClientIdLocation");
    inputRes.setOauthSecret("setOauthSecret");
    inputRes.setOauthScope("setOauthScope");
    inputRes.setOauthScopeLocation("setOauthScopeLocation");
    inputRes.setOauthUserName("setOauthUserName");
    inputRes.setOauthpw("setOauthpw");
    inputRes.setOauthCredentialsLocation("setOauthCredentialsLocation");
    inputRes.setPingUrl("setPingUrl");
    inputRes.setDocumentationUrl("setDocumentationUrl");
    inputRes.setActive("setActive");
    inputRes.setJwtSubject("setJwtSubject");
    inputRes.setX509CertAlias("setX509CertAlias");
    inputRes.setThreatProtectionOverrides("setThreatProtectionOverrides");
    inputRes.setB2bAuthRequired("setB2bAuthRequired");
    inputRes.setB2bCustomerNumberRequired("setB2bCustomerNumberRequired");
    inputRes.setB2bBillingAccountNumberRequired("setB2bBillingAccountNumberRequired");
    inputRes.setCreatedBy("setCreatedBy");
    inputRes.setCreatedDate("setCreatedDate");
    inputRes.setUpdatedBy("setUpdatedBy");
    inputRes.setUpdatedDate("setUpdatedDate");
    inputRes.setGuid("setGuid");
    inputRes.setMediatedResourceId("setMediatedResourceId");
    inputRes.setRequestorEmail("setRequestorEmail");
    inputRes.setSource("setSource");
    inputRes.setThrottlingRequestsPerSec("setThrottlingRequestsPerSec");
    inputRes.setTimeoutSecs("setTimeoutSecs");
    inputRes.setConnectionKeepAlive("setConnectionKeepAlive");
    inputRes.setReplaceUrlFromValue("setReplaceUrlFromValue");
    inputRes.setReplaceUrlToValue("setReplaceUrlToValue");
    inputRes.setEnforceHttps("setEnforceHttps");
    inputRes.setSecurityRequestNumber("setSecurityRequestNumber");

    assertTrue(inputRes.bypassApiAlreadyExists());
    assertTrue(inputRes.callAsyncBuildDeploy());
    assertTrue(inputRes.skipTaxonomyValidation());
    assertThat(inputRes.getEnv()).isEqualTo("setEnv");
    assertTrue(inputRes.isMigrationRequest());
    assertThat(inputRes.getTaxonomy()).isEqualTo("setTaxonomy");
    assertThat(inputRes.getResourceName()).isEqualTo("setResourceName");
    assertThat(inputRes.getVersion()).isEqualTo("setVersion");
    assertThat(inputRes.getRoutingExpression()).isEqualTo("setRoutingExpression");
    assertThat(inputRes.getSoap()).isEqualTo("setSoap");
    assertThat(inputRes.getType()).isEqualTo("setType");
    assertThat(inputRes.getOwningAppAppkey()).isEqualTo("setOwningAppAppkey");
    assertThat(inputRes.getMalId()).isEqualTo("setMalId");
    assertThat(inputRes.getDev1EndpointHostname()).isEqualTo("setDev1EndpointHostname");
    assertThat(inputRes.getDev2EndpointHostname()).isEqualTo("setDev2EndpointHostname");
    assertThat(inputRes.getDev3EndpointHostname()).isEqualTo("dev3endpoint");
    assertThat(inputRes.getDev4EndpointHostname()).isEqualTo("setDev3EndpointHostname");
    assertThat(inputRes.getTest1EndpointHostname()).isEqualTo("setTest1EndpointHostname");
    assertThat(inputRes.getTest2EndpointHostname()).isEqualTo("setTest2EndpointHostname");
    assertThat(inputRes.getTest3EndpointHostname()).isEqualTo("setTest3EndpointHostname");
    assertThat(inputRes.getTest4EndpointHostname()).isEqualTo("setTest4EndpointHostname");
    assertThat(inputRes.getMockEndpointHostname()).isEqualTo("setMockEndpointHostname");
    assertThat(inputRes.getSandboxEndpointHostname()).isEqualTo("setSandboxEndpointHostname");
    assertThat(inputRes.getProdEndpointHostname()).isEqualTo("setProdEndpointHostname");
    assertThat(inputRes.getEndpointPath()).isEqualTo("setEndpointPath");
    assertThat(inputRes.getInternal()).isEqualTo("setInternal");
    assertThat(inputRes.getExternal()).isEqualTo("setExternal");
    assertThat(inputRes.getProxyAuthInternal()).isEqualTo("setProxyAuthInternal");
    assertThat(inputRes.getProxyAuthExternal()).isEqualTo("setProxyAuthExternal");
    assertThat(inputRes.getAppkeyEnforceDigest()).isEqualTo("setAppkeyEnforceDigest");
    assertThat(inputRes.getAppkeyEnforceTaxonomy()).isEqualTo("setAppkeyEnforceTaxonomy");
    assertThat(inputRes.getBasicAuthGroups()).isEqualTo("setBasicAuthGroups");
    assertThat(inputRes.getBasicAuthUsers()).isEqualTo("setBasicAuthUsers");
    assertThat(inputRes.getEndpointAuth()).isEqualTo("setEndpointAuth");
    assertThat(inputRes.getEndpointBasicAuthUserAll()).isEqualTo("setEndpointBasicAuthUserAll");
    assertThat(inputRes.getEndpointBasicAuthPwAll()).isEqualTo("setEndpointBasicAuthPwAll");
    assertThat(inputRes.getEndpointBasicAuthUserDev1()).isEqualTo("setEndpointBasicAuthUserDev1");
    assertThat(inputRes.getEndpointBasicAuthPwDev1()).isEqualTo("setEndpointBasicAuthPwDev1");
    assertThat(inputRes.getEndpointBasicAuthUserDev2()).isEqualTo("setEndpointBasicAuthUserDev2");
    assertThat(inputRes.getEndpointBasicAuthPwDev2()).isEqualTo("setEndpointBasicAuthPwDev2");
    assertThat(inputRes.getEndpointBasicAuthUserDev3()).isEqualTo("setEndpointBasicAuthUserDev3");
    assertThat(inputRes.getEndpointBasicAuthPwDev3()).isEqualTo("setEndpointBasicAuthPwDev3");
    assertThat(inputRes.getEndpointBasicAuthUserDev4()).isEqualTo("setEndpointBasicAuthUserDev4");
    assertThat(inputRes.getEndpointBasicAuthPwDev4()).isEqualTo("setEndpointBasicAuthPwDev4");
    assertThat(inputRes.getOauthGrantType()).isEqualTo("setOauthGrantType");
    assertThat(inputRes.getOauthGrantLocation()).isEqualTo("setOauthGrantLocation");
    assertThat(inputRes.getOauthTokenServiceHost()).isEqualTo("setOauthTokenServiceHost");
    assertThat(inputRes.getOauthTokenServiceURI()).isEqualTo("setOauthTokenServiceURI");
    assertThat(inputRes.getOauthClientId()).isEqualTo("setOauthClientId");
    assertThat(inputRes.getOauthClientIdLocation()).isEqualTo("setOauthClientIdLocation");
    assertThat(inputRes.getOauthSecret()).isEqualTo("setOauthSecret");
    assertThat(inputRes.getOauthScope()).isEqualTo("setOauthScope");
    assertThat(inputRes.getOauthScopeLocation()).isEqualTo("setOauthScopeLocation");
    assertThat(inputRes.getOauthUserName()).isEqualTo("setOauthUserName");
    assertThat(inputRes.getOauthpw()).isEqualTo("setOauthpw");
    assertThat(inputRes.getOauthCredentialsLocation()).isEqualTo("setOauthCredentialsLocation");
    assertThat(inputRes.getPingUrl()).isEqualTo("setPingUrl");
    assertThat(inputRes.getDocumentationUrl()).isEqualTo("setDocumentationUrl");
    assertThat(inputRes.getActive()).isEqualTo("setActive");
    assertThat(inputRes.getJwtSubject()).isEqualTo("setJwtSubject");
    assertThat(inputRes.getX509CertAlias()).isEqualTo("setX509CertAlias");
    assertThat(inputRes.getThreatProtectionOverrides()).isEqualTo("setThreatProtectionOverrides");
    assertThat(inputRes.getB2bAuthRequired()).isEqualTo("setB2bAuthRequired");
    assertThat(inputRes.getB2bCustomerNumberRequired()).isEqualTo("setB2bCustomerNumberRequired");
    assertThat(inputRes.getB2bBillingAccountNumberRequired()).isEqualTo("setB2bBillingAccountNumberRequired");
    assertThat(inputRes.getCreatedBy()).isEqualTo("setCreatedBy");
    assertThat(inputRes.getCreatedDate()).isEqualTo("setCreatedDate");
    assertThat(inputRes.getUpdatedBy()).isEqualTo("setUpdatedBy");
    assertThat(inputRes.getUpdatedDate()).isEqualTo("setUpdatedDate");
    assertThat(inputRes.getGuid()).isEqualTo("setGuid");
    assertThat(inputRes.getMediatedResourceId()).isEqualTo("setMediatedResourceId");
    assertThat(inputRes.getRequestorEmail()).isEqualTo("setRequestorEmail");
    assertThat(inputRes.getSource()).isEqualTo("setSource");
    assertThat(inputRes.getThrottlingRequestsPerSec()).isEqualTo("setThrottlingRequestsPerSec");
    assertThat(inputRes.getTimeoutSecs()).isEqualTo("setTimeoutSecs");
    assertThat(inputRes.getConnectionKeepAlive()).isEqualTo("setConnectionKeepAlive");
    assertThat(inputRes.getReplaceUrlFromValue()).isEqualTo("setReplaceUrlFromValue");
    assertThat(inputRes.getReplaceUrlToValue()).isEqualTo("setReplaceUrlToValue");
    assertThat(inputRes.getEnforceHttps()).isEqualTo("setEnforceHttps");
    assertThat(inputRes.getSecurityRequestNumber()).isEqualTo("setSecurityRequestNumber");

  }

  @Test
  public void testSetOwningAppAppkeyTrim() throws Exception {
    InputApiRequest inputRes = new InputApiRequest();

    inputRes.setOwningAppAppkey(" setOwningAppAppkey");
    assertThat(inputRes.getOwningAppAppkey()).isEqualTo("setOwningAppAppkey");

    inputRes.setOwningAppAppkey("setOwningAppAppkey ");
    assertThat(inputRes.getOwningAppAppkey()).isEqualTo("setOwningAppAppkey");
  }

  @Test
  public void testSetHostnameTrim() throws Exception {
    InputApiRequest inputRes = new InputApiRequest();

    inputRes.setDev1EndpointHostname(" setDev1EndpointHostname ");
    inputRes.setDev2EndpointHostname(" setDev2EndpointHostname ");
    inputRes.setDev3EndpointHostname(" setDev3EndpointHostname ");
    inputRes.setDev4EndpointHostname(" setDev4EndpointHostname ");
    inputRes.setTest1EndpointHostname(" setTest1EndpointHostname ");
    inputRes.setTest2EndpointHostname(" setTest2EndpointHostname ");
    inputRes.setTest3EndpointHostname(" setTest3EndpointHostname ");
    inputRes.setTest4EndpointHostname(" setTest4EndpointHostname ");
    inputRes.setMockEndpointHostname(" setMockEndpointHostname ");
    inputRes.setSandboxEndpointHostname(" setSandboxEndpointHostname ");
    inputRes.setProdEndpointHostname(" setProdEndpointHostname ");
    assertThat(inputRes.getDev1EndpointHostname()).isEqualTo("setDev1EndpointHostname");
    assertThat(inputRes.getDev2EndpointHostname()).isEqualTo("setDev2EndpointHostname");
    assertThat(inputRes.getDev3EndpointHostname()).isEqualTo("setDev3EndpointHostname");
    assertThat(inputRes.getDev4EndpointHostname()).isEqualTo("setDev4EndpointHostname");
    assertThat(inputRes.getTest1EndpointHostname()).isEqualTo("setTest1EndpointHostname");
    assertThat(inputRes.getTest2EndpointHostname()).isEqualTo("setTest2EndpointHostname");
    assertThat(inputRes.getTest3EndpointHostname()).isEqualTo("setTest3EndpointHostname");
    assertThat(inputRes.getTest4EndpointHostname()).isEqualTo("setTest4EndpointHostname");
    assertThat(inputRes.getMockEndpointHostname()).isEqualTo("setMockEndpointHostname");
    assertThat(inputRes.getSandboxEndpointHostname()).isEqualTo("setSandboxEndpointHostname");
    assertThat(inputRes.getProdEndpointHostname()).isEqualTo("setProdEndpointHostname");

  }

  @Test
  public void testSetEndpointPathTrim() throws Exception {
    InputApiRequest inputRes = new InputApiRequest();

    inputRes.setEndpointPath(" setEndpointPath ");
    assertThat(inputRes.getEndpointPath()).isEqualTo("setEndpointPath");
  }

  @Test
  public void testSetMigrationRequest() throws Exception {
    InputApiRequest inputRes = new InputApiRequest();

    inputRes.setMigrationRequest(false);

    assertTrue(!inputRes.isMigrationRequest());
  }

  @Test
  public void testInputApiRequestToString() throws Exception {
    InputApiRequest inputRes = new InputApiRequest();

    inputRes.setSecurityRequestNumber("setSecurityRequestNumber");
    String myString = inputRes.toString();

    assertTrue(myString.contains("setSecurityRequestNumber"));
  }

  @Test
  public void testInputApiRequestToEmailString() throws Exception {
    InputApiRequest inputRes = new InputApiRequest();

    inputRes.setSecurityRequestNumber("setSecurityRequestNumber");
    String myString = inputRes.toEmailString();

    assertTrue(myString.contains("setSecurityRequestNumber"));
  }

}
