package com.lumen.apiexchange.service;

import static org.assertj.core.api.Assertions.assertThat;

import com.lumen.apiexchange.IntegrationTestBase;
import com.lumen.apiexchange.entity.ApiDocumentation;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("it")
@AutoConfigureWireMock(port = 0)
public class ApiServiceTest extends IntegrationTestBase {

  @Autowired
  private ApiService apiService;

  @Test
  public void shouldSaveDocumentation() {

    final UUID myDocument = UUID.randomUUID();

    assertThat(apiService.getApiDocumentation(myDocument)).hasSize(0);

    apiService.postApiDocumentation(getApiDocumentation(myDocument));

    assertThat(apiService.getApiDocumentation(myDocument)).hasSize(1);
  }
  private static ApiDocumentation getApiDocumentation(UUID myDocument) {
    ApiDocumentation apiDoc = new ApiDocumentation();
    apiDoc.setApiId(myDocument);
    apiDoc.setApiName("myapi");
    return apiDoc;
  }

}
