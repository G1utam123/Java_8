package com.lumen.apiexchange.client.apigee;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.delete;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.put;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;

import com.lumen.apiexchange.IntegrationTestBase;
import com.lumen.apiexchange.config.ApigeeMgmtApiConfigProperties;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.apigee.ApigeeProduct;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.Access;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.AccessLocation;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.Planet;
import com.lumen.apiexchange.model.apigee.ApigeeProductRequest;
import com.lumen.apiexchange.model.apigee.ApigeeProductRequest.ApprovalType;
import com.lumen.apiexchange.model.apigee.ApigeeProductResponse;
import com.lumen.apiexchange.model.apigee.ApigeeProxy;
import com.lumen.apiexchange.util.BuildHandler;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.client.HttpClientErrorException;

@SpringBootTest
@ActiveProfiles("it")
@AutoConfigureWireMock(port = 0)
class ApigeeMgmtApiClientTest extends IntegrationTestBase {

  @Autowired
  private ApigeeMgmtApiClient apimClient;

  @Autowired
  private ApigeeMgmtApiConfigProperties apigeeMgmtApiConfigProperties;

  @Test
  void getProductsNonProdInternal() {

    //given
    stubFor(get(urlEqualTo("/v1/o/int/apiproducts?expand=true"))
            .withHeader("Authorization",
                containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("apigee-apim-getproducts-nonprod-int-response-ok.json")
                    .withHeader("Content-Type", "application/json")));

    //when
    ApigeeProductResponse products = apimClient.getProducts("NONPROD", "INTERNAL");

    //then
    assertThat(products.getApiProduct()).hasSize(5);
    ApigeeProduct product = products.getApiProduct().get(0);
    assertThat(product.getName()).isEqualTo("Nonprod-Internal");

  }

  @Test
  void getProductsNonProdExternal() {

    //given
    stubFor(get(urlEqualTo("/v1/o/ext/apiproducts?expand=true"))
            .withHeader("Authorization",
                containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("apigee-apim-getproducts-nonprod-ext-response-ok.json")
                    .withHeader("Content-Type", "application/json")));

    //when
    ApigeeProductResponse products = apimClient.getProducts("NONPROD", "EXTERNAL");

    //then
    assertThat(products.getApiProduct()).hasSize(5);
    ApigeeProduct product = products.getApiProduct().get(1);
    assertThat(product.getName()).isEqualTo("Nonprod-External2");

  }

  @Test
  void getProductsProdInternal() {

    //given
    stubFor(get(urlEqualTo("/v1/o/int/apiproducts?expand=true"))
            .withHeader("Authorization",
                containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerProdBasicauth()))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("apigee-apim-getproducts-prod-int-response-ok.json")
                    .withHeader("Content-Type", "application/json")));

    //when
    ApigeeProductResponse products = apimClient.getProducts("PROD", "INTERNAL");

    //then
    assertThat(products.getApiProduct()).hasSize(5);
    ApigeeProduct product = products.getApiProduct().get(2);
    assertThat(product.getName()).isEqualTo("Prod-Internal");

  }

  @Test
  void getProductsProdExternal() {

    //given
    stubFor(get(urlEqualTo("/v1/o/ext/apiproducts?expand=true"))
            .withHeader("Authorization",
                containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerProdBasicauth()))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("apigee-apim-getproducts-prod-ext-response-ok.json")
                    .withHeader("Content-Type", "application/json")));

    //when
    ApigeeProductResponse products = apimClient.getProducts("PROD", "EXTERNAL");

    //then
    assertThat(products.getApiProduct()).hasSize(5);
    ApigeeProduct product = products.getApiProduct().get(3);
    assertThat(product.getName()).isEqualTo("Prod-External");

  }

  @Test
  void getProductNonProdInternal() {

    //given
    stubFor(get(urlEqualTo("/v1/o/int/apiproducts/OrderStatus"))
            .withHeader("Authorization",
                containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("apigee-apim-getproduct-response-ok.json")
                    .withHeader("Content-Type", "application/json")));

    //when
    ApigeeProduct product = apimClient.getProduct("OrderStatus", "NONPROD", "INTERNAL");

    //then
    assertThat(product.getName()).isEqualTo("OrderStatus");

  }

  @Test
  void getProxyNonProdInternal() {

    //given
    String proxyName = BuildHandler.buildApigeeProxyName("v1", "jeaglem", "basicAuth1",
        "eb260cea-edf1-425f-902b-efa5763b490f");

    stubFor(get(urlEqualTo("/v1/o/int/apis/" + proxyName))
            .withHeader("Authorization",
                containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("apigee-apim-getproxy-response-ok.json")
                    .withHeader("Content-Type", "application/json")));

    //when
    ApigeeProxy proxy = apimClient.getProxy(proxyName, "NONPROD", "INTERNAL");

    //then
    assertThat(proxy.getName()).isEqualTo(proxyName);

  }

  @Test
  void updateProductNonProdInternal() {

    //given
    stubFor(put(urlEqualTo("/v1/o/int/apiproducts/OrderStatus"))
            .withHeader("Authorization",
                containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("apigee-apim-getproduct-response-ok.json")
                    .withHeader("Content-Type", "application/json")));

    //when
    ApigeeProductHubRequest product = buildTestApigeeProductRequest("1", ApprovalType.manual, 
        Planet.NONPROD, AccessLocation.INTERNAL);
    product.getApigeeProductRequest().setName("OrderStatus");
    ApigeeProduct updatedProduct = apimClient.updateProduct(product.getApigeeProductRequest().getName(), product);

    //then
    assertThat(updatedProduct.getName()).isEqualTo("OrderStatus");

  }

  @Test
  void shouldGetProductNotFound() {

    //given
    stubFor(get(urlEqualTo("/v1/o/int/apiproducts/NoProductToFind"))
            .withHeader("Authorization",
                containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
            .willReturn(aResponse()
                    .withStatus(404)
                    .withBodyFile("apigee-apim-getproduct-not-found-response-404.json")
                    .withHeader("Content-Type", "application/json")));
    stubFor(put(urlEqualTo("/v1/o/int/apiproducts/NoProductToFind"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(404)
                .withBodyFile("apigee-apim-getproduct-not-found-response-404.json")
                .withHeader("Content-Type", "application/json")));
    stubFor(delete(urlEqualTo("/v1/o/int/apiproducts/NoProductToFind"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(404)
                .withBodyFile("apigee-apim-getproduct-not-found-response-404.json")
                .withHeader("Content-Type", "application/json")));
    
    ApigeeProductHubRequest product = buildTestApigeeProductRequest("1", ApprovalType.manual, 
        Planet.NONPROD, AccessLocation.INTERNAL);
    String productName = "NoProductToFind"; 
    product.getApigeeProductRequest().setName(productName);

    //when-then
    assertThatExceptionOfType(HttpClientErrorException.class)
      .isThrownBy(() -> {
        apimClient.getProduct(productName, "NONPROD", "INTERNAL");
      })
        .withMessageContaining("404 Not Found");
    assertThatExceptionOfType(HttpClientErrorException.class)
    .isThrownBy(() -> {
      apimClient.updateProduct(productName, product);
    })
        .withMessageContaining("404 Not Found");
    assertThatExceptionOfType(HttpClientErrorException.class)
    .isThrownBy(() -> {
      apimClient.deleteProduct(productName, "NONPROD", "INTERNAL");
    })
        .withMessageContaining("404 Not Found");

  }

  @Test
  void shouldGetProxyNotFound() {

    //given
    String proxyName = "Esp_IntMed_Partner_v1_jeaglem_basicAuth1_eb260cea-edf1-425f-902b-efa5763b490f";
    stubFor(get(urlEqualTo("/v1/o/int/apis/" + proxyName))
            .withHeader("Authorization",
                containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
            .willReturn(aResponse()
                    .withStatus(404)
                    .withBodyFile("apigee-apim-getproxy-not-found-response-404.json")
                    .withHeader("Content-Type", "application/json")));

    //when-then
    assertThatExceptionOfType(HttpClientErrorException.class)
      .isThrownBy(() -> {
        apimClient.getProxy(proxyName, "NONPROD", "INTERNAL");
      })
        .withMessageContaining("404 Not Found");

  }

  @Test
  void shouldGetEnvironments()  {

    //given
    stubFor(get(urlEqualTo("/v1/o/int/environments"))
            .withHeader("Authorization",
                containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("apigee-apim-getenvironments-nonprod-int-response-ok.json")
                    .withHeader("Content-Type", "application/json")));
    stubFor(get(urlEqualTo("/v1/o/ext/environments"))
            .withHeader("Authorization",
                containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth()))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("apigee-apim-getenvironments-nonprod-ext-response-ok.json")
                    .withHeader("Content-Type", "application/json")));
    stubFor(get(urlEqualTo("/v1/o/int/environments"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(200)
                .withBodyFile("apigee-apim-getenvironments-prod-int-response-ok.json")
                .withHeader("Content-Type", "application/json")));
    stubFor(get(urlEqualTo("/v1/o/ext/environments"))
        .withHeader("Authorization",
            containing("Basic " + apigeeMgmtApiConfigProperties.getManagementServerProdBasicauth()))
        .willReturn(aResponse()
                .withStatus(200)
                .withBodyFile("apigee-apim-getenvironments-prod-ext-response-ok.json")
                .withHeader("Content-Type", "application/json")));
    
    //when
    List<String> envsNonProdInt = apimClient.getEnvironments("NONPROD", "INTERNAL");
    List<String> envsNonProdExt = apimClient.getEnvironments("NONPROD", "EXTERNAL");
    List<String> envsProdInt = apimClient.getEnvironments("PROD", "INTERNAL");
    List<String> envsProdExt = apimClient.getEnvironments("PROD", "EXTERNAL");

    //then
    assertThat(envsNonProdInt).hasSize(11);
    assertThat(envsNonProdExt).hasSize(10);
    assertThat(envsProdInt).hasSize(1);
    assertThat(envsProdExt).hasSize(3);

  }

  @Test
  void shouldGetApigeeMgmtServerUrl() throws InternalServerException {

    //given-when
    String nonProdServerUrl = apimClient.getApigeeMgmtServerUrl("NONPROD");
    String prodServerUrl = apimClient.getApigeeMgmtServerUrl("PROD");

    //then
    assertThat(nonProdServerUrl).isEqualTo(apigeeMgmtApiConfigProperties.getManagementServerNonProdUrl());
    assertThat(prodServerUrl).isEqualTo(apigeeMgmtApiConfigProperties.getManagementServerProdUrl());

  }

  @Test
  void shouldGetApigeeMgmtServerCreds() throws InternalServerException {

    //given-when
    String nonProdCreds = apimClient.getApigeeMgmtServerCreds("NONPROD");
    String prodCreds = apimClient.getApigeeMgmtServerCreds("PROD");

    //then
    assertThat(nonProdCreds).isEqualTo(apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth());
    assertThat(prodCreds).isEqualTo(apigeeMgmtApiConfigProperties.getManagementServerProdBasicauth());

  }

  @Test
  void shouldGetShortOrg() throws InternalServerException {

    //given-when
    String internalOrg = apimClient.getShortOrg("INTERNAL");
    String externalOrg = apimClient.getShortOrg("EXTERNAL");

    //then
    assertThat(internalOrg).isEqualTo("int");
    assertThat(externalOrg).isEqualTo("ext");

  }

  private static ApigeeProductHubRequest buildTestApigeeProductRequest(String prodInc, 
      ApprovalType approvalType, Planet planet, AccessLocation accessLocation) {
    
    ApigeeProductHubRequest hubProduct = new ApigeeProductHubRequest();
    hubProduct.setAccess(Access.PRIVATE);
    hubProduct.setAccessLocation(accessLocation);
    hubProduct.setPlanet(planet);
    hubProduct.setProductOwner("product.owner@lumen.com");
    
    ApigeeProductRequest product = new ApigeeProductRequest();
    product.setApiResources(new ArrayList<String>(Arrays.asList("/ResourceA" + prodInc, "/ResourceB" + prodInc)));
    product.setApprovalType(approvalType);
    product.setDescription("myDescription" + prodInc);
    product.setDisplayName("myDisplayName" + prodInc);
    product.setEnvironments(new ArrayList<String>(Arrays.asList("Dev" + prodInc, "Test" + prodInc)));
    product.setName("myProductName" + prodInc);
    product.setProxies(new ArrayList<String>(Arrays.asList("ProxyA-" + prodInc, "ProxyB-" + prodInc)));
    product.setScopes(new ArrayList<String>());
    hubProduct.setApigeeProductRequest(product);
    return hubProduct;
  
  }

}