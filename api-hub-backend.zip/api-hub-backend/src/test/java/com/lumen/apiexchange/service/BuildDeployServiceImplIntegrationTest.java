package com.lumen.apiexchange.service;

import static org.awaitility.Awaitility.await;
import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.put;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo;
import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.lumen.apiexchange.IntegrationTestBase;
import com.lumen.apiexchange.exception.PartnerProxyBuildException;
import com.lumen.apiexchange.model.BuildDeployResult;
import com.lumen.apiexchange.model.InputApiRequest;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("it")
@AutoConfigureWireMock(port = 0)
@ExtendWith(OutputCaptureExtension.class)
public class BuildDeployServiceImplIntegrationTest extends IntegrationTestBase {
  
  @Autowired
  BuildDeployServiceImpl buildDeployServiceImpl;
  
  private static final String APIGEE = "apigee";
  private static final String PROXY_NAME = "/Application/v1/Apigee/resourceName";
  private final String DEV1 = "dev1";
  private final String DEV1_INTERNAL = "dev1-internal";
  private final String PROD = "prod";
  private final String PROD_INTERNAL = "prod-internal";
  
  private InputApiRequest setupInuptApiRequest() {
    InputApiRequest inputRes = new InputApiRequest();
    inputRes.setTaxonomy("Application/Apigee");
    inputRes.setVersion("v1");
    inputRes.setResourceName("resourceName");
    inputRes.setType("Inbound");
    inputRes.setOwningAppAppkey("AppKey");
    inputRes.setMalId("MalID1234");
    inputRes.setDev1EndpointHostname("http://dev1.com");
    inputRes.setEndpointPath("/doSomething");
    inputRes.setInternal("true");
    inputRes.setExternal("true");
    inputRes.setProxyAuthInternal("appkey");
    inputRes.setProxyAuthExternal("appkey");
    inputRes.setEndpointAuth("none");
    inputRes.setGuid("Guid");
    inputRes.setRequestorEmail("email.com");
    return inputRes;
  }

  @Test
  @Timeout(value = 4000, unit = TimeUnit.MILLISECONDS)
  void shouldGetApiProxyDetailsInParallel() throws Exception {

    // given
    InputApiRequest inputapirequest = setupInuptApiRequest();
    
    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing(APIGEE))
        .withQueryParam("resourceTaxonomy", equalTo(inputapirequest.getTaxonomy()))
        .withQueryParam("version", equalTo(inputapirequest.getVersion()))
        .withQueryParam("resourceName", equalTo(inputapirequest.getResourceName()))
        .willReturn(aResponse()
            .withStatus(200)
            .withFixedDelay(500)
            .withBodyFile("esp-mediated-api-lookup-api-does-not-exist-response.json")
            .withHeader("Content-Type", "application/json")));

    // when
    buildDeployServiceImpl.validateIfProxyAlreadyExists(inputapirequest);

    // then
    //should not receive timeout
  }
  
  @Test
  void buildDeployApiTest() {
    
    // given
    InputApiRequest inputapirequest = setupInuptApiRequest();
    inputapirequest.setExternal("false");
    
//    given(buildDeployServiceImpl.getEnv("host"))
//        .willReturn(DEV1);
    
    stubFor(get(urlEqualTo("/Enterprise/v1/Routing/taxonomy"))
        .withHeader("X-Application-Key", containing("APPKEY966252019031223364839633907"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-get-taxonomies-response.json")
            .withHeader("Content-Type", "application/json")));
    
    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing(APIGEE))
        .withQueryParam("resourceTaxonomy", equalTo(inputapirequest.getTaxonomy()))
        .withQueryParam("version", equalTo(inputapirequest.getVersion()))
        .withQueryParam("resourceName", equalTo(inputapirequest.getResourceName()))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-mediated-api-lookup-api-does-not-exist-response.json")
            .withHeader("Content-Type", "application/json")));

    stubFor(post(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing(inputapirequest.getRequestorEmail()))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-mediated-resource-build-response001.json")
            .withHeader("Content-Type", "application/json")));
    
    stubFor(put(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource/59698/deployInternal"))
        .withHeader("X-Username", containing(APIGEE))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")));
    
    //when
    BuildDeployResult buildDeployResult = buildDeployServiceImpl.buildDeployApi(inputapirequest);
  
    //then
    assertThat(buildDeployResult).isNotNull();
    assertThat(buildDeployResult.getProxy()).isEqualTo(PROXY_NAME);
    assertThat(buildDeployResult.getGuid()).isNotEmpty();
    assertThat(buildDeployResult.getProxyBuiltInEnvironments()).contains(DEV1);
    assertThat(buildDeployResult.getProxyDeployedToEnvironments()).contains(DEV1_INTERNAL);
    assertThat(buildDeployResult.getProxyNotBuiltInEnvironments()).isEmpty();
    assertThat(buildDeployResult.getProxyNotDeployedToEnvironments()).isEmpty();
  }
  
  @Test
  void shouldIgnoreApiAlreadyExist() {
    
    // given
    InputApiRequest inputapirequest = setupInuptApiRequest();
    inputapirequest.setDev1EndpointHostname(null);
    inputapirequest.setProdEndpointHostname("http://prod.com");
    inputapirequest.setExternal("false");
    inputapirequest.setBypassApiAlreadyExists(true);
    
    stubFor(get(urlEqualTo("/Enterprise/v1/Routing/taxonomy"))
        .withHeader("X-Application-Key", containing("APPKEY966252019031223364839633907"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-get-taxonomies-response.json")
            .withHeader("Content-Type", "application/json")));
    
    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing(APIGEE))
        .withQueryParam("resourceTaxonomy", equalTo(inputapirequest.getTaxonomy()))
        .withQueryParam("version", equalTo(inputapirequest.getVersion()))
        .withQueryParam("resourceName", equalTo(inputapirequest.getResourceName()))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-mediated-api-lookup-api-exist-single-response.json")
            .withHeader("Content-Type", "application/json")));

    stubFor(post(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing(inputapirequest.getRequestorEmail()))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-mediated-resource-build-response001.json")
            .withHeader("Content-Type", "application/json")));
    
    stubFor(put(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource/59698/deployInternal"))
        .withHeader("X-Username", containing(APIGEE))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")));

    //when
    BuildDeployResult buildDeployResult = buildDeployServiceImpl.buildDeployApi(inputapirequest);
    
    //then
    assertThat(buildDeployResult).isNotNull();
    assertThat(buildDeployResult.getProxy()).isEqualTo(PROXY_NAME);
    assertThat(buildDeployResult.getGuid()).isNotEmpty();
  }

  @Test
  void buildProxyEspExceptionTest() {
    
    // given
    InputApiRequest inputapirequest = setupInuptApiRequest();
    inputapirequest.setExternal("false");
    
    stubFor(get(urlEqualTo("/Enterprise/v1/Routing/taxonomy"))
        .withHeader("X-Application-Key", containing("APPKEY966252019031223364839633907"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-get-taxonomies-response.json")
            .withHeader("Content-Type", "application/json")));
    
    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing(APIGEE))
        .withQueryParam("resourceTaxonomy", equalTo(inputapirequest.getTaxonomy()))
        .withQueryParam("version", equalTo(inputapirequest.getVersion()))
        .withQueryParam("resourceName", equalTo(inputapirequest.getResourceName()))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-mediated-api-lookup-api-does-not-exist-response.json")
            //.withBodyFile("esp-mediated-api-lookup-api-exist-response.json")
            .withHeader("Content-Type", "application/json")));

    stubFor(post(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing(inputapirequest.getRequestorEmail()))
        .willReturn(aResponse()
            .withStatus(500)));
    
  //when
    BuildDeployResult buildDeployResult = buildDeployServiceImpl.buildDeployApi(inputapirequest);
    
    assertThat(buildDeployResult).isNotNull();
    assertThat(buildDeployResult.getProxy()).isEqualTo(PROXY_NAME);
    assertThat(buildDeployResult.getGuid()).isNotEmpty();
    assertThat(buildDeployResult.getProxyBuiltInEnvironments()).isEmpty();
    assertThat(buildDeployResult.getProxyDeployedToEnvironments()).isEmpty();
    assertThat(buildDeployResult.getProxyNotBuiltInEnvironments()).contains(DEV1);
    assertThat(buildDeployResult.getProxyNotDeployedToEnvironments()).contains(DEV1);
  }
  
  @Test
  void deployProxyHttpStatus400Test() {
    
    // given
    InputApiRequest inputapirequest = setupInuptApiRequest();
    inputapirequest.setExternal("false");
    
    stubFor(get(urlEqualTo("/Enterprise/v1/Routing/taxonomy"))
        .withHeader("X-Application-Key", containing("APPKEY966252019031223364839633907"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-get-taxonomies-response.json")
            .withHeader("Content-Type", "application/json")));
    
    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing(APIGEE))
        .withQueryParam("resourceTaxonomy", equalTo(inputapirequest.getTaxonomy()))
        .withQueryParam("version", equalTo(inputapirequest.getVersion()))
        .withQueryParam("resourceName", equalTo(inputapirequest.getResourceName()))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-mediated-api-lookup-api-does-not-exist-response.json")
            .withHeader("Content-Type", "application/json")));

    stubFor(post(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing(inputapirequest.getRequestorEmail()))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-mediated-resource-build-response001.json")
            .withHeader("Content-Type", "application/json")));
    
    stubFor(put(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource/59698/deployInternal"))
        .withHeader("X-Username", containing(APIGEE))
        .willReturn(aResponse()
            .withStatus(400)
            .withHeader("Content-Type", "application/json")));
    
    //when
    BuildDeployResult buildDeployResult = buildDeployServiceImpl.buildDeployApi(inputapirequest);

    //then
    assertThat(buildDeployResult).isNotNull();
    assertThat(buildDeployResult.getProxy()).isEqualTo(PROXY_NAME);
    assertThat(buildDeployResult.getGuid()).isNotEmpty();
    assertThat(buildDeployResult.getProxyBuiltInEnvironments()).contains(DEV1);
    assertThat(buildDeployResult.getProxyDeployedToEnvironments()).isEmpty();
    assertThat(buildDeployResult.getProxyNotBuiltInEnvironments()).isEmpty();
    assertThat(buildDeployResult.getProxyNotDeployedToEnvironments()).contains(DEV1_INTERNAL);
  }

  @Test
  void DeployProxyEspExceptionTest() {
    
    // given
    InputApiRequest inputapirequest = setupInuptApiRequest();
    inputapirequest.setExternal("false");
    
    stubFor(get(urlEqualTo("/Enterprise/v1/Routing/taxonomy"))
        .withHeader("X-Application-Key", containing("APPKEY966252019031223364839633907"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-get-taxonomies-response.json")
            .withHeader("Content-Type", "application/json")));
    
    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing(APIGEE))
        .withQueryParam("resourceTaxonomy", equalTo(inputapirequest.getTaxonomy()))
        .withQueryParam("version", equalTo(inputapirequest.getVersion()))
        .withQueryParam("resourceName", equalTo(inputapirequest.getResourceName()))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-mediated-api-lookup-api-does-not-exist-response.json")
            .withHeader("Content-Type", "application/json")));

    stubFor(post(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing(inputapirequest.getRequestorEmail()))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-mediated-resource-build-response001.json")
            .withHeader("Content-Type", "application/json")));
    
    stubFor(put(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource/59698/deployInternal"))
        .withHeader("X-Username", containing(APIGEE))
        .willReturn(aResponse()
            .withStatus(500)
            .withHeader("Content-Type", "application/json")));
    
    //when
    BuildDeployResult buildDeployResult = buildDeployServiceImpl.buildDeployApi(inputapirequest);

    //then
    assertThat(buildDeployResult).isNotNull();
    assertThat(buildDeployResult.getProxy()).isEqualTo(PROXY_NAME);
    assertThat(buildDeployResult.getGuid()).isNotEmpty();
    assertThat(buildDeployResult.getProxyBuiltInEnvironments()).contains(DEV1);
    assertThat(buildDeployResult.getProxyDeployedToEnvironments()).isEmpty();
    assertThat(buildDeployResult.getProxyNotBuiltInEnvironments()).isEmpty();
    assertThat(buildDeployResult.getProxyNotDeployedToEnvironments()).contains(DEV1_INTERNAL);
  }

  @Test
  void buildProxyHttpStatus400Test() {
    
    // given
    InputApiRequest inputapirequest = setupInuptApiRequest();
    inputapirequest.setExternal("false");
    
    stubFor(get(urlEqualTo("/Enterprise/v1/Routing/taxonomy"))
        .withHeader("X-Application-Key", containing("APPKEY966252019031223364839633907"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-get-taxonomies-response.json")
            .withHeader("Content-Type", "application/json")));
    
    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing(APIGEE))
        .withQueryParam("resourceTaxonomy", equalTo(inputapirequest.getTaxonomy()))
        .withQueryParam("version", equalTo(inputapirequest.getVersion()))
        .withQueryParam("resourceName", equalTo(inputapirequest.getResourceName()))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-mediated-api-lookup-api-does-not-exist-response.json")
            .withHeader("Content-Type", "application/json")));

    stubFor(post(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing(inputapirequest.getRequestorEmail()))
        .willReturn(aResponse()
            .withStatus(400)));   
    
    //when
    BuildDeployResult buildDeployResult = buildDeployServiceImpl.buildDeployApi(inputapirequest);

    //then
    assertThat(buildDeployResult).isNotNull();
    assertThat(buildDeployResult.getProxy()).isEqualTo(PROXY_NAME);
    assertThat(buildDeployResult.getGuid()).isNotEmpty();
    assertThat(buildDeployResult.getProxyBuiltInEnvironments()).isEmpty();
    assertThat(buildDeployResult.getProxyDeployedToEnvironments()).isEmpty();
    assertThat(buildDeployResult.getProxyNotBuiltInEnvironments()).contains(DEV1);
    assertThat(buildDeployResult.getProxyNotDeployedToEnvironments()).contains(DEV1);
  }
  
  @Test
  void shouldThrowPartnerProxyBuildException(CapturedOutput output) {
    
    // given
    InputApiRequest inputapirequest = setupInuptApiRequest();
    inputapirequest.setDev1EndpointHostname(null);
    inputapirequest.setTest1EndpointHostname("http://test1.com");
    inputapirequest.setExternal("false");
    inputapirequest.setCallAsyncBuildDeploy(true);
    inputapirequest.setEnv("test1");
    
    stubFor(get(urlEqualTo("/Enterprise/v1/Routing/taxonomy"))
        .withHeader("X-Application-Key", containing("APPKEY966252019031223364839633907"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-get-taxonomies-response.json")
            .withHeader("Content-Type", "application/json")));
    
    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing(APIGEE))
        .withQueryParam("resourceTaxonomy", equalTo(inputapirequest.getTaxonomy()))
        .withQueryParam("version", equalTo(inputapirequest.getVersion()))
        .withQueryParam("resourceName", equalTo(inputapirequest.getResourceName()))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-mediated-api-lookup-api-does-not-exist-response.json")
            .withHeader("Content-Type", "application/json")));

    stubFor(post(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing(inputapirequest.getRequestorEmail()))
        .willReturn(aResponse()
            .withStatus(500)
            .withHeader("Content-Type", "application/json")));

    buildDeployServiceImpl.buildDeployApi(inputapirequest);
    // Use Awaitility to wait for the exception
    await().atMost(10, TimeUnit.SECONDS).pollDelay(5, TimeUnit.SECONDS).untilAsserted(() -> 
    assertTrue(output.getOut().contains("Partner Proxy Build Failed")));
  }
  
}
