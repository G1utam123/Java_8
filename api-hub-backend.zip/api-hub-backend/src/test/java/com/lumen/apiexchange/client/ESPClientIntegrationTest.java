package com.lumen.apiexchange.client;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.delete;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.put;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.contains;

import com.lumen.apiexchange.IntegrationTestBase;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.model.ApiMediatedResponse;
import com.lumen.apiexchange.model.ApplicationKey;
import com.lumen.apiexchange.model.InputApiRequest;
import com.lumen.apiexchange.model.TaxonomyCreationResult;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("it")
@AutoConfigureWireMock(port = 0)
class ESPClientIntegrationTest extends IntegrationTestBase {

  @Autowired
  private ESPClient espClient;
  
  
  String getBuildRequest() {
    String buildRequest = "{\"taxonomy\" : \"Partner/partnerABC\","
        + "\"resourceName\" : \"partnerResource\", \"proxyVersion\": \"v1\"}";
    return buildRequest;
  }
  
  @Test
  void getApiProxies() throws InternalServerException {

    //given
    stubFor(get(urlEqualTo("/Enterprise/v1/Routing/mediatedResource"))
            .withHeader("X-Username", containing("apigee"))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("esp-get-apiproxies-response.json")
                    .withHeader("Content-Type", "application/json")));

    //when
    ApiMediatedResponse apiProxies = espClient.getApiProxies();

    //then
    assertThat(apiProxies.getMediatedResource().size()).isGreaterThan(500);
  }

  @Test
  void shouldGetApiProxyByEnvTaxVerResName() throws InternalServerException {

    //given
    String env = "dev1";
    String taxonomy = "Application/Apigee";
    String version = "v1";
    String resourceName = "doSomething";
    
    stubFor(get(urlEqualTo("/Enterprise/v1/Routing/mediatedResource?resourceTaxonomy=Application/Apigee"
        + "&resourceName=doSomething&version=v1"))
            .withHeader("X-Username", containing("apigee"))
            .withQueryParam("resourceTaxonomy", equalTo(taxonomy))
            .withQueryParam("resourceName", equalTo(resourceName))
            .withQueryParam("version", equalTo(version))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("esp-mediated-api-lookup-api-exist-single-response.json")
                    .withHeader("Content-Type", "application/json")));

    //when
    ApiMediatedResponse resource = espClient.getApiProxies(env, taxonomy, resourceName, version);

    //then
    assertThat(resource).isNotNull();
    assertThat(resource.getMediatedResource().size()).isEqualTo(1);
    assertThat(resource.getMediatedResource().get(0)).isNotNull();
  }

  @Test
  void shouldGetMulipleApiProxiesByEnvTaxVerResName() throws InternalServerException {

    //given
    String env = "dev1";
    String taxonomy = "Application/Apigee";
    String version = "v1";
    String resourceName = "doSomething";
    
    stubFor(get(urlEqualTo("/Enterprise/v1/Routing/mediatedResource?resourceTaxonomy=Application/Apigee"
        + "&resourceName=doSomething&version=v1"))
            .withHeader("X-Username", containing("apigee"))
            .withQueryParam("resourceTaxonomy", equalTo(taxonomy))
            .withQueryParam("resourceName", equalTo(resourceName))
            .withQueryParam("version", equalTo(version))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("esp-mediated-api-lookup-api-exist-multi-response.json")
                    .withHeader("Content-Type", "application/json")));

    //when
    ApiMediatedResponse resource = espClient.getApiProxies(env, taxonomy, resourceName, version);

    //then
    assertThat(resource).isNotNull();
    assertThat(resource.getMediatedResource().size()).isEqualTo(2);
    assertThat(resource.getMediatedResource().get(0)).isNotNull();
    assertThat(resource.getMediatedResource().get(1)).isNotNull();
  }

  @Test
  void shouldThrowExceptionApiProxyByEnvTaxVerResName() throws InternalServerException {

    //given
    String env = "dev1";
    String taxonomy = "Application/Apigee";
    String version = "v1";
    String resourceName = "doSomething";
    
    stubFor(get(urlEqualTo("/Enterprise/v1/Routing/mediatedResource?resourceTaxonomy=Application/Apigee"
        + "&resourceName=doSomething&version=v1"))
            .withHeader("X-Username", containing("apigee"))
            .withQueryParam("resourceTaxonomy", equalTo(taxonomy))
            .withQueryParam("resourceName", equalTo(resourceName))
            .withQueryParam("version", equalTo(version))
            .willReturn(aResponse()
                    .withStatus(500)
                    .withHeader("Content-Type", "application/json")));

    //when
    InternalServerException exception = assertThrows(InternalServerException.class, () -> {
      espClient.getApiProxies(env, taxonomy, resourceName, version); });

    assertThat(exception.getMessage()).contains("Unable to get Proxy Details. Please try later: 500 Server Error");
  }

  @Test
  void testGetApiProxiesByGuid() throws InternalServerException {

    //given
    String guid = "6ce67bee-66c3-4007-be6a-73c5691339f8";

    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
            .withHeader("X-Username", containing("apigee"))
            .withQueryParam("resourceGuid", equalTo(guid))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("esp-mediated-resources-response.json")
                    .withHeader("Content-Type", "application/json")));

    //when
    ApiMediatedResource apiProxy = espClient.getApiProxies(guid);

    //then
    assertThat(apiProxy.getResourceName()).isEqualTo("brightspeed");
  }

  @Test
  void shouldThrowExceptionApiProxyByGuid() throws InternalServerException {

    //given
    String guid = "6ce67bee-66c3-4007-be6a-73c5691339f8";

    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
            .withHeader("X-Username", containing("apigee"))
            .withQueryParam("resourceGuid", equalTo(guid))
            .willReturn(aResponse()
                    .withStatus(500)
                    .withHeader("Content-Type", "application/json")));

    //when
    InternalServerException exception = assertThrows(InternalServerException.class, () -> {
      espClient.getApiProxies(guid); });
    
    //then
    assertThat(exception.getMessage()).contains("Unable to get Proxy Details. Please try later: 500 Server Error");
  }

  @Test
  void testGetApiProxyEnvDetailsByEnvByGuid() throws InternalServerException {

    //given
    String guid = "6ce67bee-66c3-4007-be6a-73c5691339f8";
    UUID proxyGuid = UUID.fromString(guid);
    String environment = "test1";

    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
            .withHeader("X-Username", containing("apigee"))
            .withQueryParam("resourceGuid", equalTo(guid))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("esp-mediated-resources-response.json")
                    .withHeader("Content-Type", "application/json")));

    //when
    ApiMediatedResource apiProxy = espClient.getApiProxyEnvDetails(environment, proxyGuid);

    //then
    assertThat(apiProxy.getResourceName()).isEqualTo("brightspeed");
  }

  @Test
  void shouldThrowExceptionGetApiProxyEnvDetailsByEnvByGuid() throws InternalServerException {

    //given
    String guid = "6ce67bee-66c3-4007-be6a-73c5691339f8";
    UUID proxyGuid = UUID.fromString(guid);
    String environment = "test1";

    stubFor(get(urlPathEqualTo("/Enterprise/v1/Routing/mediatedResource"))
        .withHeader("X-Username", containing("apigee"))
        .withQueryParam("resourceGuid", equalTo(guid))
        .willReturn(aResponse()
                .withStatus(500)
                .withHeader("Content-Type", "application/json")));

    //when
    InternalServerException exception = assertThrows(InternalServerException.class, () -> {
      espClient.getApiProxyEnvDetails(environment, proxyGuid); });
    
    //then
    assertThat(exception.getMessage()).contains("Unable to get Proxy Details. Please try later:500 Server Error");

  }

  @Test
  void testConstructEspProxyUrl() {

    //given
    String resourceGuid = "6ce67bee-66c3-4007-be6a-73c5691339f8";
    
    //when-then
    assertThat(espClient.constructEspProxyUrl("mock", resourceGuid))
        .contains("resourceGuid=" + resourceGuid)
        .contains("environment=mock");
    assertThat(espClient.constructEspProxyUrl("sandbox", resourceGuid))
        .contains("resourceGuid=" + resourceGuid)
        .contains("environment=sandbox");

  }

  @Test
  void getApiProxyDetailsOnTest1() throws InternalServerException {

    //given
    InputApiRequest inputApiRequest = new InputApiRequest();
    inputApiRequest.setEnv("test1");

    stubFor(get(urlEqualTo("/Enterprise/v1/Routing/mediatedResource"))
            .withHeader("X-Username", containing("apigee"))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("esp-get-apiproxies-response.json")
                    .withHeader("Content-Type", "application/json")));

    //when
    ApiMediatedResponse apiProxies = espClient.getApiProxyDetails(inputApiRequest);

    //then
    assertThat(apiProxies.getMediatedResource().size()).isGreaterThan(500);

  }

  @Test
  void getApplicationKeys() throws InternalServerException {

    //given
    stubFor(get(urlEqualTo("/Enterprise/v1/Security/espCustomer?customerType=Internal"))
            .withHeader("X-Application-Key", containing("APPKEY966252019031223364839633907"))
            .willReturn(aResponse()
                    .withStatus(200)
                    .withBodyFile("esp-get-applicationkeys-response.json")
                    .withHeader("Content-Type", "application/json")));

    //when
    List<ApplicationKey> apiProxies = espClient.getApplicationKeys();

    //then
    assertThat(apiProxies.size()).isGreaterThan(500);

  }
  
  @Test
  void badTaxonomy() throws BadInputException {
    
    assertThatExceptionOfType(BadInputException.class)
    .isThrownBy(() -> {
      espClient.createTaxonomy("");
    })
        .withMessageContaining("Taxonomy cannot be null or blank");
    
    assertThatExceptionOfType(BadInputException.class)
    .isThrownBy(() -> {
      espClient.createTaxonomy("Partner/ATT Inc");
    })
        .withMessageContaining("Taxonomy can only contain alphanumeric characters and special characters: /-");
    
    assertThatExceptionOfType(BadInputException.class)
    .isThrownBy(() -> {
      espClient.createTaxonomy("Partner//ATT");
    })
        .withMessageContaining("Taxonomy can only be in the following pattern: xxx/xxx or xxx/xxx-xxx");
  }
  
  @Test
  void getTaxonomy() throws InternalServerException {
    
    //given
    stubFor(get(urlEqualTo("/Enterprise/v1/Routing/taxonomy"))
        .withHeader("X-Application-Key", containing("APPKEY966252019031223364839633907"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-get-taxonomies-response.json")
            .withHeader("Content-Type", "application/json")));

    //when
    List<String> taxResult = espClient.getTaxonomies();

    //then
    assertTrue(taxResult.size() > 0);
  }
  
  @Test
  void createTaxonomyHappy() throws BadInputException {
    
    //given
    stubFor(post(urlEqualTo("/Enterprise/v1/Routing/taxonomy"))
        .withHeader("X-Username", containing("apigee"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBodyFile("esp-create-taxonomy-happy-response.json")
            .withHeader("Content-Type", "application/json")));

    //when
    TaxonomyCreationResult taxCrtResult = espClient.createTaxonomy("Partner/CompanyABC");

    //then
    assertEquals("Partner/CompanyABC", taxCrtResult.getTaxonomy());
    assertThat(taxCrtResult.getTaxonomyCreatedEnv()).isNotEmpty();
    assertThat(taxCrtResult.getTaxonomyNotCreatedEnv()).isEmpty();
  }

  @Test
  void createTaxonomySad() throws BadInputException {
    
    //given
    stubFor(post(urlEqualTo("/Enterprise/v1/Routing/taxonomy"))
        .withHeader("X-Username", containing("apigee"))
        .willReturn(aResponse()
            .withStatus(500)
            .withHeader("Content-Type", "application/json")));

    //when
    TaxonomyCreationResult taxCrtResult = espClient.createTaxonomy("Partner/CompanyABC");

    //then
    assertEquals("Partner/CompanyABC", taxCrtResult.getTaxonomy());
    assertThat(taxCrtResult.getTaxonomyNotCreatedEnv()).isNotEmpty();
    assertThat(taxCrtResult.getTaxonomyCreatedEnv()).isEmpty();
  }
  
  @Test
  void shouldDeleteProxy() {
    
    //given
    stubFor(delete(urlEqualTo("/Enterprise/v1/Routing/mediatedResource/12345"))
        .willReturn(aResponse()
            .withStatus(200)));
    
    //when-then
    espClient.deleteApiProxy("12345", "test1");

  }

  @Test
  void shouldUndeployProxy() {
    
    //given
    stubFor(put(urlEqualTo("/Enterprise/v1/Routing/mediatedResource/12345/undeployInternal"))
        .willReturn(aResponse()
            .withStatus(200)));
    
    //when-then
    espClient.undeployApiProxy("12345", "test1", "undeployInternal");

  }

  @Test
  void shouldFaileOnDeleteProxyCallToEsp() {
    
    //given
    stubFor(delete(urlEqualTo("/Enterprise/v1/Routing/mediatedResource/12345"))
        .withHeader("X-Username", containing("apigee"))
        .willReturn(aResponse()
            .withStatus(500)
            .withHeader("Content-Type", "application/json")));
    stubFor(delete(urlEqualTo("/Enterprise/v1/Routing/mediatedResource/34567"))
        .withHeader("X-Username", containing("apigee"))
        .willReturn(aResponse()
            .withStatus(202)
            .withHeader("Content-Type", "application/json")));

    //when-then
    assertThatExceptionOfType(InternalServerException.class)
    .isThrownBy(() -> {
      espClient.deleteApiProxy("12345", "test1");
    }).withMessageContaining("Unable to delete proxy.");
    
    assertThatExceptionOfType(InternalServerException.class)
    .isThrownBy(() -> {
      espClient.deleteApiProxy("34567", "test1");
    }).withMessageContaining("HttpStatus from ESP Not OK. HTTPStatus:");

  }

  @Test
  void shouldFaileOnUndeployProxyCallToEsp() {
    
    //given
    stubFor(put(urlEqualTo("/Enterprise/v1/Routing/mediatedResource/12345/undeployInternal"))
        .withHeader("X-Username", containing("apigee"))
        .willReturn(aResponse()
            .withStatus(500)
            .withHeader("Content-Type", "application/json")));
    stubFor(put(urlEqualTo("/Enterprise/v1/Routing/mediatedResource/34567/undeployInternal"))
        .withHeader("X-Username", containing("apigee"))
        .willReturn(aResponse()
            .withStatus(202)
            .withHeader("Content-Type", "application/json")));

    //when-then
    assertThatExceptionOfType(InternalServerException.class)
    .isThrownBy(() -> {
      espClient.undeployApiProxy("12345", "test1", "undeployInternal");
    }).withMessageContaining("Unable to undeploy proxy.");
    
    assertThatExceptionOfType(InternalServerException.class)
    .isThrownBy(() -> {
      espClient.undeployApiProxy("34567", "test1", "undeployInternal");
    }).withMessageContaining("HttpStatus from ESP Not OK. HTTPStatus:");

  }
  
  @Test
  void shouldDeployApiProxy() {
    
    //given
    stubFor(put(urlEqualTo("/Enterprise/v1/Routing/mediatedResource/12345/deployInternal"))
        .willReturn(aResponse()
            .withStatus(200)));
    
    //when-then
    espClient.deployApiProxy("12345", "test1", "deployInternal");

  }

  @Test
  void shouldUpdateApiProxy() {
    
    //given
    String buildRequest = getBuildRequest();
    
    stubFor(put(urlEqualTo("/Enterprise/v1/Routing/mediatedResource/12345"))
        .willReturn(aResponse()
            .withStatus(200)));
    
    //when-then
    espClient.updateApiProxy("12345", buildRequest, "test1", "mickey.mouse@lumen.com");

  }
  
  @Test
  void shouldFailOnUpdateApiProxyCallToEsp() {
    
    //given
    String buildRequest = getBuildRequest();
    
    stubFor(put(urlEqualTo("/Enterprise/v1/Routing/mediatedResource/12345"))
        .withHeader("X-Username", containing("apigee"))
        .willReturn(aResponse()
            .withStatus(500)
            .withHeader("Content-Type", "application/json")));

    //when-then
    assertThatExceptionOfType(InternalServerException.class)
    .isThrownBy(() -> {
      espClient.updateApiProxy("12345", buildRequest, "test1", "mickey.mouse@lumen.com");
    }).withMessageContaining("Unable to update proxy.");

  }

}