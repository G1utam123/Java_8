package com.lumen.apiexchange.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.AssertionsForClassTypes.assertThatExceptionOfType;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

import com.lumen.apiexchange.api.partner.model.BasicAuth;
import com.lumen.apiexchange.api.partner.model.OAuth20;
import com.lumen.apiexchange.api.partner.model.OAuth20.OauthClientIdLocationEnum;
import com.lumen.apiexchange.api.partner.model.OAuth20.OauthGrantLocationEnum;
import com.lumen.apiexchange.api.partner.model.OAuth20.OauthGrantTypeEnum;
import com.lumen.apiexchange.api.partner.model.OAuth20.OauthScopeLocationEnum;
import com.lumen.apiexchange.api.partner.model.PartnerEndpoint;
import com.lumen.apiexchange.api.partner.model.PartnerEndpoint.EnvironmentEnum;
import com.lumen.apiexchange.api.partner.model.PartnerProxy;
import com.lumen.apiexchange.client.ESPClient;
import com.lumen.apiexchange.config.PartnerProxyConfigProperties;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.ForbiddenException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.NotFoundException;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.model.BuildDeployResult;
import com.lumen.apiexchange.model.InputApiRequest;
import com.lumen.apiexchange.model.TaxonomyCreationResult;
import com.lumen.apiexchange.model.apigee.ApigeeProduct;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.AccessLocation;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.Planet;
import com.lumen.apiexchange.service.apigee.ApigeeProductsService;
import com.lumen.apiexchange.util.APIHandler;
import com.lumen.apiexchange.util.BuildHandler;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.oauth2.jwt.Jwt;

@ExtendWith(MockitoExtension.class)
class PartnerProxyServiceTest {

  @InjectMocks
  private PartnerProxyService partnerProxyService;

  @InjectMocks
  private UserAuthorizationServiceImpl userAuthorizationService;

  @Mock
  private ESPClient espClient;
  
  @Mock
  private ApigeeProductsService apigeeProductsService;

  @Mock
  private PartnerProxyConfigProperties partnerProxyConfigProperties;

  @Mock
  private ProxyService proxyService;

  @Mock
  private APIHandler apiHandler;

  @Mock
  SecurityContext securityContext;
  
  @Mock
  BuildHandler buildHandler;
  
  @Mock
  BuildDeployServiceImpl buildDeployServiceImpl;
  
  @Mock
  AsyncPartnerProxyServiceImpl asyncPartnerProxyServiceImpl;
  
  

  static Jwt getMockJwtToken(String subject, String claim, String claimValue) {
    final Jwt jwt = Jwt.withTokenValue("token")
            .header("alg", "none")
            .claim(claim, claimValue)
            .subject(subject)
            .build();
    return jwt;
  }

  private BuildDeployResult createBuildDeployResult() {
    BuildDeployResult buildDeployResult = new BuildDeployResult();
    buildDeployResult = BuildDeployResult.builder()
        .proxy("/tax1/v1/tax2/resourceName")
        .guid("09ab8848-52fc-4df4-a784-de42a6266114")
        .proxyBuiltInEnvironments(new ArrayList<>())
        .proxyDeployedToEnvironments(new ArrayList<>())
        .proxyNotBuiltInEnvironments(new ArrayList<>())
        .proxyNotDeployedToEnvironments(new ArrayList<>())
        .build();
    buildDeployResult.getProxyBuiltInEnvironments().add("dev1-internal");
    buildDeployResult.getProxyBuiltInEnvironments().add("test1-internal");
    buildDeployResult.getProxyDeployedToEnvironments().add("dev1-internal");
    buildDeployResult.getProxyDeployedToEnvironments().add("test1-internal");
    buildDeployResult.getProxyNotBuiltInEnvironments().add("dev2-internal");
    buildDeployResult.getProxyNotDeployedToEnvironments().add("dev2-internal");
    
    return buildDeployResult;
  }
  
  @Test
  void shouldSaveProxyOauthLocationsForm() throws Exception {

    //given
    PartnerProxy partnerProxy = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "oauth_client_form");
    InputApiRequest inputApiRequest = partnerProxyService.buildInputApiRequest(partnerProxy);
    Jwt jwt = getMockJwtToken("test", "role", "API-HUB Partner Proxy");
    BuildDeployResult buildDeployResult = createBuildDeployResult();
    
    //when
    Mockito.when(proxyService.postProxyRequest(any(InputApiRequest.class), eq(jwt))).thenReturn(buildDeployResult);
    PartnerProxy partnerProxyResp = partnerProxyService.createProxy(partnerProxy, jwt);

    //then
    assertThat(partnerProxyResp.getPartnerName()).isEqualTo("PartnerABC");
    assertThat(partnerProxyResp.getPartnerResource()).isEqualTo("partnerResource");
    assertThat(partnerProxyResp.getProxyGateway()).isEqualTo(PartnerProxy.ProxyGatewayEnum.ESP);
    assertThat(partnerProxyResp.getProxyVersion()).isEqualTo("v1");
    assertThat(inputApiRequest.getTaxonomy()).isEqualTo("Partner/PartnerABC");
    assertThat(inputApiRequest.getResourceName()).isEqualTo(partnerProxy.getPartnerResource());
    assertThat(inputApiRequest.getVersion()).isEqualTo(partnerProxy.getProxyVersion());
    assertThat(inputApiRequest.getType()).isEqualTo("Outbound");
    assertThat(inputApiRequest.getOwningAppAppkey()).isEqualTo("APPKEY12345678901234567890");
    assertThat(inputApiRequest.getMalId()).isEqualTo("SYSGEN787489521");
    assertThat(inputApiRequest.getRequestorEmail()).isEqualTo("jeremy.eagleman@lumen.com");
    assertThat(inputApiRequest.getTest4EndpointHostname()).isEqualTo(null);
    assertThat(inputApiRequest.getTest1EndpointHostname())
        .isEqualTo(partnerProxy.getPartnerEndpoint().getEndpointHostname());
    assertThat(inputApiRequest.getEndpointPath()).isEqualTo(partnerProxy.getPartnerEndpoint().getEndpointPath());
    assertThat(inputApiRequest.getInternal()).isEqualTo("true");
    assertThat(inputApiRequest.getProxyAuthInternal()).isEqualTo("oAuth");
    assertThat(inputApiRequest.getEndpointAuth()).isEqualTo("oAuth");
    assertThat(inputApiRequest.getOauthGrantType()).isEqualTo("client_credentials");
    assertThat(inputApiRequest.getOauthGrantLocation()).isEqualTo("Form Parameter");
    assertThat(inputApiRequest.getOauthTokenServiceHost()).isEqualTo("https://oauthtokenhostname");
    assertThat(inputApiRequest.getOauthTokenServiceURI()).isEqualTo("/oauth/v1/token");
    assertThat(inputApiRequest.getOauthClientIdLocation()).isEqualTo("Form Parameter");
    assertThat(inputApiRequest.getOauthClientId()).isEqualTo("oauth_clinet_id");
    assertThat(inputApiRequest.getOauthSecret()).isEqualTo("oauth_client_secret");
    assertThat(inputApiRequest.getOauthScopeLocation()).isEqualTo("Form Parameter");
    assertThat(inputApiRequest.getOauthScope()).isEqualTo("oauth_scope");
    
  }
  
  @Test
  void shouldSaveOauthLocationsQueryParam() throws Exception {

    //given
    PartnerProxy partnerProxy = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.PRODUCTION, "https://hostname.com", "partnerPath", "oauth_client_query");
    InputApiRequest inputApiRequest = partnerProxyService.buildInputApiRequest(partnerProxy);
    Jwt jwt = getMockJwtToken("test", "role", "API-HUB Partner Proxy");
    BuildDeployResult buildDeployResult = createBuildDeployResult();
    buildDeployResult.getProxyDeployedToEnvironments().add("prod-internal");
    
    //when
    Mockito.when(proxyService.postProxyRequest(any(InputApiRequest.class), eq(jwt))).thenReturn(buildDeployResult);
    PartnerProxy partnerProxyResp = partnerProxyService.createProxy(partnerProxy, jwt);
    
    //then
    assertThat(partnerProxyResp.getPartnerName()).isEqualTo("PartnerABC");
    assertThat(partnerProxyResp.getPartnerResource()).isEqualTo("partnerResource");
    assertThat(partnerProxyResp.getProxyGateway()).isEqualTo(PartnerProxy.ProxyGatewayEnum.ESP);
    assertThat(partnerProxyResp.getProxyVersion()).isEqualTo("v1");
    assertThat(inputApiRequest.getProdEndpointHostname())
        .isEqualTo(partnerProxy.getPartnerEndpoint().getEndpointHostname());
    assertThat(inputApiRequest.getEndpointAuth()).isEqualTo("oAuth");
    assertThat(inputApiRequest.getOauthGrantType()).isEqualTo("client_credentials");
    assertThat(inputApiRequest.getOauthGrantLocation()).isEqualTo("Query Parameter");
    assertThat(inputApiRequest.getOauthTokenServiceHost()).isEqualTo("https://oauthtokenhostname");
    assertThat(inputApiRequest.getOauthTokenServiceURI()).isEqualTo("/oauth/v1/token");
    assertThat(inputApiRequest.getOauthClientIdLocation()).isEqualTo("Query Parameter");
    assertThat(inputApiRequest.getOauthClientId()).isEqualTo("oauth_clinet_id");
    assertThat(inputApiRequest.getOauthSecret()).isEqualTo("oauth_client_secret");
    assertThat(inputApiRequest.getOauthScopeLocation()).isEqualTo("Query Parameter");
    assertThat(inputApiRequest.getOauthScope()).isEqualTo("oauth_scope");
    
  }

  @Test
  void shouldSaveProxyBasicAuth() throws Exception {

    //given
    PartnerProxy partnerProxy = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.PRODUCTION, "https://hostname.com", "partnerPath", "basic_auth");
    InputApiRequest inputApiRequest = partnerProxyService.buildInputApiRequest(partnerProxy);
    Jwt jwt = getMockJwtToken("test", "role", "API-HUB Partner Proxy");
    BuildDeployResult buildDeployResult = createBuildDeployResult();
    buildDeployResult.getProxyDeployedToEnvironments().add("prod-internal");
        
    //when
    Mockito.when(proxyService.postProxyRequest(any(InputApiRequest.class), eq(jwt))).thenReturn(buildDeployResult);
    PartnerProxy partnerProxyResp = partnerProxyService.createProxy(partnerProxy, jwt);
    
    //then
    assertThat(partnerProxyResp.getPartnerName()).isEqualTo("PartnerABC");
    assertThat(partnerProxyResp.getPartnerResource()).isEqualTo("partnerResource");
    assertThat(partnerProxyResp.getProxyGateway()).isEqualTo(PartnerProxy.ProxyGatewayEnum.ESP);
    assertThat(partnerProxyResp.getProxyVersion()).isEqualTo("v1");
    assertThat(inputApiRequest.getTaxonomy()).isEqualTo("Partner/PartnerABC");
    assertThat(inputApiRequest.getResourceName()).isEqualTo(partnerProxy.getPartnerResource());
    assertThat(inputApiRequest.getVersion()).isEqualTo(partnerProxyResp.getProxyVersion());
    assertThat(inputApiRequest.getType()).isEqualTo("Outbound");
    assertThat(inputApiRequest.getOwningAppAppkey()).isEqualTo("APPKEY12345678901234567890");
    assertThat(inputApiRequest.getMalId()).isEqualTo("SYSGEN787489521");
    assertThat(inputApiRequest.getProdEndpointHostname())
        .isEqualTo(partnerProxy.getPartnerEndpoint().getEndpointHostname());
    assertThat(inputApiRequest.getTest1EndpointHostname()).isEqualTo(null);
    assertThat(inputApiRequest.getEndpointPath()).isEqualTo(partnerProxy.getPartnerEndpoint().getEndpointPath());
    assertThat(inputApiRequest.getInternal()).isEqualTo("true");
    assertThat(inputApiRequest.getProxyAuthInternal()).isEqualTo("oAuth");
    assertThat(inputApiRequest.getEndpointBasicAuthUserAll()).isEqualTo("ba_user");
    assertThat(inputApiRequest.getEndpointBasicAuthPwAll()).isEqualTo("ba_password");

  }
  
  
  @Test
  void shouldGetProxy() throws Exception {
    
    //given 
    String espEnv = "test1";
    String partnerName = "PartnerName";
    String taxonomy = "Partner/" + partnerName;
    String resource = "partnerResource";
    String proxyVersion = "v1";
    String hostname = "http://mocktarget.partner.com";
    ApiMediatedResource espResource = buildApiMediatedResourceBasicAuthResponse(taxonomy, resource, espEnv, hostname);
    UUID proxyGuid = UUID.fromString(espResource.getResourceGuid());

    //when
    Mockito.when(espClient.getApiProxyEnvDetails(espEnv, proxyGuid)).thenReturn(espResource);
    String environment = "TEST1";
    String proxyGateway = "ESP";
    PartnerProxy partnerProxy = partnerProxyService.getPartnerProxy(proxyGateway, environment, proxyGuid);
    
    //then 
    assertThat(partnerProxy.getPartnerName()).isEqualTo("PartnerName");
    assertThat(partnerProxy.getPartnerResource()).isEqualTo("partnerResource");
    assertThat(partnerProxy.getProxyGateway()).isEqualTo(PartnerProxy.ProxyGatewayEnum.ESP);
    assertThat(partnerProxy.getProxyVersion()).isEqualTo(proxyVersion);
    assertThat(partnerProxy.getProxyOwnerAppKey()).isEqualTo("APPKEY1037142019052317562540722002");
    assertThat(partnerProxy.getProxyOwnerSysgen()).isEqualTo("SYSGEN787551898");
    assertThat(partnerProxy.getProxyOwnerEmail()).isEqualTo("apigee@lumen.com");
    assertThat(partnerProxy.getProxyGateway()).isEqualTo(PartnerProxy.ProxyGatewayEnum.ESP);
    assertThat(partnerProxy.getProxyGuid()).isEqualTo(proxyGuid);
    PartnerEndpoint partnerEndpoint = partnerProxy.getPartnerEndpoint();
    assertThat(partnerEndpoint.getEnvironment()).isEqualTo(EnvironmentEnum.TEST1);
    assertThat(partnerEndpoint.getEndpointHostname()).isEqualTo("https://partnerABC.com");
    assertThat(partnerEndpoint.getEndpointPath()).isEqualTo("/partner/endpoint/path");
    BasicAuth basicAuth = (BasicAuth) partnerEndpoint.getAuthentication();
    assertThat(basicAuth.getBasicAuthUser()).isEqualTo("my_user");
    assertThat(basicAuth.getBasicAuthPassword()).isEqualTo("my_password");

  }

  @Test
  void shouldRemoveProxyFromApigee() throws Exception {
    
    //Given-When
    String productName = "API-HUB Partner Proxy";
    ApigeeProduct product = buildTestApigeeProduct(productName, "manual", 
        Planet.PROD, AccessLocation.INTERNAL);

    //when
    Mockito.when(apigeeProductsService.getProduct("API-HUB Partner Proxy", "PROD", "INTERNAL")).thenReturn(product);
    Mockito.when(partnerProxyConfigProperties.getApiProductName()).thenReturn(productName);
    ApigeeProduct updatedProduct = partnerProxyService.removeProxyFromApigee("ProxyA", "prod");

    //then
    assertThat(updatedProduct.getProxies().size()).isEqualTo(1);
  }

  @Test
  void shouldNotRemoveProxyFromApigee() throws Exception {
    
    //Given-When
    String productName = "API-HUB Partner Proxy";
    ApigeeProduct product = buildTestApigeeProduct(productName, "manual", 
        Planet.PROD, AccessLocation.INTERNAL);
    product.getEnvironments().add("test2");

    //when
    Mockito.when(apigeeProductsService.getProduct("API-HUB Partner Proxy", "PROD", "INTERNAL")).thenReturn(product);
    Mockito.when(partnerProxyConfigProperties.getApiProductName()).thenReturn(productName);
    ApigeeProduct updatedProduct = partnerProxyService.removeProxyFromApigee("ProxyA", "prod");

    //then
    assertThat(updatedProduct.getProxies().size()).isEqualTo(2);
  }

  @Test
  void shouldDeleteProxy() throws Exception {
    
    //given 
    String espEnv = "test1";
    String partnerName = "PartnerName";
    String taxonomy = "Partner/" + partnerName;
    String resource = "partnerResource";
    String proxyVersion = "v1";
    String hostname = "http://mocktarget.partner.com";
    ApiMediatedResource espResource = buildApiMediatedResourceBasicAuthResponse(taxonomy, resource, espEnv, hostname);
    UUID proxyGuid = UUID.fromString(espResource.getResourceGuid());
    String productName = "API-HUB Partner Proxy";
    Planet apigeePlanet = Planet.NONPROD;
    ApigeeProduct product = buildTestApigeeProduct(productName, "manual", 
        Planet.NONPROD, AccessLocation.INTERNAL);
    ApigeeProduct updatedProduct = buildTestApigeeProduct(productName, "manual", 
        Planet.NONPROD, AccessLocation.INTERNAL);
    product.getProxies().add("Esp_IntMed_Partner_v1_PartnerName_partnerResource_" + espResource.getResourceGuid());

    Mockito.when(espClient.getApiProxyEnvDetails(espEnv, proxyGuid)).thenReturn(espResource);
    Mockito.when(apigeeProductsService.getProduct(productName, "NONPROD", "INTERNAL"))
        .thenReturn(product);
    Mockito.when(partnerProxyConfigProperties.getApiProductName()).thenReturn(productName);
    Mockito.when(apigeeProductsService.updatePartnerProxyProduct(apigeePlanet, product))
        .thenReturn(updatedProduct);
    Mockito.doNothing().when(espClient).deleteApiProxy("12345", espResource.getEnvironment());
    
    //Then
    String environment = "TEST1";
    String proxyGateway = "ESP";
    partnerProxyService.deletePartnerProxy(proxyGateway, environment, proxyGuid);

  }

  @Test
  void shouldDeleteProxyProd() throws Exception {
    
    //given 
    String espEnv = "prod";
    String partnerName = "PartnerName";
    String taxonomy = "Partner/" + partnerName;
    String resource = "partnerResource";
    String proxyVersion = "v1";
    String hostname = "http://mocktarget.partner.com";
    ApiMediatedResource espResource = buildApiMediatedResourceBasicAuthResponse(taxonomy, resource, espEnv, hostname);
    UUID proxyGuid = UUID.fromString(espResource.getResourceGuid());
    String productName = "API-HUB Partner Proxy";
    Planet apigeePlanet = Planet.PROD;
    ApigeeProduct product = buildTestApigeeProduct(productName, "manual", 
        Planet.PROD, AccessLocation.INTERNAL);
    ApigeeProduct updatedProduct = buildTestApigeeProduct(productName, "manual", 
        Planet.PROD, AccessLocation.INTERNAL);
    product.getProxies().add("Esp_IntMed_Partner_v1_PartnerName_partnerResource_" + espResource.getResourceGuid());

    Mockito.when(espClient.getApiProxyEnvDetails(espEnv, proxyGuid)).thenReturn(espResource);
    Mockito.when(apigeeProductsService.getProduct(productName, "PROD", "INTERNAL"))
        .thenReturn(product);
    Mockito.when(partnerProxyConfigProperties.getApiProductName()).thenReturn(productName);
    Mockito.when(apigeeProductsService.updatePartnerProxyProduct(apigeePlanet, product))
        .thenReturn(updatedProduct);
    Mockito.doNothing().when(espClient).deleteApiProxy("12345", espEnv);
    
    //Then
    String environment = "PRODUCTION";
    String proxyGateway = "ESP";
    partnerProxyService.deletePartnerProxy(proxyGateway, environment, proxyGuid);

  }

  public ApiMediatedResource buildApiMediatedResourceBasicAuthResponse(String partnerName, String resource, String env,
      String hostname) {
    
    ApiMediatedResource stubResponse = new ApiMediatedResource();
    
    stubResponse.setMediatedResourceId(12345);
    stubResponse.setResourceTaxonomy("Partner/" + partnerName);
    stubResponse.setResourceName(resource);
    stubResponse.setVersion("v1");
    stubResponse.setReplaceUrlFromValue(hostname);
    stubResponse.setOwningApplicationId("SYSGEN787551898");
    stubResponse.setOwningApplicationKey("APPKEY1037142019052317562540722002");
    stubResponse.setCreatedBy("apigee@lumen.com");
    stubResponse.setEnvironment(env);
    stubResponse.setEndPointUrl("https://partnerABC.com");
    stubResponse.setReplaceUrlFromValue("Partner/v1/" + partnerName + "/" + resource);
    stubResponse.setReplaceUrlToValue("/partner/endpoint/path");
    stubResponse.setEndpointAuthType("basicAuth");
    stubResponse.setBasicAuthUser("my_user");
    stubResponse.setBasicAuthPassword("my_password");
    stubResponse.setResourceGuid(UUID.randomUUID().toString());
    
    return stubResponse;

  }

  @Test
  void shouldGetProxyOAuth() throws Exception {
    
    //given 
    String espEnv = "prod";
    String partnerName = "PartnerName";
    String taxonomy = "Partner/" + partnerName;
    String resource = "partnerResource";
    String hostname = "http://mocktarget.partner.com";
    String paramLocation = "Form Parameter";
    ApiMediatedResource espResource = buildApiMediatedResourceOAuthResponse(taxonomy, resource, espEnv, 
        hostname, paramLocation);
    UUID proxyGuid = UUID.fromString(espResource.getResourceGuid());

    //when
    Mockito.when(espClient.getApiProxyEnvDetails(espEnv, proxyGuid)).thenReturn(espResource);
    String environment = "PRODUCTION";
    String proxyGateway = "ESP";
    PartnerProxy partnerProxy = partnerProxyService.getPartnerProxy(proxyGateway, environment, proxyGuid);
    
    //then 
    assertThat(partnerProxy.getPartnerName()).isEqualTo("PartnerName");
    assertThat(partnerProxy.getPartnerResource()).isEqualTo("partnerResource");
    assertThat(partnerProxy.getProxyGateway()).isEqualTo(PartnerProxy.ProxyGatewayEnum.ESP);
    assertThat(partnerProxy.getProxyVersion()).isEqualTo("v1");
    assertThat(partnerProxy.getProxyOwnerAppKey()).isEqualTo("APPKEY1037142019052317562540722002");
    assertThat(partnerProxy.getProxyOwnerSysgen()).isEqualTo("SYSGEN787551898");
    assertThat(partnerProxy.getProxyOwnerEmail()).isEqualTo("apigee@lumen.com");
    assertThat(partnerProxy.getProxyGateway()).isEqualTo(PartnerProxy.ProxyGatewayEnum.ESP);
    assertThat(partnerProxy.getProxyGuid()).isEqualTo(proxyGuid);
    PartnerEndpoint partnerEndpoint = partnerProxy.getPartnerEndpoint();
    assertThat(partnerEndpoint.getEnvironment()).isEqualTo(EnvironmentEnum.PRODUCTION);
    assertThat(partnerEndpoint.getEndpointHostname()).isEqualTo("https://partnerABC.com");
    assertThat(partnerEndpoint.getEndpointPath()).isEqualTo("/partner/endpoint/path");
    OAuth20 oauth = (OAuth20) partnerEndpoint.getAuthentication();
    assertThat(oauth.getOauthGrantLocation()).isEqualTo(OauthGrantLocationEnum.FORM_PARAM);
    assertThat(oauth.getOauthGrantType()).isEqualTo(OauthGrantTypeEnum.CLIENT_CREDENTIALS);
    assertThat(oauth.getOauthTokenServiceHost()).isEqualTo("partner.tokenhost.com");
    assertThat(oauth.getOauthTokenServicePath()).isEqualTo("/oauth2/token");
    assertThat(oauth.getOauthClientIdLocation()).isEqualTo(OauthClientIdLocationEnum.FORM_PARAM);
    assertThat(oauth.getOauthClientId()).isEqualTo("clientIdabc123");
    assertThat(oauth.getOauthClientSecret()).isEqualTo("clientSecretabc123");
    assertThat(oauth.getOauthScopeLocation()).isEqualTo(OauthScopeLocationEnum.FORM_PARAM);
    assertThat(oauth.getOauthScope()).isEqualTo("");

  }

  public ApiMediatedResource buildApiMediatedResourceOAuthResponse(String partnerName, String resource, String env,
      String hostname, String paramLocation) {
    
    ApiMediatedResource stubResponse = new ApiMediatedResource();
    
    stubResponse.setResourceTaxonomy("Partner/" + partnerName);
    stubResponse.setResourceName(resource);
    stubResponse.setVersion("v1");
    stubResponse.setReplaceUrlFromValue(hostname);
    stubResponse.setOwningApplicationId("SYSGEN787551898");
    stubResponse.setOwningApplicationKey("APPKEY1037142019052317562540722002");
    stubResponse.setCreatedBy("apigee@lumen.com");
    stubResponse.setEnvironment(env);
    stubResponse.setEndPointUrl("https://partnerABC.com");
    stubResponse.setReplaceUrlFromValue("Partner/v1/" + partnerName + "/" + resource);
    stubResponse.setReplaceUrlToValue("/partner/endpoint/path");
    stubResponse.setEndpointAuthType("oAuth");
    stubResponse.setoAuthGrantTypeLocation(paramLocation);
    stubResponse.setoAuthTokenServiceHost("partner.tokenhost.com");
    stubResponse.setoAuthTokenServiceUri("/oauth2/token");
    stubResponse.setoAuthClientIdLocation(paramLocation);
    stubResponse.setoAuthClientId("clientIdabc123");
    stubResponse.setoAuthClientSecret("clientSecretabc123");
    stubResponse.setoAuthScopeLocation(paramLocation);
    stubResponse.setoAuthScope("");
    stubResponse.setResourceGuid(UUID.randomUUID().toString());

    return stubResponse;

  }
  
  @Test
  void shouldGetProxyOAuthQuery() throws Exception {
    
    //given 
    String espEnv = "test1";
    String partnerName = "PartnerName";
    String taxonomy = "Partner/" + partnerName;
    String resource = "partnerResource";
    String proxyVersion = "v1";
    String hostname = "http://mocktarget.partner.com";
    String paramLocation = "Query Parameter";
    ApiMediatedResource espResource = buildApiMediatedResourceOAuthResponse(taxonomy, resource, espEnv, 
        hostname, paramLocation);
    UUID proxyGuid = UUID.fromString(espResource.getResourceGuid());

    //when
    Mockito.when(espClient.getApiProxyEnvDetails(espEnv, proxyGuid)).thenReturn(espResource);
    String environment = "TEST1";
    String proxyGateway = "ESP";
    PartnerProxy partnerProxy = partnerProxyService.getPartnerProxy(proxyGateway, environment, proxyGuid);

    //then 
    assertThat(partnerProxy.getPartnerName()).isEqualTo("PartnerName");
    assertThat(partnerProxy.getPartnerResource()).isEqualTo("partnerResource");
    assertThat(partnerProxy.getProxyGateway()).isEqualTo(PartnerProxy.ProxyGatewayEnum.ESP);
    assertThat(partnerProxy.getProxyVersion()).isEqualTo(proxyVersion);
    assertThat(partnerProxy.getProxyOwnerAppKey()).isEqualTo("APPKEY1037142019052317562540722002");
    assertThat(partnerProxy.getProxyOwnerSysgen()).isEqualTo("SYSGEN787551898");
    assertThat(partnerProxy.getProxyOwnerEmail()).isEqualTo("apigee@lumen.com");
    assertThat(partnerProxy.getProxyGateway()).isEqualTo(PartnerProxy.ProxyGatewayEnum.ESP);
    assertThat(partnerProxy.getProxyGuid().equals(proxyGuid));
    PartnerEndpoint partnerEndpoint = partnerProxy.getPartnerEndpoint();
    assertThat(partnerEndpoint.getEnvironment()).isEqualTo(EnvironmentEnum.TEST1);
    assertThat(partnerEndpoint.getEndpointHostname()).isEqualTo("https://partnerABC.com");
    assertThat(partnerEndpoint.getEndpointPath()).isEqualTo("/partner/endpoint/path");
    OAuth20 oauth = (OAuth20) partnerEndpoint.getAuthentication();
    assertThat(oauth.getOauthGrantLocation()).isEqualTo(OauthGrantLocationEnum.QUERY_PARAM);
    assertThat(oauth.getOauthGrantType()).isEqualTo(OauthGrantTypeEnum.CLIENT_CREDENTIALS);
    assertThat(oauth.getOauthTokenServiceHost()).isEqualTo("partner.tokenhost.com");
    assertThat(oauth.getOauthTokenServicePath()).isEqualTo("/oauth2/token");
    assertThat(oauth.getOauthClientIdLocation()).isEqualTo(OauthClientIdLocationEnum.QUERY_PARAM);
    assertThat(oauth.getOauthClientId()).isEqualTo("clientIdabc123");
    assertThat(oauth.getOauthClientSecret()).isEqualTo("clientSecretabc123");
    assertThat(oauth.getOauthScopeLocation()).isEqualTo(OauthScopeLocationEnum.QUERY_PARAM);
    assertThat(oauth.getOauthScope()).isEmpty();

  }

  @Test
  void shouldTransformToEspEnv() throws Exception {
    
    //given 
    String envTest1 = "TEST1";
    String envProd = "PRODUCTION";

    //when
    String envTest1Transformed = partnerProxyService.validateAndTransformEnvironmentToEspEnv(envTest1);
    String envProdTransformed = partnerProxyService.validateAndTransformEnvironmentToEspEnv(envProd);
    
    //then 
    assertThat(envTest1Transformed).isEqualTo("test1");
    assertThat(envProdTransformed).isEqualTo("prod");

  }

  @Test
  void shouldFailOnEnumValidations() throws Exception {

    //given
    PartnerProxy partnerProxy1 = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "oauth_client_form");
    partnerProxy1.getPartnerEndpoint().setEnvironment(null);

    PartnerProxy partnerProxy2 = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "oauth_client_form");
    OAuth20 oauth2 = (OAuth20) partnerProxy2.getPartnerEndpoint().getAuthentication();
    oauth2.setOauthGrantType(null);
    partnerProxy2.getPartnerEndpoint().setAuthentication(oauth2);

    PartnerProxy partnerProxy3 = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "oauth_client_form");
    OAuth20 oauth3 = (OAuth20) partnerProxy3.getPartnerEndpoint().getAuthentication();
    oauth3.setOauthGrantLocation(null);
    partnerProxy3.getPartnerEndpoint().setAuthentication(oauth3);

    PartnerProxy partnerProxy4 = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "oauth_client_form");
    OAuth20 oauth4 = (OAuth20) partnerProxy4.getPartnerEndpoint().getAuthentication();
    oauth4.setOauthClientIdLocation(null);
    partnerProxy4.getPartnerEndpoint().setAuthentication(oauth4);

    PartnerProxy partnerProxy5 = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "oauth_client_form");
    OAuth20 oauth5 = (OAuth20) partnerProxy5.getPartnerEndpoint().getAuthentication();
    oauth5.setOauthScopeLocation(null);
    partnerProxy5.getPartnerEndpoint().setAuthentication(oauth5);

    //when-then
    assertThatExceptionOfType(BadInputException.class)
    .isThrownBy(() -> {
      partnerProxyService.buildInputApiRequest(partnerProxy1);
    })
        .withMessageContaining("Invalid environment");

    assertThatExceptionOfType(BadInputException.class)
    .isThrownBy(() -> {
      partnerProxyService.buildInputApiRequest(partnerProxy2);
    })
        .withMessageContaining("Invalid oauthGrantType");

    assertThatExceptionOfType(BadInputException.class)
    .isThrownBy(() -> {
      partnerProxyService.buildInputApiRequest(partnerProxy3);
    })
        .withMessageContaining("Invalid oauthGrantLocation");

    assertThatExceptionOfType(BadInputException.class)
    .isThrownBy(() -> {
      partnerProxyService.buildInputApiRequest(partnerProxy4);
    })
        .withMessageContaining("Invalid oauthClientIdLocation");

    assertThatExceptionOfType(BadInputException.class)
    .isThrownBy(() -> {
      partnerProxyService.buildInputApiRequest(partnerProxy5);
    })
        .withMessageContaining("Invalid oauthScopeLocation");

  }
  
  @Test
  void shouldFailOnCreateProxyCallForInvalidEnv() throws Exception {

    //given
    PartnerProxy partnerProxy = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "oauth_client_form");
    Jwt jwt = getMockJwtToken("test", "role", "API-HUB Partner Proxy");
    
    //when
    Mockito.when(proxyService.postProxyRequest(any(InputApiRequest.class), eq(jwt)))
        .thenThrow(new IOException("Error creating proxy in ESP."));

    //then
    assertThatExceptionOfType(InternalServerException.class)
    .isThrownBy(() -> {
      partnerProxyService.createProxy(partnerProxy, jwt);
    })
        .withMessageContaining("Error creating proxy in ESP.");

  }

  @Test
  void shouldFailOnCreateProxyCallForDuplicateProxy() throws Exception {

    //given
    PartnerProxy partnerProxy = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "oauth_client_form");
    Jwt jwt = getMockJwtToken("test", "role", "API-HUB Partner Proxy");
    
    //when
    Mockito.when(proxyService.postProxyRequest(any(InputApiRequest.class), eq(jwt)))
        .thenThrow(new BadInputException("Proxy already exists."));

    //then
    assertThatExceptionOfType(BadInputException.class)
    .isThrownBy(() -> {
      partnerProxyService.createProxy(partnerProxy, jwt);
    })
        .withMessageContaining("Proxy already exists.");

  }

  @Test
  void shouldFailForInvalidProxyGateway() throws Exception {

    //given
    PartnerProxy partnerProxy = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "oauth_client_form");
    Jwt jwt = getMockJwtToken("test", "role", "API-HUB Partner Proxy");
    
    //when
    Mockito.when(proxyService.postProxyRequest(any(InputApiRequest.class), eq(jwt)))
        .thenThrow(new IOException("Error creating proxy in ESP."));

    //then
    assertThatExceptionOfType(InternalServerException.class)
    .isThrownBy(() -> {
      partnerProxyService.createProxy(partnerProxy, jwt);
    })
        .withMessageContaining("Error creating proxy in ESP.");

  }

  @Test
  void shouldFailOnGetProxyCallForInvalidEnum() throws Exception {

    //given-when-then
    assertThatExceptionOfType(BadInputException.class)
    .isThrownBy(() -> {
      partnerProxyService.getPartnerProxy("ESP", "xxxx", UUID.randomUUID());
    })
        .withMessageContaining("Invalid environment");

    assertThatExceptionOfType(BadInputException.class)
    .isThrownBy(() -> {
      partnerProxyService.getPartnerProxy("XXX", "TEST1", UUID.randomUUID());
    })
        .withMessageContaining("Invalid proxyGateway");

  }

  @Test
  void shouldFailOnCreateProxyCall() throws Exception {

    //given addNewProxyToApiProduct
    PartnerProxy partnerProxy = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "oauth_client_query");
    Jwt jwt = getMockJwtToken("test", "role", "API-HUB Partner Proxy");
    
    //when
    Mockito.when(proxyService.postProxyRequest(any(InputApiRequest.class), eq(jwt))).thenThrow(IOException.class);
        
    //then
    assertThatExceptionOfType(InternalServerException.class)
    .isThrownBy(() -> {
      partnerProxyService.createProxy(partnerProxy, jwt);
    })
        .withMessageContaining("Error creating proxy in ESP.");

  }

  @Test
  void shouldFailOnAddRemoveProxyFromApiProductCallForProductNotFound() throws Exception {

    //given
    ApigeeProduct product1 = null;
    ApigeeProduct product2 = new ApigeeProduct();
    
    //when
    Mockito.when(apigeeProductsService.getProduct("API-HUB Partner Proxy", "NONPROD", "INTERNAL")).thenReturn(product1);
    Mockito.when(apigeeProductsService.getProduct("API-HUB Partner Proxy", "PROD", "INTERNAL")).thenReturn(product2);

    Mockito.when(partnerProxyConfigProperties.getApiProductName()).thenReturn("API-HUB Partner Proxy");

    //then
    assertThatExceptionOfType(InternalServerException.class)
    .isThrownBy(() -> {
      partnerProxyService.removeProxyFromApigee("apigeeProxyName", "prod");
    })
        .withMessageContaining("Unable to retrieve Apigee API Product");

    assertThatExceptionOfType(InternalServerException.class)
    .isThrownBy(() -> {
      partnerProxyService.removeProxyFromApigee("apigeeProxyName", "test1");
    })
        .withMessageContaining("Unable to retrieve Apigee API Product");

  }

  @Test
  void shouldFailOnDeleteProxyForInvalidEnums() throws Exception {

    //given-when-then
    assertThatExceptionOfType(BadInputException.class)
    .isThrownBy(() -> {
      partnerProxyService.deletePartnerProxy("ESP", "xxxx", UUID.randomUUID());
    })
        .withMessageContaining("Invalid environment");

    assertThatExceptionOfType(BadInputException.class)
    .isThrownBy(() -> {
      partnerProxyService.deletePartnerProxy("XXX", "TEST1", UUID.randomUUID());
    })
        .withMessageContaining("Invalid proxyGateway");

  }

  @Test
  void shouldFailOnDeleteProxyForProdProxyMissingInProduct() throws Exception {

    //given 
    String espEnv = "prod";
    String partnerName = "PartnerName";
    String taxonomy = "Partner/" + partnerName;
    String resource = "partnerResource";
    String proxyVersion = "v1";
    String hostname = "http://mocktarget.partner.com";
    ApiMediatedResource espResource = buildApiMediatedResourceBasicAuthResponse(taxonomy, resource, espEnv, hostname);
    UUID proxyGuid = UUID.fromString(espResource.getResourceGuid());
    String productName = "API-HUB Partner Proxy";
    ApigeeProduct product = buildTestApigeeProduct(productName, "manual", 
        Planet.PROD, AccessLocation.INTERNAL);
    
    //when
    Mockito.when(apigeeProductsService.getProduct(productName, "PROD", "INTERNAL"))
        .thenReturn(product);
    Mockito.when(partnerProxyConfigProperties.getApiProductName()).thenReturn(productName);
    Mockito.when(espClient.getApiProxyEnvDetails(espEnv, proxyGuid)).thenReturn(espResource);
        
    //then
    String environment = "PRODUCTION";
    String proxyGateway = "ESP";
    assertThatExceptionOfType(InternalServerException.class)
    .isThrownBy(() -> {
      partnerProxyService.deletePartnerProxy(proxyGateway, environment, proxyGuid);
    })
        .withMessageContaining("proxy not found in Apigee API Product:");

  }

  @Test
  void shouldFailOnGetApiCall() throws Exception {

    //given
    UUID proxyGuid = UUID.randomUUID();
    
    //when
    Mockito.when(espClient.getApiProxyEnvDetails("test1", proxyGuid))
        .thenThrow(new InternalServerException("Error calling ESP."));

    //then
    assertThatExceptionOfType(InternalServerException.class)
    .isThrownBy(() -> {
      partnerProxyService.getPartnerProxy("ESP", "TEST1", proxyGuid);
    })
        .withMessageContaining("An internal server error occurred calling ESP");

  }

  @Test
  void shouldThrowForbiddenException() throws Exception {

    //given
    Jwt jwt = getMockJwtToken("test", "role", "Not an authorized API Product");
    PartnerProxy partnerProxy = buildTestPartnerProxyRequest("PartnerABC", "partnerResource", 
        "v1", EnvironmentEnum.TEST1, "https://hostname.com", "partnerPath", "oauth_client_form");
        
    //when
    Mockito.when(proxyService.postProxyRequest(any(InputApiRequest.class), eq(jwt)))
        .thenThrow(new ForbiddenException(""));

    //then
    assertThatExceptionOfType(ForbiddenException.class)
        .isThrownBy(() -> {
          partnerProxyService.createProxy(partnerProxy, jwt);
        });

  }

  @Test
  void shouldFailOnDeleteApiCall() throws Exception {

    //given 
    String espEnv = "test1";
    String partnerName = "PartnerName";
    String taxonomy = "Partner/" + partnerName;
    String resource = "partnerResource";
    String proxyVersion = "v1";
    String hostname = "http://mocktarget.partner.com";
    ApiMediatedResource espResource = buildApiMediatedResourceBasicAuthResponse(taxonomy, resource, espEnv, hostname);
    UUID proxyGuid = UUID.fromString(espResource.getResourceGuid());
    String productName = "API-HUB Partner Proxy";
    Planet apigeePlanet = Planet.NONPROD;
    ApigeeProduct product = buildTestApigeeProduct(productName, "manual", 
        Planet.NONPROD, AccessLocation.INTERNAL);
    ApigeeProduct updatedProduct = buildTestApigeeProduct(productName, "manual", 
        Planet.NONPROD, AccessLocation.INTERNAL);
    product.getProxies().add("Esp_IntMed_Partner_v1_PartnerName_partnerResource_" + espResource.getResourceGuid());
    
    //when
    Mockito.when(partnerProxyConfigProperties.getApiProductName()).thenReturn(productName);
    Mockito.when(espClient.getApiProxyEnvDetails(espEnv, proxyGuid)).thenReturn(espResource);
    Mockito.when(apigeeProductsService.getProduct(productName, "NONPROD", "INTERNAL"))
        .thenReturn(product);
    Mockito.when(apigeeProductsService.updatePartnerProxyProduct(apigeePlanet, product))
        .thenReturn(updatedProduct);
    
    Mockito.doNothing().when(espClient).undeployApiProxy("12345", espResource.getEnvironment(), "undeployInternal");
    Mockito.doThrow(InternalServerException.class).when(espClient)
        .deleteApiProxy("12345", espResource.getEnvironment());
        
    //then
    String environment = "TEST1";
    String proxyGateway = "ESP";
    assertThatExceptionOfType(InternalServerException.class)
    .isThrownBy(() -> {
      partnerProxyService.deletePartnerProxy(proxyGateway, environment, proxyGuid);
    })
        .withMessageContaining("An internal server error occurred calling ESP");
    
  }

  @Test
  void shouldThrowNotFoundOnGetApiCall() throws Exception {

    //given
    ApiMediatedResource espResponse1 = null;
    UUID proxyGuid = UUID.randomUUID();
    
    //when
    Mockito.when(espClient.getApiProxyEnvDetails("test1", proxyGuid))
         .thenReturn(espResponse1);

    //then
    assertThatExceptionOfType(NotFoundException.class)
    .isThrownBy(() -> {
      partnerProxyService.getPartnerProxy("ESP", "TEST1", proxyGuid);
    })
        .withMessageContaining("Partner proxy not found");

  }

  @Test
  void shouldFailOnValidateAndTransformEnvironmentToEspEnv() throws Exception {

    //given-when-then
    assertThatExceptionOfType(BadInputException.class)
    .isThrownBy(() -> {
      partnerProxyService.validateAndTransformEnvironmentToEspEnv("INVALID_ENV");
    })
        .withMessageContaining("Invalid environment");

  }

  @Test
  void shouldFailOnValidateProxyGateway() throws Exception {

    //given-when-then
    assertThatExceptionOfType(BadInputException.class)
    .isThrownBy(() -> {
      partnerProxyService.validateProxyGateway("INVALID_GATEWAY");
    })
        .withMessageContaining("Invalid proxyGateway");

  }

  private static PartnerProxy buildTestPartnerProxyRequest(String partnerName, String partnerResource, 
      String proxyVersion, EnvironmentEnum env, String endpointHostname, String endpointPath, String auth) {
    
    PartnerProxy proxy = new PartnerProxy();
    proxy.setPartnerName(partnerName);
    proxy.setPartnerResource(partnerResource);
    proxy.setProxyVersion(proxyVersion);
    proxy.setProxyOwnerAppKey("APPKEY12345678901234567890");
    proxy.setProxyOwnerSysgen("SYSGEN787489521");
    proxy.setProxyOwnerEmail("jeremy.eagleman@lumen.com");
    proxy.setProxyGateway(PartnerProxy.ProxyGatewayEnum.ESP);
    PartnerEndpoint partnerEndpoint = new PartnerEndpoint();
    partnerEndpoint.setEnvironment(env);
    partnerEndpoint.setEndpointHostname(endpointHostname);
    partnerEndpoint.setEndpointPath(endpointPath);
    OAuth20 oauth2 = new OAuth20();
    BasicAuth basicAuth = new BasicAuth();
    
    if (auth.equals("oauth_client_form")) {
      oauth2.setOauthGrantType(OAuth20.OauthGrantTypeEnum.CLIENT_CREDENTIALS);
      oauth2.setOauthGrantLocation(OAuth20.OauthGrantLocationEnum.FORM_PARAM);
      oauth2.setOauthTokenServiceHost("https://oauthtokenhostname");
      oauth2.setOauthTokenServicePath("/oauth/v1/token");
      oauth2.setOauthClientIdLocation(OAuth20.OauthClientIdLocationEnum.FORM_PARAM);
      oauth2.setOauthClientId("oauth_clinet_id");
      oauth2.setOauthClientSecret("oauth_client_secret");
      oauth2.setOauthScopeLocation(OAuth20.OauthScopeLocationEnum.FORM_PARAM);
      oauth2.setOauthScope("oauth_scope");
      partnerEndpoint.setAuthentication(oauth2);
      
    } else if (auth.equals("oauth_client_query")) {
      oauth2.setOauthGrantType(OAuth20.OauthGrantTypeEnum.CLIENT_CREDENTIALS);
      oauth2.setOauthGrantLocation(OAuth20.OauthGrantLocationEnum.QUERY_PARAM);
      oauth2.setOauthTokenServiceHost("https://oauthtokenhostname");
      oauth2.setOauthTokenServicePath("/oauth/v1/token");
      oauth2.setOauthClientIdLocation(OAuth20.OauthClientIdLocationEnum.QUERY_PARAM);
      oauth2.setOauthClientId("oauth_clinet_id");
      oauth2.setOauthClientSecret("oauth_client_secret");
      oauth2.setOauthScopeLocation(OAuth20.OauthScopeLocationEnum.QUERY_PARAM);
      oauth2.setOauthScope("oauth_scope");
      partnerEndpoint.setAuthentication(oauth2);
      
    } else if (auth.equals("basic_auth")) {
      basicAuth.setBasicAuthUser("ba_user");
      basicAuth.setBasicAuthPassword("ba_password");
      partnerEndpoint.setAuthentication(basicAuth);
      
    }
    
    proxy.setPartnerEndpoint(partnerEndpoint);
    return proxy;
  
  }
   
  public TaxonomyCreationResult buildEspClientCreateTaxonomiesStubResponse(String createdEnvs, String notCreatedEnvs) {
    
    TaxonomyCreationResult stubResponse = new TaxonomyCreationResult();
    
    stubResponse.setTaxonomy("Partner/PartnerABC");
    stubResponse.setTaxonomyCreatedEnv(new ArrayList<String>());
    stubResponse.getTaxonomyCreatedEnv().add(createdEnvs);
    stubResponse.setTaxonomyNotCreatedEnv(new ArrayList<String>());
    stubResponse.getTaxonomyNotCreatedEnv().add(notCreatedEnvs);
    return stubResponse;
  }
  
  private static ApigeeProduct buildTestApigeeProduct(String name, String approvalType, 
      Planet planet, AccessLocation accessLocation) {
    
    ApigeeProduct product = new ApigeeProduct();
    product.setApiResources(new ArrayList<String>(Arrays.asList("/ResourceA", "/ResourceB")));
    product.setApprovalType(approvalType);
    product.setDescription("myDescription");
    product.setDisplayName(name);
    product.setEnvironments(new ArrayList<String>(Arrays.asList("test1")));
    product.setName(name);
    product.setProxies(new ArrayList<String>(Arrays.asList("ProxyA", "ProxyB")));
    product.setScopes(new ArrayList<String>());

    return product;
  
  }
  
  @Test
  void shouldUpdateProxy() throws Exception {

    //given-when
    String partnerName = "PartnerName";
    String espEnv = "test1";
    String taxonomy = "Partner/" + partnerName;
    String resource = "partnerResource";
    String hostname = "http://mocktarget.partner.com";
    String proxyVersion = "v1";
    ApiMediatedResource espResource = buildApiMediatedResourceBasicAuthResponse(taxonomy, resource, espEnv, hostname);
    UUID proxyGuid = UUID.fromString(espResource.getResourceGuid());
   
    
    PartnerProxy partnerProxy = buildTestPartnerProxyRequest(partnerName, resource, 
        proxyVersion, EnvironmentEnum.TEST1, hostname, "partnerPath", "basic_auth");
    InputApiRequest inputApiRequest = partnerProxyService.buildInputApiRequest(partnerProxy);
    String myRequest = buildHandler.createBuildRequest(inputApiRequest);
    String proxyName = "Esp_IntMed_Partner_v1_PartnerName_partnerResource_" + proxyGuid;
    String planet = "NONPROD";
    String productName = "API-HUB Partner Proxy";
    ApigeeProduct product = buildTestApigeeProduct(productName, "manual", 
        Planet.NONPROD, AccessLocation.INTERNAL);
    product.getProxies().add(proxyName);
    
    //when
    Mockito.when(espClient.getApiProxyEnvDetails(espEnv, proxyGuid)).thenReturn(espResource);
    Mockito.doNothing().when(espClient).updateApiProxy("12345", myRequest, "test1", "jeremy.eagleman@lumen.com");
    Mockito.when(apigeeProductsService.getProduct(productName, planet, "INTERNAL"))
        .thenReturn(product);
    Mockito.when(partnerProxyConfigProperties.getApiProductName()).thenReturn(productName);
    Mockito.doNothing().when(espClient).undeployApiProxy("12345", "test1", "undeployInternal");
    Mockito.doNothing().when(espClient).deployApiProxy("12345", "test1", "deployInternal");

    //then
    String environment = "TEST1";
    String proxyGateway = "ESP";
    partnerProxyService.updateProxy(partnerProxy, proxyGateway, environment, proxyGuid);

  }

  @Test
  void shouldUpdateProxyProd() throws Exception {

    //given-when
    String partnerName = "PartnerName";
    String espEnv = "prod";
    String taxonomy = "Partner/" + partnerName;
    String resource = "partnerResource";
    String hostname = "http://mocktarget.partner.com";
    String proxyVersion = "v1";
    ApiMediatedResource espResource = buildApiMediatedResourceBasicAuthResponse(taxonomy, resource, espEnv, hostname);
    UUID proxyGuid = UUID.fromString(espResource.getResourceGuid());
   
    
    PartnerProxy partnerProxy = buildTestPartnerProxyRequest(partnerName, resource, 
        proxyVersion, EnvironmentEnum.PRODUCTION, hostname, "partnerPath", "basic_auth");
    InputApiRequest inputApiRequest = partnerProxyService.buildInputApiRequest(partnerProxy);
    String myRequest = buildHandler.createBuildRequest(inputApiRequest);
    String proxyName = "Esp_IntMed_Partner_v1_PartnerName_partnerResource_" + proxyGuid;
    String planet = "PROD";
    String productName = "API-HUB Partner Proxy";
    ApigeeProduct product = buildTestApigeeProduct(productName, "manual", 
        Planet.PROD, AccessLocation.INTERNAL);
    product.getProxies().add(proxyName);
    
    //when
    Mockito.when(espClient.getApiProxyEnvDetails(espEnv, proxyGuid)).thenReturn(espResource);
    Mockito.doNothing().when(espClient).updateApiProxy("12345", myRequest, "prod", "jeremy.eagleman@lumen.com");
    Mockito.when(apigeeProductsService.getProduct(productName, planet, "INTERNAL"))
        .thenReturn(product);
    Mockito.when(partnerProxyConfigProperties.getApiProductName()).thenReturn(productName);
    Mockito.doNothing().when(espClient).undeployApiProxy("12345", "prod", "undeployInternal");
    Mockito.doNothing().when(espClient).deployApiProxy("12345", "prod", "deployInternal");

    //then
    String environment = "PRODUCTION";
    String proxyGateway = "ESP";
    partnerProxyService.updateProxy(partnerProxy, proxyGateway, environment, proxyGuid);

  }

}
