package com.lumen.apiexchange.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class InputApiMigrationRequestTests {

  @Test
  public void testSetInputApiMigrationRequest() throws Exception {

    InputApiMigrationRequest request = new InputApiMigrationRequest();

    request.setMirrorEnvironment("setMirrorEnvironment");
    request.setDev1EndpointHostname("setDev1EndpointHostname");
    request.setDev2EndpointHostname("setDev2EndpointHostname");
    request.setDev3EndpointHostname("setDev3EndpointHostname");
    request.setDev4EndpointHostname("setDev4EndpointHostname");
    request.setTest1EndpointHostname("setTest1EndpointHostname");
    request.setTest2EndpointHostname("setTest2EndpointHostname");
    request.setTest3EndpointHostname("setTest3EndpointHostname");
    request.setTest4EndpointHostname("setTest4EndpointHostname");
    request.setGuid("setGuid");
    request.setRequestorEmail("setRequestorEmail");

    assertThat(request.getMirrorEnvironment()).isEqualTo("setMirrorEnvironment");
    assertThat(request.getDev1EndpointHostname()).isEqualTo("setDev1EndpointHostname");
    assertThat(request.getDev2EndpointHostname()).isEqualTo("setDev2EndpointHostname");
    assertThat(request.getDev3EndpointHostname()).isEqualTo("setDev3EndpointHostname");
    assertThat(request.getDev4EndpointHostname()).isEqualTo("setDev4EndpointHostname");
    assertThat(request.getTest1EndpointHostname()).isEqualTo("setTest1EndpointHostname");
    assertThat(request.getTest2EndpointHostname()).isEqualTo("setTest2EndpointHostname");
    assertThat(request.getTest3EndpointHostname()).isEqualTo("setTest3EndpointHostname");
    assertThat(request.getTest4EndpointHostname()).isEqualTo("setTest4EndpointHostname");
    assertThat(request.getGuid()).isEqualTo("setGuid");
    assertThat(request.getRequestorEmail()).isEqualTo("setRequestorEmail");

  }

  @Test
  public void testInputApiMigrationRequestToString() throws Exception {

    InputApiMigrationRequest request = new InputApiMigrationRequest();

    request.setMirrorEnvironment("setMirrorEnvironment");
    request.setDev1EndpointHostname("setDev1EndpointHostname");
    request.setDev2EndpointHostname("setDev2EndpointHostname");
    request.setDev3EndpointHostname("setDev3EndpointHostname");
    request.setDev4EndpointHostname("setDev4EndpointHostname");
    request.setTest1EndpointHostname("setTest1EndpointHostname");
    request.setTest2EndpointHostname("setTest2EndpointHostname");
    request.setTest3EndpointHostname("setTest3EndpointHostname");
    request.setTest4EndpointHostname("setTest4EndpointHostname");
    request.setGuid("setGuid");
    request.setRequestorEmail("setRequestorEmail");

    String myString = request.toString();

    assertTrue(!myString.isEmpty());

  }

  @Test
  public void testInputApiMigrationRequestToEmailString() throws Exception {

    InputApiMigrationRequest request = new InputApiMigrationRequest();

    request.setMirrorEnvironment("setMirrorEnvironment");
    request.setDev1EndpointHostname("setDev1EndpointHostname");
    request.setDev2EndpointHostname("setDev2EndpointHostname");
    request.setDev3EndpointHostname("setDev3EndpointHostname");
    request.setDev4EndpointHostname("setDev4EndpointHostname");
    request.setTest1EndpointHostname("setTest1EndpointHostname");
    request.setTest2EndpointHostname("setTest2EndpointHostname");
    request.setTest3EndpointHostname("setTest3EndpointHostname");
    request.setTest4EndpointHostname("setTest4EndpointHostname");
    request.setGuid("setGuid");
    request.setRequestorEmail("setRequestorEmail");

    String myString = request.toEmailString();

    assertTrue(!myString.isEmpty());

  }

}
