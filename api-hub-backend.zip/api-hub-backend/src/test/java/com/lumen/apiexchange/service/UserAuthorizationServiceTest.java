package com.lumen.apiexchange.service;

import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.assertj.core.api.AssertionsForClassTypes.assertThatExceptionOfType;
import static org.mockito.Mockito.when;

import com.lumen.apiexchange.config.UserAuthorizationConfigProperties;
import com.lumen.apiexchange.exception.ForbiddenException;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.oauth2.jwt.Jwt;

@ExtendWith(MockitoExtension.class)
class UserAuthorizationServiceTest {

  @InjectMocks
  UserAuthorizationServiceImpl userAuthorizationService;

  @Mock
  EmailBasedAuthzServiceImpl emailBasedAuthzService;

  @Mock
  UserAuthorizationConfigProperties userAuthorizationConfigProperties;

  static Jwt getMockJwtToken(String subject, String claim, String claimValue) {
    final Jwt jwt = Jwt.withTokenValue("token")
            .header("alg", "none")
            .claim(claim, claimValue)
            .subject(subject)
            .build();
    return jwt;
  }

  @Test
  void isOkToDeployToProdForRole() throws ForbiddenException {

    //given
    List<String> authorizedProducts = new ArrayList<String>();
    authorizedProducts.add("API-HUB Partner Proxy");

    Jwt jwt = getMockJwtToken("test", "role", "API-HUB Partner Proxy");

    //when
    UserAuthorizationConfigProperties.PartnerProxy partnerProxy = new UserAuthorizationConfigProperties.PartnerProxy();
    partnerProxy.setApiProducts(authorizedProducts);

    when(userAuthorizationConfigProperties.getPartnerProxy()).thenReturn(partnerProxy);

    //when
    assertThatNoException()
        .isThrownBy(() -> {
          userAuthorizationService.isOkToDeployToProd(jwt);
        });
  }

  @Test
  void isAuthorizedToUsePartnerProxy() throws ForbiddenException {

    //given
    List<String> authorizedProducts = new ArrayList<String>();
    authorizedProducts.add("API-HUB Partner Proxy");
    Jwt jwt = getMockJwtToken("test", "role", "API-HUB Partner Proxy");

    //when
    UserAuthorizationConfigProperties.PartnerProxy partnerProxy = new UserAuthorizationConfigProperties.PartnerProxy();
    partnerProxy.setApiProducts(authorizedProducts);
    when(userAuthorizationConfigProperties.getPartnerProxy()).thenReturn(partnerProxy);

    //when
    assertThatNoException()
        .isThrownBy(() -> {
          userAuthorizationService.isAuthorizedToUsePartnerProxy(jwt);
        });
  }

  @Test
  void isOkToDeployToProdForEmail() throws ForbiddenException {

    //given
    Jwt jwt = getMockJwtToken("test", "email", "jeremy.eagleman@lumen.com");

    //when
    Mockito.when(emailBasedAuthzService.isUserHubAdmin("jeremy.eagleman@lumen.com")).thenReturn(true);

    //then
    assertThatNoException()
        .isThrownBy(() -> {
          userAuthorizationService.isOkToDeployToProd(jwt);
        });

  }
  
  @Test
  void isNotOkToDeployToProdForRole() throws ForbiddenException {

    //given
    List<String> authorizedProducts = new ArrayList<String>();
    authorizedProducts.add("API-HUB Partner Proxy");
    
    Jwt jwt = getMockJwtToken("test", "role", "Anything But API-HUB Partner Proxy");

    //when
    UserAuthorizationConfigProperties.PartnerProxy partnerProxy = new UserAuthorizationConfigProperties.PartnerProxy();
    partnerProxy.setApiProducts(authorizedProducts);

    when(userAuthorizationConfigProperties.getPartnerProxy()).thenReturn(partnerProxy);

    //then
    assertThatExceptionOfType(ForbiddenException.class)
    .isThrownBy(() -> {
      userAuthorizationService.isOkToDeployToProd(jwt);
    })
        .withMessageContaining("not authorized for Production deployment");

  }

  @Test
  void isNotOkToDeployToProdForEmail() throws ForbiddenException {
    //given
    Jwt jwt = getMockJwtToken("test", "email", "john.jacob.smith@lumen.com");

    //when
    Mockito.when(emailBasedAuthzService.isUserHubAdmin("john.jacob.smith@lumen.com")).thenReturn(false);

    //then
    assertThatExceptionOfType(ForbiddenException.class)
    .isThrownBy(() -> {
      userAuthorizationService.isOkToDeployToProd(jwt);
    })
        .withMessageContaining("not authorized for Production deployment");

  }

  @Test
  void isNotOkToDeployToProdForMissingExpectedClaims() throws ForbiddenException {
    //given
    Jwt jwt = getMockJwtToken("test", "notEmailOrRole", "doesn't matter");

    //when-then
    assertThatExceptionOfType(ForbiddenException.class)
    .isThrownBy(() -> {
      userAuthorizationService.isOkToDeployToProd(jwt);
    })
        .withMessageContaining("not authorized for Production deployment");

  }

  @Test
  void isNotAuthorizedToUsePartnerProxy() throws ForbiddenException {

    //given
    List<String> authorizedProducts = new ArrayList<String>();
    authorizedProducts.add("API-HUB Partner Proxy");
    
    Jwt jwt = getMockJwtToken("test", "role", "Anything But API-HUB Partner Proxy");

    //when
    UserAuthorizationConfigProperties.PartnerProxy partnerProxy = new UserAuthorizationConfigProperties.PartnerProxy();
    partnerProxy.setApiProducts(authorizedProducts);

    when(userAuthorizationConfigProperties.getPartnerProxy()).thenReturn(partnerProxy);

    //then
    assertThatExceptionOfType(ForbiddenException.class)
    .isThrownBy(() -> {
      userAuthorizationService.isAuthorizedToUsePartnerProxy(jwt);
    })
        .withMessageContaining("The client is not authorized for Partner Proxy");

  }

}