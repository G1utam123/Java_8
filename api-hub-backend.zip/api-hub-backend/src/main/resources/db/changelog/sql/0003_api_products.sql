-- liquibase formatted sql

-- changeset api-hub:3

CREATE TABLE api_products (
    id uuid PRIMARY KEY,
    name text,
    display_name text,
    description text,
    source_system text,
    source_system_key text,
    planet text,
    external boolean,
    access text,
    approval_type text,
    visibility text,
    created_by text,
    created_date timestamp,
    last_updated_by text,
    last_updated_date timestamp
);
