-- liquibase formatted sql

-- changeset api-hub:2

CREATE TABLE audit_trail (
    id uuid PRIMARY KEY,
    date timestamp,
    username text,
    action text,
    description text,
    result text
);