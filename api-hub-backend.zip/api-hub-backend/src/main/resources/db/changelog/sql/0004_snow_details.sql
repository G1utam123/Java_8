-- liquibase formatted sql

-- changeset api-hub:4
CREATE TABLE ownership_status (
	
	id uuid PRIMARY KEY,
	element_id text,
	element_type text,
	request_no text,
	status text,
	requester text
	
    
);
