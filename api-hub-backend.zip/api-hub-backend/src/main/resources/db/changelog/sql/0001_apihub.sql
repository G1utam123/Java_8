-- liquibase formatted sql

-- changeset api-hub:1

CREATE TABLE apiproxydetailsdatanew (
    id uuid PRIMARY KEY,
    api_id uuid,
    created_date timestamp,
    created_user_id text,
    created_user_name text,
    last_updated_date timestamp,
    resource_guuid text
);

CREATE TABLE apihomedetailsdata (
    id uuid PRIMARY KEY,
    author text,
    category text,
    created_date timestamp,
    description text,
    last_updated_date timestamp,
    name text,
    oas_url text,
    source_code_url text,
    status text,
    type text,
    version text
);

CREATE TABLE apidocumentationdata (
    id int PRIMARY KEY,
    api_id UUID,
    api_name text,
    documentation text,
    filecontent text,
    section_order int,
    section_type text,
    yaml text,
    yamlurl text
);
