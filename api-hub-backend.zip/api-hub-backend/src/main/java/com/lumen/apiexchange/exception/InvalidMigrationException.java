package com.lumen.apiexchange.exception;

public class InvalidMigrationException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public InvalidMigrationException(String message) {
    super(message);
  }

}
