package com.lumen.apiexchange.exception;

public class AppNotFoundException extends Exception {

  private static final long serialVersionUID = 1L;

  public AppNotFoundException(String message) {
    super(message);
  }

}
