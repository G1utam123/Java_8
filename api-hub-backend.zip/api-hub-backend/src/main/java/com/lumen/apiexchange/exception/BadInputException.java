package com.lumen.apiexchange.exception;

import com.lumen.apiexchange.api.partner.model.Error400;
import com.lumen.apiexchange.api.partner.model.Error400Code;

public class BadInputException extends RuntimeException {

  private static final long serialVersionUID = 1L;
  private final String message;
  private final Error400 error;
  
  public BadInputException(String message) {
    super(message);
    this.message = message;
    this.error = new Error400();
  }
  
  public BadInputException(Error400Code code, String reason, String message) {
    super(message);
    this.message = message;
    this.error = BuildCommonCodeHelper.buildCommonCode400(code, reason, message);
  }

  public Error400 getError() {
    return error;
  }
  
}
