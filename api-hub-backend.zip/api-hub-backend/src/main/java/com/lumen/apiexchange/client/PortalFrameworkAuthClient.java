package com.lumen.apiexchange.client;

import com.lumen.apiexchange.model.myapps.ProfileDetailsResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class PortalFrameworkAuthClient {

  @Autowired
  private RestTemplate restTemplate;

  @Value("${profile.details.url}")
  private String profileDetailsUrl;

  public ProfileDetailsResponse getProfileDetails(String token) {

    HttpHeaders headers = new HttpHeaders();
    headers.setBearerAuth(token.trim());

    HttpEntity<String> entity = new HttpEntity<>(headers);
    ResponseEntity<ProfileDetailsResponse> resp = restTemplate.exchange(profileDetailsUrl, HttpMethod.GET, entity,
        ProfileDetailsResponse.class);

    return resp.getBody();
  }

}
