package com.lumen.apiexchange.model.myapps.api.product;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ApigeeApiProductModelResponse {

  private List<ApigeeApiProductModel> apiProduct;

  public ApigeeApiProductModelResponse() {
  }

  public ApigeeApiProductModelResponse(List<ApigeeApiProductModel> apiProduct) {
    this.apiProduct = apiProduct;
  }

  public List<ApigeeApiProductModel> getApiProduct() {
    return apiProduct;
  }

  public void setApiProduct(List<ApigeeApiProductModel> apiProduct) {
    this.apiProduct = apiProduct;
  }
  
}
