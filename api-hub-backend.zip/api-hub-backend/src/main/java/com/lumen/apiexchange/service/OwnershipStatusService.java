package com.lumen.apiexchange.service;

import com.lumen.apiexchange.entity.OwnershipStatus;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.OwnershipStatusNotFoundException;
import com.lumen.apiexchange.exception.OwnershipStatusUniqueRecordNotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface OwnershipStatusService {

  OwnershipStatus getOwnershipStatus(String elementId) throws InternalServerException,
            OwnershipStatusUniqueRecordNotFoundException;
  
  Page<OwnershipStatus> getOwnerships(Pageable pageable) throws InternalServerException;
  
  Page<OwnershipStatus> getOwnershipStatusByStatus(String status, Pageable pageable)
      throws InternalServerException;

  Page<OwnershipStatus> getOwnershipStatusByType(String elementType, Pageable pageable)
      throws InternalServerException;

  Page<OwnershipStatus> getOwnershipStatusByTypeAndStatus(String elementType, String status, Pageable pageable);
  
  OwnershipStatus updateOwnership(OwnershipStatus ownership) throws InternalServerException,
      OwnershipStatusNotFoundException, OwnershipStatusUniqueRecordNotFoundException;


}
