package com.lumen.apiexchange.repository;

import com.lumen.apiexchange.entity.OwnershipStatus;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface OwnershipRepository extends JpaRepository<OwnershipStatus, UUID> {
  
  Optional<OwnershipStatus> findByElementId(String elementId);
  
  Page<OwnershipStatus> getOwnershipByStatus(String status, Pageable pageable);

  Page<OwnershipStatus> getOwnershipByElementType(String elementType, Pageable pageable);

  Page<OwnershipStatus> getOwnershipByElementTypeAndStatus(String elementType, String status, Pageable pageable);

  Optional<OwnershipStatus> findByRequestNo(String requestNo);

}
