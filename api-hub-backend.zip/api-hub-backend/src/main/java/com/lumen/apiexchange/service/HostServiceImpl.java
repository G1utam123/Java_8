package com.lumen.apiexchange.service;

import com.lumen.apiexchange.config.ApigeeConfigProperties;
import com.lumen.apiexchange.config.MediationResourceConfigProperties;
import com.lumen.apiexchange.exception.InternalServerException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class HostServiceImpl {

  private final MediationResourceConfigProperties mediationResourceConfigProp;
  private final ApigeeConfigProperties apigeeConfigProp;
  
  public HostServiceImpl(MediationResourceConfigProperties mediationResourceConfigProp,
      ApigeeConfigProperties apigeeConfigProp) {
    this.mediationResourceConfigProp = mediationResourceConfigProp;
    this.apigeeConfigProp = apigeeConfigProp;
  }

  public List<String> getHosts() {
    List<String> hostList = new ArrayList<>();
    hostList.add(mediationResourceConfigProp.getHostnameDev1());
    hostList.add(mediationResourceConfigProp.getHostnameDev2());
    hostList.add(mediationResourceConfigProp.getHostnameDev3());
    hostList.add(mediationResourceConfigProp.getHostnameDev4());
    hostList.add(mediationResourceConfigProp.getHostnameTest1());
    hostList.add(mediationResourceConfigProp.getHostnameTest2());
    hostList.add(mediationResourceConfigProp.getHostnameTest3());
    hostList.add(mediationResourceConfigProp.getHostnameTest4());
    hostList.add(mediationResourceConfigProp.getHostnameMock());
    hostList.add(mediationResourceConfigProp.getHostnameSandbox());
    hostList.add(mediationResourceConfigProp.getHostnameProd());

    return hostList;
  }
  
  public String getEnvHostname(String env) throws InternalServerException {
    String envHostName = "";

    switch (env.toLowerCase()) {
      case "dev1":
        envHostName = apigeeConfigProp.getApigeeHostnameDev1();
        break;
      case "dev2":
        envHostName = apigeeConfigProp.getApigeeHostnameDev2();
        break;
      case "dev3":
        envHostName = apigeeConfigProp.getApigeeHostnameDev3();
        break;
      case "dev4":
        envHostName = apigeeConfigProp.getApigeeHostnameDev4();
        break;
      case "test1":
        envHostName = apigeeConfigProp.getApigeeHostnameTest1();
        break;
      case "test2":
        envHostName = apigeeConfigProp.getApigeeHostnameTest2();
        break;
      case "test3":
        envHostName = apigeeConfigProp.getApigeeHostnameTest3();
        break;
      case "test4":
        envHostName = apigeeConfigProp.getApigeeHostnameTest4();
        break;
      case "mock":
        envHostName = apigeeConfigProp.getApigeeHostnameMock();
        break;
      case "sandbox":
        envHostName = apigeeConfigProp.getApigeeHostnameSandbox();
        break;
      case "prod":
        envHostName = apigeeConfigProp.getApigeeHostnameProd();
        break;
      default:
        throw new InternalServerException("Invalid environment");
    }

    return envHostName;
  }


}
