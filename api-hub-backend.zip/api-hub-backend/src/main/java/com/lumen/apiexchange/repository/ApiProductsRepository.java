package com.lumen.apiexchange.repository;

import com.lumen.apiexchange.entity.ApiProduct;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApiProductsRepository extends JpaRepository<ApiProduct, UUID> {

  List<ApiProduct> findByPlanetAndExternal(String planet, Boolean external);

  List<ApiProduct> findByCreatedBy(String createdBy);

}
