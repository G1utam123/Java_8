package com.lumen.apiexchange.model;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxonomyCreationResult {

  private String taxonomy;

  private List<String> taxonomyCreatedEnv;

  private List<String> taxonomyNotCreatedEnv;

}
