package com.lumen.apiexchange.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.stereotype.Component;

@Component
@JsonIgnoreProperties(ignoreUnknown = true)
public class InputApiMigrationRequest {

  private String mirrorEnvironment;
  private String dev1EndpointHostname;
  private String dev2EndpointHostname;
  private String dev3EndpointHostname;
  private String dev4EndpointHostname;
  private String test1EndpointHostname;
  private String test2EndpointHostname;
  private String test3EndpointHostname;
  private String test4EndpointHostname;
  private String mockEndpointHostname;
  private String sandboxEndpointHostname;
  private String guid;
  private String requestorEmail;

  public String getMirrorEnvironment() {
    return mirrorEnvironment;
  }

  public void setMirrorEnvironment(String mirrorEnvironment) {
    this.mirrorEnvironment = mirrorEnvironment;
  }

  public String getDev1EndpointHostname() {
    return dev1EndpointHostname;
  }

  public void setDev1EndpointHostname(String dev1EndpointHostname) {
    this.dev1EndpointHostname = dev1EndpointHostname;
  }

  public String getDev2EndpointHostname() {
    return dev2EndpointHostname;
  }

  public void setDev2EndpointHostname(String dev2EndpointHostname) {
    this.dev2EndpointHostname = dev2EndpointHostname;
  }

  public String getDev3EndpointHostname() {
    return dev3EndpointHostname;
  }

  public void setDev3EndpointHostname(String dev3EndpointHostname) {
    this.dev3EndpointHostname = dev3EndpointHostname;
  }

  public String getDev4EndpointHostname() {
    return dev4EndpointHostname;
  }

  public void setDev4EndpointHostname(String dev4EndpointHostname) {
    this.dev4EndpointHostname = dev4EndpointHostname;
  }

  public String getTest1EndpointHostname() {
    return test1EndpointHostname;
  }

  public void setTest1EndpointHostname(String test1EndpointHostname) {
    this.test1EndpointHostname = test1EndpointHostname;
  }

  public String getTest2EndpointHostname() {
    return test2EndpointHostname;
  }

  public void setTest2EndpointHostname(String test2EndpointHostname) {
    this.test2EndpointHostname = test2EndpointHostname;
  }

  public String getTest3EndpointHostname() {
    return test3EndpointHostname;
  }

  public void setTest3EndpointHostname(String test3EndpointHostname) {
    this.test3EndpointHostname = test3EndpointHostname;
  }

  public String getTest4EndpointHostname() {
    return test4EndpointHostname;
  }

  public void setTest4EndpointHostname(String test4EndpointHostname) {
    this.test4EndpointHostname = test4EndpointHostname;
  }

  public String getMockEndpointHostname() {
    return mockEndpointHostname;
  }

  public void setMockEndpointHostname(String mockEndpointHostname) {
    this.mockEndpointHostname = mockEndpointHostname;
  }

  public String getSandboxEndpointHostname() {
    return sandboxEndpointHostname;
  }

  public void setSandboxEndpointHostname(String sandboxEndpointHostname) {
    this.sandboxEndpointHostname = sandboxEndpointHostname;
  }

  public String getGuid() {
    return guid;
  }

  public void setGuid(String guid) {
    this.guid = guid;
  }

  public String getRequestorEmail() {
    return requestorEmail;
  }

  public void setRequestorEmail(String requestorEmail) {
    this.requestorEmail = requestorEmail;
  }

  public String toString() {
    String mystring;
    mystring = "\n" + "mirrorEnvironment: " + getMirrorEnvironment() + "\n" + "dev1EndpointHostname: "
        + getDev1EndpointHostname() + "\n" + "dev2EndpointHostname: " + getDev2EndpointHostname() + "\n"
        + "dev3EndpointHostname: " + getDev3EndpointHostname() + "\n" + "dev4EndpointHostname: "
        + getDev4EndpointHostname() + "\n" + "test1EndpointHostname: " + getTest1EndpointHostname() + "\n"
        + "test2EndpointHostname: " + getTest2EndpointHostname() + "\n" + "test3EndpointHostname: "
        + getTest3EndpointHostname() + "\n" + "test4EndpointHostname: " + getTest4EndpointHostname() + "\n"
        + "mockEndpointHostname: " + getMockEndpointHostname() + "\n" + "sandboxEndpointHostname: "
        + getSandboxEndpointHostname() + "\n" + "guid: " + getGuid() + "\n" + "requestorEmail: " + getRequestorEmail()
        + "\n";
    return mystring;
  }

  public String toEmailString() {
    String mystring;
    mystring = "<br><br>{<br>" + " \"mirrorEnvironment\" : " + "\"" + getMirrorEnvironment() + "\"" + ",<br>"
        + " \"dev1EndpointHostname\" : " + "\"" + getDev1EndpointHostname() + "\"" + ",<br>"
        + " \"dev2EndpointHostname\" : " + "\"" + getDev2EndpointHostname() + "\"" + ",<br>"
        + " \"dev3EndpointHostname\" : " + "\"" + getDev3EndpointHostname() + "\"" + ",<br>"
        + " \"dev4EndpointHostname\" : " + "\"" + getDev4EndpointHostname() + "\"" + ",<br>"
        + " \"test1EndpointHostname\" : " + "\"" + getTest1EndpointHostname() + "\"" + ",<br>"
        + " \"test2EndpointHostname\" : " + "\"" + getTest2EndpointHostname() + "\"" + ",<br>"
        + " \"test3EndpointHostname\" : " + "\"" + getTest3EndpointHostname() + "\"" + ",<br>"
        + " \"test4EndpointHostname\" : " + "\"" + getTest4EndpointHostname() + "\"" + ",<br>"
        + " \"mockEndpointHostname\" : " + "\"" + getMockEndpointHostname() + "\"" + ",<br>"
        + " \"sandboxEndpointHostname\" : " + "\"" + getSandboxEndpointHostname() + "\"" + ",<br>"
        + " \"requestorEmail\" : " + "\"" + getRequestorEmail() + "\"" + "<br>" + "}";
    return mystring;

  }
}
