package com.lumen.apiexchange.service;

import static com.lumen.apiexchange.util.FeatureFlags.FF_SNOW_AUTHZ_ENABLED;

import com.lumen.apiexchange.client.ESPClient;
import com.lumen.apiexchange.config.MediationResourceConfigProperties;
import com.lumen.apiexchange.entity.ProxyResponse;
import com.lumen.apiexchange.exception.ForbiddenException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.model.ApiMediatedResponse;
import com.lumen.apiexchange.model.ApiMigrateRequest;
import com.lumen.apiexchange.model.ApiMigrationResult;
import com.lumen.apiexchange.model.ApplicationKey;
import com.lumen.apiexchange.model.BuildDeployResult;
import com.lumen.apiexchange.model.InputApiRequest;
import com.lumen.apiexchange.model.ProxyRequestModel;
import com.lumen.apiexchange.model.snow.ServiceNowRequest;
import com.lumen.apiexchange.repository.ApiProxyRepository;
import com.lumen.apiexchange.util.APIMigrationHandler;
import com.lumen.apiexchange.util.Auditable;
import dev.openfeature.sdk.OpenFeatureAPI;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.stream.Collectors;
import liquibase.repackaged.org.apache.commons.collections4.CollectionUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProxyServiceImpl implements ProxyService {

  private final ESPClient espClient;
  private final MediationResourceConfigProperties mediationResourceConfigProp;
  private final AsyncProxyService asyncService;
  private final ApiProxyRepository apiProxyRepo;
  private final APIMigrationHandler apiMigrationHandler;
  private final ServiceNowService serviceNow;
  private final UserAuthorizationService userAuthorization;
  private final BuildDeployServiceImpl buildDeployServiceImpl;
  private final HostServiceImpl hostServiceImpl;
  private final OpenFeatureAPI featureFlags;

  @Override
  public List<String> getTaxonomies() throws InternalServerException {
    return espClient.getTaxonomies();
  }

  @Override
  public List<ApplicationKey> getApplicationKeys() throws InternalServerException {
    return espClient.getApplicationKeys();
  }

  @Override
  @Auditable(actionType = Auditable.Action.PROXY_CREATION)
  public BuildDeployResult postProxyRequest(InputApiRequest proxyRequest, Jwt jwt)
      throws ForbiddenException {

    try {
      userAuthorization.isOkToDeployToProd(jwt);
      //proxyRequest.setBypassApiAlreadyExists(true);
    } catch (ForbiddenException f) {
      if (StringUtils.isNotEmpty(proxyRequest.getProdEndpointHostname())) {
        throw f;
      }
    }
    
    proxyRequest.setElementType("proxy");

    if (featureFlags.getClient().getBooleanValue(FF_SNOW_AUTHZ_ENABLED, false)) {
      if (CollectionUtils.isNotEmpty(proxyRequest.getOwners())) {
        ServiceNowRequest serviceNowReq =
            new ServiceNowRequest(proxyRequest.getElementType(), proxyRequest.getMalId(), proxyRequest.getAdmins(),
                proxyRequest.getOwners(), proxyRequest.getCreatedBy());
        String snowReqNumber = serviceNow.createGroup(serviceNowReq);

        log.info("Generated ServiceNow ownership request:" + snowReqNumber);
      } else {
        log.info("No owners in the proxy creation request. We are not generating a Servicenow ownership request.");
      }
    }

    return buildDeployServiceImpl.buildDeployApi(proxyRequest);
  }

  @Override
  public List<ApiMediatedResource> getApiProxies(InputApiRequest inputApiRequest) throws InternalServerException {
    ApiMediatedResponse myApiMediatedResponse = espClient.getApiProxyDetails(inputApiRequest);
    if (myApiMediatedResponse.getMediatedResource() == null) {
      return new ArrayList<ApiMediatedResource>();
    } else {
      return myApiMediatedResponse.getMediatedResource();
    }
  }

  @Override
  public List<ApiMediatedResource> getApiProxyEnvDetails(String resourceGuid)
      throws InternalServerException {
    List<ApiMediatedResource> apiMediatedResourceList = new ArrayList<>();
    List<CompletableFuture<ApiMediatedResource>> asyncApiDetails = new ArrayList<>();

    for (String host : hostServiceImpl.getHosts()) {
      asyncApiDetails.add(asyncService.getApiProxyEnvDetails(resourceGuid, host));
    }

    try {
      apiMediatedResourceList = asyncApiDetails.stream().map(CompletableFuture::join).filter(Objects::nonNull)
          .collect(Collectors.toList());
    } catch (CompletionException ce) {
      throw new InternalServerException("Could not check the state of the proxy in all environments", ce.getCause());
    }

    return apiMediatedResourceList;
  }

  public ProxyRequestModel saveApiProxies(ProxyRequestModel proxyRequestModel, String userName)
      throws InternalServerException {
    try {
      List<ProxyResponse> listOfProxyRequest = proxyRequestModel.getProxyResponse();

      UUID apiId = listOfProxyRequest.get(0).getApiid();
      List<ProxyResponse> listOfProxies = apiProxyRepo.findByApiid(apiId);
      if (!listOfProxies.isEmpty()) {
        deleteproxiesFromDbWithApiId(apiId);
      }
      List<ProxyResponse> returnProxies = new ArrayList<>();
      ProxyRequestModel reqModel = new ProxyRequestModel();
      String createdUserId = UUID.randomUUID().toString();
      listOfProxyRequest.forEach(proxy -> {
        proxy.setId(UUID.randomUUID());
        proxy.setCreatedUserName(userName);
        proxy.setCreatedUserId(createdUserId);
        proxy.setCreatedDate(new Timestamp(new Date().getTime()));
        proxy.setLastUpdatedDate(new Timestamp(new Date().getTime()));
        ProxyResponse req = apiProxyRepo.save(proxy);
        returnProxies.add(req);
      });
      reqModel.setProxyResponse(returnProxies);
      return reqModel;
    } catch (Exception exception) {
      throw new InternalServerException("Unable to save Proxy Details. Please try later" + exception.getMessage());
    }
  }

  @Override
  public boolean deleteproxiesFromDbWithApiId(UUID apiId) throws InternalServerException {
    List<ProxyResponse> listOfProxies = apiProxyRepo.findByApiid(apiId);
    try {
      listOfProxies.forEach(apiProxy -> {
        if (!listOfProxies.isEmpty()) {
          apiProxyRepo.deleteById(apiProxy.getId());
        }
      });
      return true;
    } catch (Exception exception) {
      throw new InternalServerException("Unable to Delete Proxy Details." + exception.getMessage());
    }
  }

  @Override
  @Auditable(actionType = Auditable.Action.PROXY_MIGRATION)
  public ApiMigrationResult migrateApiProxy(ApiMigrateRequest apiMigrateRequest)
      throws InternalServerException {

    ApiMigrationResult migrationResponse;

    try {

      log.info("API Migration");
      log.info("inputapimigrationrequest.toString: " + apiMigrateRequest.toString());

      migrationResponse = apiMigrationHandler.migrateApi(apiMigrateRequest);
    } catch (Exception exp) {
      throw new InternalServerException(exp.getMessage());
    }
    return migrationResponse;
  }

}
