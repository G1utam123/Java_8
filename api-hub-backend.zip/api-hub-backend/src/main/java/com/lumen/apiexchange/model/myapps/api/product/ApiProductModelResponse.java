package com.lumen.apiexchange.model.myapps.api.product;

import java.util.List;

public class ApiProductModelResponse {

  private List<ApiProductModel> apiProduct;

  public ApiProductModelResponse() {
  }

  public ApiProductModelResponse(List<ApiProductModel> apiProduct) {
    this.apiProduct = apiProduct;
  }

  public List<ApiProductModel> getApiProduct() {
    return apiProduct;
  }

  public void setApiProduct(List<ApiProductModel> apiProduct) {
    this.apiProduct = apiProduct;
  }
  
}
