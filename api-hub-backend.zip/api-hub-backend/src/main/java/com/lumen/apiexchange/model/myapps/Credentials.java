package com.lumen.apiexchange.model.myapps;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Credentials {

  private List<ProductStatus> apiProducts;
  private List<Attribute> attributes;
  private String consumerKey;
  private String consumerSecret;
  private int expiresAt;
  private String status;

  public Credentials() {
    super();
  }

  public List<ProductStatus> getApiProducts() {
    return apiProducts;
  }

  public void setApiProducts(List<ProductStatus> apiProducts) {
    this.apiProducts = apiProducts;
  }

  public List<Attribute> getAttributes() {
    return attributes;
  }

  public void setAttributes(List<Attribute> attributes) {
    this.attributes = attributes;
  }

  public String getConsumerKey() {
    return consumerKey;
  }

  public void setConsumerKey(String consumerKey) {
    this.consumerKey = consumerKey;
  }

  public String getConsumerSecret() {
    return consumerSecret;
  }

  public void setConsumerSecret(String consumerSecret) {
    this.consumerSecret = consumerSecret;
  }

  public int getExpiresAt() {
    return expiresAt;
  }

  public void setExpiresAt(int expiresAt) {
    this.expiresAt = expiresAt;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

}
