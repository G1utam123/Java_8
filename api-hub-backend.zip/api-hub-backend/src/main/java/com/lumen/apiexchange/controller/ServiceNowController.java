package com.lumen.apiexchange.controller;

import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.OwnershipStatusAlreadyExistsException;
import com.lumen.apiexchange.exception.OwnershipStatusUniqueRecordNotFoundException;
import com.lumen.apiexchange.model.snow.ServiceNowRequest;
import com.lumen.apiexchange.service.ServiceNowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ServiceNowController {

  @Autowired
  ServiceNowService serviceNowService;

  public ServiceNowController(ServiceNowService serviceNowService) {
    this.serviceNowService = serviceNowService;
  }


  @CrossOrigin
  @PostMapping(path = "/v1/servicenow/grouprequest")
  public String createGroup(@RequestBody ServiceNowRequest serviceNowRequest) throws InternalServerException,
      OwnershipStatusAlreadyExistsException {
    return serviceNowService.createGroup(serviceNowRequest);
  }    

}
