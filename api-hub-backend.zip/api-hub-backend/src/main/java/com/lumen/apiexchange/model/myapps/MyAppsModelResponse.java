package com.lumen.apiexchange.model.myapps;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MyAppsModelResponse {
  private List<MyAppsResponse> app;

  public MyAppsModelResponse() {
    super();
  }

  public MyAppsModelResponse(List<MyAppsResponse> app) {
    super();
    this.app = app;
  }

  public List<MyAppsResponse> getApp() {
    return app;
  }

  public void setApp(List<MyAppsResponse> app) {
    this.app = app;
  }
}
