package com.lumen.apiexchange.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AuthorizationResponse {

  private AuthorizationResponseData authorizations;

  @JsonProperty("Authorizations")
  public AuthorizationResponseData getAuthorizations() {
    return authorizations;
  }

  public void setAuthorizations(AuthorizationResponseData authorizations) {
    this.authorizations = authorizations;
  }

}
