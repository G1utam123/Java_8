package com.lumen.apiexchange.config;

import dev.openfeature.contrib.providers.envvar.EnvVarProvider;
import dev.openfeature.sdk.FeatureProvider;
import dev.openfeature.sdk.OpenFeatureAPI;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Slf4j
public class FeatureFlagsConfig {

  @Bean
  public OpenFeatureAPI openFeatureAPI(FeatureProvider provider) {

    OpenFeatureAPI openFeatureAPI = OpenFeatureAPI.getInstance();
    openFeatureAPI.setProvider(provider);

    log.info("Using OpenFeature provider: {}", openFeatureAPI.getProvider().getMetadata().getName());

    return openFeatureAPI;
  }

  /**
   * OpenFeature provider that reads environment variables
   *
   * @return the FF provider
   * @see <a href="https://github.com/open-feature/java-sdk-contrib/tree/main/providers/env-var">env-var documentation</a>
   */
  @Bean
  public FeatureProvider featureFlagsProvider() {
    return new EnvVarProvider();
  }

}
