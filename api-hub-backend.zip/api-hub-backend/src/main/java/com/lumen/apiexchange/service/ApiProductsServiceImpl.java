package com.lumen.apiexchange.service;

import com.lumen.apiexchange.entity.ApiProduct;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.ProductNotFoundException;
import com.lumen.apiexchange.exception.UnauthorizedException;
import com.lumen.apiexchange.repository.ApiProductsRepository;
import java.sql.Timestamp;
import java.util.List;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class ApiProductsServiceImpl implements ApiProductsService {

  protected static final Logger log = LoggerFactory.getLogger(ApiProductsServiceImpl.class);
  
  private final ApiProductsRepository productRepository;
    
  public ApiProductsServiceImpl(ApiProductsRepository productRepository) {
    this.productRepository = productRepository;
  }

  @Override
  public List<ApiProduct> getProductsInternalOrExternalByPlanet(String planet, Boolean external)
      throws ProductNotFoundException {

    List<ApiProduct> productList = productRepository.findByPlanetAndExternal(planet, external);
    if (productList.isEmpty()) {
      throw new ProductNotFoundException("No products found.");
    }

    return productList;
  }

  @Override
  public ApiProduct getProduct(UUID id) throws ProductNotFoundException {
    return productRepository.findById(id)
        .orElseThrow(() -> new ProductNotFoundException("Product not found for id: " + id));
  }

  @Override
  public ApiProduct saveProduct(ApiProduct product) throws BadInputException {
   
    product.setId(UUID.randomUUID());
    product.setCreatedDate(new Timestamp(System.currentTimeMillis()));
    product.setLastUpdatedDate(new Timestamp(System.currentTimeMillis()));
    return productRepository.save(product);

  }

  @Override
  public ApiProduct updateProduct(ApiProduct product, String userEmail) throws BadInputException,
      ProductNotFoundException, UnauthorizedException {

    ApiProduct oldProduct;
    if (product.getId() != null) {
      // Throws a ProductNotFoundException if not found
      oldProduct = getProduct(product.getId());
    } else {
      throw new BadInputException("Id is a requried field.");
    }

    // This CreatedBy email check is only temporary until we get the full IAM solution built out.
    if (oldProduct.getCreatedBy() != null && oldProduct.getCreatedBy().equals(userEmail)) {
      product.setLastUpdatedBy(userEmail);
      product.setLastUpdatedDate(new Timestamp(System.currentTimeMillis()));

    } else {
      throw (new UnauthorizedException("User not authorized to update this resource. "
          + "User must be the resource owner."));
    }

    return productRepository.save(product);

  }

  @Override
  public void deleteProduct(UUID id, String userEmail) throws ProductNotFoundException,
      UnauthorizedException, InternalServerException {

    // Throws a ProductNotFoundException if not found
    ApiProduct product = getProduct(id);

    // This CreatedBy email check is only temporary until we get the full IAM solution built out.
    if (product.getCreatedBy().equals(userEmail)) {
      productRepository.deleteById(id);
    } else {
      throw (new UnauthorizedException("User not authorized to delete this resource. "
          + "User must be the resource owner."));
    }

  }

}
