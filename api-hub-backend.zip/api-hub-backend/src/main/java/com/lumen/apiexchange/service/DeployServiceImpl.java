package com.lumen.apiexchange.service;

import com.lumen.apiexchange.model.AsyncBuildDeployResult;
import com.lumen.apiexchange.model.InputApiRequest;
import com.lumen.apiexchange.util.DeployHandler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class DeployServiceImpl {
  
  private final DeployHandler deployH;
  
  public AsyncBuildDeployResult deployProxy(InputApiRequest inputapirequest, String org,
      AsyncBuildDeployResult asyncBuildDeployResult) {
    
    ResponseEntity<String> myEntity = null;
    try {
      myEntity = deployH.deployApi(inputapirequest.getEnv(), org, inputapirequest.getMediatedResourceId());
      
      if (myEntity.getStatusCodeValue() == HttpStatus.OK.value()) {
        asyncBuildDeployResult.getProxyDeployedToEnvironments().add(inputapirequest.getEnv() + "-" + org);
      } else {
        asyncBuildDeployResult.getProxyNotDeployedToEnvironments().add(inputapirequest.getEnv() + "-" + org);
      }
    } catch (Exception e) {
      asyncBuildDeployResult.getProxyNotDeployedToEnvironments().add(inputapirequest.getEnv() + "-" + org);
      log.error("DeployServiceImpl.deployProxy Exception Occured - {}", inputapirequest, e);
    }
    
    return asyncBuildDeployResult;
  } 
  
}
