package com.lumen.apiexchange.service;

import com.lumen.apiexchange.api.partner.model.PartnerProxy;
import com.lumen.apiexchange.service.apigee.ApigeeProductsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class AsyncPartnerProxyServiceImpl {

  private final ApigeeProductsService apigeeProductsService;

  @Async
  public void asyncAddNewProxyToApiProduct(PartnerProxy partnerProxy, String guid) {
    apigeeProductsService.addNewProxyToApiProduct(partnerProxy, guid);
  }
}
