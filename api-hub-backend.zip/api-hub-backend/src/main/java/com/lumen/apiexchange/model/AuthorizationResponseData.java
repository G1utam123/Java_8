package com.lumen.apiexchange.model;

import java.util.List;

public class AuthorizationResponseData {
  
  private List<Category> authorization;

  public List<Category> getAuthorization() {
    return authorization;
  }

  public void setAuthorization(List<Category> authorization) {
    this.authorization = authorization;
  }
  
}
