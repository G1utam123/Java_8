package com.lumen.apiexchange.model.myapps.api.product;

import java.util.List;

public class ApiProductModel {
  private String displayName;
  private String name;
  private String description;
  private List<String> environments;
  
  public ApiProductModel() {
  }

  public ApiProductModel(String displayName, String name, String description, List<String> environments) {
    this.displayName = displayName;
    this.name = name;
    this.description = description;
    this.environments = environments;
  }

  public String getDisplayName() {
    return displayName;
  }

  public String getName() {
    return name;
  }

  public String getDescription() {
    return description;
  }

  public List<String> getEnvironments() {
    return environments;
  }

  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public void setEnvironments(List<String> environments) {
    this.environments = environments;
  }
  
}
