package com.lumen.apiexchange.controller;

import com.lumen.apiexchange.api.partner.PartnerProxyApi;
import com.lumen.apiexchange.api.partner.model.PartnerProxy;
import com.lumen.apiexchange.exception.ForbiddenException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.PartnerProxyAddToProductException;
import com.lumen.apiexchange.exception.PartnerProxyBuildException;
import com.lumen.apiexchange.exception.PartnerProxyDeployException;
import com.lumen.apiexchange.service.PartnerProxyService;
import com.lumen.apiexchange.service.UserAuthorizationService;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.UUID;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PartnerProxyController implements PartnerProxyApi  {

  @Autowired
  private PartnerProxyService partnerProxyService;

  @Autowired
  private UserAuthorizationService userAuthorizationService;

  @Override
  public ResponseEntity<PartnerProxy> createPartnerProxy(@Parameter(in = ParameterIn.DEFAULT, description = "",
      schema = @Schema()) @Valid @RequestBody PartnerProxy partnerProxy) {  

    Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    userAuthorizationService.isAuthorizedToUsePartnerProxy(jwt);

    partnerProxyService.createProxy(partnerProxy, jwt);

    return new ResponseEntity<>(partnerProxy, HttpStatus.ACCEPTED);

  }

  @Override
    public ResponseEntity<PartnerProxy> getPartnerProxyByGuid(String proxyGateway, String environment, UUID proxyGuid) {

    Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    userAuthorizationService.isAuthorizedToUsePartnerProxy(jwt);
    
    return new ResponseEntity<>(partnerProxyService.getPartnerProxy(proxyGateway, environment, proxyGuid),
        HttpStatus.OK);

  }

  @Override
  public ResponseEntity<Void> deletePartnerProxyByGuid(String proxyGateway, String environment, UUID proxyGuid) {
    
    Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    userAuthorizationService.isAuthorizedToUsePartnerProxy(jwt);

    partnerProxyService.deletePartnerProxy(proxyGateway, environment, proxyGuid);

    return new ResponseEntity<>(HttpStatus.NO_CONTENT);

  }

  @Override
  public ResponseEntity<PartnerProxy> updatePartnerProxyByGuid(String proxyGateway, String environment, UUID proxyGuid,
      @Parameter(in = ParameterIn.DEFAULT, description = "", schema = @Schema()) 
      @Valid @RequestBody PartnerProxy partnerProxy) {
    
    Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    userAuthorizationService.isAuthorizedToUsePartnerProxy(jwt);

    partnerProxyService.updateProxy(partnerProxy, proxyGateway, environment, proxyGuid);

    return new ResponseEntity<>(partnerProxy, HttpStatus.OK);

  }

  /*
   * These two endpoints are purely for testing and are not part of the Partner Proxy API Spec
   */
  @CrossOrigin
  @GetMapping(path = "/partnerProxy/testUserAuth")
  @ResponseStatus(HttpStatus.OK)
  public void testUserAuth() throws ForbiddenException {

    Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    userAuthorizationService.isAuthorizedToUsePartnerProxy(jwt);
  }
  
  @CrossOrigin
  @GetMapping(path = "/partnerProxy/testAppDynamics")
  @ResponseStatus(HttpStatus.OK)
  public void testAppDynamics(String exceptionToThrow, String optionalReason, String optionalMessage) {

    Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    userAuthorizationService.isAuthorizedToUsePartnerProxy(jwt);
    
    if (null == exceptionToThrow) {
      return;
    }
    
    String exceptionMessage = "Testing Only - AppDynamics test for Partner Proxy Exception.";
    if (null != optionalMessage) {
      exceptionMessage = optionalMessage;
    }
    
    if (exceptionToThrow.equals("PartnerProxyBuildException")) {
      throw new PartnerProxyBuildException(exceptionMessage);
    } 
    if (exceptionToThrow.equals("PartnerProxyDeployException")) {
      throw new PartnerProxyDeployException(exceptionMessage);
    }
    if (exceptionToThrow.equals("PartnerProxyAddToProductException")) {
      String exceptionReason = "Default reason";
      if (null != optionalReason) {
        exceptionReason = optionalMessage;
      }
      throw new PartnerProxyAddToProductException(exceptionReason, exceptionMessage);
      
    }

  }
  
  @CrossOrigin
  @PostMapping(path = "/partnerProxy/testAppDynamics")
  @ResponseStatus(HttpStatus.OK)
  public void testAppDynamicsPost(String exceptionToThrow, @RequestBody String message) {

    Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    userAuthorizationService.isAuthorizedToUsePartnerProxy(jwt);
    
    if (null == exceptionToThrow) {
      return;
    }
    
    String exceptionMessage = "Testing Only - AppDynamics test for Partner Proxy Exception.";
    if (null != message) {
      exceptionMessage = message;
    }
    
    if (exceptionToThrow.equals("PartnerProxyBuildException")) {
      throw new PartnerProxyBuildException(exceptionMessage);
    }
    if (exceptionToThrow.equals("PartnerProxyDeployException")) {
      throw new PartnerProxyDeployException(exceptionMessage);
    }
    if (exceptionToThrow.equals("PartnerProxyAddToProductException")) {
      String exceptionReason = "Default reason";
      throw new PartnerProxyAddToProductException(exceptionReason, exceptionMessage);
      
    }

  }

}
