package com.lumen.apiexchange.entity;

import java.time.Instant;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "audit_trail")
@Data
public class AuditTrail {

  @Id
  private UUID id;

  @Column
  private Instant date;

  @Column
  private String username;

  @Column
  private String action;

  @Column
  private String description;

  @Column
  private String result;

}
