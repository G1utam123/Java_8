package com.lumen.apiexchange.client;

import com.lumen.apiexchange.exception.AppNotFoundException;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.CustomStatusResponse;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.MyAppResponse;
import com.lumen.apiexchange.model.myapps.ApigeeAPIClientModel;
import com.lumen.apiexchange.model.myapps.ApigeeAPIClientModelResponse;
import com.lumen.apiexchange.model.myapps.CreateAppRequest;
import com.lumen.apiexchange.model.myapps.MediationHeaderUtil;
import com.lumen.apiexchange.model.myapps.MyAppsModelResponse;
import com.lumen.apiexchange.model.myapps.MyAppsResponse;
import com.lumen.apiexchange.model.myapps.ProductStatus;
import com.lumen.apiexchange.model.myapps.UpdateAppRequest;
import com.lumen.apiexchange.model.myapps.api.product.ApiProductModel;
import com.lumen.apiexchange.model.myapps.api.product.ApiProductModelResponse;
import com.lumen.apiexchange.model.myapps.api.product.ApigeeApiProductModel;
import com.lumen.apiexchange.model.myapps.api.product.ApigeeApiProductModelResponse;
import com.lumen.apiexchange.model.userprofile.CreateUserRequest;
import com.lumen.apiexchange.model.userprofile.CreateUserResponse;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

@Component
public class LiamSyncClient {

  protected static final Logger log = LoggerFactory.getLogger(LiamSyncClient.class);

  private static final String MESSAGE = "message";

  @Autowired
  RestTemplate restTemplate;

  @Value("${apigee.appkey}")
  private String appKey;

  @Value("${apigee.secret}")
  private String secret;

  @Value("${apigee.apigeeBaseUrl}")
  private String apigeeBaseUrl;

  public ApigeeAPIClientModel createAppFromApigee(CreateAppRequest request, String email)
      throws InternalServerException, BadInputException {

    HttpHeaders headers = MediationHeaderUtil.getMediationHeaders(appKey, secret);
    headers.setContentType(MediaType.APPLICATION_JSON);
    HttpEntity<CreateAppRequest> entity = new HttpEntity<>(request, headers);
    ResponseEntity<ApigeeAPIClientModel> response = new ResponseEntity<>(HttpStatus.OK);
    try {
      String url = apigeeBaseUrl + "Application/v1/Apigee/liamsync/customer/" + email;
      response = restTemplate.exchange(url, HttpMethod.POST, entity, ApigeeAPIClientModel.class);
      log.info("created App Details --->>>>>>>");
    } catch (Exception e) {
      String message = e.getMessage();
      log.error(message);
      if (message.startsWith("500")) {
        String errorMessage = message.substring(message.indexOf(MESSAGE) + 10, message.length() - 2);
        throw new InternalServerException(errorMessage.length() < 4 ? null : errorMessage);
      }
    }
    return response.getBody();
  }

  public ResponseEntity<?> createUserInApigee(CreateUserRequest request) throws InternalServerException {

    HttpHeaders headers = MediationHeaderUtil.getMediationHeaders(appKey, secret);
    headers.setContentType(MediaType.APPLICATION_JSON);
    HttpEntity<CreateUserRequest> entity = new HttpEntity<>(request, headers);
    ResponseEntity<CreateUserResponse> response = new ResponseEntity<>(HttpStatus.CREATED);

    try {
      String url = apigeeBaseUrl + "Application/v1/Apigee/liamsync/customer";
      response = restTemplate.exchange(url, HttpMethod.POST, entity, CreateUserResponse.class);
    } catch (Exception e) {
      String message = e.getMessage();

      if (message.startsWith("409")) {
        String errorMsg = "Developer with the email " + request.getEmail() + " already exists!";
        ResponseEntity<CustomStatusResponse> conflictResponse = new ResponseEntity<>(
            new CustomStatusResponse(errorMsg, HttpStatus.CONFLICT), HttpStatus.CONFLICT);
        return conflictResponse;
      } else if (message.startsWith("500")) {
        String errorMsg = message.substring(message.indexOf("message") + 10, message.length() - 2);
        ResponseEntity<CustomStatusResponse> intServerExceptionResponse = new ResponseEntity<>(
            new CustomStatusResponse(errorMsg, HttpStatus.INTERNAL_SERVER_ERROR), HttpStatus.INTERNAL_SERVER_ERROR);
        return intServerExceptionResponse;
      }

    }

    return response;
  }

  public MyAppsModelResponse getApigeeApiClientForEnterpriseId(String email)
      throws InternalServerException, BadInputException {

    log.info("Inside getApigeeApiClientForEnterpriseId method() of ApigeeManger class  >>>>>>>>>");

    if (email == null) {
      throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Email Id is mandatory!");
    }

    List<ApigeeAPIClientModel> apigeeApiClientlist = new ArrayList<>();
    HttpHeaders headers = MediationHeaderUtil.getMediationHeaders(appKey, secret);
    headers.setContentType(MediaType.APPLICATION_JSON);
    HttpEntity<String> entity = new HttpEntity<>(headers);

    try {
      String url = apigeeBaseUrl + "Application/v1/Apigee/liamsync/customer/" + email + "/" + "apiclient";
      log.info("Fetching Apps for user with Email ID - {}", email);
      ResponseEntity<ApigeeAPIClientModelResponse> app =
          restTemplate.exchange(url, HttpMethod.GET, entity, ApigeeAPIClientModelResponse.class);
      List<MyAppsResponse> appsList = new ArrayList<>();
      if (app.getBody() != null) {
        apigeeApiClientlist = app.getBody().getApp();
        appsList = mapApigeeResponse(apigeeApiClientlist);
        log.info("Total Apps found in APIGEE response: {}; Total Apps in service response: {}",
            apigeeApiClientlist.size(), appsList.size());
      }
      return new MyAppsModelResponse(appsList);
    } catch (Exception e) {
      log.error("Unable to fetch data from Apigee!");
      throw new InternalServerException("Unable to get API Client from apigee " + e.getMessage());
    }

  }

  private List<MyAppsResponse> mapApigeeResponse(List<ApigeeAPIClientModel> apigeeAPIClientlist) {
    List<MyAppsResponse> myAppsList = new ArrayList<>();

    if (apigeeAPIClientlist != null) {
      apigeeAPIClientlist.forEach(list -> {
        List<ProductStatus> apiProducts = new ArrayList<>();
        String environment = "";
        String displayName = "";
        String consumerKey = "";
        String consumerSecret = "";
        int apiProdCount = 0;
        if (list.getAttributes() != null) {
          environment = list.getAttributes().get(0).getValue();
          displayName = list.getAttributes().get(1).getValue();
        }
        if (list.getCredentials() != null) {
          apiProducts = list.getCredentials().get(0).getApiProducts();
          consumerKey = list.getCredentials().get(0).getConsumerKey();
          consumerSecret = list.getCredentials().get(0).getConsumerSecret();
          apiProdCount = list.getCredentials().get(0).getApiProducts().size();
        }
        String name = list.getName();
        String status = list.getStatus();
        long createdAt = list.getCreatedAt();

        MyAppsResponse appResponse = new MyAppsResponse(environment, displayName, apiProducts, consumerKey,
            consumerSecret, name, status, apiProdCount, createdAt);
        myAppsList.add(appResponse);
      });
    }
    return myAppsList;
  }

  public ApigeeAPIClientModel updateApp(UpdateAppRequest request, String email)
      throws InternalServerException, BadInputException, AppNotFoundException {

    HttpHeaders headers = MediationHeaderUtil.getMediationHeaders(appKey, secret);
    headers.setContentType(MediaType.APPLICATION_JSON);
    HttpEntity<UpdateAppRequest> entity = new HttpEntity<>(request, headers);
    ResponseEntity<ApigeeAPIClientModel> response = new ResponseEntity<>(HttpStatus.OK);
    try {
      String url = apigeeBaseUrl + "Application/v1/Apigee/liamsync/customer/" + email + "/apiclient/"
          + request.getName() + "?action=update";
      response = restTemplate.exchange(url, HttpMethod.PUT, entity, ApigeeAPIClientModel.class);
      log.info("Updated App Details --->>>>>>>");
    } catch (Exception e) {
      String message = e.getMessage();
      log.error(message);
      if (message.startsWith("404")) {
        throw new AppNotFoundException(message.substring(message.indexOf(MESSAGE) + 10, message.length() - 2));
      } else if (message.startsWith("500")) {
        String errorMessage = message.substring(message.indexOf(MESSAGE) + 10, message.length() - 2);
        throw new InternalServerException(errorMessage.length() < 4 ? null : errorMessage);
      }
    }
    return response.getBody();
  }

  public ResponseEntity<MyAppResponse> deleteAppFromApigee(String userName, String appName)
      throws InternalServerException {

    ResponseEntity<ApigeeApiProductModel> responseEntity = null;
    MyAppResponse respo = null;
    if (userName == null && appName == null) {
      throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "userName and appName are mandatory!");
    }

    HttpHeaders headers = MediationHeaderUtil.getMediationHeaders(appKey, secret);
    headers.setContentType(MediaType.APPLICATION_JSON);
    HttpEntity<String> entity = new HttpEntity<>(headers);

    try {
      String url = apigeeBaseUrl + "Application/v1/Apigee/liamsync/customer/" + userName + "/" + "apiclient/" + appName;
      responseEntity = restTemplate.exchange(url, HttpMethod.DELETE, entity, ApigeeApiProductModel.class);
      respo = new MyAppResponse(1, 200, "Successfully deleted API Client from apigee");
      return new ResponseEntity<>(respo, responseEntity.getStatusCode());
    } catch (Exception e) {
      e.printStackTrace();
      System.out.println(e.getMessage());
      log.error("Unable to delete data from Apigee!");
      respo = new MyAppResponse(0, 404, e.getMessage());
      return new ResponseEntity<>(respo, HttpStatus.NOT_FOUND);
    }

  }

  public ResponseEntity<?> getApiProductsFromApigee() throws InternalServerException {

    HttpHeaders headers = MediationHeaderUtil.getMediationHeaders(appKey, secret);
    headers.setContentType(MediaType.APPLICATION_JSON);
    HttpEntity<String> entity = new HttpEntity<>(headers);
    ResponseEntity<ApiProductModelResponse> response = new ResponseEntity<>(HttpStatus.OK);
    List<ApigeeApiProductModel> apigeeApiProductList = new ArrayList<>();
    try {
      String url = apigeeBaseUrl + "Application/v1/Apigee/liamsync/apiproducts";
      ResponseEntity<ApigeeApiProductModelResponse> apigeeResponse = restTemplate.exchange(url, HttpMethod.GET, entity,
          ApigeeApiProductModelResponse.class);
      apigeeApiProductList = apigeeResponse.getBody().getApiProduct();
      List<ApiProductModel> apiProductList = new ArrayList<>();
      if (!apigeeApiProductList.isEmpty()) {
        apiProductList = mapApiProductResponse(apigeeApiProductList);
        log.info("Total Products in APIGEE response: {}; Total Products in Service response: {}",
            apigeeApiProductList.size(), apiProductList.size());
      } else {
        throw new RuntimeException("404");
      }

      response = new ResponseEntity<>(new ApiProductModelResponse(apiProductList), HttpStatus.OK);
    } catch (Exception e) {
      String message = e.getMessage();
      log.error(message);

      if (message.startsWith("404")) {
        String errorMsg = "API Products not found!";
        ResponseEntity<CustomStatusResponse> notFoundResponse = new ResponseEntity<>(
            new CustomStatusResponse(errorMsg, HttpStatus.NOT_FOUND), HttpStatus.NOT_FOUND);
        return notFoundResponse;
      } else if (message.startsWith("500")) {
        String errorMsg = message.substring(message.indexOf("message") + 10, message.length() - 2);
        ResponseEntity<CustomStatusResponse> intServerExceptionResponse = new ResponseEntity<>(
            new CustomStatusResponse(errorMsg, HttpStatus.INTERNAL_SERVER_ERROR), HttpStatus.INTERNAL_SERVER_ERROR);
        return intServerExceptionResponse;
      }
    }

    return response;
  }

  private List<ApiProductModel> mapApiProductResponse(List<ApigeeApiProductModel> apigeeApiProductList) {
    List<ApiProductModel> apiProductList = new ArrayList<>();

    apigeeApiProductList.forEach(list -> {

      String displayName = list.getDisplayName();
      String name = list.getName();
      String description = list.getDescription();
      List<String> environments = list.getEnvironments();
      Collections.sort(environments);

      ApiProductModel product = new ApiProductModel(displayName, name, description, environments);
      apiProductList.add(product);
    });

    apiProductList.sort((prod1, prod2) -> prod1.getDisplayName().compareTo(prod2.getDisplayName()));
    return apiProductList;
  }

}
