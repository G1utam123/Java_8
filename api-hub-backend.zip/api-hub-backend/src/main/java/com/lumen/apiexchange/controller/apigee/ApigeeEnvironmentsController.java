package com.lumen.apiexchange.controller.apigee;

import com.lumen.apiexchange.service.apigee.ApigeeEnvironmentsServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.util.List;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@AllArgsConstructor
@RestController
public class ApigeeEnvironmentsController {

  private ApigeeEnvironmentsServiceImpl apigeeEnvService;

  protected static final Logger log = LoggerFactory.getLogger(ApigeeEnvironmentsController.class);
  
  public enum InternalExternal { 
      INTERNAL, 
      EXTERNAL;
  }

  public enum Planet { 
      PROD,
      NONPROD;
  }
    
  @CrossOrigin
  @GetMapping(path = "/v1/environments/apigee")
  @ResponseStatus(HttpStatus.OK)
  @Operation(tags = "Apigee Environments",
      summary = "Gets a list of Environments from Apigee.", 
      description = "Gets a list of API Environments from Apigee for a given planet (PROD or NONPROD) and "
        + "organization (EXTERNAL or INTERNAL).")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Resources found"),
      @ApiResponse(responseCode = "400", description = "Bad request"),
      @ApiResponse(responseCode = "500", description = "Internal Server Error.")
      })
  public List<String> getProductsApigee(@RequestParam Planet planet, 
      @RequestParam InternalExternal internalExternal) {
    
    return apigeeEnvService.getEnvironments(planet.toString(), internalExternal.toString());

  }

}
