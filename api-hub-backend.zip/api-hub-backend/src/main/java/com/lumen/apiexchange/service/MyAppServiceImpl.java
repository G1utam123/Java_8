package com.lumen.apiexchange.service;

import com.lumen.apiexchange.client.ESPClient;
import com.lumen.apiexchange.client.LiamSyncClient;
import com.lumen.apiexchange.entity.ProxyResponse;
import com.lumen.apiexchange.exception.AppNotFoundException;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.MyAppResponse;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.model.ProxyDetails;
import com.lumen.apiexchange.model.myapps.ApigeeAPIClientModel;
import com.lumen.apiexchange.model.myapps.CreateAppRequest;
import com.lumen.apiexchange.model.myapps.MyAppsModelResponse;
import com.lumen.apiexchange.model.myapps.UpdateAppRequest;
import com.lumen.apiexchange.repository.ApiProxyRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class MyAppServiceImpl implements MyAppsService {

  protected static final Logger log = LoggerFactory.getLogger(MyAppServiceImpl.class);
  private final LiamSyncClient liamSyncClient;
  private final ESPClient espClient;
  private final ApiProxyRepository proxyRepository;
  private final ProxyService proxyService;

  public MyAppServiceImpl(LiamSyncClient liamSyncClient, ESPClient espClient, ApiProxyRepository proxyRepository,
                          ProxyService proxyService) {
    this.liamSyncClient = liamSyncClient;
    this.espClient = espClient;
    this.proxyRepository = proxyRepository;
    this.proxyService = proxyService;
  }

  @Override
  public MyAppsModelResponse getApigeeApiClientForEnterpriseId(String email)
      throws InternalServerException, BadInputException {
    return liamSyncClient.getApigeeApiClientForEnterpriseId(email);
  }

  @Override
  public ApigeeAPIClientModel updateApp(UpdateAppRequest request, String email)
      throws InternalServerException, BadInputException, AppNotFoundException {
    return liamSyncClient.updateApp(request, email);
  }


  @Override
  public ResponseEntity<MyAppResponse> deleteAppFromApigee(String userName, String appName)
      throws InternalServerException {
    log.info("Inside deleteAppFromApigee methos of apigeeManger class");

    return liamSyncClient.deleteAppFromApigee(userName, appName);
  }

  @Override
  public List<ApiMediatedResource> getProxyDetails(UUID apiId) throws InternalServerException {
    List<ApiMediatedResource> proxyDetails = new ArrayList<>();
    log.info("The API ID --->>>" + apiId);
    List<ProxyResponse> proxies = proxyRepository.findByApiid(apiId);
    log.info("Proxy size  --->>>>" + proxies.size());
    if (proxies.size() > 0) {
      proxies.forEach(details -> {
        try {
          log.info("Details for guuid " + details.getResourceGuuid());
          ApiMediatedResource resource = espClient.getApiProxies(details.getResourceGuuid());
          if (null != resource) {
            proxyDetails.add(resource);
          }
        } catch (InternalServerException e) {
          log.error(e.getMessage());
        }
      });

    }
    log.info("Details count " + proxyDetails.size());
    return proxyDetails;
  }

  @Override
  public ApigeeAPIClientModel createAppFromApigee(CreateAppRequest request, String email)
      throws InternalServerException, BadInputException {
    return liamSyncClient.createAppFromApigee(request, email);
  }

  @Override
  public ResponseEntity<?> getApiProductsFromApigee() throws InternalServerException {
    log.info("Inside getApiProductsFromApigee method of MyAppsService >>>>>>>>>>>>>>");
    return liamSyncClient.getApiProductsFromApigee();
  }


  @Override
  public List<ProxyDetails> getProxyEnvDetails(UUID apiId) throws InternalServerException {
    List<ProxyDetails> proxyDetails = new ArrayList<>();
    List<ProxyResponse> proxies = proxyRepository.findByApiid(apiId);
    log.info("Proxy size  --->>>>" + proxies.size());
    if (proxies.size() > 0) {
      proxies.forEach(details -> {
        try {
          log.info("Details for guuid------>> " + details.getResourceGuuid());
          List<ApiMediatedResource> resources = proxyService.getApiProxyEnvDetails(details.getResourceGuuid());
          if (null != resources) {
            ProxyDetails proxy = new ProxyDetails();
            proxy.setGuid(details.getResourceGuuid());
            proxy.setEnvironments(resources);
            proxyDetails.add(proxy);
          }
        } catch (InternalServerException e) {
          log.error(e.getMessage());
        }
      });

    }
    log.info("After getting all details.--->> " + proxyDetails.size());
    return proxyDetails;
  }
}
