package com.lumen.apiexchange.exception;

import com.lumen.apiexchange.api.partner.model.Error400;
import com.lumen.apiexchange.api.partner.model.Error400Code;
import com.lumen.apiexchange.api.partner.model.Error500;

public final class BuildCommonCodeHelper {

  public static Error400 buildCommonCode400(Error400Code code, String reason, String message) {
    Error400 error = new Error400();
    error.code(code);
    error.setReason(reason);
    error.setMessage(message);
    return error;
  }

  public static Error500 buildCommonCode500(String reason, String message) {
    Error500 error = new Error500();
    error.code(Error500.CodeEnum.INTERNALERROR);
    error.setReason(reason);
    error.setMessage(message);
    return error;
  }

}
