package com.lumen.apiexchange.model;

import java.util.List;

public class ApiMediatedResponse {

  private List<ApiMediatedResource> mediatedResource;

  public List<ApiMediatedResource> getMediatedResource() {
    return mediatedResource;
  }      
  
  public void setMediatedResource(List<ApiMediatedResource> mediatedResource) {
    this.mediatedResource = mediatedResource;
  }



}
