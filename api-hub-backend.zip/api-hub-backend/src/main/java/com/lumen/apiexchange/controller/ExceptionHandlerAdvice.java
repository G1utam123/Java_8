package com.lumen.apiexchange.controller;


import com.lumen.apiexchange.api.partner.model.Error400;
import com.lumen.apiexchange.api.partner.model.Error400Code;
import com.lumen.apiexchange.api.partner.model.Error403;
import com.lumen.apiexchange.api.partner.model.Error404;
import com.lumen.apiexchange.api.partner.model.Error422;
import com.lumen.apiexchange.api.partner.model.Error500;
import com.lumen.apiexchange.exception.AppNotFoundException;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.DuplicatedProxyException;
import com.lumen.apiexchange.exception.ForbiddenException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.NotFoundException;
import com.lumen.apiexchange.exception.OwnershipStatusAlreadyExistsException;
import com.lumen.apiexchange.exception.OwnershipStatusNotFoundException;
import com.lumen.apiexchange.exception.OwnershipStatusUniqueRecordNotFoundException;
import com.lumen.apiexchange.exception.ProductNotFoundException;
import com.lumen.apiexchange.exception.UnauthorizedException;
import com.lumen.apiexchange.exception.apigee.ApigeeMgmtApiClientException;
import java.util.NoSuchElementException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;




@ControllerAdvice
@Slf4j
public class ExceptionHandlerAdvice {

  @ExceptionHandler(DataAccessException.class)
  public ResponseEntity<String> handleDataAccessException(final DataAccessException e) {
    log.info(e.getMessage(), e);
    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
  }

  @ExceptionHandler(InternalServerException.class)
  public ResponseEntity<Error500> handleInternalServerException(final InternalServerException e) {
    log.warn(e.getMessage(), e);
    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getError());
  }

  @ExceptionHandler(AppNotFoundException.class)
  public ResponseEntity<String> handleAppNotFoundException(final AppNotFoundException e) {
    log.info(e.getMessage(), e);
    return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
  }

  @ExceptionHandler(BadInputException.class)
  public ResponseEntity<Error400> handleBadInputException(final BadInputException e) {
    log.info(e.getMessage(), e);
    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getError());
  }
  
  @ExceptionHandler(MethodArgumentNotValidException.class)
  public ResponseEntity<Error400> handleBadInputException(final MethodArgumentNotValidException e) {
    log.info(e.getMessage(), e);
    BadInputException commonError = new BadInputException(Error400Code.INVALIDBODY, "Input validation failed",
        e.getMessage());
    
    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(commonError.getError());
  }
  
  @ExceptionHandler(HttpMessageNotReadableException.class)
  public ResponseEntity<Error400> handleBadInputException(final HttpMessageNotReadableException e) {
    log.info(e.getMessage(), e);
    BadInputException commonError = new BadInputException(Error400Code.INVALIDBODY, "Input validation failed",
        e.getMessage());
    
    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(commonError.getError());
  }
  
  @ExceptionHandler(ProductNotFoundException.class)
  public ResponseEntity<String> handleProductNotFoundException(final ProductNotFoundException e) {
    log.info(e.getMessage(), e);
    return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
  }

  @ExceptionHandler(UnauthorizedException.class)
  public ResponseEntity<String> handleUnauthorizedException(final UnauthorizedException e) {
    log.warn(e.getMessage(), e);
    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
  }

  @ExceptionHandler(ForbiddenException.class)
  public ResponseEntity<Error403> handleUnauthorizedException(final ForbiddenException e) {
    log.warn(e.getMessage(), e);
    return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getError());
  }

  @ExceptionHandler(NotFoundException.class)
  public ResponseEntity<Error404> handleNotFoundException(final NotFoundException e) {
    log.info(e.getMessage(), e);
    return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getError());
  }

  @ExceptionHandler(NoSuchElementException.class)
  public ResponseEntity<String> handleNoSuchElementException(final NoSuchElementException e) {
    log.info(e.getMessage(), e);
    return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
  }


  @ExceptionHandler(ApigeeMgmtApiClientException.class)
  public ResponseEntity<String> handleApigeeMgmtApiClientException(final ApigeeMgmtApiClientException e) {
    log.info(e.getMessage(), e);
    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
  }

  @ExceptionHandler(OwnershipStatusNotFoundException.class)
  public ResponseEntity<String> handleOwnershipStatusNotFoundException(final OwnershipStatusNotFoundException e) {
    log.info(e.getMessage(), e);
    return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
  }

  @ExceptionHandler(OwnershipStatusUniqueRecordNotFoundException.class)
  public ResponseEntity<String> handleOwnershipStatusUniqueRecordNotFoundException(
      final OwnershipStatusUniqueRecordNotFoundException e) {
    String errorMessage = e.getMessage()
        + " has several entries in the ownership_status database,"
        + " please contact 'API Enablement' support team by opening "
        + "an incident ticket in servicenow providing this information";
    log.info(errorMessage, e);
    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorMessage);
  }

  @ExceptionHandler(OwnershipStatusAlreadyExistsException.class)
  public ResponseEntity<Error422> handleOwnershipStatusAlreadyExistsException(
      final OwnershipStatusAlreadyExistsException e) {
    log.info(e.getMessage(), e);
    return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body(e.getError());
  }

  @ExceptionHandler(DuplicatedProxyException.class)
  public ResponseEntity<Error500> handleDuplicatedProxyException(
      final DuplicatedProxyException e) {
    log.info(e.getMessage(), e);
    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getError());
  }

}
