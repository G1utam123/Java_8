package com.lumen.apiexchange.exception;

public class PartnerProxyDeployException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public PartnerProxyDeployException(String message) {
    super(message);
  }

}
