package com.lumen.apiexchange.service;

import com.lumen.apiexchange.config.UserAuthorizationConfigProperties;
import com.lumen.apiexchange.exception.ForbiddenException;
import com.lumen.apiexchange.exception.UnauthorizedException;
import io.micrometer.core.instrument.util.StringUtils;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class UserAuthorizationServiceImpl implements UserAuthorizationService {

  @Autowired
  private UserAuthorizationConfigProperties userAuthorizationConfigProperties;
  
  @Autowired
  private EmailBasedAuthzServiceImpl emailBasedAuthzServiceImpl;

  @Override
  public void isOkToDeployToProd(Jwt jwt) throws ForbiddenException {
    /*
     * Determine if the JWT token is from the API Gateway or from the API-HUB & is a PO Auth JWT.
     * If the JWT contains a "role" claim, then the request came from the API Gateway and the value is the 
     * API Product name used for the OAuth 2 authorization. 
     * If the JWT contains an "email" claim, then it's a PO Auth JWT from the API-HUB.  
     */
    String role = jwt.getClaimAsString("role");
    if (StringUtils.isEmpty(role)) { 
      String user = jwt.getClaim("email");
      if (StringUtils.isEmpty(user) || !emailBasedAuthzServiceImpl.isUserHubAdmin(user)) {
        throw new ForbiddenException("The user is not authorized for Production deployment.");
      }
      
    } else {
      List<String> apiProducts = userAuthorizationConfigProperties.getPartnerProxy().getApiProducts();
      if (!apiProducts.contains(role)) {
        throw new ForbiddenException("The user is not authorized for Production deployment.");
      }
    }
      
  }

  @Override
  public void isAuthorizedToUsePartnerProxy(Jwt jwt) {
    /*
     * Determine if the JWT contains a "role" claim and the value is the API Product name used for 
     * the webhooks Partner Proxies.  
     */
    String role = jwt.getClaimAsString("role");
    if (StringUtils.isEmpty(role)) { 
      throw new UnauthorizedException("Missing or invalid credentials");
      
    } else {
      List<String> apiProducts = userAuthorizationConfigProperties.getPartnerProxy().getApiProducts();
      if (!apiProducts.contains(role)) {
        throw new ForbiddenException("The client is not authorized for Partner Proxy");
      }
    }
      
  }
}
