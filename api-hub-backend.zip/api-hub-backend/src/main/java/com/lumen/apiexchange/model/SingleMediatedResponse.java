package com.lumen.apiexchange.model;

public class SingleMediatedResponse {

  private ApiMediatedResource mediatedResource;

  public ApiMediatedResource getMediatedResource() {
    return mediatedResource;
  }

  public void setMediatedResource(ApiMediatedResource mediatedResource) {
    this.mediatedResource = mediatedResource;
  }


}
