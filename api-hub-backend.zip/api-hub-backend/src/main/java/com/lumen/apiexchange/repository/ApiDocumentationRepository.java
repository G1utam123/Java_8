package com.lumen.apiexchange.repository;

import com.lumen.apiexchange.entity.ApiDocumentation;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ApiDocumentationRepository extends JpaRepository<ApiDocumentation, Integer> {

  List<ApiDocumentation> findByApiId(UUID apiid);

  void deleteByApiIdIn(List<Integer> ids);

}
