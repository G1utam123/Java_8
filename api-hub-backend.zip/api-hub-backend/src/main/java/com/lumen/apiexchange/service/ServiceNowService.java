package com.lumen.apiexchange.service;



import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.snow.ServiceNowRequest;


public interface ServiceNowService {
  String createGroup(ServiceNowRequest serviceNowRequest) throws InternalServerException;

}
