package com.lumen.apiexchange.exception;

import com.lumen.apiexchange.api.partner.model.Error404;

public class NotFoundException extends RuntimeException {

  private static final long serialVersionUID = 1L;
  private Error404 error;

  public NotFoundException(String message) {
    super(message);
  }

  public NotFoundException(String reason, String message) {
    super(message);
    this.error = buildCommonCode404(reason, message);

  }

  private static Error404 buildCommonCode404(String reason, String message) {
    Error404 error = new Error404();
    error.code(Error404.CodeEnum.NOTFOUND);
    error.setReason(reason);
    error.setMessage(message);
    return error;
  }

  public Error404 getError() {
    return error;
  }
}
