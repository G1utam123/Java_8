package com.lumen.apiexchange.model.myapps;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ApigeeAPIClientModelResponse {
  private List<ApigeeAPIClientModel> app;

  public ApigeeAPIClientModelResponse() {
    super();
  }

  public ApigeeAPIClientModelResponse(List<ApigeeAPIClientModel> app) {
    super();
    this.app = app;
  }

  public List<ApigeeAPIClientModel> getApp() {
    return app;
  }

  public void setApp(List<ApigeeAPIClientModel> app) {
    this.app = app;
  }

}
