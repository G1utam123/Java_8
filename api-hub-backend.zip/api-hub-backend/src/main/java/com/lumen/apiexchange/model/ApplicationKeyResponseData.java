package com.lumen.apiexchange.model;

import java.util.List;

public class ApplicationKeyResponseData {

  private List<ApplicationKey> applicationKey;

  public List<ApplicationKey> getApplicationKey() {
    return applicationKey;
  }

  public void setApplicationKey(List<ApplicationKey> applicationKey) {
    this.applicationKey = applicationKey;
  }

}
