package com.lumen.apiexchange.controller;

import com.lumen.apiexchange.exception.AppNotFoundException;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.MyAppResponse;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.model.myapps.ApigeeAPIClientModel;
import com.lumen.apiexchange.model.myapps.CreateAppRequest;
import com.lumen.apiexchange.model.myapps.MyAppsModelResponse;
import com.lumen.apiexchange.model.myapps.UpdateAppRequest;
import com.lumen.apiexchange.service.MyAppsService;
import com.lumen.apiexchange.service.ProfileService;
import java.util.List;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyAppsController {

  @Autowired
  private MyAppsService myAppService;

  @Autowired
  private ProfileService profileService;

  protected static final Logger log = LoggerFactory.getLogger(MyAppsController.class);

  private String getEmailFromJwt(Jwt principal) {
    return profileService.getEmailFromProfile(principal);
  }

  @CrossOrigin
  @GetMapping(value = "/v1/userapps")
  public MyAppsModelResponse getAllApps(@AuthenticationPrincipal Jwt principal)
      throws InternalServerException, BadInputException {
    String email = getEmailFromJwt(principal);
    return myAppService.getApigeeApiClientForEnterpriseId(email);
  }

  @CrossOrigin
  @DeleteMapping(value = "/v1/deleteuserapp/{appName}")
  public ResponseEntity<MyAppResponse> deleteapp(@PathVariable(value = "appName") String appName,
                                                 @AuthenticationPrincipal Jwt principal)
      throws InternalServerException {
    String userName = getEmailFromJwt(principal);
    return myAppService.deleteAppFromApigee(userName, appName);
  }

  @CrossOrigin
  @PostMapping(value = "/v1/updateuserapps")
  public ApigeeAPIClientModel updateUserApp(@RequestBody UpdateAppRequest request,
                                            @AuthenticationPrincipal Jwt principal)
      throws InternalServerException, BadInputException, AppNotFoundException {

    String emailFromProfile = getEmailFromJwt(principal);

    log.info("Email obtained from profileService.getEmailFromProfile :: {}", emailFromProfile);

    return myAppService.updateApp(request, emailFromProfile);
  }

  @CrossOrigin
  @GetMapping(value = "/v1/getproxydetails/{apiId}")
  public List<ApiMediatedResource> getProxyDetails(@PathVariable(value = "apiId") UUID apiId)
      throws InternalServerException, BadInputException, AppNotFoundException {

    return myAppService.getProxyDetails(apiId);
  }

  @CrossOrigin
  @PostMapping(value = "/v1/createuserapps")
  public ApigeeAPIClientModel createUserApp(@RequestBody CreateAppRequest request,
                                            @AuthenticationPrincipal Jwt principal)
      throws InternalServerException, BadInputException {

    String emailFromProfile = getEmailFromJwt(principal);

    log.info("Email obtained from profileService.getEmailFromProfile :: {}", emailFromProfile);

    return myAppService.createAppFromApigee(request, emailFromProfile);
  }

  @CrossOrigin
  @GetMapping(value = "/v1/apiproducts")
  public ResponseEntity<?> getApiProducts(@AuthenticationPrincipal Jwt principal) throws InternalServerException {
    return myAppService.getApiProductsFromApigee();
  }

}
