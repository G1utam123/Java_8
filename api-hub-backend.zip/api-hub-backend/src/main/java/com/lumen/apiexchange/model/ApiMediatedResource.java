
package com.lumen.apiexchange.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author mchikka
 *
 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiMediatedResource {

  private int mediatedResourceId;
  private String resourceTaxonomy;
  private String resourceName;
  private String version;
  private String serviceType;
  private String internallyAvailable;
  private String externallyAvailable;
  private String active;
  private String endPointUrl;
  private int throttlingRequestsPerSec;
  private int timeoutSecs;
  private String connectionKeepAlive;
  private String owningApplicationId;
  private String owningApplicationKey;
  private String replaceUrlFromValue;
  private String replaceUrlToValue;
  private String routingExpression;
  private String resourceGuid;
  private String validAuthTypes;
  private String enforceDigest;
  private String enforceTaxonomy;
  private String authorizedGroups;
  private String authorizedUsers;
  private String enforceHttps;
  private String endpointAuthType;
  private String basicAuthPassword;
  private String basicAuthUser;
  private String oauthClientIdLocation;
  private String oauthClientId;
  private String oauthClientSecret;
  private String oauthGrantType;
  private String oauthPassword;
  private String oauthTokenServiceHost;
  private String oauthTokenServiceUri;
  private String oauthGrantTypeLocation;
  private String oauthScopeLocation;
  private String oauthScope;
  private String b2bAuthRequired;
  private String b2bCustomerNumberRequired;
  private String b2bBillingAccountNumberRequired;
  private String source;
  private String routingType;
  private String createdBy;
  private String createdDate;
  private String updatedBy;
  private String updatedDate;
  private String environment;
  private Boolean allowMigration;

  public ApiMediatedResource() {
    super();
  }


  public int getMediatedResourceId() {
    return mediatedResourceId;
  }

  public void setMediatedResourceId(int mediatedResourceId) {
    this.mediatedResourceId = mediatedResourceId;
  }

  public String getResourceTaxonomy() {
    return resourceTaxonomy;
  }

  public void setResourceTaxonomy(String resourceTaxonomy) {
    this.resourceTaxonomy = resourceTaxonomy;
  }

  public String getResourceName() {
    return resourceName;
  }

  public void setResourceName(String resourceName) {
    this.resourceName = resourceName;
  }

  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public String getServiceType() {
    return serviceType;
  }

  public void setServiceType(String serviceType) {
    this.serviceType = serviceType;
  }

  public String getInternallyAvailable() {
    return internallyAvailable;
  }

  public void setInternallyAvailable(String internallyAvailable) {
    this.internallyAvailable = internallyAvailable;
  }

  public String getExternallyAvailable() {
    return externallyAvailable;
  }

  public void setExternallyAvailable(String externallyAvailable) {
    this.externallyAvailable = externallyAvailable;
  }

  public String getActive() {
    return active;
  }

  public void setActive(String active) {
    this.active = active;
  }

  public String getEndPointUrl() {
    return endPointUrl;
  }

  public void setEndPointUrl(String endPointUrl) {
    this.endPointUrl = endPointUrl;
  }

  public int getThrottlingRequestsPerSec() {
    return throttlingRequestsPerSec;
  }

  public void setThrottlingRequestsPerSec(int throttlingRequestsPerSec) {
    this.throttlingRequestsPerSec = throttlingRequestsPerSec;
  }

  public int getTimeoutSecs() {
    return timeoutSecs;
  }

  public void setTimeoutSecs(int timeoutSecs) {
    this.timeoutSecs = timeoutSecs;
  }

  public String getConnectionKeepAlive() {
    return connectionKeepAlive;
  }

  public void setConnectionKeepAlive(String connectionKeepAlive) {
    this.connectionKeepAlive = connectionKeepAlive;
  }

  public String getOwningApplicationId() {
    return owningApplicationId;
  }

  public void setOwningApplicationId(String owningApplicationId) {
    this.owningApplicationId = owningApplicationId;
  }

  public String getOwningApplicationKey() {
    return owningApplicationKey;
  }

  public void setOwningApplicationKey(String owningApplicationKey) {
    this.owningApplicationKey = owningApplicationKey;
  }

  public String getReplaceUrlFromValue() {
    return replaceUrlFromValue;
  }

  public void setReplaceUrlFromValue(String replaceUrlFromValue) {
    this.replaceUrlFromValue = replaceUrlFromValue;
  }

  public String getReplaceUrlToValue() {
    return replaceUrlToValue;
  }

  public void setReplaceUrlToValue(String replaceUrlToValue) {
    this.replaceUrlToValue = replaceUrlToValue;
  }

  public String getRoutingExpression() {
    return routingExpression;
  }

  public void setRoutingExpression(String routingExpression) {
    this.routingExpression = routingExpression;
  }

  public String getResourceGuid() {
    return resourceGuid;
  }

  public void setResourceGuid(String resourceGuid) {
    this.resourceGuid = resourceGuid;
  }

  public String getValidAuthTypes() {
    return validAuthTypes;
  }

  public void setValidAuthTypes(String validAuthTypes) {
    this.validAuthTypes = validAuthTypes;
  }

  public String getEnforceDigest() {
    return enforceDigest;
  }

  public void setEnforceDigest(String enforceDigest) {
    this.enforceDigest = enforceDigest;
  }

  public String getEnforceTaxonomy() {
    return enforceTaxonomy;
  }

  public void setEnforceTaxonomy(String enforceTaxonomy) {
    this.enforceTaxonomy = enforceTaxonomy;
  }

  public String getAuthorizedGroups() {
    return authorizedGroups;
  }

  public void setAuthorizedGroups(String authorizedGroups) {
    this.authorizedGroups = authorizedGroups;
  }

  public String getAuthorizedUsers() {
    return authorizedUsers;
  }

  public void setAuthorizedUsers(String authorizedUsers) {
    this.authorizedUsers = authorizedUsers;
  }

  public String getEnforceHttps() {
    return enforceHttps;
  }

  public void setEnforceHttps(String enforceHttps) {
    this.enforceHttps = enforceHttps;
  }

  public String getEndpointAuthType() {
    return endpointAuthType;
  }

  public void setEndpointAuthType(String endpointAuthType) {
    this.endpointAuthType = endpointAuthType;
  }

  public String getBasicAuthUser() {
    return basicAuthUser;
  }

  public void setBasicAuthUser(String basicAuthUser) {
    this.basicAuthUser = basicAuthUser;
  }

  public String getBasicAuthPassword() {
    return basicAuthPassword;
  }

  public void setBasicAuthPassword(String basicAuthPassword) {
    this.basicAuthPassword = basicAuthPassword;
  }

  public String getoAuthClientIdLocation() {
    return oauthClientIdLocation;
  }

  public void setoAuthClientIdLocation(String oauthClientIdLocation) {
    this.oauthClientIdLocation = oauthClientIdLocation;
  }

  public String getoAuthClientId() {
    return oauthClientId;
  }

  public void setoAuthClientId(String oauthClientId) {
    this.oauthClientId = oauthClientId;
  }

  public String getoAuthClientSecret() {
    return oauthClientSecret;
  }

  public void setoAuthClientSecret(String oauthClientSecret) {
    this.oauthClientSecret = oauthClientSecret;
  }

  public String getoAuthGrantType() {
    return oauthGrantType;
  }

  public void setoAuthGrantType(String oauthGrantType) {
    this.oauthGrantType = oauthGrantType;
  }

  public String getoAuthPassword() {
    return oauthPassword;
  }

  public void setoAuthPassword(String oauthPassword) {
    this.oauthPassword = oauthPassword;
  }

  public String getoAuthTokenServiceHost() {
    return oauthTokenServiceHost;
  }

  public void setoAuthTokenServiceHost(String oauthTokenServiceHost) {
    this.oauthTokenServiceHost = oauthTokenServiceHost;
  }

  public String getoAuthTokenServiceUri() {
    return oauthTokenServiceUri;
  }

  public void setoAuthTokenServiceUri(String oauthTokenServiceUri) {
    this.oauthTokenServiceUri = oauthTokenServiceUri;
  }

  public String getoAuthScopeLocation() {
    return oauthScopeLocation;
  }

  public void setoAuthScopeLocation(String oauthScopeLocation) {
    this.oauthScopeLocation = oauthScopeLocation;
  }

  public String getoAuthScope() {
    return oauthScope;
  }

  public void setoAuthScope(String oauthScope) {
    this.oauthScope = oauthScope;
  }

  public String getoAuthGrantTypeLocation() {
    return oauthGrantTypeLocation;
  }

  public void setoAuthGrantTypeLocation(String oauthGrantTypeLocation) {
    this.oauthGrantTypeLocation = oauthGrantTypeLocation;
  }

  public String getB2bAuthRequired() {
    return b2bAuthRequired;
  }

  public void setB2bAuthRequired(String b2bAuthRequired) {
    this.b2bAuthRequired = b2bAuthRequired;
  }

  public String getB2bCustomerNumberRequired() {
    return b2bCustomerNumberRequired;
  }

  public void setB2bCustomerNumberRequired(String b2bCustomerNumberRequired) {
    this.b2bCustomerNumberRequired = b2bCustomerNumberRequired;
  }

  public String getB2bBillingAccountNumberRequired() {
    return b2bBillingAccountNumberRequired;
  }

  public void setB2bBillingAccountNumberRequired(String b2bBillingAccountNumberRequired) {
    this.b2bBillingAccountNumberRequired = b2bBillingAccountNumberRequired;
  }

  public String getSource() {
    return source;
  }

  public void setSource(String source) {
    this.source = source;
  }

  public String getRoutingType() {
    return routingType;
  }

  public void setRoutingType(String routingType) {
    this.routingType = routingType;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public String getCreatedDate() {
    return createdDate;
  }


  public void setCreatedDate(String createdDate) {
    this.createdDate = createdDate;
  }


  public String getUpdatedDate() {
    return updatedDate;
  }


  public void setUpdatedDate(String updatedDate) {
    this.updatedDate = updatedDate;
  }

  public String getUpdatedBy() {
    return updatedBy;
  }

  public void setUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
  }

  public String getEnvironment() {
    return environment;
  }

  public void setEnvironment(String environment) {
    this.environment = environment;
  }

  public Boolean getAllowMigration() {
    return allowMigration;
  }

  public void setAllowMigration(Boolean allowMigration) {
    this.allowMigration = allowMigration;
  }
}
