package com.lumen.apiexchange.model.myapps;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ApigeeAPIClientModel {
  private List<String> apiProducts;
  private List<Attribute> attributes;
  private List<Credentials> credentials;
  private String name;
  private int keyExpiresIn;
  private String status;
  private long createdAt;

  public List<String> getApiProducts() {
    return apiProducts;
  }

  public void setApiProducts(List<String> apiProducts) {
    this.apiProducts = apiProducts;
  }

  public List<Credentials> getCredentials() {
    return credentials;
  }

  public void setCredentials(List<Credentials> credentials) {
    this.credentials = credentials;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public int getKeyExpiresIn() {
    return keyExpiresIn;
  }

  public void setKeyExpiresIn(int keyExpiresIn) {
    this.keyExpiresIn = keyExpiresIn;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public List<Attribute> getAttributes() {
    return attributes;
  }

  public void setAttributes(List<Attribute> attributes) {
    this.attributes = attributes;
  }

  public long getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(long createdAt) {
    this.createdAt = createdAt;

  }
}
