package com.lumen.apiexchange.util;

public abstract class FeatureFlags {
  public static final String FF_SNOW_AUTHZ_ENABLED = "FF_SNOW_AUTHZ_ENABLED";

  private FeatureFlags() {}
}
