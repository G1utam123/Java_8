package com.lumen.apiexchange.model;

public class Category {

  private String categoryservice;

  

  @Override
  public String toString() {
    return "Authorization [categoryservice=" + categoryservice + "]";
  }



  public String getCategoryservice() {
    return categoryservice;
  }



  public void setCategoryservice(String categoryservice) {
    this.categoryservice = categoryservice;
  }
}
