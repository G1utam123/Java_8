package com.lumen.apiexchange.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "com.lumen.apienable.autoapi")
public class ApigeeConfigProperties {

  private String apigeeHostnameDev1;
  private String apigeeHostnameDev1Https;
  private String apigeeHostnameDev2;
  private String apigeeHostnameDev3;
  private String apigeeHostnameDev4;
  private String apigeeHostnameTest1;
  private String apigeeHostnameTest2;
  private String apigeeHostnameTest3;
  private String apigeeHostnameTest4;
  private String apigeeHostnameMock;
  private String apigeeHostnameSandbox;
  private String apigeeHostnameProd;

  private String apigeeApiBuildDefaultThrottle;
  private String apigeeApiBuildDefaultTimeout;
  private String apigeeApiBuildDefaultKeepalive;
  private String apigeeApiBuildDefaultEnforcehttps;
  private String apigeeApiBuildDefaultJwtissprod;
  private String apigeeApiBuildDefaultJwtissnonprod;

  private String appkey;
  private String hyperionAppkey;
  private String apigeeAppkey;
  private String apigeeAppkeySecret;
  private String apigeeUser;
}
