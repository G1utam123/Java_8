package com.lumen.apiexchange.service.apigee;

import com.lumen.apiexchange.client.apigee.ApigeeMgmtApiClient;
import com.lumen.apiexchange.exception.BadInputException;
import java.util.Collections;
import java.util.List;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@AllArgsConstructor
@Service
public class ApigeeEnvironmentsServiceImpl implements ApigeeEnvironmentsService {

  protected static final Logger log = LoggerFactory.getLogger(ApigeeEnvironmentsServiceImpl.class);
  
  private final ApigeeMgmtApiClient apigeeMgmtApiClient;

  @Override
  public List<String> getEnvironments(String planet, String org) {

    List<String> envs = apigeeMgmtApiClient.getEnvironments(planet, org);
    Collections.sort(envs);
    
    return envs; 

  }

  @Override
  public void validateEnvironments(String planet, String org, List<String> envsToValidate) throws BadInputException {

    List<String> validEnvs = getEnvironments(planet, org);
    envsToValidate.removeAll(validEnvs);
    
    if (!envsToValidate.isEmpty()) {
      throw new BadInputException("environments: " + envsToValidate.toString() 
          + " not valid for " + planet + " and " + org);      
    }

  }

}
