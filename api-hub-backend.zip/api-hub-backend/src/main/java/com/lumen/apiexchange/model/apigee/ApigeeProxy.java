/*
 * API Proxy - Apigee OPDK
 * For more information, see 
 * <a href=\"https://apidocs.apigee.com/docs/api-proxies/1/types/APIProxy">API Proxies API</a>.
 *
 */
/* Sample Apigee API Proxy 
 *
 {
    "metaData": {
      "createdAt": 1472699641914,
      "createdBy": "ahamilton@example.com",
      "lastModifiedAt": 1560950346500,
      "lastModifiedBy": "ahamilton@example.com",
      "subType": "null"
    },
    "name": "Mock-Target-API",
    "revision": [
      "1",
      "2"
    ]
  }
 */
  
package com.lumen.apiexchange.model.apigee;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
/**
 * API product details.
 */

@AllArgsConstructor
@Builder
@Data
@Getter
@NoArgsConstructor
public class ApigeeProxy {

  private ApigeeProxyMetaData metaData;
  private String name;
  private List<String> revision;
}
