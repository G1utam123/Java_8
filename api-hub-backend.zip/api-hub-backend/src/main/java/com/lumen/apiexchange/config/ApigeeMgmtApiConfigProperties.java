package com.lumen.apiexchange.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "apigee.management.api")
public class ApigeeMgmtApiConfigProperties {

  private String managementServerProdUrl;
  private String managementServerProdBasicauth;

  private String managementServerNonProdUrl;
  private String managementServerNonProdBasicauth;
}
