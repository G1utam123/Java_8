package com.lumen.apiexchange.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class InputApiResponse {
  private String status;
  
  private String message;
  
  private String guid;

}