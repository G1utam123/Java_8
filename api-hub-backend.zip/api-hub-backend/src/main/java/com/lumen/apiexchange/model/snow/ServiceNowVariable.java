package com.lumen.apiexchange.model.snow;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@Builder
@AllArgsConstructor
@ToString
public class ServiceNowVariable {

  @JsonProperty("prymary_owner")
  private String primaryOwner;

  @JsonProperty("azure_sync")
  private Boolean azureSync;

  @JsonProperty("request_action")
  private String requestAction;

  private String comments;

  @JsonProperty("request_type")
  private String requestType;

  @JsonProperty("group_name")
  private String groupName;

  @JsonProperty("secondary_owner")
  private String secondaryOwner;

  @JsonProperty("purpose_of_share")
  private String purposeOfShare;

  @JsonProperty("requested_for")
  private String requestedFor;

  @JsonProperty("opened_by")
  private String openedBy;

}