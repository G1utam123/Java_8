package com.lumen.apiexchange.model.apigee;

import java.util.List;
import javax.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
/**
 * API product details.
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApigeeProductRequest {

  /**
   * Properties sent to Apigee
   */
  private List<String> apiResources;
  private ApprovalType approvalType;
  private List<Attribute> attributes;
  private String description;
  @NotBlank(message = "displayName is mandatory")
  private String displayName;
  private List<String> environments;
  private String name;
  private List<String> proxies;
  private String quota;
  private String quotaInterval;
  private QuotaTimeUnit quotaTimeUnit;
  private List<String> scopes;

  
  /**
   * Flag that specifies how API keys are approved to access the APIs defined by the API product. 
   * If set to 'manual', the consumer key is generated and returned in "pending" state. 
   * In this case, the API keys won't work until they have been explicitly approved. If set to 'auto', 
   * the consumer key is generated and returned in "approved" state and can be used immediately.  
   * **Note**: Typically, 'auto' is used to provide access to free or trial API products that provide limited 
   * quota or capabilities.
   */
  @AllArgsConstructor
  @Getter
  public enum ApprovalType {
    auto,
    manual;
  }
  
  /**
   * Time unit defined for the 'quotaInterval'.
   */
  @AllArgsConstructor
  @Getter
  public enum QuotaTimeUnit {
    minute,
    hour,
    day,
    month;
  }  
  
}
