package com.lumen.apiexchange.client;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lumen.apiexchange.config.ApigeeConfigProperties;
import com.lumen.apiexchange.config.MediationResourceConfigProperties;
import com.lumen.apiexchange.config.ProxyConfigProperties;
import com.lumen.apiexchange.config.ProxyCustomerProperties;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.model.ApiMediatedResponse;
import com.lumen.apiexchange.model.ApplicationKey;
import com.lumen.apiexchange.model.ApplicationKeyResponse;
import com.lumen.apiexchange.model.AuthorizationResponse;
import com.lumen.apiexchange.model.Category;
import com.lumen.apiexchange.model.InputApiRequest;
import com.lumen.apiexchange.model.SingleMediatedResponse;
import com.lumen.apiexchange.model.TaxonomyCreationResult;
import com.lumen.apiexchange.service.HostServiceImpl;
import com.lumen.apiexchange.util.APIHandler;
import io.micrometer.core.instrument.util.StringUtils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpServerErrorException.InternalServerError;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@RequiredArgsConstructor
@Slf4j
public class ESPClient {

  private static final String APPLICATION_KEY_HEADER = "X-Application-Key";
  private static final String USER_HEADER = "X-Username";
  private static final String HTTPSTATUS_NOT_OK = "HttpStatus from ESP Not OK. HTTPStatus: ";
  
  private final RestTemplate restTemplate;
  private final ApigeeConfigProperties apigeeConfigProperties;
  private final ProxyConfigProperties proxyConfigProperties;
  private final MediationResourceConfigProperties mediationResourceConfigProp;
  private final ProxyCustomerProperties proxyCustomerProperties;
  private final APIHandler apiHandler;
  private final Environment environment;
  private final HostServiceImpl hostService;

  public List<String> getTaxonomies() throws InternalServerException {
    String appKeyValue = proxyConfigProperties.getApplicationKey();
    String url = environment.getProperty("proxy.taxonomy.url.dev1");
    List<Category> categoryService = new ArrayList<>();
    try {
      HttpHeaders headers = new HttpHeaders();
      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
      headers.set(APPLICATION_KEY_HEADER, appKeyValue);

      HttpEntity<String> entity = new HttpEntity<>(headers);
      ResponseEntity<AuthorizationResponse> authorizationResponse = restTemplate.exchange(url, HttpMethod.GET, entity,
          AuthorizationResponse.class);

      if (authorizationResponse != null && authorizationResponse.getBody() != null
          && authorizationResponse.getBody().getAuthorizations() != null
          && authorizationResponse.getBody().getAuthorizations().getAuthorization() != null) {
        categoryService = authorizationResponse.getBody().getAuthorizations().getAuthorization();

        List<String> categoryList = categoryService.stream().map(Category::getCategoryservice)
            .collect(Collectors.toList());

        Comparator<String> category = (categoryObject1, categorOobject2) -> {
          return categoryObject1.compareTo(categorOobject2);
        };
        Collections.sort(categoryList, category);
        return categoryList;

      } else {
        throw new InternalServerException("Unable to get data now. Please try again later");
      }

    } catch (Exception e) {
      throw new InternalServerException("Unable to get data now. Please try again later");
    }
  }

  @SuppressWarnings("unchecked")
  public TaxonomyCreationResult createTaxonomy(String taxonomy) throws BadInputException {
    if (StringUtils.isEmpty(taxonomy)) {
      throw new BadInputException("Taxonomy cannot be null or blank");
    } else if (!taxonomy.matches("^[a-zA-Z0-9\\/-]+$")) {
      throw new BadInputException("Taxonomy can only contain alphanumeric characters and special characters: /-");
    } else if (!taxonomy.matches("(\\w*)/(\\w*)|(\\w*)/(\\w*)-(\\w*)")) {
      throw new BadInputException("Taxonomy can only be in the following pattern: xxx/xxx or xxx/xxx-xxx");
    }
    
    Map<String, String> envUrls = proxyConfigProperties.getUrl();
    
    TaxonomyCreationResult taxCrtResult = TaxonomyCreationResult.builder()
        .taxonomy(taxonomy)
        .taxonomyCreatedEnv(new ArrayList<>())
        .taxonomyNotCreatedEnv(new ArrayList<>()).build();
    
    JSONObject request = new JSONObject();
    request.put("categoryservice", taxonomy);
    
    envUrls.forEach((env, url) -> {
      ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.OK);
      try {
        response = sendNewTaxonomyRequest(url, request.toJSONString());
        if (response.getStatusCodeValue() == HttpStatus.OK.value()) {
          taxCrtResult.getTaxonomyCreatedEnv().add(env);
        } else {
          taxCrtResult.getTaxonomyNotCreatedEnv().add(env);
        }
      } catch (Exception e) {
        taxCrtResult.getTaxonomyNotCreatedEnv().add(env);
      }
    });
    
    log.info("Taxonomy {} successfully created on {}", taxCrtResult.getTaxonomy(),
        taxCrtResult.getTaxonomyCreatedEnv());
    
    if (taxCrtResult.getTaxonomyNotCreatedEnv().isEmpty()) {
      log.error("Error creating taxonomy {} on {}", taxCrtResult.getTaxonomy(),
          taxCrtResult.getTaxonomyNotCreatedEnv());
    }
    
    return taxCrtResult;
  }
  
  public ResponseEntity<String> sendNewTaxonomyRequest(String url, String request) {
    
    HttpHeaders headers = getHttpHeaders();
    HttpEntity<String> entity = new HttpEntity<>(request, headers);
    ResponseEntity<String> myEntity = new ResponseEntity<>(HttpStatus.OK);
    myEntity = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
    return myEntity;
    
  }
  
  public List<ApplicationKey> getApplicationKeys() throws InternalServerException {
    String appKeyValue = proxyConfigProperties.getApplicationKey();
    String url = proxyCustomerProperties.getUrl();

    try {
      HttpHeaders headers = new HttpHeaders();
      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
      headers.set(APPLICATION_KEY_HEADER, appKeyValue);
      HttpEntity<String> entity = new HttpEntity<>(headers);
      // Calling Service
      ResponseEntity<ApplicationKeyResponse> applicationDetailsResponse = restTemplate.exchange(url, HttpMethod.GET,
          entity, ApplicationKeyResponse.class);

      if (applicationDetailsResponse != null && applicationDetailsResponse.getBody() != null
          && applicationDetailsResponse.getBody().getApplicationKeys() != null
          && applicationDetailsResponse.getBody().getApplicationKeys().getApplicationKey() != null) {
        List<ApplicationKey> appKeyList = applicationDetailsResponse.getBody().getApplicationKeys().getApplicationKey();

        Comparator<ApplicationKey> appKeyId = (appKeyObj1, appKeyObj2) -> {
          return appKeyObj1.getApplicationKeyID().compareTo(appKeyObj2.getApplicationKeyID());
        };
        Collections.sort(appKeyList, appKeyId);
        return appKeyList;
      } else {
        throw new InternalServerException("Unable to get ApplicationKeys, please try later");
      }

    } catch (Exception e) {
      throw new InternalServerException("Unable to get ApplicationKeys, please try later");
    }
  }

  public ApiMediatedResource getApiProxyEnvDetails(String resourceGuid, String url) throws InternalServerException {

    RestTemplate restTemplate = new RestTemplate();

    ObjectMapper mapper = new ObjectMapper();
    MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
    converter.setObjectMapper(mapper);
    mapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);

    restTemplate.setMessageConverters(Collections.singletonList(converter));

    HttpHeaders headers = new HttpHeaders();
    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
    headers.set(APPLICATION_KEY_HEADER, mediationResourceConfigProp.getAppkey());
    headers.set(USER_HEADER, mediationResourceConfigProp.getApigeeUser());
    HttpEntity<String> entity = new HttpEntity<>(headers);

    ResponseEntity<ApiMediatedResponse> apiDetailsResponse = null;
    apiDetailsResponse = restTemplate.exchange(url, HttpMethod.GET, entity, ApiMediatedResponse.class);

    if (apiDetailsResponse.getBody().getMediatedResource() != null
        && !apiDetailsResponse.getBody().getMediatedResource().isEmpty()) {
      return apiDetailsResponse.getBody().getMediatedResource().get(0);
    } else {
      return null;
    }
  }

  public ApiMediatedResource getApiProxyEnvDetails(String environment, UUID proxyGuid) throws InternalServerException {

    String resourceGuid = proxyGuid.toString();
    String url = constructEspProxyUrl(environment, resourceGuid); 

    ApiMediatedResource espResource = null;
    try {
    
      espResource = getApiProxyEnvDetails(resourceGuid, url);
    
    } catch (InternalServerError e) {
      throw new InternalServerException("Unable to get Proxy Details. Please try later:" + e.getMessage());
    }
    
    return espResource;
  }

  public ApiMediatedResponse getApiProxies() throws InternalServerException {

    InputApiRequest inputApiRequest = new InputApiRequest();
    inputApiRequest.setEnv("dev1");
    String myURL = apiHandler.constructUrlWithQueryParameter(inputApiRequest);

    HttpHeaders headers = getHttpHeaders();

    HttpEntity<String> entity = new HttpEntity<>(headers);

    try {
      ResponseEntity<ApiMediatedResponse> apiDetailsResponse = restTemplate.exchange(myURL, HttpMethod.GET, entity,
          ApiMediatedResponse.class);
      return apiDetailsResponse.getBody();
    } catch (Exception e) {
      throw new InternalServerException("Unable to get Proxy Details. Please try later" + e.getMessage());
    }
  }

  public ApiMediatedResource getApiProxies(String uuid) throws InternalServerException {

    InputApiRequest inputApiRequest = new InputApiRequest();
    inputApiRequest.setEnv("dev1");
    inputApiRequest.setGuid(uuid);

    String myURL = apiHandler.constructUrlWithQueryParameter(inputApiRequest);

    HttpHeaders headers = getHttpHeaders();

    HttpEntity<String> entity = new HttpEntity<>(headers);

    try {
      ResponseEntity<SingleMediatedResponse> apiDetailsResponse = restTemplate.exchange(myURL, HttpMethod.GET, entity,
          SingleMediatedResponse.class);
      return apiDetailsResponse.getBody().getMediatedResource();
    } catch (Exception e) {
      throw new InternalServerException("Unable to get Proxy Details. Please try later: " + e.getMessage());
    }
  }

  public ApiMediatedResponse getApiProxies(String env, String taxonomy, String resourceName, String version)
      throws InternalServerException {

    InputApiRequest inputApiRequest = new InputApiRequest();
    inputApiRequest.setEnv(env);
    inputApiRequest.setTaxonomy(taxonomy);
    inputApiRequest.setResourceName(resourceName);
    inputApiRequest.setVersion(version);
    return getApiProxies(inputApiRequest);
    
  }

  public ApiMediatedResponse getApiProxies(InputApiRequest inputApiRequest) throws InternalServerException {

    String myURL = apiHandler.constructUrlWithQueryParameter(inputApiRequest);

    HttpHeaders headers = getHttpHeaders();

    HttpEntity<String> entity = new HttpEntity<>(headers);

    try {
      ResponseEntity<ApiMediatedResponse> apiDetailsResponse = restTemplate.exchange(myURL, HttpMethod.GET, entity,
          ApiMediatedResponse.class);
      //ApiMediatedResource singleResource = apiDetailsResponse.getBody().getMediatedResource().get(0); 
      return apiDetailsResponse.getBody();
    } catch (Exception e) {
      throw new InternalServerException("Unable to get Proxy Details. Please try later: " + e.getMessage());
    }
  }

  private HttpHeaders getHttpHeaders() {
    HttpHeaders headers = new HttpHeaders();
    headers.set(APPLICATION_KEY_HEADER, apigeeConfigProperties.getAppkey());
    headers.set(USER_HEADER, apigeeConfigProperties.getApigeeUser());
    headers.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
    return headers;
  }

  public ApiMediatedResponse getApiProxyDetails(InputApiRequest inputApiRequest) throws InternalServerException {

    String myURL = apiHandler.constructUrlWithQueryParameter(inputApiRequest);

    HttpHeaders headers = getHttpHeaders();

    HttpEntity<String> entity = new HttpEntity<>(headers);

    try {
      ResponseEntity<ApiMediatedResponse> apiDetailsResponse = restTemplate.exchange(myURL, HttpMethod.GET, entity,
          ApiMediatedResponse.class);
      if (apiDetailsResponse.getStatusCodeValue() != HttpStatus.OK.value()) {
        throw new InternalServerException("HttpStatus Not OK");
      }
      return apiDetailsResponse.getBody();
    } catch (Exception e) {
      throw new InternalServerException("Unable to get Proxy Details. Please try later" + e.getMessage());
    }
  }

  public void deleteApiProxy(String mediatedResourceId, String env) throws InternalServerException {

    String url = apiHandler.constructMediationUrl(env) + "/" + mediatedResourceId;
    HttpHeaders headers = getHttpHeaders();
    HttpEntity<String> entity = new HttpEntity<>(headers);
    
    try {
      ResponseEntity<Void> espResponse = restTemplate.exchange(url, HttpMethod.DELETE, entity, Void.class);
      if (espResponse.getStatusCodeValue() != HttpStatus.OK.value()) {
        throw new InternalServerException(HTTPSTATUS_NOT_OK 
            + espResponse.getStatusCodeValue());
      }
    } catch (Exception e) {
      String reason = "Unable to delete proxy.  mediatedResourceId: " + mediatedResourceId;
      throw new InternalServerException(reason + e.getMessage());
    }
  }

  public void updateApiProxy(String mediatedResourceId, String request, String env, String requestorEmail) {
    String url = apiHandler.constructMediationUrl(env) + "/" + mediatedResourceId;
    HttpHeaders headers = new HttpHeaders();
    headers.set(APPLICATION_KEY_HEADER, apigeeConfigProperties.getAppkey());
    headers.set(USER_HEADER, requestorEmail);
    headers.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
    HttpEntity<String> entity = new HttpEntity<>(request, headers);

    ResponseEntity<Void> espResponse = null;
    
    try {
      espResponse = restTemplate.exchange(url, HttpMethod.PUT, entity, Void.class);
    } catch (Exception e) {
      String reason = "Unable to update proxy.  mediatedResourceId: " + mediatedResourceId;
      throw new InternalServerException(reason + e.getMessage());
    }
    
    if (espResponse.getStatusCodeValue() != HttpStatus.OK.value()) {
      throw new InternalServerException(HTTPSTATUS_NOT_OK 
          + espResponse.getStatusCodeValue());
    }
    
  }

  //NOTE: undeployType should be either "undeployInternal" or "undeployExternal"
  public void undeployApiProxy(String mediatedResourceId, String env, String undeployType)
      throws InternalServerException {
    
    String url = apiHandler.constructMediationUrl(env) + "/" + mediatedResourceId + "/" + undeployType;
    String reasonMessage = "Unable to undeploy proxy.";
    
    callEspPut(url, mediatedResourceId, reasonMessage);

  }

  public void deployApiProxy(String mediatedResourceId, String env, String deployWhere) {
    
    String url = apiHandler.constructMediationUrl(env) + "/" + mediatedResourceId + "/" + deployWhere;
    String reasonMessage = "Unable to deploy proxy.";
    
    callEspPut(url, mediatedResourceId, reasonMessage);

  }
  
  public void callEspPut(String url, String mediatedResourceId, String reasonMessage) {
    HttpHeaders headers = getHttpHeaders();
    HttpEntity<String> entity = new HttpEntity<>(headers);
    
    ResponseEntity<Void> espResponse = null;

    try {
      espResponse = restTemplate.exchange(url, HttpMethod.PUT, entity, Void.class);
    } catch (Exception e) {
      String reason = reasonMessage + " mediatedResourceId: " + mediatedResourceId;
      throw new InternalServerException(reason + e.getMessage());
    }
    
    if (espResponse.getStatusCodeValue() != HttpStatus.OK.value()) {
      String reason = HTTPSTATUS_NOT_OK 
          + espResponse.getStatusCodeValue() + " " + reasonMessage + " mediatedResourceId: " + mediatedResourceId;
      throw new InternalServerException(reason);
    }
    
  }

  public String constructEspProxyUrl(String environment, String resourceGuid) {
    Optional<String> env = Optional.empty();
    String host = hostService.getEnvHostname(environment);
    
    if (environment.equals("mock")) {
      env = Optional.of("mock");
      host = mediationResourceConfigProp.getHostnameProd();
    } else if (environment.equals("sandbox")) {
      env = Optional.of("sandbox");
      host = mediationResourceConfigProp.getHostnameProd();
    }
    
    return UriComponentsBuilder
        .fromUriString(host + mediationResourceConfigProp.getMediationResourceUri())
        .queryParamIfPresent("environment", env)
        .queryParam("resourceGuid", resourceGuid).build().toUriString();

  }

}
