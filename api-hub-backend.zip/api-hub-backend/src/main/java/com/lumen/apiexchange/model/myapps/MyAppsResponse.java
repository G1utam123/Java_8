package com.lumen.apiexchange.model.myapps;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MyAppsResponse {
  public MyAppsResponse() {

  }

  private String environment;
  private String displayName;
  private List<ProductStatus> apiProducts;
  private String consumerKey;
  private String consumerSecret;
  private String name;
  private String status;
  private int apiProdCount;
  private long createdAt;

  public String getEnvironment() {
    return environment;
  }

  public void setEnvironment(String environment) {
    this.environment = environment;
  }

  public String getDisplayName() {
    return displayName;
  }

  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  public List<ProductStatus> getApiProducts() {
    return apiProducts;
  }

  public void setApiProducts(List<ProductStatus> apiProducts) {
    this.apiProducts = apiProducts;
  }

  public String getConsumerKey() {
    return consumerKey;
  }

  public void setConsumerKey(String consumerKey) {
    this.consumerKey = consumerKey;
  }

  public String getConsumerSecret() {
    return consumerSecret;
  }

  public void setConsumerSecret(String consumerSecret) {
    this.consumerSecret = consumerSecret;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public int getApiProdCount() {
    return apiProdCount;
  }

  public void setApiProdCount(int apiProdCount) {
    this.apiProdCount = apiProdCount;
  }

  public long getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(long createdAt) {
    this.createdAt = createdAt;
  }

  public MyAppsResponse(String environment, String displayName, List<ProductStatus> apiProducts, String consumerKey,
      String consumerSecret, String name, String status, int apiProdCount, long createdAt) {
    super();
    this.environment = environment;
    this.displayName = displayName;
    this.apiProducts = apiProducts;
    this.consumerKey = consumerKey;
    this.consumerSecret = consumerSecret;
    this.name = name;
    this.status = status;
    this.apiProdCount = apiProdCount;
    this.createdAt = createdAt;
  }

}
