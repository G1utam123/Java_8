package com.lumen.apiexchange.service.apigee;

import com.lumen.apiexchange.exception.BadInputException;
import java.util.List;

public interface ApigeeEnvironmentsService {

  List<String> getEnvironments(String planet, String org);
  
  void validateEnvironments(String planet, String org, List<String> envs) throws BadInputException;
}
