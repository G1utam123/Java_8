package com.lumen.apiexchange.entity;

import java.sql.Timestamp;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "apiproxydetailsdatanew")
public class ProxyResponse {

  @Id
  private UUID id;
  @Column(name = "api_id")
  private UUID apiid;
  @Column
  private String resourceGuuid;
  private String createdUserId;
  private Timestamp createdDate;
  private String createdUserName;
  private Timestamp lastUpdatedDate;

  public UUID getId() {
    return id;
  }

  public void setId(UUID uuid) {
    this.id = uuid;
  }

  public UUID getApiid() {
    return apiid;
  }

  public void setApiid(UUID apiid) {
    this.apiid = apiid;
  }

  public String getResourceGuuid() {
    return resourceGuuid;
  }

  public void setResourceGuuid(String resourceGuuid) {
    this.resourceGuuid = resourceGuuid;
  }

  public Timestamp getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Timestamp createdDate) {
    this.createdDate = createdDate;
  }

  public String getCreatedUserId() {
    return createdUserId;
  }

  public void setCreatedUserId(String createdUserId) {
    this.createdUserId = createdUserId;
  }

  public Timestamp getLastUpdatedDate() {
    return lastUpdatedDate;
  }

  public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
    this.lastUpdatedDate = lastUpdatedDate;
  }

  public String getCreatedUserName() {
    return createdUserName;
  }

  public void setCreatedUserName(String createdUserName) {
    this.createdUserName = createdUserName;
  }



}
