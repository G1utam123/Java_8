package com.lumen.apiexchange.model.myapps;

public class ProductStatus {
  private String apiproduct;
  private String status;

  public String getApiproduct() {
    return apiproduct;
  }

  public void setApiproduct(String apiproduct) {
    this.apiproduct = apiproduct;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

}
