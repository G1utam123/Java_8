package com.lumen.apiexchange.controller;

import com.lumen.apiexchange.model.FeedbackMessage;
import com.lumen.apiexchange.service.EmailService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FeedbackController {
  @Autowired
  EmailService emailService;

  @CrossOrigin
  @PostMapping(value = "/v1/feedback")
  @ResponseStatus(HttpStatus.ACCEPTED)
  @Operation(summary = "Receives a feedback message", description = "Receives a feedback message from a user.")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "202", description = "Request accepted"),
      @ApiResponse(responseCode = "400", description = "Invalid request")})
  public void sendFeedback(@Valid @RequestBody FeedbackMessage request) {
    emailService.sendFeedbackReceivedEmail(request);
  }
}
