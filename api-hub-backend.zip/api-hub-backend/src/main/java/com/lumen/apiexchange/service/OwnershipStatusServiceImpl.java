package com.lumen.apiexchange.service;

import com.lumen.apiexchange.entity.OwnershipStatus;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.OwnershipStatusNotFoundException;
import com.lumen.apiexchange.exception.OwnershipStatusUniqueRecordNotFoundException;
import com.lumen.apiexchange.repository.OwnershipRepository;
import java.util.NoSuchElementException;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;



@Service
@RequiredArgsConstructor
public class OwnershipStatusServiceImpl implements OwnershipStatusService {

  protected static final Logger log = LoggerFactory.getLogger(OwnershipStatusServiceImpl.class);

  @Autowired
  OwnershipRepository ownerRepo;

  @Override
  public OwnershipStatus getOwnershipStatus(String elementId) throws InternalServerException,
      OwnershipStatusUniqueRecordNotFoundException {
    OwnershipStatus ownershipStatus = null;
    try {
      ownershipStatus = ownerRepo.findByElementId(elementId).orElseThrow(() ->
          new OwnershipStatusNotFoundException("No Record Found for the ID " + elementId));
    } catch (IncorrectResultSizeDataAccessException exception) {
      throw new OwnershipStatusUniqueRecordNotFoundException(elementId);
    }
    return ownershipStatus;
  }

  @Override
  public Page<OwnershipStatus> getOwnerships(Pageable pageable) throws InternalServerException {
    return ownerRepo.findAll(pageable);
  }

  @Override
  public Page<OwnershipStatus> getOwnershipStatusByStatus(String status, Pageable pageable)
      throws InternalServerException {
    return ownerRepo.getOwnershipByStatus(status, pageable);

  }

  @Override
  public Page<OwnershipStatus> getOwnershipStatusByType(String elementType, Pageable pageable)
      throws InternalServerException {
    return ownerRepo.getOwnershipByElementType(elementType, pageable);

  }

  @Override
  public Page<OwnershipStatus> getOwnershipStatusByTypeAndStatus(String elementType, String status, Pageable pageable)
      throws InternalServerException {
    return ownerRepo.getOwnershipByElementTypeAndStatus(elementType, status, pageable);

  }

  @Override
  public OwnershipStatus updateOwnership(OwnershipStatus ownership)
      throws NoSuchElementException, IncorrectResultSizeDataAccessException,
      OwnershipStatusUniqueRecordNotFoundException {
    OwnershipStatus oldOwnership;
    String requestNo = ownership.getRequestNo();
    String status = ownership.getStatus();

    if (status.equalsIgnoreCase("Provisioned") || status.equalsIgnoreCase("Provisioning")) {
      try {
        oldOwnership = ownerRepo.findByRequestNo(requestNo).get();
        oldOwnership.setStatus(ownership.getStatus());
      } catch (IncorrectResultSizeDataAccessException exception) {
        throw new OwnershipStatusUniqueRecordNotFoundException(requestNo);
      }
    } else {
      throw new BadInputException("Invalid Request No or Status");
    }
    return ownerRepo.save(oldOwnership);
  }

}
