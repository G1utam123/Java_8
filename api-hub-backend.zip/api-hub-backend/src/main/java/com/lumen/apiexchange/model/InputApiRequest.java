package com.lumen.apiexchange.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class InputApiRequest implements Serializable {

  private String env;
  
  private String environment;
  
  private boolean migrationRequest;
  
  private boolean bypassApiAlreadyExists;
  
  private boolean callAsyncBuildDeploy;
  
  private boolean skipTaxonomyValidation;
  
  private String taxonomy;
  
  private String resourceName;
  
  private String version;
  
  private String routingExpression;
  
  private String soap;
  
  private String type;
  
  private String owningAppAppkey;
  
  private String malId;
  
  private String dev1EndpointHostname;
  
  private String dev2EndpointHostname;
  
  private String dev3EndpointHostname;
  
  private String dev4EndpointHostname;
  
  private String test1EndpointHostname;
  
  private String test2EndpointHostname;
  
  private String test3EndpointHostname;
  
  private String test4EndpointHostname;
  
  private String mockEndpointHostname;
  
  private String sandboxEndpointHostname;
  
  private String prodEndpointHostname;
  
  private String endpointPath;
  
  private String internal;
  
  private String external;
  
  private String proxyAuthInternal;
  
  private String proxyAuthExternal;
  
  private String appkeyEnforceDigest;
  
  private String appkeyEnforceTaxonomy;
  
  private String basicAuthGroups;
  
  private String basicAuthUsers;
  
  private String endpointAuth;
  
  private String endpointBasicAuthUserAll;
  
  private String endpointBasicAuthPwAll;
  
  private String endpointBasicAuthUserDev1;
  
  private String endpointBasicAuthPwDev1;
  
  private String endpointBasicAuthUserDev2;
  
  private String endpointBasicAuthPwDev2;
  
  private String endpointBasicAuthUserDev3;
  
  private String endpointBasicAuthPwDev3;
  
  private String endpointBasicAuthUserDev4;
  
  private String endpointBasicAuthPwDev4;
  
  private String oauthGrantType;
  
  private String oauthGrantLocation;
  
  private String oauthTokenServiceHost;
  
  private String oauthTokenServiceURI;
  
  private String oauthClientId;
  
  private String oauthClientIdLocation;
  
  private String oauthSecret;
  
  private String oauthScope;
  
  private String oauthScopeLocation;
  
  private String oauthUserName;
  
  private String oauthpw;
  
  private String oauthCredentialsLocation;
  
  private String pingUrl;
  
  private String documentationUrl;
  
  private String active;
  
  private String jwtSubject;
  
  private String x509CertAlias;
  
  private String threatProtectionOverrides;
  
  private String b2bAuthRequired;
  
  private String b2bCustomerNumberRequired;
  
  private String b2bBillingAccountNumberRequired;
  
  private String createdBy;
  
  private String createdDate;
  
  private String updatedBy;
  
  private String updatedDate;
  
  private String guid;
  
  private String mediatedResourceId;
  
  private String requestorEmail;
  
  private String source;
  
  private String throttlingRequestsPerSec;
  
  private String timeoutSecs;
  
  private String connectionKeepAlive;
  
  private String replaceUrlFromValue;
  
  private String replaceUrlToValue;
  
  private String enforceHttps;
  
  private String securityRequestNumber;
  
  private String elementType;
  
  private List<String> admins;
  
  private List<String> owners;
  
  public boolean isMigrationRequest() {
    return migrationRequest;
  }

  public void setMigrationRequest(boolean migrationRequest) {
    this.migrationRequest = migrationRequest;
  }

  public boolean bypassApiAlreadyExists() {
    return bypassApiAlreadyExists;
  }

  public void setBypassApiAlreadyExists(boolean bypassApiAlreadyExists) {
    this.bypassApiAlreadyExists = bypassApiAlreadyExists;
  }

  public boolean callAsyncBuildDeploy() {
    return callAsyncBuildDeploy;
  }

  public void setCallAsyncBuildDeploy(boolean callAsyncBuildDeploy) {
    this.callAsyncBuildDeploy = callAsyncBuildDeploy;
  }

  public boolean skipTaxonomyValidation() {
    return skipTaxonomyValidation;
  }

  public void setSkipTaxonomyValidation(boolean skipTaxonomyValidation) {
    this.skipTaxonomyValidation = skipTaxonomyValidation;
  }

  public String getTaxonomy() {
    return taxonomy;
  }

  public void setTaxonomy(String taxonomy) {
    this.taxonomy = taxonomy;
  }

  public String getResourceName() {
    return resourceName;
  }

  public void setResourceName(String resourceName) {
    this.resourceName = resourceName;
  }

  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public String getRoutingExpression() {
    return routingExpression;
  }

  public void setRoutingExpression(String routingExpression) {
    this.routingExpression = routingExpression;
  }

  public String getSoap() {
    return soap;
  }

  public void setSoap(String soap) {
    this.soap = soap;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getOwningAppAppkey() {
    return owningAppAppkey;
  }

  public void setOwningAppAppkey(String owningAppAppkey) {
    if (owningAppAppkey != null) {
      this.owningAppAppkey = owningAppAppkey.trim();
    } else {
      this.owningAppAppkey = owningAppAppkey;
    }
  }

  public String getMalId() {
    return malId;
  }

  public void setMalId(String malId) {
    this.malId = malId;
  }

  public String getEnv() {
    return env;
  }

  public void setEnv(String env) {
    this.env = env;
  }

  public String getEnvironment() {
    return environment;
  }

  public void setEnvironment(String environment) {
    this.environment = environment;
  }

  public String getDev1EndpointHostname() {
    return dev1EndpointHostname;
  }

  public void setDev1EndpointHostname(String dev1EndpointHostname) {
    if (dev1EndpointHostname != null) {
      this.dev1EndpointHostname = dev1EndpointHostname.trim();
    } else {
      this.dev1EndpointHostname = dev1EndpointHostname;
    }
  }

  public String getDev2EndpointHostname() {
    return dev2EndpointHostname;
  }

  public void setDev2EndpointHostname(String dev2EndpointHostname) {
    if (dev2EndpointHostname != null) {
      this.dev2EndpointHostname = dev2EndpointHostname.trim();
    } else {
      this.dev2EndpointHostname = dev2EndpointHostname;
    }
  }

  public String getDev3EndpointHostname() {
    return dev3EndpointHostname;
  }

  public void setDev3EndpointHostname(String dev3EndpointHostname) {
    if (dev3EndpointHostname != null) {
      this.dev3EndpointHostname = dev3EndpointHostname.trim();
    } else {
      this.dev3EndpointHostname = dev3EndpointHostname;
    }
  }

  public String getDev4EndpointHostname() {
    return dev4EndpointHostname;
  }

  public void setDev4EndpointHostname(String dev4EndpointHostname) {
    if (dev4EndpointHostname != null) {
      this.dev4EndpointHostname = dev4EndpointHostname.trim();
    } else {
      this.dev4EndpointHostname = dev4EndpointHostname;
    }
  }

  public String getTest1EndpointHostname() {
    return test1EndpointHostname;
  }

  public void setTest1EndpointHostname(String test1EndpointHostname) {
    if (test1EndpointHostname != null) {
      this.test1EndpointHostname = test1EndpointHostname.trim();
    } else {
      this.test1EndpointHostname = test1EndpointHostname;
    }
  }

  public String getTest2EndpointHostname() {
    return test2EndpointHostname;
  }

  public void setTest2EndpointHostname(String test2EndpointHostname) {
    if (test2EndpointHostname != null) {
      this.test2EndpointHostname = test2EndpointHostname.trim();
    } else {
      this.test2EndpointHostname = test2EndpointHostname;
    }
  }

  public String getTest3EndpointHostname() {
    return test3EndpointHostname;
  }

  public void setTest3EndpointHostname(String test3EndpointHostname) {
    if (test3EndpointHostname != null) {
      this.test3EndpointHostname = test3EndpointHostname.trim();
    } else {
      this.test3EndpointHostname = test3EndpointHostname;
    }
  }

  public String getTest4EndpointHostname() {
    return test4EndpointHostname;
  }

  public void setTest4EndpointHostname(String test4EndpointHostname) {
    if (test4EndpointHostname != null) {
      this.test4EndpointHostname = test4EndpointHostname.trim();
    } else {
      this.test4EndpointHostname = test4EndpointHostname;
    }
  }

  public String getMockEndpointHostname() {
    return mockEndpointHostname;
  }

  public void setMockEndpointHostname(String mockEndpointHostname) {
    if (mockEndpointHostname != null) {
      this.mockEndpointHostname = mockEndpointHostname.trim();
    } else {
      this.mockEndpointHostname = mockEndpointHostname;
    }
  }

  public String getSandboxEndpointHostname() {
    return sandboxEndpointHostname;
  }

  public void setSandboxEndpointHostname(String sandboxEndpointHostname) {
    if (sandboxEndpointHostname != null) {
      this.sandboxEndpointHostname = sandboxEndpointHostname.trim();
    } else {
      this.sandboxEndpointHostname = sandboxEndpointHostname;
    }
  }

  public String getProdEndpointHostname() {
    return prodEndpointHostname;
  }

  public void setProdEndpointHostname(String prodEndpointHostname) {
    if (prodEndpointHostname != null) {
      this.prodEndpointHostname = prodEndpointHostname.trim();
    } else {
      this.prodEndpointHostname = prodEndpointHostname;
    }
  }

  public String getEndpointPath() {
    return endpointPath;
  }

  public void setEndpointPath(String endpointPath) {
    if (endpointPath != null) {
      this.endpointPath = endpointPath.trim();
    } else {
      this.endpointPath = endpointPath;
    }
  }

  public String getInternal() {
    return internal;
  }

  public void setInternal(String internal) {
    this.internal = internal;
  }

  public String getExternal() {
    return external;
  }

  public void setExternal(String external) {
    this.external = external;
  }

  public String getProxyAuthInternal() {
    return proxyAuthInternal;
  }

  public void setProxyAuthInternal(String proxyAuthInternal) {
    this.proxyAuthInternal = proxyAuthInternal;
  }

  public String getProxyAuthExternal() {
    return proxyAuthExternal;
  }

  public void setProxyAuthExternal(String proxyAuthExternal) {
    this.proxyAuthExternal = proxyAuthExternal;
  }

  public String getAppkeyEnforceDigest() {
    return appkeyEnforceDigest;
  }

  public void setAppkeyEnforceDigest(String appkeyEnforceDigest) {
    this.appkeyEnforceDigest = appkeyEnforceDigest;
  }

  public String getAppkeyEnforceTaxonomy() {
    return appkeyEnforceTaxonomy;
  }

  public void setAppkeyEnforceTaxonomy(String appkeyEnforceTaxonomy) {
    this.appkeyEnforceTaxonomy = appkeyEnforceTaxonomy;
  }

  public String getBasicAuthGroups() {
    return basicAuthGroups;
  }

  public void setBasicAuthGroups(String basicAuthGroups) {
    this.basicAuthGroups = basicAuthGroups;
  }

  public String getBasicAuthUsers() {
    return basicAuthUsers;
  }

  public void setBasicAuthUsers(String basicAuthUsers) {
    this.basicAuthUsers = basicAuthUsers;
  }

  public String getEndpointAuth() {
    return endpointAuth;
  }

  public void setEndpointAuth(String endpointAuth) {
    this.endpointAuth = endpointAuth;
  }

  public String getEndpointBasicAuthUserAll() {
    return endpointBasicAuthUserAll;
  }

  public void setEndpointBasicAuthUserAll(String endpointBasicAuthUserAll) {
    this.endpointBasicAuthUserAll = endpointBasicAuthUserAll;
  }

  public String getEndpointBasicAuthPwAll() {
    return endpointBasicAuthPwAll;
  }

  public void setEndpointBasicAuthPwAll(String endpointBasicAuthPwAll) {
    this.endpointBasicAuthPwAll = endpointBasicAuthPwAll;
  }

  public String getEndpointBasicAuthUserDev1() {
    return endpointBasicAuthUserDev1;
  }

  public void setEndpointBasicAuthUserDev1(String endpointBasicAuthUserDev1) {
    this.endpointBasicAuthUserDev1 = endpointBasicAuthUserDev1;
  }

  public String getEndpointBasicAuthPwDev1() {
    return endpointBasicAuthPwDev1;
  }

  public void setEndpointBasicAuthPwDev1(String endpointBasicAuthPwDev1) {
    this.endpointBasicAuthPwDev1 = endpointBasicAuthPwDev1;
  }

  public String getEndpointBasicAuthUserDev2() {
    return endpointBasicAuthUserDev2;
  }

  public void setEndpointBasicAuthUserDev2(String endpointBasicAuthUserDev2) {
    this.endpointBasicAuthUserDev2 = endpointBasicAuthUserDev2;
  }

  public String getEndpointBasicAuthPwDev2() {
    return endpointBasicAuthPwDev2;
  }

  public void setEndpointBasicAuthPwDev2(String endpointBasicAuthPwDev2) {
    this.endpointBasicAuthPwDev2 = endpointBasicAuthPwDev2;
  }

  public String getEndpointBasicAuthUserDev3() {
    return endpointBasicAuthUserDev3;
  }

  public void setEndpointBasicAuthUserDev3(String endpointBasicAuthUserDev3) {
    this.endpointBasicAuthUserDev3 = endpointBasicAuthUserDev3;
  }

  public String getEndpointBasicAuthPwDev3() {
    return endpointBasicAuthPwDev3;
  }

  public void setEndpointBasicAuthPwDev3(String endpointBasicAuthPwDev3) {
    this.endpointBasicAuthPwDev3 = endpointBasicAuthPwDev3;
  }

  public String getEndpointBasicAuthUserDev4() {
    return endpointBasicAuthUserDev4;
  }

  public void setEndpointBasicAuthUserDev4(String endpointBasicAuthUserDev4) {
    this.endpointBasicAuthUserDev4 = endpointBasicAuthUserDev4;
  }

  public String getEndpointBasicAuthPwDev4() {
    return endpointBasicAuthPwDev4;
  }

  public void setEndpointBasicAuthPwDev4(String endpointBasicAuthPwDev4) {
    this.endpointBasicAuthPwDev4 = endpointBasicAuthPwDev4;
  }

  public String getOauthGrantType() {
    return oauthGrantType;
  }

  public void setOauthGrantType(String oauthGrantType) {
    this.oauthGrantType = oauthGrantType;
  }

  public String getOauthGrantLocation() {
    return oauthGrantLocation;
  }

  public void setOauthGrantLocation(String oauthGrantLocation) {
    this.oauthGrantLocation = oauthGrantLocation;
  }

  public String getOauthTokenServiceHost() {
    return oauthTokenServiceHost;
  }

  public void setOauthTokenServiceHost(String oauthTokenServiceHost) {
    this.oauthTokenServiceHost = oauthTokenServiceHost;
  }

  public String getOauthTokenServiceURI() {
    return oauthTokenServiceURI;
  }

  public void setOauthTokenServiceURI(String oauthTokenServiceURI) {
    this.oauthTokenServiceURI = oauthTokenServiceURI;
  }

  public String getOauthClientId() {
    return oauthClientId;
  }

  public void setOauthClientId(String oauthClientId) {
    this.oauthClientId = oauthClientId;
  }

  public String getOauthClientIdLocation() {
    return oauthClientIdLocation;
  }

  public void setOauthClientIdLocation(String oauthClientIdLocation) {
    this.oauthClientIdLocation = oauthClientIdLocation;
  }

  public String getOauthSecret() {
    return oauthSecret;
  }

  public void setOauthSecret(String oauthSecret) {
    this.oauthSecret = oauthSecret;
  }

  public String getOauthScope() {
    return oauthScope;
  }

  public void setOauthScope(String oauthScope) {
    this.oauthScope = oauthScope;
  }

  public String getOauthScopeLocation() {
    return oauthScopeLocation;
  }

  public void setOauthScopeLocation(String oauthScopeLocation) {
    this.oauthScopeLocation = oauthScopeLocation;
  }

  public String getOauthUserName() {
    return oauthUserName;
  }

  public void setOauthUserName(String oauthUserName) {
    this.oauthUserName = oauthUserName;
  }

  public String getOauthpw() {
    return oauthpw;
  }

  public void setOauthpw(String oauthpw) {
    this.oauthpw = oauthpw;
  }

  public String getOauthCredentialsLocation() {
    return oauthCredentialsLocation;
  }

  public void setOauthCredentialsLocation(String oauthCredentialsLocation) {
    this.oauthCredentialsLocation = oauthCredentialsLocation;
  }

  public String getPingUrl() {
    return pingUrl;
  }

  public void setPingUrl(String pingUrl) {
    this.pingUrl = pingUrl;
  }

  public String getDocumentationUrl() {
    return documentationUrl;
  }

  public void setDocumentationUrl(String documentationUrl) {
    this.documentationUrl = documentationUrl;
  }

  public String getActive() {
    return active;
  }

  public void setActive(String active) {
    this.active = active;
  }

  public String getJwtSubject() {
    return jwtSubject;
  }

  public void setJwtSubject(String jwtSubject) {
    this.jwtSubject = jwtSubject;
  }

  public String getX509CertAlias() {
    return x509CertAlias;
  }

  public void setX509CertAlias(String x509CertAlias) {
    this.x509CertAlias = x509CertAlias;
  }

  public String getThreatProtectionOverrides() {
    return threatProtectionOverrides;
  }

  public void setThreatProtectionOverrides(String threatProtectionOverrides) {
    this.threatProtectionOverrides = threatProtectionOverrides;
  }

  public String getB2bAuthRequired() {
    return b2bAuthRequired;
  }

  public void setB2bAuthRequired(String b2bAuthRequired) {
    this.b2bAuthRequired = b2bAuthRequired;
  }

  public String getB2bCustomerNumberRequired() {
    return b2bCustomerNumberRequired;
  }

  public void setB2bCustomerNumberRequired(String b2bCustomerNumberRequired) {
    this.b2bCustomerNumberRequired = b2bCustomerNumberRequired;
  }

  public String getB2bBillingAccountNumberRequired() {
    return b2bBillingAccountNumberRequired;
  }

  public void setB2bBillingAccountNumberRequired(String b2bBillingAccountNumberRequired) {
    this.b2bBillingAccountNumberRequired = b2bBillingAccountNumberRequired;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public String getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(String createdDate) {
    this.createdDate = createdDate;
  }

  public String getUpdatedBy() {
    return updatedBy;
  }

  public void setUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
  }

  public String getUpdatedDate() {
    return updatedDate;
  }

  public void setUpdatedDate(String updatedDate) {
    this.updatedDate = updatedDate;
  }

  public String getGuid() {
    return guid;
  }

  public void setGuid(String guid) {
    this.guid = guid;
  }

  public String getMediatedResourceId() {
    return mediatedResourceId;
  }

  public void setMediatedResourceId(String mediatedResourceId) {
    this.mediatedResourceId = mediatedResourceId;
  }

  public String getRequestorEmail() {
    return requestorEmail;
  }

  public void setRequestorEmail(String requestorEmail) {
    this.requestorEmail = requestorEmail;
  }

  public String getSource() {
    return source;
  }

  public void setSource(String source) {
    this.source = source;
  }

  public String getThrottlingRequestsPerSec() {
    return throttlingRequestsPerSec;
  }

  public void setThrottlingRequestsPerSec(String throttlingRequestsPerSec) {
    this.throttlingRequestsPerSec = throttlingRequestsPerSec;
  }

  public String getTimeoutSecs() {
    return timeoutSecs;
  }

  public void setTimeoutSecs(String timeoutSecs) {
    this.timeoutSecs = timeoutSecs;
  }

  public String getConnectionKeepAlive() {
    return connectionKeepAlive;
  }

  public void setConnectionKeepAlive(String connectionKeepAlive) {
    this.connectionKeepAlive = connectionKeepAlive;
  }

  public String getReplaceUrlFromValue() {
    return replaceUrlFromValue;
  }

  public void setReplaceUrlFromValue(String replaceUrlFromValue) {
    this.replaceUrlFromValue = replaceUrlFromValue;
  }

  public String getReplaceUrlToValue() {
    return replaceUrlToValue;
  }

  public void setReplaceUrlToValue(String replaceUrlToValue) {
    this.replaceUrlToValue = replaceUrlToValue;
  }

  public String getEnforceHttps() {
    return enforceHttps;
  }

  public void setEnforceHttps(String enforceHttps) {
    this.enforceHttps = enforceHttps;
  }

  public String getSecurityRequestNumber() {
    return securityRequestNumber;
  }

  public void setSecurityRequestNumber(String securityRequestNumber) {
    this.securityRequestNumber = securityRequestNumber;
  }

  public String getElementType() {
    return elementType;
  }
  
  public void setElementType(String elementType) {
    this.elementType = elementType;
  }

  public List<String> getAdmins() {
    return admins;
  }
  
  public void setAdmins(List<String> admins) {
    this.admins = admins;
  }
  
  public List<String> getOwners() {
    return owners;
  }
  
  public void setOwners(List<String> owners) {
    this.owners = owners;
  }

  public String toString() {
    String mystring;
    mystring = "env: " + getEnv() + "\n" + "taxonomy: " + getTaxonomy() + "\n" + "resourceName: "
      + getResourceName() + "\n" + "version: " + getVersion() + "\n" + "routingExpression: " + getRoutingExpression()
      + "\n" + "soap: " + getSoap() + "\n" + "type: " + getType() + "\n" + "owningAppAppkey: " + getOwningAppAppkey()
      + "\n" + "malId: " + getMalId() + "\n" + "dev1EndpointHostname: " + getDev1EndpointHostname() + "\n" 
      + "dev2EndpointHostname: " + getDev2EndpointHostname() + "\n" + "dev3EndpointHostname: "
      + getDev3EndpointHostname() + "\n" + "dev4EndpointHostname: " + getDev4EndpointHostname() + "\n" 
      + "test1EndpointHostname: " + getTest1EndpointHostname() + "\n" + "test2EndpointHostname: " 
      + getTest2EndpointHostname() + "\n" + "test3EndpointHostname: " + getTest3EndpointHostname() + "\n" 
      + "test4EndpointHostname: " + getTest4EndpointHostname() + "\n" + "mockEndpointHostname: " 
      + getMockEndpointHostname() + "\n" + "sandbox4EndpointHostname: " + getSandboxEndpointHostname() + "\n" 
      + "prodEndpointHostname: " + getProdEndpointHostname() + "\n" + "endpointPath: " + getEndpointPath() + "\n" 
      + "internal: " + getInternal() + "\n" + "external: " + getExternal() + "\n" + "proxyAuthInternal: " 
      + getProxyAuthInternal() + "\n" + "proxyAuthExternal: " + getProxyAuthExternal() + "\n" + "appkeyEnforceDigest:"
      + getAppkeyEnforceDigest() + "\n" + "appkeyEnforceTaxonomy: " + getAppkeyEnforceTaxonomy() + "\n" 
      + "basicAuthGroups: " + getBasicAuthGroups() + "\n" + "basicAuthUsers: " + getBasicAuthUsers() + "\n" 
      + "endpointAuth: " + getEndpointAuth() + "\n" + "endpointBasicAuthUserAll: " + getEndpointBasicAuthUserAll()
      + "\n" + "endpointBasicAuthPwAll: " + getEndpointBasicAuthPwAll() + "\n" + "endpointBasicAuthUserDev1: "
      + getEndpointBasicAuthUserDev1() + "\n" + "endpointBasicAuthPwDev1: " + getEndpointBasicAuthPwDev1() + "\n"
      + "endpointBasicAuthUserDev2: " + getEndpointBasicAuthUserDev2() + "\n" + "endpointBasicAuthPwDev2: "
      + getEndpointBasicAuthPwDev2() + "\n" + "endpointBasicAuthUserDev3: " + getEndpointBasicAuthUserDev3() + "\n"
      + "endpointBasicAuthPwDev3: " + getEndpointBasicAuthPwDev3() + "\n" + "endpointBasicAuthUserDev4: "
      + getEndpointBasicAuthUserDev4() + "\n" + "endpointBasicAuthPwDev4: " + getEndpointBasicAuthPwDev4() + "\n"
      + "oauthGrantType: " + getOauthGrantType() + "\n" + "oauthGrantLocation: " + getOauthGrantLocation() + "\n"
      + "oauthTokenServiceHost: " + getOauthTokenServiceHost() + "\n" + "oauthTokenServiceURI: "
      + getOauthTokenServiceURI() + "\n" + "oauthClientId: " + getOauthClientId() + "\n" + "oauthClientIdLocation: "
      + getOauthClientIdLocation() + "\n" + "oauthSecret: " + getOauthSecret() + "\n" + "oauthScope: "
      + getOauthScope() + "\n" + "oauthScopeLocation: " + getOauthScopeLocation() + "\n" + "oauthUserName: "
      + getOauthUserName() + "\n" + "oauthpw: " + getOauthpw() + "\n" + "oauthCredentialsLocation: "
      + getOauthCredentialsLocation() + "\n" + "pingUrl: " + getPingUrl() + "\n" + "documentationUrl: "
      + getDocumentationUrl() + "\n" + "active: " + getActive() + "\n" + "jwtSubject: " + getJwtSubject() + "\n"
      + "x509CertAlias: " + getX509CertAlias() + "\n" + "threatProtectionOverrides: " + getThreatProtectionOverrides()
      + "\n" + "b2bAuthRequired: " + getB2bAuthRequired() + "\n" + "b2bCustomerNumberRequired: "
      + getB2bCustomerNumberRequired() + "\n" + "b2bBillingAccountNumberRequired: "
      + getB2bBillingAccountNumberRequired() + "\n" + "createdBy: " + getCreatedBy() + "\n" + "createdDate: "
      + getCreatedDate() + "\n" + "updatedBy: " + getUpdatedBy() + "\n" + "updatedDate: " + getUpdatedDate() + "\n"
      + "guid: " + getGuid() + "\n" + "mediatedResourceId: " + getMediatedResourceId() + "\n" + "requestorEmail: "
      + getRequestorEmail() + "\n" + "source: " + getSource() + "\n" + "securityRequestNumber: "
      + getSecurityRequestNumber() + "\n" + "element_type:" + getElementType() + "\n" + "admins:" + getAdmins() + "\n"
      + "owners:" + getOwners() + "\n";
    return mystring;
  }
  
  private static final String COMMA_BR = ",<br>";

  public String toEmailString() {
    String mystring;
    mystring = "<br><br>{<br>" + " \"env\" : " + "\"" + getEnv() + "\"" + COMMA_BR 
      + " \"taxonomy\" : " + "\"" + getTaxonomy() + "\"" + COMMA_BR + " \"resourceName\" : " + "\""
      + getResourceName() + "\"" + COMMA_BR + " \"version\" : " + "\"" + getVersion() + "\"" + COMMA_BR 
      + " \"routingExpression\" : " + "\"" + getRoutingExpression() + "\"" + COMMA_BR + " \"soap\" : "
      + "\"" + getSoap() + "\"" + COMMA_BR + " \"type\" : " + "\"" + getType() + "\"" + COMMA_BR
      + " \"owningAppAppkey\" : " + "\"" + getOwningAppAppkey() + "\"" + COMMA_BR + " \"malId\" : " + "\""
      + getMalId() + "\"" + COMMA_BR + " \"dev1EndpointHostname\" : " + "\"" + getDev1EndpointHostname() + "\"" 
      + COMMA_BR + " \"dev2EndpointHostname\" : " + "\"" + getDev2EndpointHostname() + "\"" + COMMA_BR 
      + " \"dev3EndpointHostname\" : " + "\"" + getDev3EndpointHostname() + "\"" + COMMA_BR 
      + " \"dev4EndpointHostname\" : " + "\"" + getDev4EndpointHostname() + "\"" + COMMA_BR 
      + " \"test1EndpointHostname\" : " + "\"" + getTest1EndpointHostname() + "\"" + COMMA_BR 
      + " \"test2EndpointHostname\" : " + "\"" + getTest2EndpointHostname() + "\"" + COMMA_BR 
      + " \"test3EndpointHostname\" : " + "\"" + getTest3EndpointHostname() + "\"" + COMMA_BR
      + " \"test4EndpointHostname\" : " + "\"" + getTest4EndpointHostname() + "\"" + COMMA_BR
      + " \"mockEndpointHostname\" : " + "\"" + getMockEndpointHostname() + "\"" + COMMA_BR 
      + " \"sandboxEndpointHostname\" : " + "\"" + getSandboxEndpointHostname() + "\"" + COMMA_BR
      + " \"prodEndpointHostname\" : " + "\"" + getProdEndpointHostname() + "\"" + COMMA_BR
      + " \"endpointPath\" : " + "\"" + getEndpointPath() + "\"" + COMMA_BR + " \"internal\" : "
      + "\"" + getInternal() + "\"" + COMMA_BR + " \"external\" : " + "\"" + getExternal() + "\"" + COMMA_BR
      + " \"proxyAuthInternal\" : " + "\"" + getProxyAuthInternal() + "\"" + COMMA_BR
      + " \"proxyAuthExternal\" : " + "\"" + getProxyAuthExternal() + "\"" + COMMA_BR
      + " \"appkeyEnforceDigest\" : " + "\"" + getAppkeyEnforceDigest() + "\"" + COMMA_BR
      + " \"appkeyEnforceTaxonomy\" : " + "\"" + getAppkeyEnforceTaxonomy() + "\"" + COMMA_BR
      + " \"basicAuthGroups\" : " + "\"" + getBasicAuthGroups() + "\"" + COMMA_BR
      + " \"basicAuthUsers\" : " + "\"" + getBasicAuthUsers() + "\"" + COMMA_BR
      + " \"endpointAuth\" : " + "\"" + getEndpointAuth() + "\"" + COMMA_BR
      + " \"endpointBasicAuthUserAll\" : " + "\"" + getEndpointBasicAuthUserAll() + "\"" + COMMA_BR
      + " \"endpointBasicAuthPwAll\" : " + "\"" + getEndpointBasicAuthPwAll() + "\"" + COMMA_BR
      + " \"endpointBasicAuthUserDev1\" : " + "\"" + getEndpointBasicAuthUserDev1() + "\"" + COMMA_BR
      + " \"endpointBasicAuthPwDev1\" : " + "\"" + getEndpointBasicAuthPwDev1() + "\"" + COMMA_BR
      + " \"endpointBasicAuthUserDev2\" : " + "\"" + getEndpointBasicAuthUserDev2() + "\"" + COMMA_BR
      + " \"endpointBasicAuthPwDev2\" : " + "\"" + getEndpointBasicAuthPwDev2() + "\"" + COMMA_BR
      + " \"endpointBasicAuthUserDev3\" : " + "\"" + getEndpointBasicAuthUserDev3() + "\"" + COMMA_BR
      + " \"endpointBasicAuthPwDev3\" : " + "\"" + getEndpointBasicAuthPwDev3() + "\"" + COMMA_BR
      + " \"endpointBasicAuthUserDev4\" : " + "\"" + getEndpointBasicAuthUserDev4() + "\"" + COMMA_BR
      + " \"endpointBasicAuthPwDev4\" : " + "\"" + getEndpointBasicAuthPwDev4() + "\"" + COMMA_BR
      + " \"oauthGrantType\" : " + "\"" + getOauthGrantType() + "\"" + COMMA_BR
      + " \"oauthGrantLocation\" : " + "\"" + getOauthGrantLocation() + "\"" + COMMA_BR
      + " \"oauthTokenServiceHost\" : " + "\"" + getOauthTokenServiceHost() + "\"" + COMMA_BR
      + " \"oauthTokenServiceURI\" : " + "\"" + getOauthTokenServiceURI() + "\"" + COMMA_BR
      + " \"oauthClientId\" : " + "\"" + getOauthClientId() + "\"" + COMMA_BR
      + " \"oauthClientIdLocation\" : " + "\"" + getOauthClientIdLocation() + "\"" + COMMA_BR
      + " \"oauthSecret\" : " + "\"" + getOauthSecret() + "\"" + COMMA_BR
      + " \"oauthScope\" : " + "\"" + getOauthScope() + "\"" + COMMA_BR
      + " \"oauthScopeLocation\" : " + "\"" + getOauthScopeLocation() + "\"" + COMMA_BR
      + " \"oauthUserName\" : " + "\"" + getOauthUserName() + "\"" + COMMA_BR
      + " \"oauthpw\" : " + "\"" + getOauthpw() + "\"" + COMMA_BR
      + " \"oauthCredentialsLocation\" : " + "\"" + getOauthCredentialsLocation() + "\"" + COMMA_BR
      + " \"pingUrl\" : " + "\"" + getPingUrl() + "\"" + COMMA_BR
      + " \"documentationUrl\" : " + "\"" + getDocumentationUrl() + "\"" + COMMA_BR
      + " \"active\" : " + "\"" + getActive() + "\"" + COMMA_BR
      + " \"jwtSubject\" : " + "\"" + getJwtSubject() + "\"" + COMMA_BR
      + " \"x509CertAlias\" : " + "\"" + getX509CertAlias() + "\"" + COMMA_BR
      + " \"threatProtectionOverrides\" : " + "\"" + getThreatProtectionOverrides() + "\"" + COMMA_BR
      + " \"b2bAuthRequired\" : " + "\"" + getB2bAuthRequired() + "\"" + COMMA_BR
      + " \"b2bCustomerNumberRequired\" : " + "\"" + getB2bCustomerNumberRequired() + "\"" + COMMA_BR
      + " \"b2bBillingAccountNumberRequired\" : " + "\"" + getB2bBillingAccountNumberRequired() + "\"" + COMMA_BR
      + " \"createdBy\" : " + "\"" + getCreatedBy() + "\"" + COMMA_BR
      + " \"createdDate\" : " + "\"" + getCreatedDate() + "\"" + COMMA_BR
      + " \"updatedBy\" : " + "\"" + getUpdatedBy() + "\"" + COMMA_BR
      + " \"updatedDate\" : " + "\"" + getUpdatedDate() + "\"" + COMMA_BR
      + " \"guid\" : " + "\"" + getGuid() + "\"" + COMMA_BR
      + " \"mediatedResourceId\" : " + "\"" + getMediatedResourceId() + "\"" + COMMA_BR
      + " \"requestorEmail\" : " + "\"" + getRequestorEmail() + "\"" + "<br>"
      + " \"source\" : " + "\"" + getSource() + "\"" + "<br>"
      + " \"securityRequestNumber\" : " + "\"" + getSecurityRequestNumber() + "\"" + "<br>"
      + " \"element_type\" : " + "\"" + getElementType() + "\"" + "<br>"
      + " \"admins\" : " + "\"" + getAdmins() + "\"" + "<br>"
      + " \"owners\" : " + "\"" + getOwners() + "\"" + "<br>"
      + "}";
    return mystring;
  }

}
