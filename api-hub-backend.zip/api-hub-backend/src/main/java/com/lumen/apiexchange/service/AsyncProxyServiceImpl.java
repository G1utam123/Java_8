package com.lumen.apiexchange.service;

import com.lumen.apiexchange.client.ESPClient;
import com.lumen.apiexchange.config.MediationResourceConfigProperties;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.PartnerProxyBuildException;
import com.lumen.apiexchange.exception.PartnerProxyDeployException;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.model.ApiMediatedResponse;
import com.lumen.apiexchange.model.AsyncBuildDeployResult;
import com.lumen.apiexchange.model.BuildDeployResult;
import com.lumen.apiexchange.model.InputApiRequest;
import java.util.ArrayList;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

@Service
@RequiredArgsConstructor
@Slf4j
public class AsyncProxyServiceImpl implements AsyncProxyService {

  private final ESPClient espClient;
  private final MediationResourceConfigProperties mediationResourceConfigProp;
  private final BuildServiceImpl buildServiceImpl;
  private final DeployServiceImpl deployServiceImpl;
  
  private static final String INTERNAL = "internal";
  private static final String EXTERNAL = "external";

  @Override
  @Async
  public CompletableFuture<ApiMediatedResource> getApiProxyEnvDetails(String resourceGuid, String host)
      throws InternalServerException {

    String url = constructUrl(host, resourceGuid);
    log.info("Getting details for proxy '{}' on host '{}' ...", resourceGuid, host);

    ApiMediatedResource apiProxyEnvDetails = espClient.getApiProxyEnvDetails(resourceGuid, url);

    return CompletableFuture.completedFuture(apiProxyEnvDetails);
  }
 
  @Override
  @Async
  public CompletableFuture<ApiMediatedResource> getApiProxyDetails(String env, String taxonomy, String resourceName,
      String version) {

    ApiMediatedResponse espResponse = espClient.getApiProxies(env, taxonomy, resourceName, version);
    ApiMediatedResource espResource = null;
    if (espResponse != null && espResponse.getMediatedResource() != null 
        && !espResponse.getMediatedResource().isEmpty() && espResponse.getMediatedResource().size() > 0) {
      espResource = espResponse.getMediatedResource().get(0);
    }
    
    return CompletableFuture.completedFuture(espResource);
  }
  
  @Override
  @Async
  public CompletableFuture<AsyncBuildDeployResult> buildDeployApi(InputApiRequest inputapirequest) {
    AsyncBuildDeployResult asyncBuildDeployResult = AsyncBuildDeployResult.builder()
        .proxyBuiltInEnvironments("")
        .proxyNotBuiltInEnvironments("")
        .proxyDeployedToEnvironments(new ArrayList<>())
        .proxyNotDeployedToEnvironments(new ArrayList<>())
        .build();
    String mediatedResourceId = buildServiceImpl.buildProxy(inputapirequest);
    if (StringUtils.isNotEmpty(mediatedResourceId)) {
      asyncBuildDeployResult.setProxyBuiltInEnvironments(inputapirequest.getEnv());
      inputapirequest.setMediatedResourceId(mediatedResourceId);
      
      //deploy APIs
      if (inputapirequest.getInternal() != null && inputapirequest.getInternal().equalsIgnoreCase("true")) {
        //deploy internal
        asyncBuildDeployResult = deployServiceImpl.deployProxy(inputapirequest, INTERNAL, asyncBuildDeployResult);
      }
      
      if (inputapirequest.getExternal() != null && inputapirequest.getExternal().equalsIgnoreCase("true")) {
        //deploy external
        asyncBuildDeployResult = deployServiceImpl.deployProxy(inputapirequest, EXTERNAL, asyncBuildDeployResult);
      } 
      
    } else {
      asyncBuildDeployResult.setProxyNotBuiltInEnvironments(inputapirequest.getEnv());
      asyncBuildDeployResult.getProxyNotDeployedToEnvironments().add(inputapirequest.getEnv());
    }
    
    return CompletableFuture.completedFuture(asyncBuildDeployResult);
  }

  private String constructUrl(String host, String resourceGuid) {
    Optional<String> env = Optional.empty();
    if (host.contains("mock")) {
      env = Optional.of("mock");
      host = mediationResourceConfigProp.getHostnameProd();
    } else if (host.contains("sandbox")) {
      env = Optional.of("sandbox");
      host = mediationResourceConfigProp.getHostnameProd();
    }
    String thisUrl = UriComponentsBuilder
        .fromUriString(host + mediationResourceConfigProp.getMediationResourceUri())
        .queryParamIfPresent("environment", env)
        .queryParam("resourceGuid", resourceGuid).build().toUriString();

    return thisUrl;

  }
  
  @Override
  @Async
  public void buildDeployAsync(InputApiRequest inputapirequest, BuildDeployResult buildDeployResult) {
    CompletableFuture<AsyncBuildDeployResult> asyncBuildDeployResult = buildDeployApi(inputapirequest);
    if (asyncBuildDeployResult != null) {
      if (!asyncBuildDeployResult.join().getProxyNotBuiltInEnvironments().isEmpty()) {
        throw new PartnerProxyBuildException("Partner Proxy Build Failed\n"
            + "Request:\n" + inputapirequest);
      } else if (!asyncBuildDeployResult.join().getProxyNotDeployedToEnvironments().isEmpty()) {
        throw new PartnerProxyDeployException("Partner Proxy Deploy Failed\n"
            + "Request:\n" + inputapirequest);
      }
    } else {
      throw new PartnerProxyBuildException("Partner Proxy Build Failed\n"
          + "Request:\n" + inputapirequest);
    }
  }
}
