package com.lumen.apiexchange.model;

public class ApiHomeRequest {

  private int id;
  private String apiName;
  private String description;
  private String type;
  private String category;
  private String status;
  private String version;
  private String oasUrl;
  private String sourceCodeUrl;


  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getApiName() {
    return apiName;
  }

  public void setApiName(String apiName) {
    this.apiName = apiName;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public String getOasUrl() {
    return oasUrl;
  }

  public void setOasUrl(String oasUrl) {
    this.oasUrl = oasUrl;
  }

  public String getSourceCodeUrl() {
    return sourceCodeUrl;
  }

  public void setSourceCodeUrl(String sourceCodeUrl) {
    this.sourceCodeUrl = sourceCodeUrl;
  }

  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }



}
