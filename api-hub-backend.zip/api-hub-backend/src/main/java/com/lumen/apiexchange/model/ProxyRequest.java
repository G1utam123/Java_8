package com.lumen.apiexchange.model;

public class ProxyRequest {
  private String taxonomy;
  private String resourceName;
  private String version;
  private String soap;
  private String type;
  private String owningAppAppkey;
  private String malId;
  private String dev1EndpointHostname;
  private String dev2EndpointHostname;
  private String dev3EndpointHostname;
  private String dev4EndpointHostname;
  private String endpointPath;
  private String internal;
  private String external;
  private String proxyAuthInternal;
  private String proxyAuthExternal;
  private String appkeyEnforceDigest;
  private String appkeyEnforceTaxonomy;
  private String basicAuthGroups;
  private String basicAuthUsers;
  private String endpointAuth;
  private String endpointBasicAuthUserAll;
  private String endpointBasicAuthPwAll;
  private String oauthGrantType;
  private String oauthGrantLocation;
  private String oauthTokenServiceHost;
  private String oauthTokenServiceURI;
  private String oauthClientId;
  private String oauthClientIdLocation;
  private String oauthSecret;
  private String oauthScopeLocation;
  private String oauthUserName;
  private String oauthpw;
  private String oauthCredentialsLocation;
  private String x509CertAlias;
  private String requestorEmail;

  public String getTaxonomy() {
    return taxonomy;
  }

  public void setTaxonomy(final String taxonomy) {
    this.taxonomy = taxonomy;
  }

  public String getResourceName() {
    return resourceName;
  }

  public void setResourceName(final String resourceName) {
    this.resourceName = resourceName;
  }

  public String getVersion() {
    return version;
  }

  public void setVersion(final String version) {
    this.version = version;
  }

  public String getSoap() {
    return soap;
  }

  public void setSoap(final String soap) {
    this.soap = soap;
  }

  public String getType() {
    return type;
  }

  public void setType(final String type) {
    this.type = type;
  }

  public String getOwningAppAppkey() {
    return owningAppAppkey;
  }

  public void setOwningAppAppkey(final String owningAppAppkey) {
    this.owningAppAppkey = owningAppAppkey;
  }

  public String getMalId() {
    return malId;
  }

  public void setMalId(final String malId) {
    this.malId = malId;
  }

  public String getDev1EndpointHostname() {
    return dev1EndpointHostname;
  }


  public void setDev1EndpointHostname(
      final String dev1EndpointHostname) {
    this.dev1EndpointHostname = dev1EndpointHostname;
  }


  public String getDev2EndpointHostname() {
    return dev2EndpointHostname;
  }

  public void setDev2EndpointHostname(
      final String dev2EndpointHostname) {
    this.dev2EndpointHostname = dev2EndpointHostname;
  }

  public String getDev3EndpointHostname() {
    return dev3EndpointHostname;
  }

  public void setDev3EndpointHostname(
      final String dev3EndpointHostname) {
    this.dev3EndpointHostname = dev3EndpointHostname;
  }

  public String getDev4EndpointHostname() {
    return dev4EndpointHostname;
  }

  public void setDev4EndpointHostname(
      final String dev4EndpointHostname) {
    this.dev4EndpointHostname = dev4EndpointHostname;
  }

  public String getEndpointPath() {
    return endpointPath;
  }

  public void setEndpointPath(final String endpointPath) {
    this.endpointPath = endpointPath;
  }

  public String getInternal() {
    return internal;
  }

  public void setInternal(final String internal) {
    this.internal = internal;
  }

  public String getExternal() {
    return external;
  }

  public void setExternal(final String external) {
    this.external = external;
  }

  public String getProxyAuthInternal() {
    return proxyAuthInternal;
  }

  public void setProxyAuthInternal(final String proxyAuthInternal) {
    this.proxyAuthInternal = proxyAuthInternal;
  }

  public String getProxyAuthExternal() {
    return proxyAuthExternal;
  }

  public void setProxyAuthExternal(final String proxyAuthExternal) {
    this.proxyAuthExternal = proxyAuthExternal;
  }

  public String getAppkeyEnforceDigest() {
    return appkeyEnforceDigest;
  }

  public void setAppkeyEnforceDigest(final String appkeyEnforceDigest) {
    this.appkeyEnforceDigest = appkeyEnforceDigest;
  }

  public String getAppkeyEnforceTaxonomy() {
    return appkeyEnforceTaxonomy;
  }

  public void setAppkeyEnforceTaxonomy(
      final String appkeyEnforceTaxonomy) {
    this.appkeyEnforceTaxonomy = appkeyEnforceTaxonomy;
  }


  public String getBasicAuthGroups() {
    return basicAuthGroups;
  }

  public void setBasicAuthGroups(final String basicAuthGroups) {
    this.basicAuthGroups = basicAuthGroups;
  }

  public String getBasicAuthUsers() {
    return basicAuthUsers;
  }

  public void setBasicAuthUsers(final String basicAuthUsers) {
    this.basicAuthUsers = basicAuthUsers;
  }

  public String getEndpointAuth() {
    return endpointAuth;
  }

  public void setEndpointAuth(final String endpointAuth) {
    this.endpointAuth = endpointAuth;
  }

  public String getEndpointBasicAuthUserAll() {
    return endpointBasicAuthUserAll;
  }

  public void setEndpointBasicAuthUserAll(
      final String endpointBasicAuthUserAll) {

    this.endpointBasicAuthUserAll = endpointBasicAuthUserAll;
  }

  public String getEndpointBasicAuthPwAll() {
    return endpointBasicAuthPwAll;
  }

  public void setEndpointBasicAuthPwAll(final String endpointBasicAuthPwAll) {
    this.endpointBasicAuthPwAll = endpointBasicAuthPwAll;
  }

  public String getOauthGrantType() {
    return oauthGrantType;
  }

  public void setOauthGrantType(final String oauthGrantType) {
    this.oauthGrantType = oauthGrantType;
  }

  public String getOauthGrantLocation() {
    return oauthGrantLocation;
  }

  public void setOauthGrantLocation(final String oauthGrantLocation) {
    this.oauthGrantLocation = oauthGrantLocation;
  }

  public String getOauthTokenServiceHost() {
    return oauthTokenServiceHost;
  }

  public void setOauthTokenServiceHost(
      final String oauthTokenServiceHost) {
    this.oauthTokenServiceHost = oauthTokenServiceHost;
  }

  public String getOauthTokenServiceURI() {
    return oauthTokenServiceURI;
  }

  public void setOauthTokenServiceURI(
      final String oauthTokenServiceURI) {
    this.oauthTokenServiceURI = oauthTokenServiceURI;
  }

  public String getOauthClientId() {
    return oauthClientId;
  }

  public void setOauthClientId(final String oauthClientId) {
    this.oauthClientId = oauthClientId;
  }

  public String getOauthClientIdLocation() {
    return oauthClientIdLocation;
  }

  public void setOauthClientIdLocation(
      final String oauthClientIdLocation) {
    this.oauthClientIdLocation = oauthClientIdLocation;
  }

  public String getOauthSecret() {
    return oauthSecret;
  }

  public void setOauthSecret(final String oauthSecret) {
    this.oauthSecret = oauthSecret;
  }

  public String getOauthScopeLocation() {
    return oauthScopeLocation;
  }

  public void setOauthScopeLocation(final String oauthScopeLocation) {
    this.oauthScopeLocation = oauthScopeLocation;
  }

  public String getOauthUserName() {
    return oauthUserName;
  }

  public void setOauthUserName(String oauthUserName) {
    this.oauthUserName = oauthUserName;
  }

  public String getOauthpw() {
    return oauthpw;
  }

  public void setOauthpw(String oauthpw) {
    this.oauthpw = oauthpw;
  }

  public String getOauthCredentialsLocation() {
    return oauthCredentialsLocation;
  }

  public void setOauthCredentialsLocation(
      String oauthCredentialsLocation) {
    this.oauthCredentialsLocation = oauthCredentialsLocation;
  }

  public String getX509CertAlias() {
    return x509CertAlias;
  }

  public void setX509CertAlias(String x509CertAlias) {
    this.x509CertAlias = x509CertAlias;
  }

  public String getRequestorEmail() {
    return requestorEmail;
  }

  public void setRequestorEmail(String requestorEmail) {
    this.requestorEmail = requestorEmail;
  }

  @Override
  public String toString() {

    return "ProxyRequest [taxonomy=" + taxonomy + ", resourceName="
        + resourceName + ", version=" + version + ", soap=" + soap
        + ", type=" + type + ", owningAppAppkey=" + owningAppAppkey
        + ", malId=" + malId + ", dev1EndpointHostname="
        + dev1EndpointHostname + ", dev2EndpointHostname="
        + dev2EndpointHostname + ", dev3EndpointHostname="
        + dev3EndpointHostname + ", dev4EndpointHostname="
        + dev4EndpointHostname + ", endpointPath=" + endpointPath
        + ", internal=" + internal + ", external=" + external
        + ", proxyAuthInternal=" + proxyAuthInternal
        + ", proxyAuthExternal=" + proxyAuthExternal
        + ", appkeyEnforceDigest=" + appkeyEnforceDigest
        + ", appkeyEnforceTaxonomy=" + appkeyEnforceTaxonomy
        + ", basicAuthGroups=" + basicAuthGroups + ", basicAuthUsers="
        + basicAuthUsers + ", endpointAuth=" + endpointAuth
        + ", endpointBasicAuthUserAll=" + endpointBasicAuthUserAll
        + ", oauthGrantType=" + oauthGrantType + ", oauthGrantLocation="
        + oauthGrantLocation + ", oauthTokenServiceHost="
        + oauthTokenServiceHost + ", oauthTokenServiceURI="
        + oauthTokenServiceURI + ", oauthClientId=" + oauthClientId
        + ", oauthClientIdLocation=" + oauthClientIdLocation
        + ", oauthSecret=" + oauthSecret
        + ", oauthScopeLocation=" + oauthScopeLocation
        + ", oauthUserName=" + oauthUserName + ", oauthpw=" + oauthpw
        + ", oauthCredentialsLocation=" + oauthCredentialsLocation
        + ", requestorEmail=" + requestorEmail + "]";
  }

}
