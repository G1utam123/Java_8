package com.lumen.apiexchange.model.userprofile;


public class CreateUserRequest {

  private String email;
  private String firstName;
  private String lastName;
  private String userName;

  public CreateUserRequest() {

  }

  public CreateUserRequest(String email, String firstName, String lastName, String userName) {
    this.email = email;
    this.firstName = firstName;
    this.lastName = lastName;
    this.userName = userName;
  }

  public String getEmail() {
    return email;
  }

  public String getFirstName() {
    return firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public String getUserName() {
    return userName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  @Override
  public String toString() {
    return "CreateUserRequest [email=" + email + ", firstName=" + firstName + ", lastName=" + lastName + ", userName="
        + userName + "]";
  }

}
