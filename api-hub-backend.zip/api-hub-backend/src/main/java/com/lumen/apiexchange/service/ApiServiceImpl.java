package com.lumen.apiexchange.service;

import com.lumen.apiexchange.client.ESPClient;
import com.lumen.apiexchange.entity.ApiDocumentation;
import com.lumen.apiexchange.entity.ApiHomeDetails;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ApiHomeCategoryCollection;
import com.lumen.apiexchange.model.ApiHomeRequest;
import com.lumen.apiexchange.model.ApiMediatedResponse;
import com.lumen.apiexchange.repository.ApiDocumentationRepository;
import com.lumen.apiexchange.repository.ApiHomeRepository;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class ApiServiceImpl implements ApiService {

  protected static final Logger log = LoggerFactory.getLogger(ApiServiceImpl.class);
  private final ApiDocumentationRepository docRepository;
  private final ApiHomeRepository homeRepostory;
  private final ESPClient espClient;
  private final ProxyService proxyService;

  public ApiServiceImpl(ApiDocumentationRepository docRepository,
                        ApiHomeRepository homeRepostory, ESPClient espClient, ProxyService proxyService) {
    this.docRepository = docRepository;
    this.homeRepostory = homeRepostory;
    this.espClient = espClient;
    this.proxyService = proxyService;
  }


  @Override
  public List<ApiDocumentation> getApiDocumentation(UUID apiid) {
    log.info("Inside getAPIDocumentation with id " + apiid);
    List<ApiDocumentation> documentation = docRepository
        .findByApiId(apiid);
    if (!documentation.isEmpty()) {
      log.info("Not Null");

      return documentation;

    }

    return new ArrayList<ApiDocumentation>();
  }

  /**
   * @author ac38432
   */
  @Override
  public ApiHomeCategoryCollection getApiHomeDetails() {
    List<ApiHomeDetails> details = homeRepostory.findAll();
    return new ApiHomeCategoryCollection(details);
  }

  @Override
  public ApiDocumentation getApiDocumentationFile(final int id) {
    Optional<ApiDocumentation> docFile = docRepository.findById(id);

    if (docFile.isPresent()) {
      return docFile.get();
    }
    return null;

  }

  @Override
  public ApiDocumentation postApiDocumentation(
      ApiDocumentation apiDoc) {
    final int num = 100;
    int id = new SecureRandom().nextInt(num);
    apiDoc.setId(id);
    try {
      ApiDocumentation apiDocumentation = docRepository.save(apiDoc);
      return apiDocumentation;
    } catch (Exception e) {
      throw e;
    }
  }

  @Override
  public ApiDocumentation updateDocumentation(
      ApiDocumentation apidoc) {

    try {
      return docRepository.save(apidoc);
    } catch (Exception e) {
      throw e;
    }
  }

  public List<ApiDocumentation> updateSequence(List<ApiDocumentation> apidoc) {
    try {
      for (int i = 0; i < apidoc.size(); i++) {
        docRepository.save(apidoc.get(i));
      }
      return apidoc;
    } catch (Exception e) {
      throw e;
    }
  }

  @Override
  public void deleteDocumentation(final int id) {
    docRepository.deleteById(id);
  }

  @Override
  public ApiHomeDetails postNewApiDetail(ApiHomeRequest apiHomeRequestModel, String author) {

    final int num1 = 100;

    ApiHomeDetails apiDetail = new ApiHomeDetails();
    UUID createdUserId = UUID.randomUUID();
    apiDetail.setId(createdUserId);
    apiDetail.setName(apiHomeRequestModel.getApiName());
    apiDetail.setDescription(apiHomeRequestModel.getDescription());
    apiDetail.setCategory(apiHomeRequestModel.getCategory());
    apiDetail.setAuthor(author);
    apiDetail.setType(apiHomeRequestModel.getType());
    apiDetail.setStatus(apiHomeRequestModel.getStatus());
    apiDetail.setVersion(apiHomeRequestModel.getVersion());
    apiDetail.setCreatedDate(new Timestamp(System.currentTimeMillis()));
    apiDetail.setLastUpdatedDate(new Timestamp(System.currentTimeMillis()));
    apiDetail.setOasUrl(apiHomeRequestModel.getOasUrl());
    apiDetail.setSourceCodeUrl(apiHomeRequestModel.getSourceCodeUrl());

    homeRepostory.save(apiDetail);
    return apiDetail;

  }

  @Override
  public ApiHomeDetails updateApiDetails(UUID id, ApiHomeRequest apiHomeRequestModel, String author) {

    ApiHomeDetails apiDetails = homeRepostory.findById(id).get();

    apiDetails.setName(apiHomeRequestModel.getApiName());
    apiDetails.setCategory(apiHomeRequestModel.getCategory());
    apiDetails.setDescription(apiHomeRequestModel.getDescription());
    apiDetails.setType(apiHomeRequestModel.getType());
    apiDetails.setStatus(apiHomeRequestModel.getStatus());
    apiDetails.setVersion(apiHomeRequestModel.getVersion());
    apiDetails.setOasUrl(apiHomeRequestModel.getOasUrl());
    apiDetails.setSourceCodeUrl(apiHomeRequestModel.getSourceCodeUrl());
    apiDetails.setLastUpdatedDate(new Timestamp(System.currentTimeMillis()));

    return homeRepostory.save(apiDetails);
  }

  @Override
  public void deleteApiDetails(UUID apiid) throws InternalServerException {
    List<ApiDocumentation> apiDocumentationList = docRepository.findByApiId(apiid);
    if (!apiDocumentationList.isEmpty()) {
      List<Integer> ids = getIdFromApiDocList(apiDocumentationList);
      docRepository.deleteByApiIdIn(ids);
    }
    apiDocumentationList = docRepository.findByApiId(apiid);
    if (apiDocumentationList.isEmpty()) {
      homeRepostory.deleteById(apiid);
    }
    proxyService.deleteproxiesFromDbWithApiId(apiid);
  }

  @Override
  public ApiMediatedResponse getApiProxies() throws InternalServerException {
    return espClient.getApiProxies();
  }

  private List<Integer> getIdFromApiDocList(List<ApiDocumentation> apiDocumentationList) {
    List<Integer> docIds = new ArrayList<>();
    apiDocumentationList.forEach(apidoc -> docIds.add(apidoc.getId()));
    return docIds;
  }

}
