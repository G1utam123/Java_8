package com.lumen.apiexchange.service;

import com.lumen.apiexchange.api.partner.model.BasicAuth;
import com.lumen.apiexchange.api.partner.model.Error400Code;
import com.lumen.apiexchange.api.partner.model.OAuth20;
import com.lumen.apiexchange.api.partner.model.OAuth20.OauthClientIdLocationEnum;
import com.lumen.apiexchange.api.partner.model.OAuth20.OauthGrantLocationEnum;
import com.lumen.apiexchange.api.partner.model.OAuth20.OauthGrantTypeEnum;
import com.lumen.apiexchange.api.partner.model.OAuth20.OauthScopeLocationEnum;
import com.lumen.apiexchange.api.partner.model.PartnerEndpoint;
import com.lumen.apiexchange.api.partner.model.PartnerEndpoint.EnvironmentEnum;
import com.lumen.apiexchange.api.partner.model.PartnerProxy;
import com.lumen.apiexchange.api.partner.model.PartnerProxy.ProxyGatewayEnum;
import com.lumen.apiexchange.client.ESPClient;
import com.lumen.apiexchange.config.PartnerProxyConfigProperties;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.ForbiddenException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.NotFoundException;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.model.BuildDeployResult;
import com.lumen.apiexchange.model.InputApiRequest;
import com.lumen.apiexchange.model.apigee.ApigeeProduct;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.Planet;
import com.lumen.apiexchange.service.apigee.ApigeeProductsService;
import com.lumen.apiexchange.util.BuildHandler;
import java.io.IOException;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Service
@Slf4j
@RequiredArgsConstructor
public class PartnerProxyService {

  private final ESPClient espClient;
  private final ProxyService proxyService;
  private final ApigeeProductsService apigeeProductsService;
  private final PartnerProxyConfigProperties partnerProxyConfigProperties;
  private final BuildHandler buildHandler;
  private final BuildDeployServiceImpl buildDeployServiceImpl;
  private final AsyncPartnerProxyServiceImpl asyncPartnerProxyServiceImpl;
  private static final String ESP = "ESP";
  private static final String ESP_BASIC_AUTH = "basicAuth";
  private static final String ESP_ENV_PROD = "prod";
  private static final String ESP_ENV_TEST1 = "test1";
  private static final String ESP_INTERNAL_ERROR_REASON = "An internal server error occurred calling ESP";
  private static final String TAXONOMY_DOMAIN = "Partner/";

  public PartnerProxy createProxy(PartnerProxy partnerProxy, Jwt jwt) {

    log.debug("partnerProxy: {}", partnerProxy.toString());
    InputApiRequest espProxyRequest = buildInputApiRequest(partnerProxy);
    log.debug("espProxyRequest: {}", espProxyRequest.toString());
    
    try {
      BuildDeployResult buildDeployResult = proxyService.postProxyRequest(espProxyRequest, jwt);
      
      log.debug("Proxy {}/{} successfully accepted in {}. proxyGuid = {}", TAXONOMY_DOMAIN
          + partnerProxy.getPartnerName(), partnerProxy.getPartnerResource(), 
          partnerProxy.getPartnerEndpoint().getEnvironment().toString(), buildDeployResult.getGuid());

      partnerProxy.setProxyGuid(UUID.fromString(buildDeployResult.getGuid()));
      
      asyncPartnerProxyServiceImpl.asyncAddNewProxyToApiProduct(partnerProxy, buildDeployResult.getGuid());

    } catch (BadInputException e) {
      String reason = e.getMessage();
      String message = String.format("%s. Env: %s Proxy: Partner/%s/%s/%s", e.getMessage(), 
          partnerProxy.getPartnerEndpoint().getEnvironment().toString(), partnerProxy.getProxyVersion(),
          partnerProxy.getPartnerName(), partnerProxy.getPartnerResource());
      throw new BadInputException(Error400Code.INVALIDBODY, reason, message);
      
    } catch (ForbiddenException e) {
      String reason = "Forbidden";
      String message = e.getMessage();
      throw new ForbiddenException(reason, message);
      
    } catch (IOException e) {
      String reason = "Error creating proxy in ESP.";
      throw new InternalServerException(reason, reason);
    }
    
    return partnerProxy;
  }

  public PartnerProxy getPartnerProxy(String proxyGateway, String environment, UUID proxyGuid) {

    validateProxyGateway(proxyGateway);
    PartnerProxy partnerProxy = null;
    if (!ESP.equals(proxyGateway)) {
      return partnerProxy; 
    }

    ApiMediatedResource espResponse = getEspProxy(environment, proxyGuid);
    partnerProxy = transformEspResponseToPartnerProxy(espResponse, environment);
    
    return partnerProxy; 
  }
  
  public ApiMediatedResource getEspProxy(String environment, UUID proxyGuid) {
    
    String espEnv = validateAndTransformEnvironmentToEspEnv(environment);

    ApiMediatedResource espResource;
    try {
      espResource = espClient.getApiProxyEnvDetails(espEnv, proxyGuid);

    } catch (InternalServerException e) {
      String reason = ESP_INTERNAL_ERROR_REASON;
      throw new InternalServerException(reason, reason);
    }
    
    if (espResource == null) {
      String reason = "Partner proxy not found";
      String message = String.format("Partner proxy not found for proxyGuid %s in %s", proxyGuid, espEnv);
      throw new NotFoundException(reason, message);
    }
    
    log.info("Found proxyGuid: {} in Env: {}", proxyGuid, environment);

    return espResource; 
   
  }

  public void deletePartnerProxy(String proxyGateway, String environment, UUID proxyGuid) {
    
    validateProxyGateway(proxyGateway);
    if (!ESP.equals(proxyGateway)) {
      return;
    }
    
    ApiMediatedResource espResponse = getEspProxy(environment, proxyGuid);
    String mediatedResourceId = Integer.toString(espResponse.getMediatedResourceId());
    String apigeeProxyName = BuildHandler.buildApigeeProxyName(espResponse.getVersion(), 
        extractPartnerNameFromTaxonomy(espResponse.getResourceTaxonomy()),
        espResponse.getResourceName(), espResponse.getResourceGuid());
    removeProxyFromApigee(apigeeProxyName, espResponse.getEnvironment());
    
    try {
      espClient.undeployApiProxy(mediatedResourceId, espResponse.getEnvironment(), "undeployInternal");
      espClient.deleteApiProxy(mediatedResourceId, espResponse.getEnvironment());
    } catch (InternalServerException e) {
      String reason = ESP_INTERNAL_ERROR_REASON;
      throw new InternalServerException(reason, reason);
    }
    
  }
  
  public ApigeeProduct removeProxyFromApigee(String apigeeProxyName, String environment) {
    
    String planet = "NONPROD";
    Planet apigeePlanet = Planet.NONPROD;
    if (environment.equals(ESP_ENV_PROD)) {
      planet = "PROD";
      apigeePlanet = Planet.PROD;
    }
    String productName = partnerProxyConfigProperties.getApiProductName();

    ApigeeProduct product = apigeeProductsService.getProduct(productName, planet, "INTERNAL");

    if (product == null || CollectionUtils.isEmpty(product.getEnvironments()) 
        || CollectionUtils.isEmpty(product.getProxies())) {
      String reason = String.format("Unable to retrieve Apigee API Product: %s", productName);
      throw new InternalServerException(reason, reason);
    }
    //Check if the product is deployed to multiple envs before removing the proxy. Don't remove it if it is.
    if (product.getEnvironments().size() == 1) {
      if (product.getProxies().contains(apigeeProxyName)) {
        product.getProxies().remove(apigeeProxyName);
        apigeeProductsService.updatePartnerProxyProduct(apigeePlanet, product);
      } else {
        String reason = String.format("%s proxy not found in Apigee API Product: %s.", apigeeProxyName, productName);
        String message = String.format("%s proxy not found in Apigee API Product: %s. Possible out-of-synch condition"
            + " between ESP and Apigee.", apigeeProxyName, productName);
        throw new InternalServerException(reason, message);
      }
    }
    
    return product;
    
  }

  public String validateAndTransformEnvironmentToEspEnv(String environment) {
    
    //For some reason, the Controller "allowableValues" isn't rejecting on invalid envs so had to validate manually
    EnvironmentEnum env = EnvironmentEnum.fromValue(environment);
    if (null == env) {
      String reason = "Invalid environment: " + environment;
      String message = "Invalid environment: " + environment + ". Valid environments are: PRODUCTION | TEST1";
      throw new BadInputException(Error400Code.INVALIDQUERY, reason, message);
    }
    return transformEnvToEspEnv(environment);
  }

  public void validateProxyGateway(String proxyGateway) {
    
    //For some reason, the Controller "allowableValues" isn't rejecting on invalid proxyGateway 
    //so had to validate manually
    ProxyGatewayEnum gateway = ProxyGatewayEnum.fromValue(proxyGateway);
    if (null == gateway) {
      String reason = "Invalid proxyGateway: " + proxyGateway;
      String message = "Invalid proxyGateway: " + proxyGateway + ". Valid proxyGateways are: ESP";
      throw new BadInputException(Error400Code.INVALIDQUERY, reason, message);
    }

  }

  public InputApiRequest buildInputApiRequest(PartnerProxy partnerProxy) {
    
    // If this method ever gets called from outside the controller, add more individual field validation    
    InputApiRequest espProxyRequest = new InputApiRequest();
    espProxyRequest.setBypassApiAlreadyExists(true);
    espProxyRequest.setCallAsyncBuildDeploy(true);
    espProxyRequest.setSkipTaxonomyValidation(true);
    espProxyRequest.setTaxonomy(TAXONOMY_DOMAIN + partnerProxy.getPartnerName());
    espProxyRequest.setResourceName(partnerProxy.getPartnerResource());
    espProxyRequest.setVersion(partnerProxy.getProxyVersion());
    espProxyRequest.setType("Outbound");
    espProxyRequest.setOwningAppAppkey(partnerProxy.getProxyOwnerAppKey());
    espProxyRequest.setMalId(partnerProxy.getProxyOwnerSysgen());
    espProxyRequest.setRequestorEmail(partnerProxy.getProxyOwnerEmail());
    String partnerHostname = partnerProxy.getPartnerEndpoint().getEndpointHostname();
    if (partnerProxy.getPartnerEndpoint().getEnvironment() == null) {
      String reason = "Invalid environment";
      String message = "Invalid environment. Valid environments are: PRODUCTION | TEST1";
      throw new BadInputException(Error400Code.INVALIDQUERY, reason, message);
    }
    String environment = partnerProxy.getPartnerEndpoint().getEnvironment().toString();
    if (environment.equalsIgnoreCase("production")) {
      espProxyRequest.setProdEndpointHostname(partnerHostname);
      espProxyRequest.setEnv(ESP_ENV_PROD);
    } else {
      espProxyRequest.setTest1EndpointHostname(partnerHostname);
      espProxyRequest.setEnv(ESP_ENV_TEST1);
    } 
    espProxyRequest.setEndpointPath(partnerProxy.getPartnerEndpoint().getEndpointPath());
    espProxyRequest.setInternal("true");
    espProxyRequest.setProxyAuthInternal("oAuth");
    if (partnerProxy.getPartnerEndpoint().getAuthentication().getClass().isInstance(new BasicAuth())) {
      espProxyRequest.setEndpointAuth(ESP_BASIC_AUTH);
      BasicAuth basicAuth = (BasicAuth) partnerProxy.getPartnerEndpoint().getAuthentication();
      espProxyRequest.setEndpointBasicAuthUserAll(basicAuth.getBasicAuthUser());
      espProxyRequest.setEndpointBasicAuthPwAll(basicAuth.getBasicAuthPassword());
    } else {
      OAuth20 oauth = (OAuth20) partnerProxy.getPartnerEndpoint().getAuthentication();
      espProxyRequest = setOauthDetails(espProxyRequest, oauth);
    }
    
    return espProxyRequest;
  }
  
  private InputApiRequest setOauthDetails(InputApiRequest espProxyRequest, OAuth20 oauth) throws BadInputException {

    // If this method ever gets called from outside the controller, add more individual field validation
    espProxyRequest.setEndpointAuth("oAuth");
    if (oauth.getOauthGrantType() == null) {
      String reason = "Invalid oauthGrantType";
      String message = "Invalid oauthGrantType. Only CLIENT_CREDENTIALS is allowed.";
      throw new BadInputException(Error400Code.INVALIDBODY, reason, message);
    }
    espProxyRequest.setOauthGrantType("client_credentials");
    if (oauth.getOauthGrantLocation() == null) {
      String reason = "Invalid oauthGrantLocation.";
      String message = "Invalid oauthGrantLocation. Only FORM_PARAM or QUERY_PARAM are allowed.";
      throw new BadInputException(Error400Code.INVALIDBODY, reason, message);
    } else if (oauth.getOauthGrantLocation().toString().equals("FORM_PARAM")) {
      espProxyRequest.setOauthGrantLocation("Form Parameter");
    } else {
      espProxyRequest.setOauthGrantLocation("Query Parameter");
    }
    espProxyRequest.setOauthTokenServiceHost(oauth.getOauthTokenServiceHost());
    espProxyRequest.setOauthTokenServiceURI(oauth.getOauthTokenServicePath());

    if (oauth.getOauthClientIdLocation() == null) {
      String reason = "Invalid oauthClientIdLocation.";
      String message = "Invalid oauthClientIdLocation. Only FORM_PARAM, QUERY_PARAM"
          + " or BASIC_AUTH are allowed.";
      throw new BadInputException(Error400Code.INVALIDBODY, reason, message);
    } else if (oauth.getOauthClientIdLocation().toString().equals("FORM_PARAM")) {
      espProxyRequest.setOauthClientIdLocation("Form Parameter");
    } else  if (oauth.getOauthClientIdLocation().toString().equals("QUERY_PARAM")) {
      espProxyRequest.setOauthClientIdLocation("Query Parameter");
    } else {
      espProxyRequest.setOauthClientIdLocation("Basic Auth");
    }
    
    espProxyRequest.setOauthClientId(oauth.getOauthClientId());
    espProxyRequest.setOauthSecret(oauth.getOauthClientSecret());

    if (oauth.getOauthScopeLocation() == null) {
      String reason = "Invalid oauthScopeLocation";
      String message = "Invalid oauthScopeLocation. Only FORM_PARAM or QUERY_PARAM are allowed.";
      throw new BadInputException(Error400Code.INVALIDBODY, reason, message);
    } else if (oauth.getOauthScopeLocation().toString().equals("FORM_PARAM")) {
      espProxyRequest.setOauthScopeLocation("Form Parameter");
    } else {
      espProxyRequest.setOauthScopeLocation("Query Parameter");
    }
    espProxyRequest.setOauthScope(oauth.getOauthScope());
    
    return espProxyRequest;
  }

  public String transformEnvToEspEnv(String environment) {
    
    String env = environment.toLowerCase();
    if (env.equals("production")) {
      env = ESP_ENV_PROD;
    }
    
    return env;
    
  }
  
  public PartnerProxy transformEspResponseToPartnerProxy(ApiMediatedResource espResponse, String environment) {
    
    PartnerProxy partnerProxy = new PartnerProxy();
    partnerProxy.setPartnerName(extractPartnerNameFromTaxonomy(espResponse.getResourceTaxonomy()));
    partnerProxy.setPartnerResource(espResponse.getResourceName());
    partnerProxy.setProxyVersion(espResponse.getVersion());
    partnerProxy.setProxyOwnerAppKey(espResponse.getOwningApplicationKey());
    partnerProxy.setProxyOwnerSysgen(espResponse.getOwningApplicationId());
    partnerProxy.setProxyOwnerEmail(espResponse.getCreatedBy());
    partnerProxy.setProxyGateway(ProxyGatewayEnum.ESP);
    partnerProxy.setProxyGuid(UUID.fromString(espResponse.getResourceGuid()));
    PartnerEndpoint partnerEndpoint = new PartnerEndpoint();
    if (environment.equals("PRODUCTION")) {
      partnerEndpoint.setEnvironment(EnvironmentEnum.PRODUCTION);
    } else {
      partnerEndpoint.setEnvironment(EnvironmentEnum.TEST1);
    }
    partnerEndpoint.setEndpointHostname(espResponse.getEndPointUrl());
    partnerEndpoint.setEndpointPath(espResponse.getReplaceUrlToValue());
    if (espResponse.getEndpointAuthType().equals(ESP_BASIC_AUTH)) {
      BasicAuth basicAuth = new BasicAuth();
      basicAuth.setBasicAuthUser(espResponse.getBasicAuthUser());
      basicAuth.setBasicAuthPassword(espResponse.getBasicAuthPassword());
      // For some reason, the gen'd code returns two "types" in the response. 
      // If you don't set this one here, it returns one of them as "null".
      basicAuth.setType("BasicAuth");
      partnerEndpoint.setAuthentication(basicAuth);
    } else {
      partnerEndpoint.setAuthentication(transformEspResponseToPartnerProxyOauth(espResponse));
    }
    
    partnerProxy.setPartnerEndpoint(partnerEndpoint);
    
    return partnerProxy;
 
  }
  
  public String extractPartnerNameFromTaxonomy(String taxonomy) {

    int start = taxonomy.lastIndexOf("/") + 1;
    int end = taxonomy.length();
    
    return taxonomy.substring(start, end);
    
  }

  public OAuth20 transformEspResponseToPartnerProxyOauth(ApiMediatedResource espResponse) {
    OAuth20 oauth = new OAuth20();

    oauth.setType("OAuth20");
    oauth.setOauthGrantType(OauthGrantTypeEnum.CLIENT_CREDENTIALS);
    if (espResponse.getoAuthGrantTypeLocation().equals("Form Parameter")) {
      oauth.setOauthGrantLocation(OauthGrantLocationEnum.FORM_PARAM);
    } else {
      oauth.setOauthGrantLocation(OauthGrantLocationEnum.QUERY_PARAM);
    } 
    oauth.setOauthTokenServiceHost(espResponse.getoAuthTokenServiceHost());
    oauth.setOauthTokenServicePath(espResponse.getoAuthTokenServiceUri());

    if (espResponse.getoAuthClientIdLocation().equals("Query Parameter")) {
      oauth.setOauthClientIdLocation(OauthClientIdLocationEnum.QUERY_PARAM);
    } else if (espResponse.getoAuthGrantTypeLocation().equals("Form Parameter")) {
      oauth.setOauthClientIdLocation(OauthClientIdLocationEnum.FORM_PARAM);
    } else {
      oauth.setOauthClientIdLocation(OauthClientIdLocationEnum.BASIC_AUTH);
    }
    oauth.setOauthClientId(espResponse.getoAuthClientId());
    oauth.setOauthClientSecret(espResponse.getoAuthClientSecret());
    
    if (espResponse.getoAuthScopeLocation().equals("Form Parameter")) {
      oauth.setOauthScopeLocation(OauthScopeLocationEnum.FORM_PARAM);
    } else {
      oauth.setOauthScopeLocation(OauthScopeLocationEnum.QUERY_PARAM);
    }
    oauth.setOauthScope(espResponse.getoAuthScope());

    return oauth;
  }

  public PartnerProxy updateProxy(PartnerProxy partnerProxy, String proxyGateway, String environment,
      UUID proxyGuid) {
      
    validateProxyGateway(proxyGateway);
    if (!ESP.equals(proxyGateway)) {
      return partnerProxy;
    }
      
    ApiMediatedResource espResponse = getEspProxy(environment, proxyGuid);

    InputApiRequest inputApiRequest = buildInputApiRequest(partnerProxy);
    
    buildDeployServiceImpl.validateRequest(inputApiRequest);
    
    String myRequest = buildHandler.createBuildRequest(inputApiRequest);
    
    espClient.updateApiProxy(Integer.toString(espResponse.getMediatedResourceId()),
        myRequest, espResponse.getEnvironment(), inputApiRequest.getRequestorEmail());
    
    // remove api from product
    String apigeeProxyName = BuildHandler.buildApigeeProxyName(partnerProxy.getProxyVersion(),
        partnerProxy.getPartnerName(), partnerProxy.getPartnerResource(), espResponse.getResourceGuid());
    try {

      removeProxyFromApigee(apigeeProxyName, espResponse.getEnvironment());

    } catch (Exception e) {
      log.warn("Error received while removing API from product: " + apigeeProxyName + " Reason: " + e.getMessage());
    }

    espClient.undeployApiProxy(Integer.toString(espResponse.getMediatedResourceId()),
        espResponse.getEnvironment(), "undeployInternal");
    
    espClient.deployApiProxy(Integer.toString(espResponse.getMediatedResourceId()),
        espResponse.getEnvironment(), "deployInternal");
    
    // add api back to product
    apigeeProductsService.addNewProxyToApiProduct(partnerProxy, espResponse.getResourceGuid());
    
    return partnerProxy;
    
  }

  
}
