package com.lumen.apiexchange.util;

import com.lumen.apiexchange.client.ESPClient;
import com.lumen.apiexchange.config.ApiHubConfig;
import com.lumen.apiexchange.model.ApiMigrateRequest;
import com.lumen.apiexchange.model.InputApiRequest;
import io.micrometer.core.instrument.util.StringUtils;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class ValidationHandler {
  
  @Autowired
  private ESPClient espClient;
  
  private final ApiHubConfig apiHubConfig;

  final String br2 = "<br><br>";

  public String validateMigrationRequest(ApiMigrateRequest apiMigReq) {
    log.info("VALIDATE MIGRATIOIN REQUEST STEP");

    String valErrMsg = "";

    if (apiMigReq.getMirrorEnvironment() == null || apiMigReq.getMirrorEnvironment().isEmpty()) {
      valErrMsg = valErrMsg + "The mirrorEnvironment field is required. Cannot proceed with API migration. ";
    }

    if (apiMigReq.getGuid() == null || apiMigReq.getGuid().isEmpty()) {
      valErrMsg = valErrMsg + "The guid field is required. Cannot proceed with API migration. ";
    }

    valErrMsg = valErrMsg + validateEndpointHostname(apiMigReq.getDev1EndpointHostname());
    valErrMsg = valErrMsg + validateEndpointHostname(apiMigReq.getDev2EndpointHostname());
    valErrMsg = valErrMsg + validateEndpointHostname(apiMigReq.getDev3EndpointHostname());
    valErrMsg = valErrMsg + validateEndpointHostname(apiMigReq.getDev4EndpointHostname());
    valErrMsg = valErrMsg + validateEndpointHostname(apiMigReq.getTest1EndpointHostname());
    valErrMsg = valErrMsg + validateEndpointHostname(apiMigReq.getTest2EndpointHostname());
    valErrMsg = valErrMsg + validateEndpointHostname(apiMigReq.getTest3EndpointHostname());
    valErrMsg = valErrMsg + validateEndpointHostname(apiMigReq.getTest4EndpointHostname());
    valErrMsg = valErrMsg + validateEndpointHostname(apiMigReq.getMockEndpointHostname());
    valErrMsg = valErrMsg + validateEndpointHostname(apiMigReq.getSandboxEndpointHostname());

    return valErrMsg;

  }

  private String validateEndpointHostname(String hostname) {
    String errMessage = "";
    if (hostname != null && !hostname.isEmpty()) {
      if (!hostname.toLowerCase().startsWith("http://") && !hostname.toLowerCase().startsWith("https://")) {
        errMessage = "Hostname " + hostname + " must start with http:// or https://. ";
      }

      if (hostname.endsWith("/")) {
        if (StringUtils.isNotEmpty(errMessage)) {
          errMessage = errMessage + " ";
        } 
      
        errMessage = errMessage + "Hostname " + hostname + " cannot end with /. ";
      }
    }

    return errMessage;
  }

  public String validateRequest(InputApiRequest inputapirequest) {

    log.info("VALIDATE STEP");

    String valErrMsg = "";

    valErrMsg = valErrMsg + validateTaxonomy(inputapirequest);
    valErrMsg = valErrMsg + validateResourceName(inputapirequest.getResourceName());

    if (inputapirequest.getVersion() == null || inputapirequest.getVersion().length() < 1) {
      valErrMsg = valErrMsg + "- Version is missing" + br2;
    }

    if (inputapirequest.getVersion() != null && !inputapirequest.getVersion().matches("v[0-9]+")) {
      valErrMsg = valErrMsg + "- Version syntax invalid, should be a lowercase v followed by a number" + br2;
    }

    if (inputapirequest.getOwningAppAppkey() == null || inputapirequest.getOwningAppAppkey().length() < 1) {
      valErrMsg = valErrMsg + "- Owning Application AppKey is missing" + br2;
    }

    if (inputapirequest.getMalId() == null || inputapirequest.getMalId().length() < 1) {
      valErrMsg = valErrMsg + "- Mal ID is missing" + br2;
    }

    valErrMsg = valErrMsg + buildDeployValidateEndpointHostname(inputapirequest);

    valErrMsg = valErrMsg + validateEndpointPath(inputapirequest.getEndpointPath());
    valErrMsg = valErrMsg
        + validateProxyAuthBasicAuth(inputapirequest.getProxyAuthInternal(), inputapirequest.getProxyAuthExternal(),
            inputapirequest.getBasicAuthGroups(), inputapirequest.getBasicAuthUsers());
    
    valErrMsg = valErrMsg + validateAuthTypes(inputapirequest);
    valErrMsg = valErrMsg + validateB2bAuthentication(
        inputapirequest.getProxyAuthExternal(), inputapirequest.getB2bAuthRequired(),
        inputapirequest.getB2bCustomerNumberRequired(), inputapirequest.getB2bBillingAccountNumberRequired());
    valErrMsg = valErrMsg + validateEndpointAuthType(inputapirequest);
    valErrMsg = valErrMsg + validateOauthTokenServiceHost(inputapirequest.getOauthTokenServiceHost());

    return valErrMsg;
  }
  
  public String validateOauthTokenServiceHost(String oauthTokenServiceHost) {
    
    String errorMessage = "";
    
    if (StringUtils.isNotEmpty(oauthTokenServiceHost)) {
      if (oauthTokenServiceHost.toLowerCase().startsWith("http://") || oauthTokenServiceHost.toLowerCase().startsWith("https://")) {
        errorMessage = "oauthTokenServiceHost can't contain http:// or https://\n";
      }
        
    }
    
    return errorMessage;
  }

  public String validateB2bAuthentication(String proxyAuthExternal, String b2bAuthRequired,
      String b2bCustomerNumberRequired, String b2bBillingAccountNumberRequired) {
    StringBuilder errorMessage = new StringBuilder();
    
    if (StringUtils.isNotEmpty(proxyAuthExternal) && proxyAuthExternal.contains("LIAMOauth")) {
      if ("true".equalsIgnoreCase(b2bAuthRequired)) {
        errorMessage.append("b2bAuthRequired can't be true if proxyAuthExternal contains LIAMOauth\n");
      }
      if ("true".equalsIgnoreCase(b2bCustomerNumberRequired)) {
        errorMessage.append("b2bCustomerNumberRequired can't be true if proxyAuthExternal contains LIAMOauth\n");
      }
      if ("true".equalsIgnoreCase(b2bBillingAccountNumberRequired)) {
        errorMessage.append("b2bBillingAccountNumberRequired can't be true if proxyAuthExternal contains LIAMOauth\n");
      }
    }
    
    return errorMessage.toString();
  }

  public String validateEndpointAuthType(InputApiRequest inputapirequest) {
    String endpointAuthType = inputapirequest.getEndpointAuth();
    StringBuilder errorMessage = new StringBuilder();
    String regexendpointauthtype = apiHubConfig.getRegexendpointauthtype();

    if (endpointAuthType == null || endpointAuthType.isEmpty()) {
      errorMessage.append("EndpointAuth must be populated\n");
    } else if (!endpointAuthType.matches(regexendpointauthtype)) {
      errorMessage.append("EndpointAuth must be 'none', 'jwt', 'basicAuth',"
          + " 'authHeaderPassThrough', 'x509Cert', 'oAuth', or 'LIAMJwt'\n");
    }

    return errorMessage.toString();
  }

  public String validateAuthTypes(InputApiRequest inputapirequest) {
    String internallyAvailable = inputapirequest.getInternal();
    String validAuthTypesInt = inputapirequest.getProxyAuthInternal();
    String externallyAvailable = inputapirequest.getExternal();
    String validAuthTypesExt = inputapirequest.getProxyAuthExternal();
    StringBuilder errorMessage = new StringBuilder();
    String regexproxyauthexternal = apiHubConfig.getRegexproxyauthexternal();
    String regexproxyauthinternal = apiHubConfig.getRegexproxyauthinternal();

    if ("true".equalsIgnoreCase(internallyAvailable)) {
      if (validAuthTypesInt == null || validAuthTypesInt.isEmpty()) {
        errorMessage.append("ProxyAuthInternal must be populated when internally available is true\n");
      } else if (!validAuthTypesInt.matches(regexproxyauthinternal)) {
        errorMessage.append("ProxyAuthInternal must contain 'basicAuth', 'oAuth', or"
            + " 'appkey' when internally available is true\n");
      }
    }

    if ("true".equalsIgnoreCase(externallyAvailable)) {
      if (validAuthTypesExt == null || validAuthTypesExt.isEmpty()) {
        errorMessage.append("ProxyAuthExternal must be populated when externally available is true\n");
      } else if (!validAuthTypesExt.matches(regexproxyauthexternal)) {
        errorMessage.append("ProxyAuthExternal must contain 'oAuth', 'basicAuth', 'appkey',"
            + " 'LIAMOAuth', or 'jwt' when externally available is true\n");
      } else if (validAuthTypesExt.contains("oAuth") && validAuthTypesExt.contains("LIAMOauth")) {
        errorMessage.append("ProxyAuthExternal cannot contain both 'oAuth' and 'LIAMOauth'\n");
      }

    }

    return errorMessage.toString();
  }


  private String buildDeployValidateEndpointHostname(InputApiRequest inputapirequest) {
    
    String temp = "";
    StringBuffer sb = new StringBuffer();

    temp = validateEndpointHostname(inputapirequest.getDev1EndpointHostname());
    if (StringUtils.isNotEmpty(temp)) {
      sb.append("- Dev1 " + temp + br2);
    }

    temp = validateEndpointHostname(inputapirequest.getDev2EndpointHostname());
    if (StringUtils.isNotEmpty(temp)) {
      sb.append("- Dev2 " + temp + br2);
    }

    temp = validateEndpointHostname(inputapirequest.getDev3EndpointHostname());
    if (StringUtils.isNotEmpty(temp)) {
      sb.append("- Dev3 " + temp + br2);
    }

    temp = validateEndpointHostname(inputapirequest.getDev4EndpointHostname());
    if (StringUtils.isNotEmpty(temp)) {
      sb.append("- Dev4 " + temp + br2);
    }

    temp = validateEndpointHostname(inputapirequest.getTest1EndpointHostname());
    if (StringUtils.isNotEmpty(temp)) {
      sb.append("- Test1 " + temp + br2);
    }

    temp = validateEndpointHostname(inputapirequest.getTest2EndpointHostname());
    if (StringUtils.isNotEmpty(temp)) {
      sb.append("- Test2 " + temp + br2);
    }

    temp = validateEndpointHostname(inputapirequest.getTest3EndpointHostname());
    if (StringUtils.isNotEmpty(temp)) {
      sb.append("- Test3 " + temp + br2);
    }

    temp = validateEndpointHostname(inputapirequest.getTest4EndpointHostname());
    if (StringUtils.isNotEmpty(temp)) {
      sb.append("- Test4 " + temp + br2);
    }
    
    if (StringUtils.isEmpty(inputapirequest.getDev1EndpointHostname())
        && StringUtils.isEmpty(inputapirequest.getDev2EndpointHostname())
        && StringUtils.isEmpty(inputapirequest.getDev3EndpointHostname())
        && StringUtils.isEmpty(inputapirequest.getDev4EndpointHostname())
        && StringUtils.isEmpty(inputapirequest.getTest1EndpointHostname())
        && StringUtils.isEmpty(inputapirequest.getTest2EndpointHostname())
        && StringUtils.isEmpty(inputapirequest.getTest3EndpointHostname())
        && StringUtils.isEmpty(inputapirequest.getTest4EndpointHostname())
        && StringUtils.isEmpty(inputapirequest.getMockEndpointHostname())
        && StringUtils.isEmpty(inputapirequest.getSandboxEndpointHostname())
        && StringUtils.isEmpty(inputapirequest.getProdEndpointHostname())) {
      
      sb.append("- At least 1 endpoint hostname must be populated" + br2);
    }
    
    return sb.toString();
  }

  public String validateTaxonomy(InputApiRequest inputApiRequest) {
  
    String errMessage = "";
    
    if (inputApiRequest.skipTaxonomyValidation()) {
      return errMessage;
    }
    
    String temp = "";

    List<String> espTaxonomies;

    if (inputApiRequest.getTaxonomy() == null || inputApiRequest.getTaxonomy().length() < 1) {
      errMessage = "- Taxonomy is missing" + br2;
    } else {
      try {
        espTaxonomies = espClient.getTaxonomies();

        if (!espTaxonomies.contains(inputApiRequest.getTaxonomy())) {
          errMessage = "- Taxonomy is invalid" + br2;
        }
      } catch (Exception e) {
        if (e.getMessage().length() > 200) {
          temp = e.getMessage().substring(0, 200);
        } else {
          temp = e.getMessage();
        }
        errMessage = "- Error occurred, could not validate Taxonomy: " + temp + br2;
      }
  
    }
  
    return errMessage;
  
  }

  public String validateResourceName(String resourceName) {

    String errMessage = "";

    if (resourceName == null || resourceName.length() < 1) {
      errMessage = "- Resource Name is missing" + br2;
    } else if (resourceName.startsWith("/")) {
      errMessage = "- Resource Name cannot start with /" + br2;
    }

    return errMessage;
  }

  public String validateEndpointPath(String endpointPath) {

    String errMessage = "";

    if (endpointPath != null && !endpointPath.isEmpty()) {
      if (endpointPath.equals("/")) {
        errMessage = "- Resource Path cannot equal /, for no Resource Path leave blank" + br2;
      } else if (!endpointPath.startsWith("/")) {
        errMessage = "- If Resource Path is populated, it must start with /" + br2;
      }

    }

    if (endpointPath != null && endpointPath.contains("*")) {
      errMessage = "- If Resource Path is populated, it cannot contain an asterisk *" + br2;
    }

    return errMessage;
  }

  public String validateProxyAuthBasicAuth(String proxyAuthInternal, String proxyAuthExternal, String basicAuthGroups,
      String basicAuthUsers) {

    String errMessage = "";

    if (proxyAuthInternal != null && proxyAuthInternal.contains("basicAuth")) {
      if (basicAuthGroups == null || basicAuthGroups.trim().isEmpty()) {
        if (basicAuthUsers == null || basicAuthUsers.trim().isEmpty()) {
          errMessage = "- If Basic Authentication is selected for the Internal Gateway Authentication type,"
              + " a LDAP Group or User must be provided"
              + br2;
        }
      }
    }

    if (proxyAuthExternal != null && proxyAuthExternal.contains("basicAuth")) {
      if (basicAuthGroups == null || basicAuthGroups.trim().isEmpty()) {
        if (basicAuthUsers == null || basicAuthUsers.trim().isEmpty()) {
          errMessage = "- If Basic Authentication is selected for the External Gateway Authentication type,"
              + " a LDAP Group or User must be provided"
              + br2;
        }
      }
    }

    return errMessage;
  }

}
