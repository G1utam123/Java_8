package com.lumen.apiexchange.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ApplicationKey {


  private String applicationKeyID;
  private String applicationKeyType;
  private String applicationName;
  private String applicationType;
  private String authorizationType;
  private String clientPublicKeys;
  private String customerType;
  private String customernumbers;
  private String itpkmServiceId;
  private String owneremail;
  private String user;
  private String usertype;

  public String getApplicationKeyID() {
    return applicationKeyID;
  }

  public void setApplicationKeyID(final String appKeyID) {
    this.applicationKeyID = appKeyID;
  }

  public String getApplicationKeyType() {
    return applicationKeyType;
  }

  public void setApplicationKeyType(final String appKeyType) {
    this.applicationKeyType = appKeyType;
  }

  public String getApplicationName() {
    return applicationName;
  }

  public void setApplicationName(final String appName) {
    this.applicationName = appName;
  }

  public String getApplicationType() {
    return applicationType;
  }

  public void setApplicationType(final String appType) {
    this.applicationType = appType;
  }

  public String getAuthorizationType() {
    return authorizationType;
  }

  public void setAuthorizationType(final String authType) {
    this.authorizationType = authType;
  }

  public String getClientPublicKeys() {
    return clientPublicKeys;
  }

  public void setClientPublicKeys(final String clientPubKeys) {
    this.clientPublicKeys = clientPubKeys;
  }


  public String getCustomerType() {
    return customerType;
  }


  public void setCustomerType(final String custType) {
    this.customerType = custType;
  }


  public String getCustomernumbers() {
    return customernumbers;
  }


  public void setCustomernumbers(final String custnumbers) {
    this.customernumbers = custnumbers;
  }


  public String getItpkmServiceId() {
    return itpkmServiceId;
  }


  public void setItpkmServiceId(final String itpkmServId) {
    this.itpkmServiceId = itpkmServId;
  }


  public String getOwneremail() {
    return owneremail;
  }

  public void setOwneremail(final String ownemail) {
    this.owneremail = ownemail;
  }

  public String getUser() {
    return user;
  }

  public void setUser(final String userName) {
    this.user = userName;
  }

  public String getUsertype() {
    return usertype;
  }

  public void setUsertype(final String userType) {
    this.usertype = userType;
  }

  @Override
  public String toString() {
    return "Customer [applicationKeyID=" + applicationKeyID + ", applicationKeyType=" + applicationKeyType
        + ", applicationName=" + applicationName + ", applicationType=" + applicationType + ", authorizationType="
        + authorizationType + ", clientPublicKeys=" + clientPublicKeys + ", customerType=" + customerType
        + ", customernumbers=" + customernumbers + ", itpkmServiceId=" + itpkmServiceId + ", owneremail=" + owneremail
        + ", user=" + user + ", usertype=" + usertype + "]";
  }

}
