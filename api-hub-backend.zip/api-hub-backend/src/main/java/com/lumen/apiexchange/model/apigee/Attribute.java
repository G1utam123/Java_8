/*
 * API products API - Apigee
 */

package com.lumen.apiexchange.model.apigee;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * Apigee API product attribute name and value.
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Attribute {
  private String name;
  private String value;
}
