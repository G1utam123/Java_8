package com.lumen.apiexchange.config;

import java.nio.charset.StandardCharsets;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.thymeleaf.spring5.SpringTemplateEngine;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

@Configuration
public class TemplateEngineConfig {

  @Bean
  @Primary
  public SpringTemplateEngine springTemplateEngine() {
    SpringTemplateEngine springTemplateEngine = new SpringTemplateEngine();
    springTemplateEngine.addTemplateResolver(templateResolver());
    return springTemplateEngine;
  }

  @Bean("txtTemplateEngine")
  public SpringTemplateEngine springTxtTemplateEngine() {
    SpringTemplateEngine springTemplateEngine = new SpringTemplateEngine();
    springTemplateEngine.addTemplateResolver(txtTemplateResolver());
    return springTemplateEngine;
  }

  public ClassLoaderTemplateResolver templateResolver() {
    ClassLoaderTemplateResolver templateResolver = new ClassLoaderTemplateResolver();
    templateResolver.setPrefix("/templates/");
    templateResolver.setSuffix(".html");
    templateResolver.setTemplateMode(TemplateMode.HTML);
    templateResolver.setCharacterEncoding(StandardCharsets.UTF_8.name());
    templateResolver.setCacheable(false);
    return templateResolver;
  }

  public ClassLoaderTemplateResolver txtTemplateResolver() {
    ClassLoaderTemplateResolver txtTemplateResolver = new ClassLoaderTemplateResolver();
    txtTemplateResolver.setPrefix("/templates/");
    txtTemplateResolver.setSuffix(".txt");
    txtTemplateResolver.setTemplateMode(TemplateMode.TEXT);
    txtTemplateResolver.setCharacterEncoding(StandardCharsets.UTF_8.name());
    txtTemplateResolver.setCacheable(false);
    return txtTemplateResolver;
  }
}