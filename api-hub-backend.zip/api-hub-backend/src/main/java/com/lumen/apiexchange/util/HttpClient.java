package com.lumen.apiexchange.util;

import com.lumen.apiexchange.config.ApigeeConfigProperties;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

@Component
public class HttpClient {

  private static final Logger log = LoggerFactory.getLogger(HttpClient.class);

  @Autowired
  private ApigeeConfigProperties apigeeConfigProp;

  public ResponseEntity<String> sendRequest(String url, String method) throws IOException {
    return sendRequest(url, method, "", "");
  }

  public ResponseEntity<String> sendRequest(String url, String method, String user) throws IOException {
    return sendRequest(url, method, "", user);
  }

  public ResponseEntity<String> sendRequest(String url, String method, String body, String user) throws IOException {
    URL httpsUrl = new URL(url);
    HttpURLConnection con = (HttpURLConnection) httpsUrl.openConnection();

    con.setRequestMethod(method);
    setContentType(body, con);
    con.addRequestProperty(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
    con.setRequestProperty("X-Application-Key", apigeeConfigProp.getAppkey());
    if (user != null && !user.isEmpty()) {
      con.setRequestProperty("X-Username", user);
    }

    if (method.equals(HttpMethod.POST.toString()) || method.equals(HttpMethod.PUT.toString())) {
      if (body != null) {
        con.setChunkedStreamingMode(body.getBytes(StandardCharsets.UTF_8).length);
      }
      // For anything that requires a body
      con.setDoOutput(true);
    }

    if (body != null && !body.isEmpty()) {
      log.info("body is not empty");
      try (OutputStream os = con.getOutputStream()) {
        byte[] input = body.getBytes(StandardCharsets.UTF_8);
        os.write(input, 0, input.length);
      }
    }

    int responseCode = con.getResponseCode();

    log.info("URL :: " + url);
    log.info("Response Code :: " + responseCode);

    BufferedReader in = null;
    if (HttpStatus.valueOf(responseCode).is2xxSuccessful()) {

      in = new BufferedReader(new InputStreamReader(con.getInputStream()));

    } else {

      in = new BufferedReader(new InputStreamReader(con.getErrorStream()));

    }

    String inputLine;
    StringBuffer response = new StringBuffer();

    while ((inputLine = in.readLine()) != null) {
      response.append(inputLine);
    }

    Iterator<String> itr = con.getHeaderFields().keySet().iterator();
    Map<String, String> headers = new HashMap<String, String>();
    while (itr.hasNext()) {
      String key = itr.next();
      if (key != null) {
        headers.put(key, con.getHeaderField(key));
      }
    }

    MultiValueMap<String, String> responseHeaders = new LinkedMultiValueMap<>();

    responseHeaders.setAll(headers);

    in.close();

    con.disconnect();

    log.info("Response Body :: " + response.toString());

    return new ResponseEntity<String>(response.toString(), responseHeaders, HttpStatus.valueOf(responseCode));

  }

  private void setContentType(String body, HttpURLConnection con) {
    if (body == null || body.trim().equals("") || body.isEmpty()) {
      con.addRequestProperty(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE);
    } else {
      con.addRequestProperty(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
    }
  }

}
