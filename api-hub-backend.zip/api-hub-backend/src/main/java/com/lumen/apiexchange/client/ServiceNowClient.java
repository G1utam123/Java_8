package com.lumen.apiexchange.client;

import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.snow.ServiceNowApiResponse;
import com.lumen.apiexchange.model.snow.ServiceNowCreateGroupRequest;
import com.lumen.apiexchange.model.snow.ServiceNowResponse;
import com.lumen.apiexchange.model.snow.ServiceNowResult;
import com.lumen.apiexchange.model.snow.ServiceNowRitmQueryResponse;
import com.lumen.apiexchange.model.snow.ServiceNowUserQueryResponse;
import java.nio.charset.StandardCharsets;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;


@Component
@RequiredArgsConstructor
public class ServiceNowClient {

  @Value("${servicenow.url}")
  private String serviceNowUrl;

  @Value("${servicenow.username}")
  private String snUserName;

  @Value("${servicenow.password}")
  private String snPassword;

  @Value("${servicenow.createGroupRequestSysid}")
  private String createGroupRequestSysid;

  @Value("${servicenow.apiservicecatalogitems}")
  private String apiservicecatalogitems;

  @Value("${servicenow.orderitem}")
  private String orderitem;
  
  @Value("${servicenow.requestitem}")
  private String requestitem;

  @Value("${servicenow.snApiTable}")
  private String snApiTable;


  @Value("${servicenow.usersTable}")
  private String usersTable;

  private final RestTemplate restTemplate;

  protected static final Logger log = LoggerFactory.getLogger(ServiceNowClient.class);


  public String getSysIdFromServiceNow(ServiceNowCreateGroupRequest createGroupRequest)
      throws InternalServerException {
    String sysId;
    String ritmNo = null;
    HttpHeaders headers = createHeaders(snUserName, snPassword);
    HttpEntity<ServiceNowCreateGroupRequest> entity = new HttpEntity<>(createGroupRequest, headers);

    String url = serviceNowUrl + apiservicecatalogitems + createGroupRequestSysid + orderitem;
    ResponseEntity<ServiceNowResponse> response = restTemplate.exchange(url, HttpMethod.POST,
        entity, ServiceNowResponse.class);

    if (response.getBody() != null) {
      List<ServiceNowResult> resultList = response.getBody().getResult();
      if (resultList.size() > 0) {
        sysId = response.getBody().getResult().get(0).getSysId();
        ritmNo = getRitmNumberFromSnow(sysId);
      } else {
        throw new InternalServerException("No response received from servicenow: " + url);
      }
    }
    return ritmNo;

  }

  private String getRitmNumberFromSnow(String sysId)
      throws InternalServerException {
    String ritmResultNo = null;
    HttpHeaders headers = createHeaders(snUserName, snPassword);
    HttpEntity<String> entity = new HttpEntity<>("", headers);
    String getUrl = serviceNowUrl + snApiTable + requestitem + "?request=" + sysId;
    ResponseEntity<ServiceNowApiResponse<ServiceNowRitmQueryResponse>> response = restTemplate.exchange(
        getUrl, HttpMethod.GET, entity,
        new ParameterizedTypeReference<ServiceNowApiResponse<ServiceNowRitmQueryResponse>>() {
        });
    if (response.getBody() != null) {
      List<ServiceNowRitmQueryResponse> apiList = response.getBody().getResult();
      if (apiList.size() > 0) { 
        ritmResultNo = apiList.get(0).getNumber();
      } else {
        throw new InternalServerException("No RITM number returned by serviceNow for REQ with sysId: " + sysId);
      }
    } else {
      throw new InternalServerException("No response received from servicenow:" + getUrl);
    }
    return ritmResultNo;
  }

  public String getUserSysId(String requester) {
    String userSysId = null;
    HttpHeaders headers = createHeaders(snUserName, snPassword);
    HttpEntity<String> entity = new HttpEntity<>("", headers);
    String getUrl = serviceNowUrl + snApiTable + usersTable + "?u_cuid=" + requester;
    ResponseEntity<ServiceNowApiResponse<ServiceNowUserQueryResponse>> response = restTemplate.exchange(
        getUrl, HttpMethod.GET, entity,
        new ParameterizedTypeReference<ServiceNowApiResponse<ServiceNowUserQueryResponse>>() {});
    if (response.getBody() != null) {
      List<ServiceNowUserQueryResponse> userList = response.getBody().getResult();
      if (userList.size() > 0) {
        userSysId = userList.get(0).getSysId();
      } else {
        log.warn("User" + requester + "not found in the ServiceNow users table");
      }
    } else {
      throw new InternalServerException("No response received from servicenow:" + getUrl);
    }
    return userSysId;
  }

  private HttpHeaders createHeaders(String snUserName, String snPassword) {
    HttpHeaders httpHeaders = new HttpHeaders();
    String auth = snUserName + ":" + snPassword;
    byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.US_ASCII));
    String authHeader = "Basic " + new String(encodedAuth);
    httpHeaders.set("Authorization", authHeader);
    httpHeaders.setContentType(MediaType.APPLICATION_JSON);

    return httpHeaders;
  }
}

