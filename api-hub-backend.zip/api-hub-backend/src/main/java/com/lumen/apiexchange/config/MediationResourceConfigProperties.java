package com.lumen.apiexchange.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "mediation.resource")
public class MediationResourceConfigProperties {

  private String hostnameDev1;
  private String hostnameDev2;
  private String hostnameDev3;
  private String hostnameDev4;
  private String hostnameTest1;
  private String hostnameTest2;
  private String hostnameTest3;
  private String hostnameTest4;
  private String hostnameMock;
  private String hostnameSandbox;
  private String hostnameProd;
  private String mediationResourceUri;
  private String mediationTaxonomyUri;
  private String appkey;
  private String apigeeUser;
}
