package com.lumen.apiexchange.service;

import com.lumen.apiexchange.entity.ApiProduct;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.ProductNotFoundException;
import com.lumen.apiexchange.exception.UnauthorizedException;
import java.util.List;
import java.util.UUID;

public interface ApiProductsService {

  List<ApiProduct> getProductsInternalOrExternalByPlanet(String planet, Boolean external)
      throws ProductNotFoundException;

  ApiProduct getProduct(UUID id) throws ProductNotFoundException;

  void deleteProduct(UUID id, String user) throws ProductNotFoundException,
      UnauthorizedException, InternalServerException;

  ApiProduct saveProduct(ApiProduct product) throws BadInputException;

  ApiProduct updateProduct(ApiProduct product, String user) throws BadInputException,
      ProductNotFoundException, UnauthorizedException;
}
