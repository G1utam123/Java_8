package com.lumen.apiexchange.model;

import java.util.List;

public class ProxyDetails {

  private String guid;
  private List<ApiMediatedResource> environments;

  public String getGuid() {
    return guid;
  }

  public void setGuid(String guid) {
    this.guid = guid;
  }

  public List<ApiMediatedResource> getEnvironments() {
    return environments;
  }

  public void setEnvironments(List<ApiMediatedResource> environments) {
    this.environments = environments;
  }

}
