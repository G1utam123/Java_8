package com.lumen.apiexchange.client.apigee;

import com.lumen.apiexchange.config.ApigeeMgmtApiConfigProperties;
import com.lumen.apiexchange.model.apigee.ApigeeProduct;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest;
import com.lumen.apiexchange.model.apigee.ApigeeProductRequest;
import com.lumen.apiexchange.model.apigee.ApigeeProductResponse;
import com.lumen.apiexchange.model.apigee.ApigeeProxy;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Component
public class ApigeeMgmtApiClient {

  @Autowired
  private RestTemplate restTemplate;

  @Autowired
  private ApigeeMgmtApiConfigProperties apigeeMgmtApiConfigProperties;

  @AllArgsConstructor
  @Getter
  public enum ShortOrg { 
      INTERNAL("int"),
      EXTERNAL("ext");
    private String value;
  }

  public ApigeeProductResponse getProducts(String planet, String org) {

    String apigeeMgmtServerCreds = getApigeeMgmtServerCreds(planet);
    
    HttpHeaders headers = new HttpHeaders();
    headers.setBasicAuth(apigeeMgmtServerCreds);

    HttpEntity<String> entity = new HttpEntity<>(headers);
    String url = getApigeeMgmtServerUrl(planet) + "/v1/o/" + getShortOrg(org) + "/apiproducts?expand=true"; 
    ResponseEntity<ApigeeProductResponse> resp = restTemplate.exchange(url, HttpMethod.GET, entity,
        ApigeeProductResponse.class);
    
    return resp.getBody();
  }

  public ApigeeProduct getProduct(String productName, String planet, String org) {

    String apigeeMgmtServerCreds = getApigeeMgmtServerCreds(planet);
    
    HttpHeaders headers = new HttpHeaders();
    headers.setBasicAuth(apigeeMgmtServerCreds);

    HttpEntity<String> entity = new HttpEntity<>(headers);
    String url = getApigeeMgmtServerUrl(planet) + "/v1/o/" + getShortOrg(org) + "/apiproducts/" + productName; 
    ResponseEntity<ApigeeProduct> resp = restTemplate.exchange(url, HttpMethod.GET, entity, ApigeeProduct.class);

    return resp.getBody();
  }

  public ApigeeProduct saveProduct(ApigeeProductHubRequest hubProductReq) {

    String planet = hubProductReq.getPlanet().toString();
    String org = getShortOrg(hubProductReq.getAccessLocation().toString());
    String apigeeMgmtServerCreds = getApigeeMgmtServerCreds(planet);
    
    HttpHeaders headers = new HttpHeaders();
    headers.setBasicAuth(apigeeMgmtServerCreds);

    HttpEntity<ApigeeProductRequest> entity = new HttpEntity<>(hubProductReq.getApigeeProductRequest(), headers);
    String url = getApigeeMgmtServerUrl(planet) + "/v1/o/" + org + "/apiproducts"; 
    ResponseEntity<ApigeeProduct> resp = restTemplate.exchange(url, HttpMethod.POST, entity, ApigeeProduct.class);

    return resp.getBody();
  }

  public ApigeeProduct updateProduct(String name, ApigeeProductHubRequest hubProductReq) {

    String planet = hubProductReq.getPlanet().toString();
    String org = getShortOrg(hubProductReq.getAccessLocation().toString());
    String apigeeMgmtServerCreds = getApigeeMgmtServerCreds(planet);
    
    HttpHeaders headers = new HttpHeaders();
    headers.setBasicAuth(apigeeMgmtServerCreds);

    HttpEntity<ApigeeProductRequest> entity = new HttpEntity<>(hubProductReq.getApigeeProductRequest(), headers);
    String url = getApigeeMgmtServerUrl(planet) + "/v1/o/" + org + "/apiproducts/" + name; 
    ResponseEntity<ApigeeProduct> resp = restTemplate.exchange(url, HttpMethod.PUT, entity, ApigeeProduct.class);

    return resp.getBody();
  }

  public void deleteProduct(String name, String planet, String org) throws RestClientException {

    String apigeeMgmtServerCreds = getApigeeMgmtServerCreds(planet);
    
    HttpHeaders headers = new HttpHeaders();
    headers.setBasicAuth(apigeeMgmtServerCreds);

    HttpEntity<String> entity = new HttpEntity<>(headers);
    String url = getApigeeMgmtServerUrl(planet) + "/v1/o/" + getShortOrg(org) + "/apiproducts/{name}"; 
    restTemplate.exchange(url, HttpMethod.DELETE, entity, Void.class, name); 
  }

  public ApigeeProxy getProxy(String proxyName, String planet, String org) {

    String apigeeMgmtServerCreds = getApigeeMgmtServerCreds(planet);
    
    HttpHeaders headers = new HttpHeaders();
    headers.setBasicAuth(apigeeMgmtServerCreds);

    HttpEntity<String> entity = new HttpEntity<>(headers);
    String url = getApigeeMgmtServerUrl(planet) + "/v1/o/" + getShortOrg(org) + "/apis/{proxyName}"; 
    ResponseEntity<ApigeeProxy> resp = restTemplate.exchange(url, HttpMethod.GET, entity, ApigeeProxy.class, proxyName);

    return resp.getBody();
  }


  public List<String> getEnvironments(String planet, String org) {

    String apigeeMgmtServerCreds = getApigeeMgmtServerCreds(planet);
    
    HttpHeaders headers = new HttpHeaders();
    headers.setBasicAuth(apigeeMgmtServerCreds);

    HttpEntity<String> entity = new HttpEntity<>(headers);
    String url = getApigeeMgmtServerUrl(planet) + "/v1/o/" + getShortOrg(org) + "/environments"; 
    ResponseEntity<List<String>> resp =
        restTemplate.exchange(url, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {
            });

    return resp.getBody();

  }

  public String getApigeeMgmtServerUrl(String planet) {
    
    String url = apigeeMgmtApiConfigProperties.getManagementServerNonProdUrl();
    
    if (ApigeeProductHubRequest.Planet.PROD.toString().equals(planet)) {
      url = apigeeMgmtApiConfigProperties.getManagementServerProdUrl();
    }
    
    return url;
  }
  
  public String getApigeeMgmtServerCreds(String planet) {
    
    String basicAuthCreds = apigeeMgmtApiConfigProperties.getManagementServerNonProdBasicauth();
    
    if (ApigeeProductHubRequest.Planet.PROD.toString().equals(planet)) {
      basicAuthCreds = apigeeMgmtApiConfigProperties.getManagementServerProdBasicauth();
    }
    
    return basicAuthCreds;
  }

  public String getShortOrg(String accessLocation) {
    
    String org = "orgNotFound";
        
    ShortOrg[] shortOrgs = ShortOrg.values();
    for (ShortOrg shortOrg : shortOrgs) {
      if (shortOrg.toString().equals(accessLocation)) {
        org = shortOrg.value;
      }
    }

    return org;
  }

}