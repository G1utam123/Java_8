package com.lumen.apiexchange.service;

import com.lumen.apiexchange.config.ApiHubConfig;
import com.lumen.apiexchange.model.ApiMediatedResource;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class EmailBasedAuthzServiceImpl implements ApiAuthzService {

  private final ApiHubConfig apiHubConfig;

  public Boolean isUserAnApiOwner(String user, ApiMediatedResource api) {

    List<String> allowedEmails = getOwners(api);
    return allowedEmails.contains(user.toLowerCase());
  }

  private String getEmailForUser(String user) {

    String email = null;

    if (user != null && isValidEmailAddress(user)) {
      email = user;
    }

    return email;
  }

  public static boolean isValidEmailAddress(String email) {
    boolean result = true;
    try {
      InternetAddress emailAddr = new InternetAddress(email);
      emailAddr.validate();
    } catch (AddressException ex) {
      result = false;
    }
    return result;
  }

  public List<String> getOwners(String createdBy) {

    CopyOnWriteArrayList<String> allowedEmails
        = new CopyOnWriteArrayList<>(apiHubConfig.getAdmin().getUsers());
    allowedEmails.add(getEmailForUser(createdBy));

    List<String> owners = new ArrayList<>();
    for (String email : allowedEmails) {
      if (email != null) {
        owners.add(email.toLowerCase());
      }
    }
    return owners;
  }

  public List<String> getOwners(ApiMediatedResource api) {

    return getOwners(api.getCreatedBy());

  }

  public boolean isUserHubAdmin(String user) {

    CopyOnWriteArrayList<String> adminEmails = new CopyOnWriteArrayList<>(apiHubConfig.getAdmin().getUsers());

    return adminEmails.contains(user.toLowerCase());

  }

}
