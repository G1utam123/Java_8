package com.lumen.apiexchange.config;

import java.util.List;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "apihub")
public class ApiHubConfig {

  private AdminProperties admin;
  private String regexproxyauthexternal;
  private String regexproxyauthinternal;
  private String regexendpointauthtype;

  @Data
  public static class AdminProperties {
    private List<String> users;
  }
}
