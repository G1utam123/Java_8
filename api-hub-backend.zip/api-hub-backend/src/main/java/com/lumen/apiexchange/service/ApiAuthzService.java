package com.lumen.apiexchange.service;

import com.lumen.apiexchange.model.ApiMediatedResource;
import java.util.List;

public interface ApiAuthzService {

  List<String> getOwners(ApiMediatedResource apiProxy);

  List<String> getOwners(String createdBy);

  Boolean isUserAnApiOwner(String user, ApiMediatedResource api);

}
