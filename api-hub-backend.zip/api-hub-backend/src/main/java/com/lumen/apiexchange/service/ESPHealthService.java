package com.lumen.apiexchange.service;

import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ESPHealthStatusResponse;

public interface ESPHealthService {
  ESPHealthStatusResponse getESPHealthStatus() throws InternalServerException;
}
