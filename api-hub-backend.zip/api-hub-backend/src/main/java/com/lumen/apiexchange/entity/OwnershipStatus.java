package com.lumen.apiexchange.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data
@Table(name = "ownership_status")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OwnershipStatus {

  @Id
  @JsonProperty("UUID")
  private UUID id;

  @Column
  @JsonProperty("id")
  private String elementId;

  @Column
  @JsonProperty("type")
  private String elementType;

  @Column
  @NotNull(groups = {PutValidation.class})
  @JsonProperty("request")
  private String requestNo;

  @Column
  @NotNull(groups = {PutValidation.class})
  @JsonProperty("status")
  private String status;

  @Column
  @JsonProperty("requester")
  private String requester;


  @PrePersist
  @PreUpdate
  private void uppercaseFields() {
    this.elementId = this.elementId.toUpperCase();
    this.elementType = this.elementType.toUpperCase();
    this.requestNo = this.requestNo.toUpperCase();
    this.status = this.status.toUpperCase();
    this.requester = this.requester.toUpperCase();
  }
  
  
  public interface PutValidation {
  }
}
