package com.lumen.apiexchange.util;

import com.lumen.apiexchange.config.ApigeeConfigProperties;
import com.lumen.apiexchange.config.MediationResourceConfigProperties;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.InputApiRequest;
import com.lumen.apiexchange.service.HostServiceImpl;
import io.micrometer.core.instrument.util.StringUtils;
import java.io.IOException;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@Slf4j
@RequiredArgsConstructor
public class APIHandler {

  private final ApigeeConfigProperties apigeeConfigProp;
  private final MediationResourceConfigProperties mediationResourceConfigProp;
  private final HttpClient httpclient;
  private final HostServiceImpl hostServiceImpl;
  
  @Retryable(value = IOException.class, maxAttempts = 3, backoff = @Backoff(delay = 5000))
  public ResponseEntity<String> getApi(String env, String taxonomy, String resourceName, String version)
      throws IOException, InternalServerException {

    log.info("Step APIHandler.getApi");

    String myURL = hostServiceImpl.getEnvHostname(env) + mediationResourceConfigProp.getMediationResourceUri()
        + "?resourceTaxonomy=" + taxonomy + "&resourceName=" + resourceName + "&version=" + version;

    return httpclient.sendRequest(myURL, HttpMethod.GET.toString(), apigeeConfigProp.getApigeeUser());

  }

  @Retryable(value = IOException.class, maxAttempts = 3, backoff = @Backoff(delay = 5000))
  public ResponseEntity<String> getApi(InputApiRequest inApiRes) throws IOException, InternalServerException {

    log.info("Step APIHandler.getApi");

    String myURL = "";

    myURL = constructUrlWithQueryParameter(inApiRes);
    
    log.info("myURL: " + myURL);

    return httpclient.sendRequest(myURL, HttpMethod.GET.toString(), apigeeConfigProp.getApigeeUser());

  }

  public String constructUrlWithQueryParameter(InputApiRequest inApiRes) throws InternalServerException {

    log.info("Step APIHandler.constructUrlWithQueryParameter");
    log.info("inApiRes.toString():" + inApiRes.toString());

    Optional<String> queryTaxonomy = Optional.empty();
    Optional<String> queryResourceName = Optional.empty();
    Optional<String> queryVersion = Optional.empty();
    Optional<String> queryInternallyAvailable = Optional.empty();
    Optional<String> queryExternallyAvailable = Optional.empty();
    Optional<String> queryActive = Optional.empty();
    Optional<String> queryOwningApplicationId = Optional.empty();
    Optional<String> queryOwningApplicationKey = Optional.empty();
    Optional<String> queryRoutingExpression = Optional.empty();
    Optional<String> queryResourceGuid = Optional.empty();
    Optional<String> queryEndpointAuthType = Optional.empty();
    Optional<String> querySource = Optional.empty();
    Optional<String> queryB2bAuthRequired = Optional.empty();
    Optional<String> queryCreatedBy = Optional.empty();
    Optional<String> queryCreatedDate = Optional.empty();
    Optional<String> queryUpdatedBy = Optional.empty();
    Optional<String> queryUpdatedDate = Optional.empty();
    Optional<String> myEnv = Optional.empty();

    if (StringUtils.isNotEmpty(inApiRes.getTaxonomy())) {
      queryTaxonomy = Optional.of(inApiRes.getTaxonomy());
    }

    if (StringUtils.isNotEmpty(inApiRes.getResourceName())) {
      queryResourceName = Optional.of(inApiRes.getResourceName());
    }

    if (StringUtils.isNotEmpty(inApiRes.getVersion())) {
      queryVersion = Optional.of(inApiRes.getVersion());
    }

    if (StringUtils.isNotEmpty(inApiRes.getInternal())) {
      queryInternallyAvailable = Optional.of(inApiRes.getInternal());
    }

    if (StringUtils.isNotEmpty(inApiRes.getExternal())) {
      queryExternallyAvailable = Optional.of(inApiRes.getExternal());
    }

    if (StringUtils.isNotEmpty(inApiRes.getActive())) {
      queryActive = Optional.of(inApiRes.getActive());
    }

    if (StringUtils.isNotEmpty(inApiRes.getMalId())) {
      queryOwningApplicationId = Optional.of(inApiRes.getMalId());
    }

    if (StringUtils.isNotEmpty(inApiRes.getOwningAppAppkey())) {
      queryOwningApplicationKey = Optional.of(inApiRes.getOwningAppAppkey());
    }

    if (StringUtils.isNotEmpty(inApiRes.getRoutingExpression())) {
      queryRoutingExpression = Optional.of(inApiRes.getRoutingExpression());
    }

    if (StringUtils.isNotEmpty(inApiRes.getGuid())) {
      queryResourceGuid = Optional.of(inApiRes.getGuid());
    }

    if (StringUtils.isNotEmpty(inApiRes.getEndpointAuth())) {
      queryEndpointAuthType = Optional.of(inApiRes.getEndpointAuth());
    }

    if (StringUtils.isNotEmpty(inApiRes.getSource())) {
      querySource = Optional.of(inApiRes.getSource());
    }

    if (StringUtils.isNotEmpty(inApiRes.getB2bAuthRequired())) {
      queryB2bAuthRequired = Optional.of(inApiRes.getB2bAuthRequired());
    }

    if (StringUtils.isNotEmpty(inApiRes.getCreatedBy())) {
      queryCreatedBy = Optional.of(inApiRes.getCreatedBy());
    }

    if (StringUtils.isNotEmpty(inApiRes.getCreatedDate())) {
      queryCreatedDate = Optional.of(inApiRes.getCreatedDate());
    }

    if (StringUtils.isNotEmpty(inApiRes.getUpdatedBy())) {
      queryUpdatedBy = Optional.of(inApiRes.getUpdatedBy());
    }

    if (StringUtils.isNotEmpty(inApiRes.getUpdatedDate())) {
      queryUpdatedDate = Optional.of(inApiRes.getUpdatedDate());
    }

    if (inApiRes.getEnv().equals("mock") || inApiRes.getEnv().equals("sandbox")) {

      myEnv = Optional.of(inApiRes.getEnv());

    }

    return UriComponentsBuilder
        .fromUriString(
            hostServiceImpl.getEnvHostname(inApiRes.getEnv()) + mediationResourceConfigProp.getMediationResourceUri())
        .queryParamIfPresent("resourceTaxonomy", queryTaxonomy)
        .queryParamIfPresent("resourceName", queryResourceName)
        .queryParamIfPresent("version", queryVersion)
        .queryParamIfPresent("internallyAvailable", queryInternallyAvailable)
        .queryParamIfPresent("externallyAvailable", queryExternallyAvailable)
        .queryParamIfPresent("active", queryActive)
        .queryParamIfPresent("owningApplicationId", queryOwningApplicationId)
        .queryParamIfPresent("owningApplicationKey", queryOwningApplicationKey)
        .queryParamIfPresent("routingExpression", queryRoutingExpression)
        .queryParamIfPresent("resourceGuid", queryResourceGuid)
        .queryParamIfPresent("endpointAuthType", queryEndpointAuthType)
        .queryParamIfPresent("source", querySource)
        .queryParamIfPresent("b2bAuthRequired", queryB2bAuthRequired)
        .queryParamIfPresent("createdBy", queryCreatedBy)
        .queryParamIfPresent("createdDate", queryCreatedDate)
        .queryParamIfPresent("updatedBy", queryUpdatedBy)
        .queryParamIfPresent("updatedDate", queryUpdatedDate)
        .queryParamIfPresent("environment", myEnv)
        .build()
        .toUriString();
  }

  public String constructMediationUrl(String env) {

    return UriComponentsBuilder
        .fromUriString(
            hostServiceImpl.getEnvHostname(env) + mediationResourceConfigProp.getMediationResourceUri())
        .build()
        .toUriString();
  }

}
