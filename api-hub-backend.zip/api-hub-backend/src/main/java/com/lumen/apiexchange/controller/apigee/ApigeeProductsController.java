package com.lumen.apiexchange.controller.apigee;

import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.ProductNotFoundException;
import com.lumen.apiexchange.exception.UnauthorizedException;
import com.lumen.apiexchange.model.apigee.ApigeeProduct;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest;
import com.lumen.apiexchange.model.apigee.ApigeeProductResponse;
import com.lumen.apiexchange.service.ProfileService;
import com.lumen.apiexchange.service.apigee.ApigeeProductsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RequiredArgsConstructor
@RestController
public class ApigeeProductsController {

  private final ApigeeProductsService apigeeProductsService;

  private final ProfileService profileService;

  protected static final Logger log = LoggerFactory.getLogger(ApigeeProductsController.class);
  
  public enum InternalExternal { 
      INTERNAL, 
      EXTERNAL;
  }

  public enum Planet { 
      PROD,
      NONPROD;
  }
    
  @CrossOrigin
  @GetMapping(path = "/v1/products/apigee")
  @ResponseStatus(HttpStatus.OK)
  @Operation(tags = "Apigee Products",
      summary = "Gets a list of API Products from Apigee ", 
      description = "Gets a list of API Products from Apigee for a given planet (PROD or NONPROD) and "
        + "organization (EXTERNAL or INTERNAL). Optional param to restrict the list to the productOwner.")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Resources found"),
      @ApiResponse(responseCode = "404", description = "No resources found matching the given criteria"),
      @ApiResponse(responseCode = "500", description = "Internal Server Error.")
      })
  public ApigeeProductResponse getProductsApigee(@RequestParam Planet planet, 
      @RequestParam InternalExternal internalExternal, 
      @RequestParam(name = "productOwner", required = false)String productOwner)
          throws ProductNotFoundException {
    
    return apigeeProductsService.getProducts(planet.toString(), internalExternal.toString(), productOwner);

  }

  @CrossOrigin
  @GetMapping(path = "/v1/products/apigee/{name}")
  @ResponseStatus(HttpStatus.OK)
  @Operation(tags = "Apigee Products",
      summary = "Gets an API Product from Apigee.", 
      description = "Gets an API Product from Apigee for a given planet (PROD or NONPROD) and "
          + "organization (EXTERNAL or INTERNAL).")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Resource found"),
      @ApiResponse(responseCode = "404", description = "No resource found matching the given criteria"),
      @ApiResponse(responseCode = "500", description = "Internal Server Error.")
      })
  public ApigeeProduct getProductApigee(@PathVariable String name, @RequestParam Planet planet, 
      @RequestParam InternalExternal internalExternal) throws ProductNotFoundException {
    
    return apigeeProductsService.getProduct(name, planet.toString(), internalExternal.toString());

  }

  @CrossOrigin
  @PostMapping(path = "/v1/products/apigee")
  @ResponseStatus(HttpStatus.CREATED)
  @Operation(tags = "Apigee Products",
      summary = "Saves an API Product in Apigee.",
      description = "Saves an API Product to Apigee for a given planet (PROD or NONPROD) and "
          + "organization (EXTERNAL or INTERNAL).")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "201", description = "Resource created"),
      @ApiResponse(responseCode = "400", description = "Bad request"),
      @ApiResponse(responseCode = "500", description = "Internal Server Error. Product not saved.")
      })
  public ApigeeProduct saveProduct(@Valid @RequestBody ApigeeProductHubRequest apigeeHubProduct,
      @AuthenticationPrincipal Jwt principal) throws BadInputException {

    /* Temporarily using the productOwner provided until we get the full IAM solution built out with Admin groups.
     * If one isn't provided, defaults to the user so at least they can manage the product. 
     */
    if (apigeeHubProduct.getProductOwner() == null || apigeeHubProduct.getProductOwner().isEmpty()) {
      String email = profileService.getEmailFromProfile(principal);
      apigeeHubProduct.setProductOwner(email);
    }
    
    return apigeeProductsService.saveProduct(apigeeHubProduct);
    
  }

  @CrossOrigin
  @PutMapping(path = "/v1/products/apigee/{name}")
  @ResponseStatus(HttpStatus.OK)
  @Operation(tags = "Apigee Products",
      summary = "Updates an API Product in Apigee.",
      description = "Updates an API Product to Apigee for a given planet (PROD or NONPROD) and "
          + "organization (EXTERNAL or INTERNAL).")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Resource updated"),
      @ApiResponse(responseCode = "400", description = "Bad request"),
      @ApiResponse(responseCode = "401", description = "User not authorized to update this resource. " 
          + "User must be the Product owner."),
      @ApiResponse(responseCode = "404", description = "No resource found matching the given criteria"),
      @ApiResponse(responseCode = "500", description = "Internal Server Error. Product not updated.")
      })
  public ApigeeProduct updateProduct(@PathVariable String name, 
      @Valid @RequestBody ApigeeProductHubRequest apigeeHubProduct,
      @AuthenticationPrincipal Jwt principal) throws BadInputException {
    
    String email = profileService.getEmailFromProfile(principal);

    return apigeeProductsService.updateProduct(name, apigeeHubProduct, email);
    
  }

  @CrossOrigin
  @DeleteMapping(path = "/v1/products/apigee/{name}")   
  @ResponseStatus(HttpStatus.NO_CONTENT)
  @Operation(tags = "Apigee Products",
      summary = "Deletes an API Product in Apigee.",
      description = "Deletes an API Product in Apigee for a given planet (PROD or NONPROD) and "
          + "organization (EXTERNAL or INTERNAL).")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "204", description = "Product deleted"),
      @ApiResponse(responseCode = "401", description = "User not authorized to delete this resource. " 
          + "User must be the resource owner."),
      @ApiResponse(responseCode = "404", description = "Product not found for id: {name}"),
      @ApiResponse(responseCode = "500", description = "Internal Server Error. Product not deleted."),
      })
  public void deleteProduct(@PathVariable String name, @RequestParam Planet planet, 
      @RequestParam InternalExternal internalExternal, @AuthenticationPrincipal Jwt principal) throws
      InternalServerException, ProductNotFoundException, UnauthorizedException  {
    
    String userEmail = profileService.getEmailFromProfile(principal);

    apigeeProductsService.deleteProduct(name, userEmail, planet.toString(), internalExternal.toString());
    
  }
  
}
