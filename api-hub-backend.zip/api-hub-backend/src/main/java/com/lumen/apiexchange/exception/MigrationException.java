package com.lumen.apiexchange.exception;

public class MigrationException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public MigrationException(final String msg) {
    super(msg);
  }
}
