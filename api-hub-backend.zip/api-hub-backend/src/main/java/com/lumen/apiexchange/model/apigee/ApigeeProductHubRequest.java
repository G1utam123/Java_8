package com.lumen.apiexchange.model.apigee;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
/**
 * API-HUB Product details.
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApigeeProductHubRequest {

  /**
   * These properties are not sent to Apigee but necessary to determine the Apigee instance and 
   *  for security ('productOwnerGroups") or simplicity ("access") purposes.
   */
  private Access access;
  private AccessLocation accessLocation;
  private Planet planet;
  private String productOwner;

  /**
   * Actual request that gets sent to Apigee.
   */
  private ApigeeProductRequest apigeeProductRequest;


  /**
   * Public - API products that are available to all developers. You can add them to integrated or 
   *          Drupal-based developer portals
   * Private - API products that are designed for private or internal use.
   * Notes for Apigee implementation:
   *    - From Apigee: "There is no functional difference between Private and Internal only access levels." 
   *      Because of this we chose not to implement "Internal only" as an option to reduce confusion.
   *    - "access" isn't a property of the Apigee Product Request. It gets set as an entry in the 
   *      "attributes" property in the Service class. It is also converted to all lowercase in the Service Impl.  
   *  
   */
  @AllArgsConstructor
  @Getter
  public enum Access {
    PUBLIC,
    PRIVATE;
  }  

  /**
   * Internal or External - Indicates whether the Product is available from within Lumen or outside Lumen. 
   * Determines which Apigee Organization the Product gets built in.
   */
  @AllArgsConstructor
  @Getter
  public enum AccessLocation {
    INTERNAL,
    EXTERNAL;

  }
  
  /**
   * Prod or Non-Prod - Determines which Apigee Planet the Product gets built in.
   */
  @AllArgsConstructor
  @Getter
  public enum Planet {
    PROD,
    NONPROD;
  }  

}
