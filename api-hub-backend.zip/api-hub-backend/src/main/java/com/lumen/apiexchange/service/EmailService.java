package com.lumen.apiexchange.service;

import com.lumen.apiexchange.model.FeedbackMessage;

public interface EmailService {
  
  void sendFeedbackReceivedEmail(FeedbackMessage message);
}
