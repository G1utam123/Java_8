package com.lumen.apiexchange.model.snow;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@Builder
@AllArgsConstructor
@ToString
public class ServiceNowCreateGroupRequest {

  @JsonProperty("sysparm_quantity")
  private String sysparmQuantity;


  @JsonProperty("sysparm_item_guid")
  private String sysparmItemGuid;


  @JsonProperty("get_portal_messages")
  private String getPortalMessages;

  @JsonProperty("sysparm_no_validation")
  private String sysparmNoValidation;

  @JsonProperty("sysparm_requested_for")
  private String sysparmRequestedFor;

  private ServiceNowVariable variables;
  
}
