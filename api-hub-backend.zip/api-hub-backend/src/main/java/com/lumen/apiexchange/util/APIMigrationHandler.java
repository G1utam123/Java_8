package com.lumen.apiexchange.util;

import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ApiMigrateRequest;
import com.lumen.apiexchange.model.ApiMigrationResult;
import com.lumen.apiexchange.model.InputApiRequest;
import io.micrometer.core.instrument.util.StringUtils;
import java.io.IOException;
import java.util.ArrayList;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.stereotype.Service;

@Service 
@EnableRetry
public class APIMigrationHandler {

  private static final Logger log = LoggerFactory.getLogger(APIMigrationHandler.class);

  @Autowired
  private ValidationHandler valH;

  @Autowired
  private APIHandler apiH;

  @Autowired
  private BuildHandler buildH;

  @Autowired
  private DeployHandler deployH;

  private static final String ENVIRONMENT_MOCK = "mock";
  private static final String ENVIRONMENT_SANDBOX = "sandbox";
  private static final String MEDIATED_RESOURCE = "mediatedResource";

  public ApiMigrationResult migrateApi(ApiMigrateRequest apiMigrateRequest)
      throws InternalServerException, BadInputException {

    String message = "";
    InputApiRequest inApiRes = new InputApiRequest();
    InputApiRequest myBuildRequest;
    JSONParser parser = new JSONParser();
    JSONObject responseJsonObj3 = null;
    String myEnv = "";
    ResponseEntity<String> myEntity = null;

    message = valH.validateMigrationRequest(apiMigrateRequest);

    if (!message.isEmpty()) {
      throw new BadInputException("Invalid Request");
    }
  
    myBuildRequest = retrieveMirrorEnvironmentInformation(apiMigrateRequest, inApiRes,
        parser);

    log.info("MIGRATE API STEP");
    ApiMigrationResult apiMigResult = ApiMigrationResult.builder()
        .routingExpression(myBuildRequest.getRoutingExpression())
        .migratedEnv(new ArrayList<>())
        .notMigratedEnv(new ArrayList<>()).build();
    
    for (int i = 1; i < 11; i++) {
      myEnv = setMyEnv(i);
      myBuildRequest.setEnv(myEnv);
      
      try {
        log.info("BUILD API STEP");
        if (!myEnv.equalsIgnoreCase(apiMigrateRequest.getMirrorEnvironment())
            && !skipEnvMigration(myEnv, myBuildRequest)) {
          
          if ((myEnv.equalsIgnoreCase(ENVIRONMENT_MOCK) || myEnv.equalsIgnoreCase(ENVIRONMENT_SANDBOX))
              && StringUtils.isNotBlank(myBuildRequest.getExternal())
              && !myBuildRequest.getExternal().equalsIgnoreCase("true")) {
            throw new BadInputException("Mock and Sandbox environments can only be deployed externally.");
          }
  
          myEntity = buildH.buildApi(myBuildRequest);
          if (myEntity.getStatusCodeValue() == HttpStatus.OK.value()) {
  
            responseJsonObj3 = parseJson(myEntity.getBody(), parser);
  
            log.info("DEPLOY API STEP");
            deployApi(responseJsonObj3.get("mediatedResourceId").toString(), myBuildRequest);

            apiMigResult.getMigratedEnv().add(myEnv);
  
          } else {
            apiMigResult.getNotMigratedEnv().add(myEnv);
          }
        }
      } catch (IOException | ParseException | BadInputException e) {
        apiMigResult.getNotMigratedEnv().add(myEnv);
      }
    }

    log.info("MIGRATION COMPLETE");

    return apiMigResult;
    
  }

  private InputApiRequest retrieveMirrorEnvironmentInformation(ApiMigrateRequest apiMigrateRequest,
       InputApiRequest inApiRes, JSONParser parser)
      throws InternalServerException {
    InputApiRequest myBuildRequest = new InputApiRequest();
    JSONObject responseJsonObj;
    JSONObject responseJsonObj2;
    try {
      log.info("RETRIEVE MIRROR ENVIRONMENT STEP");
      ResponseEntity<String> response = retrieveMirrorEnvironment(apiMigrateRequest, inApiRes);
      if (response.getStatusCodeValue() == HttpStatus.OK.value() && response.getBody().contains(MEDIATED_RESOURCE)) {

        log.info("PARSE JSON STEP");
        responseJsonObj = parseJson(response.getBody(), parser);
        responseJsonObj2 = parseJson(responseJsonObj.get(MEDIATED_RESOURCE).toString(), parser);

        log.info("BUILD REQUEST");
        myBuildRequest = buildRequest(responseJsonObj2);
        myBuildRequest = setEnvHostnames(apiMigrateRequest, myBuildRequest);
        myBuildRequest.setRequestorEmail(apiMigrateRequest.getRequestorEmail());
        myBuildRequest.setMigrationRequest(true);
      } else {
        throw new InternalServerException("Source API could not be returned.");
      }
    } catch (IOException | ParseException e) {
      throw new InternalServerException("Source API could not be returned.");
    }
    return myBuildRequest;
  }

  private void deployApi(String mediatedResourceId, InputApiRequest myBuildRequest)
      throws IOException, InternalServerException {

    if (myBuildRequest.getExternal() != null && myBuildRequest.getExternal().equalsIgnoreCase("true")) {

      deployH.deployApi(myBuildRequest.getEnv(), "external", mediatedResourceId);
    }

    if (myBuildRequest.getInternal() != null && myBuildRequest.getInternal().equalsIgnoreCase("true")
        && !(myBuildRequest.getEnv().equalsIgnoreCase(ENVIRONMENT_MOCK)
            || myBuildRequest.getEnv().equalsIgnoreCase(ENVIRONMENT_SANDBOX))) {

      deployH.deployApi(myBuildRequest.getEnv(), "internal", mediatedResourceId);
    }
  }

  private boolean skipEnvMigration(String myEnv, InputApiRequest myBuildRequest) throws InternalServerException {
    boolean skipEnvMigration = true;
    switch (myEnv) {
      case "dev1":
        if (StringUtils.isNotEmpty(myBuildRequest.getDev1EndpointHostname())) {
          skipEnvMigration = false;
        }
        break;
      case "dev2":
        if (StringUtils.isNotEmpty(myBuildRequest.getDev2EndpointHostname())) {
          skipEnvMigration = false;
        }
        break;
      case "dev3":
        if (StringUtils.isNotEmpty(myBuildRequest.getDev3EndpointHostname())) {
          skipEnvMigration = false;
        }
        break;
      case "dev4":
        if (StringUtils.isNotEmpty(myBuildRequest.getDev4EndpointHostname())) {
          skipEnvMigration = false;
        }
        break;
      case "test1":
        if (StringUtils.isNotEmpty(myBuildRequest.getTest1EndpointHostname())) {
          skipEnvMigration = false;
        }
        break;
      case "test2":
        if (StringUtils.isNotEmpty(myBuildRequest.getTest2EndpointHostname())) {
          skipEnvMigration = false;
        }
        break;
      case "test3":
        if (StringUtils.isNotEmpty(myBuildRequest.getTest3EndpointHostname())) {
          skipEnvMigration = false;
        }
        break;
      case "test4":
        if (StringUtils.isNotEmpty(myBuildRequest.getTest4EndpointHostname())) {
          skipEnvMigration = false;
        }
        break;
      case ENVIRONMENT_MOCK:
        if (StringUtils.isNotEmpty(myBuildRequest.getMockEndpointHostname())) {
          skipEnvMigration = false;
        }
        break;
      case ENVIRONMENT_SANDBOX:
        if (StringUtils.isNotEmpty(myBuildRequest.getSandboxEndpointHostname())) {
          skipEnvMigration = false;
        }
        break;
      default:
        throw new InternalServerException("Invalid environment");
    }
    return skipEnvMigration;
  }

  private InputApiRequest setEnvHostnames(ApiMigrateRequest apiMigrateRequest, InputApiRequest myBuildRequest) {
    if (StringUtils.isNotEmpty(apiMigrateRequest.getDev1EndpointHostname())) {
      myBuildRequest.setDev1EndpointHostname(apiMigrateRequest.getDev1EndpointHostname());
    }

    if (StringUtils.isNotEmpty(apiMigrateRequest.getDev2EndpointHostname())) {
      myBuildRequest.setDev2EndpointHostname(apiMigrateRequest.getDev2EndpointHostname());
    }

    if (StringUtils.isNotEmpty(apiMigrateRequest.getDev3EndpointHostname())) {
      myBuildRequest.setDev3EndpointHostname(apiMigrateRequest.getDev3EndpointHostname());
    }

    if (StringUtils.isNotEmpty(apiMigrateRequest.getDev4EndpointHostname())) {
      myBuildRequest.setDev4EndpointHostname(apiMigrateRequest.getDev4EndpointHostname());
    }

    if (StringUtils.isNotEmpty(apiMigrateRequest.getTest1EndpointHostname())) {
      myBuildRequest.setTest1EndpointHostname(apiMigrateRequest.getTest1EndpointHostname());
    }

    if (StringUtils.isNotEmpty(apiMigrateRequest.getTest2EndpointHostname())) {
      myBuildRequest.setTest2EndpointHostname(apiMigrateRequest.getTest2EndpointHostname());
    }

    if (StringUtils.isNotEmpty(apiMigrateRequest.getTest3EndpointHostname())) {
      myBuildRequest.setTest3EndpointHostname(apiMigrateRequest.getTest3EndpointHostname());
    }

    if (StringUtils.isNotEmpty(apiMigrateRequest.getTest4EndpointHostname())) {
      myBuildRequest.setTest4EndpointHostname(apiMigrateRequest.getTest4EndpointHostname());
    }

    if (StringUtils.isNotEmpty(apiMigrateRequest.getMockEndpointHostname())) {
      myBuildRequest.setMockEndpointHostname(apiMigrateRequest.getMockEndpointHostname());
    }

    if (apiMigrateRequest.getSandboxEndpointHostname() != null
        && !apiMigrateRequest.getSandboxEndpointHostname().isEmpty()) {
      myBuildRequest.setSandboxEndpointHostname(apiMigrateRequest.getSandboxEndpointHostname());
    }
    return myBuildRequest;
  }

  private String setMyEnv(int i) throws InternalServerException {
    String myEnv = "";
    switch (i) {
      case 1:
        myEnv = "dev1";
        break;
      case 2:
        myEnv = "dev2";
        break;
      case 3:
        myEnv = "dev3";
        break;
      case 4:
        myEnv = "dev4";
        break;
      case 5:
        myEnv = "test1";
        break;
      case 6:
        myEnv = "test2";
        break;
      case 7:
        myEnv = "test3";
        break;
      case 8:
        myEnv = "test4";
        break;
      case 9:
        myEnv = ENVIRONMENT_MOCK;
        break;
      case 10:
        myEnv = ENVIRONMENT_SANDBOX;
        break;
      default:
        throw new InternalServerException("Invalid environment");
    }
    return myEnv;
  }

  private ResponseEntity<String> retrieveMirrorEnvironment(ApiMigrateRequest apiMigrateRequest,
      InputApiRequest inApiRes) throws IOException, InternalServerException {
    inApiRes.setEnv(apiMigrateRequest.getMirrorEnvironment());
    inApiRes.setGuid(apiMigrateRequest.getGuid());

    ResponseEntity<String> response = apiH.getApi(inApiRes);

    return response;
  }

  JSONObject parseJson(String response, JSONParser parser) throws ParseException {
    Object responseObj = parser.parse(response);

    JSONObject responseJsonObj = (JSONObject) responseObj;

    log.debug("parseJson :: " + responseJsonObj);

    return responseJsonObj;
  }

  InputApiRequest buildRequest(JSONObject responseJsonObj2) {

    final String RESOURCE_TAXONOMY = "resourceTaxonomy";
    final String RESOURCE_NAME = "resourceName";
    final String VERSION = "version";
    final String SERVICE_TYPE = "serviceType";
    final String INTERNALLY_AVAILABLE = "internallyAvailable";
    final String EXTERNALLY_AVAILABLE = "externallyAvailable";
    final String ACTIVE = "active";
    final String THROTTLING_REQUEST_PER_SEC = "throttlingRequestsPerSec";
    final String TIMEOUT_SECS = "timeoutSecs";
    final String CONNECTION_KEEP_ALIVE = "connectionKeepAlive";
    final String OWNING_APPLICATION_ID = "owningApplicationId";
    final String OWNING_APPLICATION_KEY = "owningApplicationKey";
    final String REPLACE_URL_FROM_VALUE = "replaceUrlFromValue";
    final String REPLACE_URL_TO_VALUE = "replaceUrlToValue";
    final String ROUTING_EXPRESSION = "routingExpression";
    final String RESOURCE_GUID = "resourceGuid";
    final String VALID_AUTH_TYPES = "validAuthTypes";
    final String VALID_AUTH_TYPES_EXT = "validAuthTypesExt";
    final String ENFORCE_DIGEST = "enforceDigest";
    final String ENFORCE_TAXONOMY = "enforceTaxonomy";
    final String AUTHORIZED_GROUPS = "authorizedGroups";
    final String AUTHORIZED_USERS = "authorizedUsers";
    final String ENFORCE_HTTPS = "enforceHttps";
    final String ENDPOINT_AUTH_TYPE = "endpointAuthType";
    final String BASIC_AUTH_USER = "basicAuthUser";
    final String BASIC_AUTH_PASSWORD = "basicAuthPassword";
    final String OAUTH_CLIENT_ID = "oAuthClientId";
    final String OAUTH_CLIENT_ID_LOCATION = "oAuthClientIdLocation";
    final String OAUTH_CLIENT_SECRET = "oAuthClientSecret";
    final String OAUTH_GRANT_TYPE = "oAuthGrantType";
    final String OAUTH_USERNAME = "oAuthUsername";
    final String OAUTH_PASSWORD = "oAuthPassword";
    final String OAUTH_USERNAME_LOCATION = "oAuthUsernameLocation";
    final String OAUTH_TOKEN_SERVICE_HOST = "oAuthTokenServiceHost";
    final String OAUTH_TOKEN_SERVICE_URI = "oAuthTokenServiceUri";
    final String OAUTH_GRANT_TYPE_LOCATION = "oAuthGrantTypeLocation";
    final String OAUTH_SCOPE = "oAuthScope";
    final String OAUTH_SCOPE_LOCATION = "oAuthScopeLocation";
    final String B2B_AUTH_REQUIRED = "b2bAuthRequired";
    final String B2B_CUSTOMER_NUMBER_REQUIRED = "b2bCustomerNumberRequired";
    final String B2B_BILLING_ACCOUNT_NUMBER_REQUIRED = "b2bBillingAccountNumberRequired";
    final String ROUTING_TYPE = "routingType";
    final String SECURITY_REQUEST_NUMBER = "securityRequestNumber";

    InputApiRequest temp = new InputApiRequest();

    setSoap(responseJsonObj2, SERVICE_TYPE, temp);
    setTaxonomy(responseJsonObj2, RESOURCE_TAXONOMY, temp);
    setResourceName(responseJsonObj2, RESOURCE_NAME, temp);
    setVersion(responseJsonObj2, VERSION, temp);
    setType(responseJsonObj2, ROUTING_TYPE, temp);
    setInternal(responseJsonObj2, INTERNALLY_AVAILABLE, temp);
    setExternal(responseJsonObj2, EXTERNALLY_AVAILABLE, temp);
    setActive(responseJsonObj2, ACTIVE, temp);
    setThrottlingRequestsPerSec(responseJsonObj2, THROTTLING_REQUEST_PER_SEC, temp);
    setTimeoutSecs(responseJsonObj2, TIMEOUT_SECS, temp);
    setConnectionKeepAlive(responseJsonObj2, CONNECTION_KEEP_ALIVE, temp);
    setMalId(responseJsonObj2, OWNING_APPLICATION_ID, temp);
    setOwningAppAppkey(responseJsonObj2, OWNING_APPLICATION_KEY, temp);
    setReplaceUrlFromValue(responseJsonObj2, REPLACE_URL_FROM_VALUE, temp);
    setEndpointPath(responseJsonObj2, REPLACE_URL_TO_VALUE, temp);
    setRoutingExpression(responseJsonObj2, ROUTING_EXPRESSION, temp);
    setGuid(responseJsonObj2, RESOURCE_GUID, temp);
    setProxyAuthInternal(responseJsonObj2, VALID_AUTH_TYPES, temp);
    setProxyAuthExternal(responseJsonObj2, VALID_AUTH_TYPES_EXT, temp);
    setAppkeyEnforceDigest(responseJsonObj2, ENFORCE_DIGEST, temp);
    setAppkeyEnforceTaxonomy(responseJsonObj2, ENFORCE_TAXONOMY, temp);
    setBasicAuthGroups(responseJsonObj2, AUTHORIZED_GROUPS, temp);
    setBasicAuthUsers(responseJsonObj2, AUTHORIZED_USERS, temp);
    setEnforceHttps(responseJsonObj2, ENFORCE_HTTPS, temp);
    setEndpointAuth(responseJsonObj2, ENDPOINT_AUTH_TYPE, temp);
    setEndpointBasicAuthUserAll(responseJsonObj2, BASIC_AUTH_USER, temp);
    setEndpointBasicAuthPwAll(responseJsonObj2, BASIC_AUTH_PASSWORD, temp);
    setOauthClientId(responseJsonObj2, OAUTH_CLIENT_ID, temp);
    setOauthClientIdLocation(responseJsonObj2, OAUTH_CLIENT_ID_LOCATION, temp);
    setOauthSecret(responseJsonObj2, OAUTH_CLIENT_SECRET, temp);
    setOauthGrantType(responseJsonObj2, OAUTH_GRANT_TYPE, temp);
    setOauthUserName(responseJsonObj2, OAUTH_USERNAME, temp);
    setOauthpw(responseJsonObj2, OAUTH_PASSWORD, temp);
    setOauthCredentialsLocation(responseJsonObj2, OAUTH_USERNAME_LOCATION, temp);
    setOauthTokenServiceHost(responseJsonObj2, OAUTH_TOKEN_SERVICE_HOST, temp);
    setOauthTokenServiceURI(responseJsonObj2, OAUTH_TOKEN_SERVICE_URI, temp);
    setOauthGrantLocation(responseJsonObj2, OAUTH_GRANT_TYPE_LOCATION, temp);
    setOauthScope(responseJsonObj2, OAUTH_SCOPE, temp);
    setOauthScopeLocation(responseJsonObj2, OAUTH_SCOPE_LOCATION, temp);
    setB2bAuthRequired(responseJsonObj2, B2B_AUTH_REQUIRED, temp);
    setB2bCustomerNumberRequired(responseJsonObj2, B2B_CUSTOMER_NUMBER_REQUIRED, temp);
    setB2bBillingAccountNumberRequired(responseJsonObj2, B2B_BILLING_ACCOUNT_NUMBER_REQUIRED, temp);
    setType(responseJsonObj2, ROUTING_TYPE, temp);
    setSecurityRequestNumber(responseJsonObj2, SECURITY_REQUEST_NUMBER, temp);

    return temp;

  }

  private void setSecurityRequestNumber(JSONObject responseJsonObj2, final String securityRequestNumber,
      InputApiRequest temp) {
    if (responseJsonObj2.get(securityRequestNumber) != null
        && !responseJsonObj2.get(securityRequestNumber).toString().isEmpty()) {
      temp.setSecurityRequestNumber(responseJsonObj2.get(securityRequestNumber).toString());
    }
  }

  private void setB2bBillingAccountNumberRequired(JSONObject responseJsonObj2,
      final String b2bBillingAccountNumberRequired, InputApiRequest temp) {
    if (responseJsonObj2.get(b2bBillingAccountNumberRequired) != null
        && !responseJsonObj2.get(b2bBillingAccountNumberRequired).toString().isEmpty()) {
      temp.setB2bBillingAccountNumberRequired(responseJsonObj2.get(b2bBillingAccountNumberRequired).toString());
    }
  }

  private void setB2bCustomerNumberRequired(JSONObject responseJsonObj2, final String b2bCustomerNumberRequired,
      InputApiRequest temp) {
    if (responseJsonObj2.get(b2bCustomerNumberRequired) != null
        && !responseJsonObj2.get(b2bCustomerNumberRequired).toString().isEmpty()) {
      temp.setB2bCustomerNumberRequired(responseJsonObj2.get(b2bCustomerNumberRequired).toString());
    }
  }

  private void setB2bAuthRequired(JSONObject responseJsonObj2, final String b2bAuthRequired, InputApiRequest temp) {
    if (responseJsonObj2.get(b2bAuthRequired) != null
        && !responseJsonObj2.get(b2bAuthRequired).toString().isEmpty()) {
      temp.setB2bAuthRequired(responseJsonObj2.get(b2bAuthRequired).toString());
    }
  }

  private void setOauthScopeLocation(JSONObject responseJsonObj2, final String oauthScopeLocation,
      InputApiRequest temp) {
    if (responseJsonObj2.get(oauthScopeLocation) != null
        && !responseJsonObj2.get(oauthScopeLocation).toString().isEmpty()) {
      temp.setOauthScopeLocation(responseJsonObj2.get(oauthScopeLocation).toString());
    }
  }

  private void setOauthScope(JSONObject responseJsonObj2, final String oauthScope, InputApiRequest temp) {
    if (responseJsonObj2.get(oauthScope) != null && !responseJsonObj2.get(oauthScope).toString().isEmpty()) {
      temp.setOauthScope(responseJsonObj2.get(oauthScope).toString());
    }
  }

  private void setOauthGrantLocation(JSONObject responseJsonObj2, final String oauthGrantTypeLocation,
      InputApiRequest temp) {
    if (responseJsonObj2.get(oauthGrantTypeLocation) != null
        && !responseJsonObj2.get(oauthGrantTypeLocation).toString().isEmpty()) {
      temp.setOauthGrantLocation(responseJsonObj2.get(oauthGrantTypeLocation).toString());
    }
  }

  private void setOauthTokenServiceURI(JSONObject responseJsonObj2, final String oauthTokenServiceUri,
      InputApiRequest temp) {
    if (responseJsonObj2.get(oauthTokenServiceUri) != null
        && !responseJsonObj2.get(oauthTokenServiceUri).toString().isEmpty()) {
      temp.setOauthTokenServiceURI(responseJsonObj2.get(oauthTokenServiceUri).toString());
    }
  }

  private void setOauthTokenServiceHost(JSONObject responseJsonObj2, final String oauthTokenServiceHost,
      InputApiRequest temp) {
    if (responseJsonObj2.get(oauthTokenServiceHost) != null
        && !responseJsonObj2.get(oauthTokenServiceHost).toString().isEmpty()) {
      temp.setOauthTokenServiceHost(responseJsonObj2.get(oauthTokenServiceHost).toString());
    }
  }

  private void setOauthCredentialsLocation(JSONObject responseJsonObj2, final String oauthUsernameLocation,
      InputApiRequest temp) {
    if (responseJsonObj2.get(oauthUsernameLocation) != null
        && !responseJsonObj2.get(oauthUsernameLocation).toString().isEmpty()) {
      temp.setOauthCredentialsLocation(responseJsonObj2.get(oauthUsernameLocation).toString());
    }
  }

  private void setOauthpw(JSONObject responseJsonObj2, final String oauthPassword, InputApiRequest temp) {
    if (responseJsonObj2.get(oauthPassword) != null && !responseJsonObj2.get(oauthPassword).toString().isEmpty()) {
      temp.setOauthpw(responseJsonObj2.get(oauthPassword).toString());
    }
  }

  private void setOauthUserName(JSONObject responseJsonObj2, final String oauthUsername, InputApiRequest temp) {
    if (responseJsonObj2.get(oauthUsername) != null && !responseJsonObj2.get(oauthUsername).toString().isEmpty()) {
      temp.setOauthUserName(responseJsonObj2.get(oauthUsername).toString());
    }
  }

  private void setOauthGrantType(JSONObject responseJsonObj2, final String oauthGrantType, InputApiRequest temp) {
    if (responseJsonObj2.get(oauthGrantType) != null
        && !responseJsonObj2.get(oauthGrantType).toString().isEmpty()) {
      temp.setOauthGrantType(responseJsonObj2.get(oauthGrantType).toString());
    }
  }

  private void setOauthSecret(JSONObject responseJsonObj2, final String oauthClientSecret, InputApiRequest temp) {
    if (responseJsonObj2.get(oauthClientSecret) != null
        && !responseJsonObj2.get(oauthClientSecret).toString().isEmpty()) {
      temp.setOauthSecret(responseJsonObj2.get(oauthClientSecret).toString());
    }
  }

  private void setOauthClientIdLocation(JSONObject responseJsonObj2, final String oauthClientIdLocation,
      InputApiRequest temp) {
    if (responseJsonObj2.get(oauthClientIdLocation) != null
        && !responseJsonObj2.get(oauthClientIdLocation).toString().isEmpty()) {
      temp.setOauthClientIdLocation(responseJsonObj2.get(oauthClientIdLocation).toString());
    }
  }

  private void setOauthClientId(JSONObject responseJsonObj2, final String oauthClientId, InputApiRequest temp) {
    if (responseJsonObj2.get(oauthClientId) != null && !responseJsonObj2.get(oauthClientId).toString().isEmpty()) {
      temp.setOauthClientId(responseJsonObj2.get(oauthClientId).toString());
    }
  }

  private void setEndpointBasicAuthPwAll(JSONObject responseJsonObj2, final String basicAuthPassword,
      InputApiRequest temp) {
    if (responseJsonObj2.get(basicAuthPassword) != null
        && !responseJsonObj2.get(basicAuthPassword).toString().isEmpty()) {
      temp.setEndpointBasicAuthPwAll(responseJsonObj2.get(basicAuthPassword).toString());
    }
  }

  private void setEndpointBasicAuthUserAll(JSONObject responseJsonObj2, final String basicAuthUser,
      InputApiRequest temp) {
    if (responseJsonObj2.get(basicAuthUser) != null && !responseJsonObj2.get(basicAuthUser).toString().isEmpty()) {
      temp.setEndpointBasicAuthUserAll(responseJsonObj2.get(basicAuthUser).toString());
    }
  }

  private void setEndpointAuth(JSONObject responseJsonObj2, final String endpointAuthType, InputApiRequest temp) {
    if (responseJsonObj2.get(endpointAuthType) != null
        && !responseJsonObj2.get(endpointAuthType).toString().isEmpty()) {
      temp.setEndpointAuth(responseJsonObj2.get(endpointAuthType).toString());
    }
  }

  private void setEnforceHttps(JSONObject responseJsonObj2, final String enforceHttps, InputApiRequest temp) {
    if (responseJsonObj2.get(enforceHttps) != null && !responseJsonObj2.get(enforceHttps).toString().isEmpty()) {
      temp.setEnforceHttps(responseJsonObj2.get(enforceHttps).toString());
    }
  }

  private void setBasicAuthUsers(JSONObject responseJsonObj2, final String authorizedUsers, InputApiRequest temp) {
    if (responseJsonObj2.get(authorizedUsers) != null
        && !responseJsonObj2.get(authorizedUsers).toString().isEmpty()) {
      temp.setBasicAuthUsers(responseJsonObj2.get(authorizedUsers).toString());
    }
  }

  private void setBasicAuthGroups(JSONObject responseJsonObj2, final String authorizedGroups, InputApiRequest temp) {
    if (responseJsonObj2.get(authorizedGroups) != null
        && !responseJsonObj2.get(authorizedGroups).toString().isEmpty()) {
      temp.setBasicAuthGroups(responseJsonObj2.get(authorizedGroups).toString());
    }
  }

  private void setAppkeyEnforceTaxonomy(JSONObject responseJsonObj2, final String enforceTaxonomy,
      InputApiRequest temp) {
    if (responseJsonObj2.get(enforceTaxonomy) != null
        && !responseJsonObj2.get(enforceTaxonomy).toString().isEmpty()) {
      temp.setAppkeyEnforceTaxonomy(responseJsonObj2.get(enforceTaxonomy).toString());
    }
  }

  private void setAppkeyEnforceDigest(JSONObject responseJsonObj2, final String enforceDigest, InputApiRequest temp) {
    if (responseJsonObj2.get(enforceDigest) != null && !responseJsonObj2.get(enforceDigest).toString().isEmpty()) {
      temp.setAppkeyEnforceDigest(responseJsonObj2.get(enforceDigest).toString());
    }
  }

  private void setProxyAuthExternal(JSONObject responseJsonObj2, final String validAuthTypesExt,
      InputApiRequest temp) {
    if (responseJsonObj2.get(validAuthTypesExt) != null
        && !responseJsonObj2.get(validAuthTypesExt).toString().isEmpty()) {
      temp.setProxyAuthExternal(responseJsonObj2.get(validAuthTypesExt).toString());
    }
  }

  private void setProxyAuthInternal(JSONObject responseJsonObj2, final String validAuthTypes, InputApiRequest temp) {
    if (responseJsonObj2.get(validAuthTypes) != null
        && !responseJsonObj2.get(validAuthTypes).toString().isEmpty()) {
      temp.setProxyAuthInternal(responseJsonObj2.get(validAuthTypes).toString());
    }
  }

  private void setGuid(JSONObject responseJsonObj2, final String resourceGuid, InputApiRequest temp) {
    if (responseJsonObj2.get(resourceGuid) != null && !responseJsonObj2.get(resourceGuid).toString().isEmpty()) {
      temp.setGuid(responseJsonObj2.get(resourceGuid).toString());
    }
  }

  private void setRoutingExpression(JSONObject responseJsonObj2, final String routingExpression,
      InputApiRequest temp) {
    if (responseJsonObj2.get(routingExpression) != null
        && !responseJsonObj2.get(routingExpression).toString().isEmpty()) {
      temp.setRoutingExpression(responseJsonObj2.get(routingExpression).toString());
    }
  }

  private void setEndpointPath(JSONObject responseJsonObj2, final String replaceUrlToValue, InputApiRequest temp) {
    if (responseJsonObj2.get(replaceUrlToValue) != null
        && !responseJsonObj2.get(replaceUrlToValue).toString().isEmpty()) {
      temp.setEndpointPath(responseJsonObj2.get(replaceUrlToValue).toString());
    }
  }

  private void setReplaceUrlFromValue(JSONObject responseJsonObj2, final String replaceUrlFromValue,
      InputApiRequest temp) {
    if (responseJsonObj2.get(replaceUrlFromValue) != null
        && !responseJsonObj2.get(replaceUrlFromValue).toString().isEmpty()) {
      temp.setReplaceUrlFromValue(responseJsonObj2.get(replaceUrlFromValue).toString());
    }
  }

  private void setOwningAppAppkey(JSONObject responseJsonObj2, final String owningApplicationKey,
      InputApiRequest temp) {
    if (responseJsonObj2.get(owningApplicationKey) != null
        && !responseJsonObj2.get(owningApplicationKey).toString().isEmpty()) {
      temp.setOwningAppAppkey(responseJsonObj2.get(owningApplicationKey).toString());
    }
  }

  private void setMalId(JSONObject responseJsonObj2, final String oawningApplicationId, InputApiRequest temp) {
    if (responseJsonObj2.get(oawningApplicationId) != null
        && !responseJsonObj2.get(oawningApplicationId).toString().isEmpty()) {
      temp.setMalId(responseJsonObj2.get(oawningApplicationId).toString());
    }
  }

  private void setConnectionKeepAlive(JSONObject responseJsonObj2, final String connectionKeepAlive,
      InputApiRequest temp) {
    if (responseJsonObj2.get(connectionKeepAlive) != null
        && !responseJsonObj2.get(connectionKeepAlive).toString().isEmpty()) {
      temp.setConnectionKeepAlive(responseJsonObj2.get(connectionKeepAlive).toString());
    }
  }

  private void setTimeoutSecs(JSONObject responseJsonObj2, final String timeoutSecs, InputApiRequest temp) {
    if (responseJsonObj2.get(timeoutSecs) != null && !responseJsonObj2.get(timeoutSecs).toString().isEmpty()) {
      temp.setTimeoutSecs(responseJsonObj2.get(timeoutSecs).toString());
    }
  }

  private void setThrottlingRequestsPerSec(JSONObject responseJsonObj2, final String throttlingRequestPerSec,
      InputApiRequest temp) {
    if (responseJsonObj2.get(throttlingRequestPerSec) != null
        && !responseJsonObj2.get(throttlingRequestPerSec).toString().isEmpty()) {
      temp.setThrottlingRequestsPerSec(responseJsonObj2.get(throttlingRequestPerSec).toString());
    }
  }

  private void setActive(JSONObject responseJsonObj2, final String active, InputApiRequest temp) {
    if (responseJsonObj2.get(active) != null && !responseJsonObj2.get(active).toString().isEmpty()) {
      temp.setActive(responseJsonObj2.get(active).toString());
    }
  }

  private void setExternal(JSONObject responseJsonObj2, final String externallyAvailable, InputApiRequest temp) {
    if (responseJsonObj2.get(externallyAvailable) != null
        && !responseJsonObj2.get(externallyAvailable).toString().isEmpty()) {
      temp.setExternal(responseJsonObj2.get(externallyAvailable).toString());
    }
  }

  private void setInternal(JSONObject responseJsonObj2, final String internallyAvailable, InputApiRequest temp) {
    if (responseJsonObj2.get(internallyAvailable) != null
        && !responseJsonObj2.get(internallyAvailable).toString().isEmpty()) {
      temp.setInternal(responseJsonObj2.get(internallyAvailable).toString());
    }
  }

  private void setType(JSONObject responseJsonObj2, final String routingType, InputApiRequest temp) {
    if (responseJsonObj2.get(routingType) != null && !responseJsonObj2.get(routingType).toString().isEmpty()) {
      temp.setType(responseJsonObj2.get(routingType).toString());
    }
  }

  private void setVersion(JSONObject responseJsonObj2, final String version, InputApiRequest temp) {
    if (responseJsonObj2.get(version) != null && !responseJsonObj2.get(version).toString().isEmpty()) {
      temp.setVersion(responseJsonObj2.get(version).toString());
    }
  }

  private void setResourceName(JSONObject responseJsonObj2, final String resourceName, InputApiRequest temp) {
    if (responseJsonObj2.get(resourceName) != null && !responseJsonObj2.get(resourceName).toString().isEmpty()) {
      temp.setResourceName(responseJsonObj2.get(resourceName).toString());
    }
  }

  private void setTaxonomy(JSONObject responseJsonObj2, final String resourceTaxonomy, InputApiRequest temp) {
    if (responseJsonObj2.get(resourceTaxonomy) != null
        && !responseJsonObj2.get(resourceTaxonomy).toString().isEmpty()) {
      temp.setTaxonomy(responseJsonObj2.get(resourceTaxonomy).toString());
    }
  }

  private void setSoap(JSONObject responseJsonObj2, final String serviceType, InputApiRequest temp) {
    if (responseJsonObj2.get(serviceType) != null && !responseJsonObj2.get(serviceType).toString().isEmpty()) {
      temp.setSoap(responseJsonObj2.get(serviceType).toString());
    }
  }

}
