package com.lumen.apiexchange.model.userprofile;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CreateUserResponse {

  private String email;
  private String firstName;
  private String lastName;
  private String userName;
  private String organizationName;
  private String developerId;
  private String status;
  private List<String> attributes;
  private List<String> apps;
  
  
  public CreateUserResponse() {
  }


  public CreateUserResponse(String email, String firstName, String lastName, String userName, String organizationName,
      String developerId, String status, List<String> attributes, List<String> apps) {
    super();
    this.email = email;
    this.firstName = firstName;
    this.lastName = lastName;
    this.userName = userName;
    this.organizationName = organizationName;
    this.developerId = developerId;
    this.status = status;
    this.attributes = attributes;
    this.apps = apps;
  }


  public String getEmail() {
    return email;
  }


  public void setEmail(String email) {
    this.email = email;
  }


  public String getFirstName() {
    return firstName;
  }


  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }


  public String getLastName() {
    return lastName;
  }


  public void setLastName(String lastName) {
    this.lastName = lastName;
  }


  public String getUserName() {
    return userName;
  }


  public void setUserName(String userName) {
    this.userName = userName;
  }


  public String getOrganizationName() {
    return organizationName;
  }


  public void setOrganizationName(String organizationName) {
    this.organizationName = organizationName;
  }


  public String getDeveloperId() {
    return developerId;
  }


  public void setDeveloperId(String developerId) {
    this.developerId = developerId;
  }


  public String getStatus() {
    return status;
  }


  public void setStatus(String status) {
    this.status = status;
  }


  public List<String> getAttributes() {
    return attributes;
  }


  public void setAttributes(List<String> attributes) {
    this.attributes = attributes;
  }


  public List<String> getApps() {
    return apps;
  }


  public void setApps(List<String> apps) {
    this.apps = apps;
  }


  @Override
  public String toString() {
    return "CreateUserResponse [email=" + email + ", firstName=" + firstName + ", lastName=" + lastName + ", userName="
        + userName + ", organizationName=" + organizationName + ", developerId=" + developerId + ", status=" + status
        + ", attributes=" + attributes + ", apps=" + apps + "]";
  }
  
  
}
