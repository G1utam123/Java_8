package com.lumen.apiexchange.controller;

import com.lumen.apiexchange.api.status.HeartbeatApi;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ESPHealthStatusResponse;
import com.lumen.apiexchange.service.ESPHealthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class HealthController implements HeartbeatApi {

  @Autowired
  private ESPHealthService espHealthService;


  @CrossOrigin
  @GetMapping(path = "/v1/health/esp")
  public ResponseEntity<ESPHealthStatusResponse> getESPHealthStatus() throws InternalServerException {
    return ResponseEntity.ok(espHealthService.getESPHealthStatus());
  }


}
