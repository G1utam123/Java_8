package com.lumen.apiexchange.controller;

import com.lumen.apiexchange.entity.ApiProduct;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.ProductNotFoundException;
import com.lumen.apiexchange.exception.UnauthorizedException;
import com.lumen.apiexchange.service.ApiProductsService;
import com.lumen.apiexchange.service.ProfileService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.security.Principal;
import java.util.List;
import java.util.UUID;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductsController {

  @Autowired
  private ApiProductsService apiProductsService;

  @Autowired
  private ProfileService profileService;

  protected static final Logger log = LoggerFactory.getLogger(ProductsController.class);
  
  public enum InternalExternal { 
      INTERNAL, 
      EXTERNAL;
  }

  public enum Planet { 
      PROD,
      NONPROD;
  }
    
  @CrossOrigin
  @GetMapping(path = "/v1/products")
  @ResponseStatus(HttpStatus.OK)
  @Operation(summary = "Gets a list of API Products", 
      description = "Gets a list of API Products from the API-HUB Cassandra DB.")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Resources found"),
      @ApiResponse(responseCode = "404", description = "No resources found matching the given criteria")})
  public List<ApiProduct> getProducts(@RequestParam Planet planet, 
      @RequestParam InternalExternal internalExternal) throws ProductNotFoundException {
    
    Boolean external = false;
    if (internalExternal.equals(InternalExternal.EXTERNAL)) {
      external = true;
    }

    return apiProductsService.getProductsInternalOrExternalByPlanet(planet.toString(), external);

  }

  @CrossOrigin
  @GetMapping(path = "/v1/products/{id}")   
  @ResponseStatus(HttpStatus.OK)
  @Operation(summary = "Returns an API Product",
      description = "Returns an API Product from the API-HUB Cassandra DB for the given id.")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Resource created"),
      @ApiResponse(responseCode = "404", description = "Resource not found")})
  public ApiProduct getProduct(@PathVariable UUID id, Principal principal) 
      throws ProductNotFoundException {
    
    return apiProductsService.getProduct(id);
  }
  
  @CrossOrigin
  @PostMapping(path = "/v1/products")
  @ResponseStatus(HttpStatus.CREATED)
  @Operation(summary = "Saves an API Product", description = "Saves an API Product to the API-HUB Cassandra DB.")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "201", description = "Resource created"),
      @ApiResponse(responseCode = "400", description = "Bad request")})
  public ApiProduct saveProduct(@Valid @RequestBody ApiProduct apiProduct,
      @AuthenticationPrincipal Jwt principal) throws BadInputException {
    
    String email = profileService.getEmailFromProfile(principal);
    apiProduct.setCreatedBy(email);
    apiProduct.setLastUpdatedBy(email);
    
    return apiProductsService.saveProduct(apiProduct);
    
  }

  @CrossOrigin
  @PutMapping(path = "/v1/products")
  @ResponseStatus(HttpStatus.OK)
  @Operation(summary = "Updates an API Product", description = "Updates an API Product to the API-HUB Cassandra DB.")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Resource updated"),
      @ApiResponse(responseCode = "400", description = "Bad request"),
      @ApiResponse(responseCode = "401", description = 
          "User not authorized to delete this resource. User must be the resource owner.")})
  public ApiProduct updateProduct(@Valid @RequestBody ApiProduct apiProduct,
      @AuthenticationPrincipal Jwt principal) throws BadInputException, ProductNotFoundException, 
      UnauthorizedException {
    
    String email = profileService.getEmailFromProfile(principal);
    
    return apiProductsService.updateProduct(apiProduct, email);
    
  }

  @CrossOrigin
  @DeleteMapping(path = "/v1/products/{id}")   
  @ResponseStatus(HttpStatus.NO_CONTENT)
  @Operation(summary = "Delete's an API Product",
      description = "Delete's an API Product from the API-HUB Cassandra DB for the given id.")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "204", description = "Product deleted"),
      @ApiResponse(responseCode = "404", description = "Product not found for id: {id}"),
      @ApiResponse(responseCode = "401", description = 
          "User not authorized to delete this resource. User must be the resource owner."),
      @ApiResponse(responseCode = "500", description = "Internal Server Error. Product not deleted for id: {id}"),
      })
  public void deleteProduct(@PathVariable UUID id, @AuthenticationPrincipal Jwt principal) throws 
      InternalServerException, ProductNotFoundException, UnauthorizedException {
    
    String userEmail = profileService.getEmailFromProfile(principal);

    apiProductsService.deleteProduct(id, userEmail);
    
  }

}
