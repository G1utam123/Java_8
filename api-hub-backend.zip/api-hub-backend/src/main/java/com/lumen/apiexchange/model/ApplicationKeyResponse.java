package com.lumen.apiexchange.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ApplicationKeyResponse {

  private ApplicationKeyResponseData applicationKeys;

  public ApplicationKeyResponseData getApplicationKeys() {
    return applicationKeys;
  }

  public void setApplicationKeys(ApplicationKeyResponseData applicationKeys) {
    this.applicationKeys = applicationKeys;
  }

}
