package com.lumen.apiexchange.exception;

import com.lumen.apiexchange.api.partner.model.Error422;
import com.lumen.apiexchange.api.partner.model.Error422Code;

public class OwnershipStatusAlreadyExistsException extends RuntimeException {

  private static final long serialVersionUID = 1L;
  private final Error422 error;


  public OwnershipStatusAlreadyExistsException(String reason, String message) {
    super(message);
    this.error = buildCommonCode422(reason, message);

  }

  private static Error422 buildCommonCode422(String reason, String message) {
    Error422 error = new Error422();
    error.code(Error422Code.INVALIDVALUE);
    error.setReason(reason);
    error.setMessage(message);
    return error;
  }

  public Error422 getError() {
    return error;
  }
  
}
