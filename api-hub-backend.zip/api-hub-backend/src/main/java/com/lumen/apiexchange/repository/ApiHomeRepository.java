package com.lumen.apiexchange.repository;

import com.lumen.apiexchange.entity.ApiHomeDetails;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApiHomeRepository extends JpaRepository<ApiHomeDetails, UUID> {

}
