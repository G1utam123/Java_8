package com.lumen.apiexchange.entity;

import java.sql.Timestamp;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;


@Entity
@Getter
@Setter
@Table(name = "apihomedetailsdata")
public class ApiHomeDetails {

  @Id
  private UUID id;
  private String name;
  private String description;
  private String category;
  private String author;
  private String type;
  private String status;
  private String version;
  @Column
  private Timestamp createdDate;
  private Timestamp lastUpdatedDate;
  private String oasUrl;
  private String sourceCodeUrl;

  public ApiHomeDetails() {
    super();
  }

  public ApiHomeDetails(final UUID id, final String category, final String name, final String description) {
    this.id = id;
    this.category = category;
    this.name = name;
    this.description = description;
  }

}
