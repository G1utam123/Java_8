package com.lumen.apiexchange.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lumen.apiexchange.entity.AuditTrail;
import com.lumen.apiexchange.repository.AuditTrailRepository;
import java.time.Instant;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Slf4j
@RequiredArgsConstructor
public class AuditableAspect {

  private final AuditTrailRepository auditTrailRepository;
  private final ObjectMapper objectMapper;

  @AfterReturning(value = "@annotation(auditable)", returning = "result")
  public void logAuditActivity(JoinPoint joinPoint, Auditable auditable, Object result)
      throws JsonProcessingException, IllegalAccessException {

    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

    if (authentication == null) {
      throw new IllegalAccessException("Authentication context not found");
    }

    Jwt principal = (Jwt) authentication.getPrincipal();

    if (principal == null) {
      throw new IllegalAccessException("Authenticated user not found");
    }

    String actionType = auditable.actionType().name();
    AuditTrail auditEntity = new AuditTrail();
    auditEntity.setId(UUID.randomUUID());
    auditEntity.setDate(Instant.now());
    auditEntity.setUsername(principal.getClaimAsString("email"));
    auditEntity.setAction(actionType);

    Object[] signatureArgs = joinPoint.getArgs();
    if (signatureArgs.length > 0) {
      //We may want to consider more than one object here!
      auditEntity.setDescription(objectMapper.writeValueAsString(signatureArgs[0]));
    }
    
    auditEntity.setResult(objectMapper.writeValueAsString(result));

    log.info("Auditing information: {}", auditEntity);

    auditTrailRepository.save(auditEntity);
  }

}
