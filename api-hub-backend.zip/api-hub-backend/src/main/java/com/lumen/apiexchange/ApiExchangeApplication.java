package com.lumen.apiexchange;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@SpringBootApplication
public class ApiExchangeApplication implements WebMvcConfigurer {

  public static void main(final String[] args) {
    SpringApplication.run(ApiExchangeApplication.class, args);

  }

}
