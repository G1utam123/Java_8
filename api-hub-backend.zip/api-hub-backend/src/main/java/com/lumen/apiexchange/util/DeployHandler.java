package com.lumen.apiexchange.util;

import com.lumen.apiexchange.config.ApigeeConfigProperties;
import com.lumen.apiexchange.config.MediationResourceConfigProperties;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.service.HostServiceImpl;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

@Service 
@EnableRetry
public class DeployHandler {

  private static final Logger log = LoggerFactory.getLogger(DeployHandler.class);

  @Autowired
  private HttpClient httpclient;

  @Autowired
  private ApigeeConfigProperties apigeeConfigProp;

  @Autowired
  private MediationResourceConfigProperties mediationResourceConfigProp;

  @Autowired
  private HostServiceImpl hostServiceImpl;

  @Retryable(value = IOException.class, maxAttempts = 3, backoff = @Backoff(delay = 5000))
  public ResponseEntity<String> deployApi(String env, String org, String mediatedResourceId)
      throws IOException, InternalServerException {

    log.info("Calling mediatedResource(Deploy)");

    String deployWhere = "";

    switch (org) {
      case "internal":
        deployWhere = "deployInternal";
        break;
      case "external":
        deployWhere = "deployExternal";
        break;
      default:
        throw new InternalServerException("Invalid Organization");
    }

    String myURL = hostServiceImpl.getEnvHostname(env) + mediationResourceConfigProp.getMediationResourceUri() + "/"
        + mediatedResourceId + "/" + deployWhere;

    log.info("myURL: " + myURL);

    String myRequest = "";

    return httpclient.sendRequest(myURL, HttpMethod.PUT.toString(), myRequest, apigeeConfigProp.getApigeeUser());

  }

}
