package com.lumen.apiexchange.service;

import com.lumen.apiexchange.exception.ForbiddenException;
import org.springframework.security.oauth2.jwt.Jwt;

public interface UserAuthorizationService {

  void isOkToDeployToProd(Jwt jwt) throws ForbiddenException;

  void isAuthorizedToUsePartnerProxy(Jwt jwt);
}
