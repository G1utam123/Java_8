package com.lumen.apiexchange.service;

import com.lumen.apiexchange.api.status.model.ApihubHeartbeatResponse;
import com.lumen.apiexchange.api.status.model.ElementStatus;
import com.lumen.apiexchange.client.WebhookStatusClient;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ESPHealthStatusResponse;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


@Service
@RequiredArgsConstructor
public class ESPHealthServiceImpl implements ESPHealthService {

  private static final Logger logger = LoggerFactory.getLogger(ESPHealthServiceImpl.class);

  private final WebhookStatusClient webhookStatusClient;

  public ESPHealthStatusResponse getESPHealthStatus() throws InternalServerException {
    logger.info("getESPHealthStatus() called");

    ResponseEntity<ApihubHeartbeatResponse> responseEntity = webhookStatusClient.getApihubHeartbeat();
    if (responseEntity.getStatusCode() != HttpStatus.OK) {
      throw new InternalServerException("Error getting ESP health status");
    }

    ApihubHeartbeatResponse heartbeatStatus  = responseEntity.getBody();
    Map<String, List<ElementStatus>> heartbeatMap  = heartbeatStatus.getHeartbeatList();
    ESPHealthStatusResponse espHealthStatusResponse = ESPHealthStatusResponse.builder()
            .espDev1(getLatestHeartbeatStatus(heartbeatMap.get("2")))
            .espDev2(getLatestHeartbeatStatus(heartbeatMap.get("3")))
            .espDev3(getLatestHeartbeatStatus(heartbeatMap.get("4")))
            .espDev4(getLatestHeartbeatStatus(heartbeatMap.get("5")))
            .espTest1(getLatestHeartbeatStatus(heartbeatMap.get("6")))
            .espTest2(getLatestHeartbeatStatus(heartbeatMap.get("7")))
            .espTest3(getLatestHeartbeatStatus(heartbeatMap.get("8")))
            .espTest4(getLatestHeartbeatStatus(heartbeatMap.get("9")))
            .espProd(getLatestHeartbeatStatus(heartbeatMap.get("10")))
            .build();
    return espHealthStatusResponse;

  }

  private Integer getLatestHeartbeatStatus(List<ElementStatus> list) throws InternalServerException {
    if (list != null && !list.isEmpty()) {
      ElementStatus lastElement = list.get(list.size() - 1);
      return lastElement.getStatus();
    } else {
      logger.error("One of the ESP environments has no status list");
      return 0;
    }
  }



}
