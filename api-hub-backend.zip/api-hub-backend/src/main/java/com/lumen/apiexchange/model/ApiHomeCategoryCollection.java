package com.lumen.apiexchange.model;

import com.lumen.apiexchange.entity.ApiHomeDetails;
import java.util.List;

public class ApiHomeCategoryCollection {

  private List<ApiHomeDetails> apis;

  public ApiHomeCategoryCollection() {
  }

  public ApiHomeCategoryCollection(
      final List<ApiHomeDetails> apiList) {
    super();
    apis = apiList;
  }


  public List<ApiHomeDetails> getApis() {
    return apis;
  }

 
  public void setApis(final List<ApiHomeDetails> apiList) {
    apis = apiList;
  }

}
