package com.lumen.apiexchange.controller;

import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.model.ApiMigrateRequest;
import com.lumen.apiexchange.model.ApiMigrationResult;
import com.lumen.apiexchange.model.ApplicationKey;
import com.lumen.apiexchange.model.BuildDeployResult;
import com.lumen.apiexchange.model.InputApiRequest;
import com.lumen.apiexchange.model.InputApiResponse;
import com.lumen.apiexchange.model.ProxyRequestModel;
import com.lumen.apiexchange.service.ApiAuthzService;
import com.lumen.apiexchange.service.ProfileService;
import com.lumen.apiexchange.service.ProxyService;
import io.swagger.v3.oas.annotations.Operation;
import java.util.List;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author ac38432
 */

@RestController
@RequiredArgsConstructor
public class ProxyController {

  private final ProxyService proxyService;
  
  private final ProfileService profileService;
  
  private final ApiAuthzService apiAuthzService;

  @CrossOrigin
  @GetMapping(path = "v1/taxonomies")
  public ResponseEntity<List<String>> getTaxonomies() throws InternalServerException {
    List<String> authorization = proxyService.getTaxonomies();
    return new ResponseEntity<List<String>>(authorization, HttpStatus.OK);
  }

  @CrossOrigin
  @GetMapping(path = "v1/applicationKeys")
  public ResponseEntity<List<ApplicationKey>> getApplicationKeys() throws InternalServerException {
    List<ApplicationKey> applicationList = proxyService.getApplicationKeys();
    return new ResponseEntity<List<ApplicationKey>>(applicationList, HttpStatus.OK);
  }

  @CrossOrigin
  @PostMapping(path = "v1/postProxyBuildDeploy")
  @ResponseStatus(HttpStatus.OK)
  public BuildDeployResult postProxyBuildDeploy(@RequestBody InputApiRequest proxyRequest)
      throws Exception {
    Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    return proxyService.postProxyRequest(proxyRequest, jwt);
  }

  @CrossOrigin
  @GetMapping(path = "v1/apiProxyDetails")
  @ResponseStatus(HttpStatus.OK)
  @Operation(summary = "Gets a list of API Proxies from ESP", description = "Gets a list of API Proxies from ESP"
      + " dependent on the query search parameters.")
  public ResponseEntity<List<ApiMediatedResource>> getProxyDetails(@AuthenticationPrincipal Jwt principal,
      @RequestParam String env, @RequestParam(name = "taxonomy", required = false)String taxonomy,
      @RequestParam(name = "resourceName", required = false)String resourceName,
      @RequestParam(name = "version", required = false)String version,
      @RequestParam(name = "internallyAvailable", required = false)String internallyAvailable,
      @RequestParam(name = "externallyAvailable", required = false)String externallyAvailable,
      @RequestParam(name = "active", required = false)String active,
      @RequestParam(name = "owningApplicationId", required = false)String owningApplicationId,
      @RequestParam(name = "owningApplicationKey", required = false)String owningApplicationKey,
      @RequestParam(name = "routingExpression", required = false)String routingExpression,
      @RequestParam(name = "resourceGuid", required = false)String resourceGuid,
      @RequestParam(name = "endpointAuthType", required = false)String endpointAuthType,
      @RequestParam(name = "source", required = false)String source,
      @RequestParam(name = "b2bAuthRequired", required = false)String b2bAuthRequired,
      @RequestParam(name = "createdBy", required = false)String createdBy,
      @RequestParam(name = "createdDate", required = false)String createdDate,
      @RequestParam(name = "updatedBy", required = false)String updatedBy,
      @RequestParam(name = "updatedDate", required = false)String updatedDate) throws InternalServerException {
    InputApiRequest inputApiRequest = new InputApiRequest();
    inputApiRequest.setEnv(env);
    inputApiRequest.setTaxonomy(taxonomy);
    inputApiRequest.setResourceName(resourceName);
    inputApiRequest.setVersion(version);
    inputApiRequest.setInternal(internallyAvailable);
    inputApiRequest.setExternal(externallyAvailable);
    inputApiRequest.setActive(active);
    inputApiRequest.setMalId(owningApplicationId);
    inputApiRequest.setOwningAppAppkey(owningApplicationKey);
    inputApiRequest.setRoutingExpression(routingExpression);
    inputApiRequest.setGuid(resourceGuid);
    inputApiRequest.setEndpointAuth(endpointAuthType);
    inputApiRequest.setSource(source);
    inputApiRequest.setB2bAuthRequired(b2bAuthRequired);
    inputApiRequest.setCreatedBy(createdBy);
    inputApiRequest.setCreatedDate(createdDate);
    inputApiRequest.setUpdatedBy(updatedBy);
    inputApiRequest.setUpdatedDate(updatedDate);
    
    String email = profileService.getEmailFromProfile(principal);
    
    List<ApiMediatedResource> apiResources =
        addMigrationPermissions(proxyService.getApiProxies(inputApiRequest), email);
    return new ResponseEntity<>(apiResources, HttpStatus.OK);
  }

  protected List<ApiMediatedResource> addMigrationPermissions(List<ApiMediatedResource> apiProxies, String email) {
    for (ApiMediatedResource api : apiProxies) {
      api.setAllowMigration(apiAuthzService.isUserAnApiOwner(email, api));
    }
    return apiProxies;
  }

  @CrossOrigin
  @GetMapping(path = "v1/apiEnvironments")
  public List<ApiMediatedResource> getProxyEnvironments(@RequestParam String resourceGuid)
      throws Exception {
    List<ApiMediatedResource> apiEnvResources = proxyService.getApiProxyEnvDetails(resourceGuid);
    return apiEnvResources;
  }

  @CrossOrigin
  @PostMapping(path = "v1/saveApiProxies")
  public ResponseEntity<ProxyRequestModel> saveApiProxies(@RequestBody ProxyRequestModel proxyRequestModel,
      @AuthenticationPrincipal Jwt principal) throws InternalServerException {
    String userName = profileService.getEmailFromProfile(principal);
    ProxyRequestModel response = proxyService.saveApiProxies(proxyRequestModel, userName);
    return new ResponseEntity<ProxyRequestModel>(response, HttpStatus.OK);
  }

  @CrossOrigin
  @DeleteMapping(path = "v1/deleteapiProxies/{apiId}")
  public String deleteApiProxies(@PathVariable("apiId") final UUID apiId) throws InternalServerException {
    proxyService.deleteproxiesFromDbWithApiId(apiId);
    return "OK";
  }

  @CrossOrigin
  @PostMapping(path = "v1/migrateApiProxies")
  public ResponseEntity<ApiMigrationResult> migrateApiProxies(@RequestBody ApiMigrateRequest apiMigrateRequest,
      @RequestHeader HttpHeaders headers) throws InternalServerException { 
    ApiMigrationResult apiMigResult = proxyService.migrateApiProxy(apiMigrateRequest);
    if (apiMigResult.getNotMigratedEnv().size() > 0) {
      return new ResponseEntity<ApiMigrationResult>(apiMigResult, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    return new ResponseEntity<ApiMigrationResult>(apiMigResult, HttpStatus.OK);
  }

}
