package com.lumen.apiexchange.service;

import com.lumen.apiexchange.entity.ApiDocumentation;
import com.lumen.apiexchange.entity.ApiHomeDetails;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ApiHomeCategoryCollection;
import com.lumen.apiexchange.model.ApiHomeRequest;
import com.lumen.apiexchange.model.ApiMediatedResponse;
import java.util.List;
import java.util.UUID;

public interface ApiService {

  List<ApiDocumentation> getApiDocumentation(UUID apiid);

  ApiDocumentation getApiDocumentationFile(int id);

  ApiDocumentation postApiDocumentation(ApiDocumentation apiDoc);

  ApiDocumentation updateDocumentation(ApiDocumentation apidoc);

  void deleteDocumentation(int id);

  ApiHomeCategoryCollection getApiHomeDetails();

  ApiHomeDetails postNewApiDetail(ApiHomeRequest apiHomeRequestModel, String name);

  ApiHomeDetails updateApiDetails(UUID id, ApiHomeRequest apiHomeRequestModel, String author);

  List<ApiDocumentation> updateSequence(List<ApiDocumentation> apiDocumentation);

  void deleteApiDetails(UUID apiid) throws InternalServerException;

  ApiMediatedResponse getApiProxies() throws InternalServerException;

}
