package com.lumen.apiexchange.exception;

import com.lumen.apiexchange.api.partner.model.Error500;

public class DuplicatedProxyException extends RuntimeException {

  private static final long serialVersionUID = 1L;
  private final Error500 error;

  public DuplicatedProxyException(String reason, String message) {
    super(message);
    this.error = BuildCommonCodeHelper.buildCommonCode500(reason, message);
  }

  public Error500 getError() {
    return error;
  }

}
