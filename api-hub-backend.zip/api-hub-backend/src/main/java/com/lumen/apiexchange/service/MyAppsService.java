package com.lumen.apiexchange.service;

import com.lumen.apiexchange.exception.AppNotFoundException;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.MyAppResponse;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.model.ProxyDetails;
import com.lumen.apiexchange.model.myapps.ApigeeAPIClientModel;
import com.lumen.apiexchange.model.myapps.CreateAppRequest;
import com.lumen.apiexchange.model.myapps.MyAppsModelResponse;
import com.lumen.apiexchange.model.myapps.UpdateAppRequest;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.http.ResponseEntity;

public interface MyAppsService {
  public MyAppsModelResponse getApigeeApiClientForEnterpriseId(String email)
      throws InternalServerException, BadInputException;

  public ApigeeAPIClientModel updateApp(UpdateAppRequest request, String email)
      throws InternalServerException, BadInputException, AppNotFoundException;

  public ResponseEntity<MyAppResponse> deleteAppFromApigee(String userName, String appName)
      throws InternalServerException;


  public ApigeeAPIClientModel createAppFromApigee(CreateAppRequest request, String email)
      throws InternalServerException, BadInputException;

  public List<ApiMediatedResource> getProxyDetails(UUID apiId) throws InternalServerException;
  
  public ResponseEntity<?> getApiProductsFromApigee() throws InternalServerException;
  
  public List<ProxyDetails> getProxyEnvDetails(UUID apiId) throws InternalServerException;

}
