package com.lumen.apiexchange.controller;

import com.lumen.apiexchange.entity.ApiDocumentation;
import com.lumen.apiexchange.entity.ApiHomeDetails;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ApiDetails;
import com.lumen.apiexchange.model.ApiHomeCategoryCollection;
import com.lumen.apiexchange.model.ApiHomeRequest;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.model.ProxyDetails;
import com.lumen.apiexchange.service.ApiService;
import com.lumen.apiexchange.service.MyAppsService;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


/**
 * @author ac38432
 */
@RestController
public class ApiController {

  @Autowired
  private ApiService apiService;

  @Autowired
  private MyAppsService myAppService;

  public ApiController(ApiService apiService) {
    this.apiService = apiService;
  }

  @CrossOrigin
  @GetMapping(path = "/welcome")
  public @ResponseBody String home() {
    return "Welcome to API Hub !! Change for checkin!";
  }

  @CrossOrigin
  @GetMapping(path = "v1/homedetails")
  public ApiHomeCategoryCollection getApiHome() {

    return apiService.getApiHomeDetails();
  }


  @CrossOrigin
  @GetMapping(path = "v1/documentation/{apiid}")
  public List<ApiDocumentation> getApiDocumentation(@PathVariable("apiid") final UUID apiid) {

    return apiService.getApiDocumentation(apiid);

  }

  @CrossOrigin
  @GetMapping(path = "v1/docFile/{id}")
  public ResponseEntity<Resource> getApiDocumentationFile(@PathVariable("id") final int id) {

    HttpHeaders headers = new HttpHeaders();
    headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
    headers.add("Pragma", "no-cache");
    headers.add("Expires", "0");
    headers.add("Content-Type", "application/json");
    headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=swaggerFile.yaml");
    String yaml = null;
    ApiDocumentation docFile = apiService.getApiDocumentationFile(id);
    if (docFile != null) {
      yaml = docFile.getFilecontent();
    } else {
      yaml = getResourceFileAsString("networkDiagnosticsSwagger_7.yaml");
    }
    return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_OCTET_STREAM)
        .body(new ByteArrayResource(yaml.getBytes()));

  }

  public static String getResourceFileAsString(String fileName) {
    InputStream is = getResourceFileAsInputStream(fileName);
    if (is != null) {
      BufferedReader reader = new BufferedReader(new InputStreamReader(is));
      return (String) reader.lines().collect(Collectors.joining(System.lineSeparator()));
    } else {
      throw new RuntimeException("resource not found");
    }
  }

  public static InputStream getResourceFileAsInputStream(String fileName) {
    ClassLoader classLoader = ApiController.class.getClassLoader();
    return classLoader.getResourceAsStream(fileName);
  }

  @CrossOrigin
  @PostMapping(path = "v1/newdoc")
  public ApiDocumentation addApiDocumentation(@RequestBody ApiDocumentation apiDocumentation) {
    return apiService.postApiDocumentation(apiDocumentation);
  }

  @CrossOrigin
  @PutMapping(path = "v1/editdoc")
  public ApiDocumentation updateApiDocumentation(@RequestBody ApiDocumentation apiDocumentation) {

    return apiService.updateDocumentation(apiDocumentation);
  }

  @CrossOrigin
  @DeleteMapping(path = "v1/documentation/{id}")
  public String deleteApiDocumentation(@PathVariable("id") final int id) {
    apiService.deleteDocumentation(id);
    return "OK";
  }

  @CrossOrigin
  @PostMapping(path = "v1/addnewapi")
  public ApiHomeDetails addNewApi(@AuthenticationPrincipal Jwt principal,
                                  @RequestBody ApiHomeRequest apiHomeRequestModel) {

    String name = principal.getClaimAsString("name");

    return apiService.postNewApiDetail(apiHomeRequestModel, name);
  }

  @CrossOrigin
  @PutMapping(path = "v1/updateapi/{id}")
  public ApiHomeDetails updateApiDetail(@PathVariable("id") final UUID id, @AuthenticationPrincipal Jwt principal,
                                        @RequestBody ApiHomeRequest apiHomeRequestModel) {

    String author = principal.getClaimAsString("name");

    return apiService.updateApiDetails(id, apiHomeRequestModel, author);
  }

  @CrossOrigin
  @PutMapping(path = "v1/updatesequence")
  public List<ApiDocumentation> updateApiSectionOrder(@RequestBody List<ApiDocumentation> apiDocumentation) {
    return apiService.updateSequence(apiDocumentation);
  }

  @CrossOrigin
  @DeleteMapping(path = "v1/deleteapi/{apiid}")
  public String deleteApiDetails(@PathVariable("apiid") final UUID apiid) throws InternalServerException {
    apiService.deleteApiDetails(apiid);
    return "OK";
  }

  @CrossOrigin
  @GetMapping(path = "v1/apiproxies")
  public ResponseEntity<List<ApiMediatedResource>> getApiProxies()
      throws InternalServerException {

    List<ApiMediatedResource> apiProxies = apiService.getApiProxies().getMediatedResource();
    return new ResponseEntity(apiProxies, HttpStatus.OK);
  }

  @CrossOrigin
  @GetMapping(path = "v1/documentationwithproxy/{apiId}")
  public ApiDetails getApiDocumentationProxy(@PathVariable("apiId") final UUID apiId) throws InternalServerException {

    ApiDetails details = new ApiDetails();
    List<ApiDocumentation> documentations = apiService.getApiDocumentation(apiId);
    List<ProxyDetails> proxies = myAppService.getProxyEnvDetails(apiId);
    details.setDocumentations(documentations);
    details.setProxies(proxies);
    return details;
  }

}
