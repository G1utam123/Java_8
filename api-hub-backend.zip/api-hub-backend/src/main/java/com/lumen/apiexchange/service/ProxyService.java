package com.lumen.apiexchange.service;

import com.lumen.apiexchange.exception.ForbiddenException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.model.ApiMigrateRequest;
import com.lumen.apiexchange.model.ApiMigrationResult;
import com.lumen.apiexchange.model.ApplicationKey;
import com.lumen.apiexchange.model.BuildDeployResult;
import com.lumen.apiexchange.model.InputApiRequest;
import com.lumen.apiexchange.model.ProxyRequestModel;
import java.io.IOException;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import org.springframework.security.oauth2.jwt.Jwt;

public interface ProxyService {

  List<String> getTaxonomies() throws InternalServerException;

  List<ApplicationKey> getApplicationKeys() throws InternalServerException;

  public BuildDeployResult postProxyRequest(InputApiRequest proxyRequest, Jwt jwt)
      throws IOException, ForbiddenException;

  List<ApiMediatedResource> getApiProxies(InputApiRequest inputApiRequest) throws InternalServerException;

  List<ApiMediatedResource> getApiProxyEnvDetails(String resourceGuid) 
      throws InternalServerException;

  public ProxyRequestModel saveApiProxies(ProxyRequestModel proxyRequestModel, String userName)
      throws InternalServerException;

  boolean deleteproxiesFromDbWithApiId(UUID apiId) throws InternalServerException;

  public ApiMigrationResult migrateApiProxy(ApiMigrateRequest apiMigrateRequest) throws InternalServerException;

}
