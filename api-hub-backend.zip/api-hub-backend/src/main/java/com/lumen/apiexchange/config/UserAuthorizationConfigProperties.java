package com.lumen.apiexchange.config;

import java.util.List;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "user.authorization")
public class UserAuthorizationConfigProperties {

  private PartnerProxy partnerProxy;

  @Data
  public static class PartnerProxy {
    private List<String> apiProducts;
  }


}
