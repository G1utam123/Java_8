package com.lumen.apiexchange.service;

import com.lumen.apiexchange.client.PortalFrameworkAuthClient;
import com.lumen.apiexchange.exception.UnauthorizedException;
import com.lumen.apiexchange.model.myapps.ProfileDetailsResponse;
import com.lumen.apiexchange.model.userprofile.CreateUserRequest;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ProfileService {

  protected static final Logger log = LoggerFactory.getLogger(ProfileService.class);

  private final PortalFrameworkAuthClient pfAuthClient;

  public String getEmailFromProfile(Jwt token) {

    String email = token.getClaimAsString("email");

    if (StringUtils.isBlank(email)) {
      ProfileDetailsResponse resp = pfAuthClient.getProfileDetails(token.getTokenValue());
      email = resp.getEmail();
    }

    if (StringUtils.isBlank(email)) {
      throw new UnauthorizedException("Could not find a valid email in the request");
    }

    return email.toLowerCase();
  }

  public CreateUserRequest getCreateUserRequestBody(String token) {

    ProfileDetailsResponse response = pfAuthClient.getProfileDetails(token);

    String email = response.getDetails().getEmailAddress().toLowerCase();
    String firstName = response.getDetails().getFirstName();
    String lastName = response.getDetails().getLastName();
    String userName = response.getDetails().getEmailAddress().toLowerCase();

    return new CreateUserRequest(email, firstName, lastName, userName);
  }

}
