package com.lumen.apiexchange.exception;

import org.springframework.http.HttpStatus;

public class CustomStatusResponse {

  private String message;
  private int statusCode;
  private HttpStatus status;

  public CustomStatusResponse() {}


  public CustomStatusResponse(String message, HttpStatus status) {
    this.message = message;
    this.status = status;
    this.statusCode = status.value();
  }


  public String getMessage() {
    return message;
  }


  public void setMessage(String message) {
    this.message = message;
  }


  public int getStatusCode() {
    return statusCode;
  }


  public void setStatusCode(int statusCode) {
    this.statusCode = statusCode;
  }


  public HttpStatus getStatus() {
    return status;
  }


  public void setStatus(HttpStatus status) {
    this.status = status;
  }





}
