package com.lumen.apiexchange.model.myapps;

import com.lumen.apiexchange.exception.InternalServerException;
import java.util.Base64;
import java.util.Date;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;



public class MediationHeaderUtil {

  private MediationHeaderUtil() {}

  private static Logger logger = LoggerFactory.getLogger(MediationHeaderUtil.class);

  protected static final String KEY_HEADER_NAME = "X-Level3-Application-Key";
  protected static final String TIME_HEADER_NAME = "X-Level3-Digest-Time";
  protected static final String DIGEST_HEADER_NAME = "X-Level3-Digest";

  public static void addMediationHeaders(HttpHeaders headers, String appKey, String appKeySecret)
      throws InternalServerException {
    String digestTime = String.valueOf(new Date().getTime());
    try {
      String digest = encrypt(appKeySecret, digestTime);
      headers.set(DIGEST_HEADER_NAME, digest);
    } catch (Exception e) {
      logger.error("Error setting header secret for mediation. {}", e);
      throw new InternalServerException("apigee header is not able to create" + e.getMessage());
    }
    headers.set(KEY_HEADER_NAME, appKey);
    headers.set(TIME_HEADER_NAME, digestTime);
  }


  public static void addMediationHeadersDelete(HttpHeaders headers, String appKey, String appKeySecret)
      throws InternalServerException {
    String digestTime = String.valueOf(new Date().getTime());
    try {
      String digest = encrypt(appKeySecret, digestTime);
      headers.set("X-Digest", digest);
      headers.set("X-Application-Key", appKey);
      headers.set("X-Digest-Time", digestTime);
    } catch (Exception e) {
      logger.error("Error setting header secret for mediation. {}", e);
      throw new InternalServerException("idmgr delete header is not able to create" + e.getMessage());
    }

  }

  public static HttpHeaders getMediationHeaders(String appKey, String appKeySecret) throws InternalServerException {
    HttpHeaders headers = new HttpHeaders();
    addMediationHeaders(headers, appKey, appKeySecret);
    return headers;
  }

  private static String encrypt(String key, String data) throws InternalServerException {
    Mac encode;
    try {
      encode = Mac.getInstance("HmacSHA256");

      SecretKeySpec secretKey = new SecretKeySpec(key.getBytes(), "HmacSHA256");
      encode.init(secretKey);
      byte[] result = encode.doFinal(data.getBytes());

      return Base64.getEncoder().encodeToString(result);
    } catch (Exception e) {

      throw new InternalServerException("Error in ecrypting the apigee headers" + e.getMessage());
    }

  }
}
