package com.lumen.apiexchange.exception;

public class OwnershipStatusNotFoundException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public OwnershipStatusNotFoundException(String message) {
    super(message);
  }

}
