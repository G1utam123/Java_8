package com.lumen.apiexchange.model.snow;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ServiceNowResult {

  @JsonProperty("sys_id")
  private String sysId;

  private String number;

  @JsonProperty("$$uiNotification")
  private String[] uiNotification;

  @JsonProperty("request_number")
  private String requestNumber;

  @JsonProperty("parent_id")
  private String parentId;

  @JsonProperty("request_id")
  private String requestId;

  @JsonProperty("parent_table")
  private String parentTable;

  private String table;
}
