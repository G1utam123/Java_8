package com.lumen.apiexchange.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class FeedbackMessage {

  @NotBlank(message = "First name is mandatory")
  private String firstName;

  @NotBlank(message = "Last name is mandatory")
  private String lastName;

  @Email
  @NotBlank(message = "Email is mandatory")
  private String email;

  private String phoneNumber;

  @NotBlank(message = "Message is mandatory")
  private String message;

}
