package com.lumen.apiexchange.model;

import com.lumen.apiexchange.entity.ProxyResponse;
import java.util.List;

public class ProxyRequestModel {

  private List<ProxyResponse> proxyResponse;

  public List<ProxyResponse> getProxyResponse() {
    return proxyResponse;
  }

  public void setProxyResponse(List<ProxyResponse> proxyResponse) {
    this.proxyResponse = proxyResponse;
  }

}
