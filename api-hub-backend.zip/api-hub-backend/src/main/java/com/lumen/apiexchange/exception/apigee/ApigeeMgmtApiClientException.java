package com.lumen.apiexchange.exception.apigee;

public class ApigeeMgmtApiClientException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public ApigeeMgmtApiClientException(String message) {
    super(message);
  }

}
