package com.lumen.apiexchange.service;

import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.userprofile.CreateUserRequest;
import org.springframework.http.ResponseEntity;

public interface UserService {

  public ResponseEntity<?> createUserInApigee(CreateUserRequest request) throws InternalServerException;
  
}
