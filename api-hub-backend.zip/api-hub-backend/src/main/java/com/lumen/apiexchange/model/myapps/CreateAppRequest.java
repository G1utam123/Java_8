package com.lumen.apiexchange.model.myapps;

import java.util.List;

public class CreateAppRequest {

  private List<Credentials> credentials;
  private String name;
  private int keyExpiresIn;
  private String status;
  private List<Attribute> attributes;

  public List<Credentials> getCredentials() {
    return credentials;
  }

  public void setCredentials(List<Credentials> credentials) {
    this.credentials = credentials;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public int getKeyExpiresIn() {
    return keyExpiresIn;
  }

  public void setKeyExpiresIn(int keyExpiresIn) {
    this.keyExpiresIn = keyExpiresIn;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public List<Attribute> getAttributes() {
    return attributes;
  }

  public void setAttributes(List<Attribute> attributes) {
    this.attributes = attributes;
  }

  @Override
  public String toString() {
    return "CreateAppRequest [credentials=" + credentials + ", name=" + name + ", keyExpiresIn=" + keyExpiresIn
        + ", status=" + status + ", attributes=" + attributes + "]";
  }

}
