package com.lumen.apiexchange.controller;

import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.userprofile.CreateUserRequest;
import com.lumen.apiexchange.service.ProfileService;
import com.lumen.apiexchange.service.UserService;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

  @Autowired
  private ProfileService profileService;
  
  @Autowired
  private UserService userService;

  protected static final Logger log = LoggerFactory.getLogger(UserController.class);

  @CrossOrigin
  @PostMapping(value = "/v1/createuser")
  @ResponseStatus(code = HttpStatus.CREATED)
  public ResponseEntity<?> createApigeeUser(@RequestHeader HttpHeaders headers) throws InternalServerException {
    
    List<String> authHeader = headers.get("authorization");
    CreateUserRequest createUserRequest = profileService.getCreateUserRequestBody(authHeader.get(0));
    
    return userService.createUserInApigee(createUserRequest);
  }
}
