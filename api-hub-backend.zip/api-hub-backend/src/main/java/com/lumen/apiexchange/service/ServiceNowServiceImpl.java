package com.lumen.apiexchange.service;

import com.lumen.apiexchange.client.ServiceNowClient;
import com.lumen.apiexchange.entity.OwnershipStatus;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.OwnershipStatusAlreadyExistsException;
import com.lumen.apiexchange.exception.OwnershipStatusNotFoundException;
import com.lumen.apiexchange.model.snow.ServiceNowCreateGroupRequest;
import com.lumen.apiexchange.model.snow.ServiceNowRequest;
import com.lumen.apiexchange.model.snow.ServiceNowVariable;
import com.lumen.apiexchange.repository.OwnershipRepository;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;


@Service
@RequiredArgsConstructor
public class ServiceNowServiceImpl implements ServiceNowService {

  protected static final Logger log = LoggerFactory.getLogger(ServiceNowServiceImpl.class);

  @Value("${servicenow.systemid}")
  private String snSystemId;

  @Value("${servicenow.primaryowner}")
  private String snPrimaryOwner;

  @Value("${servicenow.productactivedirectoryou}")
  private String productActiveDirectoryOu;

  @Value("${servicenow.proxyactivedirectoryou}")
  private String proxyActiveDirectoryOu;

  @Value("${servicenow.secondaryowner}")
  private String snSecondaryOwner;

  @Value("${servicenow.systemparamguid}")
  private String snSystemParamGuid;

  @Value("${servicenow.snapihubusersysid}")
  private String openedBy;
  
  private final ServiceNowClient serviceNowClient;
  
  @Autowired
  @Qualifier("txtTemplateEngine")
  private final SpringTemplateEngine springTxtTemplateEngine;

  private final OwnershipRepository ownershipRepo;

  @Autowired
  private OwnershipStatusService ownershipStatusService;


  @Override
  public String createGroup(ServiceNowRequest serviceNowRequest)
      throws InternalServerException, OwnershipStatusAlreadyExistsException {
    try {
      String elementName = serviceNowRequest.getElementName().toUpperCase();
      OwnershipStatus ownershipStatus = ownershipStatusService.getOwnershipStatus(elementName);
      String reason = "Ownership status already exists for element";
      String message = reason + elementName + " with status: " + ownershipStatus.getStatus();
      log.info(message);
      throw new OwnershipStatusAlreadyExistsException(message, reason);
    } catch (OwnershipStatusNotFoundException e) {
      log.info("Ownership status does not exist for element: " + serviceNowRequest.getElementName().toUpperCase());
    }

    String description = buildShortDescription(serviceNowRequest);
    log.info("template-" + description);

    String requesterSysId = serviceNowClient.getUserSysId(serviceNowRequest.getRequester());

    ServiceNowVariable serviceNow = ServiceNowVariable.builder()
        .primaryOwner((requesterSysId != null) ? requesterSysId : openedBy)
        .azureSync(false)
        .requestAction("Add")
        .comments(description)
        .requestType("Active Directory Security Group")
        .groupName("This is an automated API-HUB request please check the description")
        .secondaryOwner(snSecondaryOwner)
        .purposeOfShare("API HUB Ownership groups")
        .requestedFor((requesterSysId != null) ? requesterSysId : openedBy)
        .openedBy(openedBy).build();

    ServiceNowCreateGroupRequest request = ServiceNowCreateGroupRequest.builder()
        .sysparmQuantity("1")
        .sysparmItemGuid(snSystemParamGuid)
        .getPortalMessages("true")
        .sysparmNoValidation("true")
        .sysparmRequestedFor((requesterSysId != null) ? requesterSysId : openedBy)
        .variables(serviceNow).build();

    String snowReqNumber = serviceNowClient.getSysIdFromServiceNow(request);

    // Define and update Ownership object
    OwnershipStatus ownership = OwnershipStatus.builder()
        .id(UUID.randomUUID())
        .elementType(serviceNowRequest.getElementType())
        .requestNo(snowReqNumber)
        .status("PROVISIONING")
        .requester(serviceNowRequest.getRequester())
        .elementId(serviceNowRequest.getElementName()).build();
    ownershipRepo.save(ownership);

    return snowReqNumber;
  }

  private String buildShortDescription(ServiceNowRequest serviceNowRequest) {
    String activeDirectoryOu = null;

    if (serviceNowRequest.getElementType().equals("proxy")) {
      activeDirectoryOu = proxyActiveDirectoryOu;
    } else if (serviceNowRequest.getElementType().equals("product")) {
      activeDirectoryOu = productActiveDirectoryOu;
    }
    Context context = new Context();
    context.setVariable("activeDirectoryOU", activeDirectoryOu);
    context.setVariable("elementType", serviceNowRequest.getElementType().toUpperCase());
    context.setVariable("elementName", serviceNowRequest.getElementName().replace(" ", "-").toUpperCase());
    context.setVariable("admins", serviceNowRequest.getAdmins());
    context.setVariable("owners", serviceNowRequest.getOwners());
    return springTxtTemplateEngine.process("snow-group-request", context);
  }
  
}
