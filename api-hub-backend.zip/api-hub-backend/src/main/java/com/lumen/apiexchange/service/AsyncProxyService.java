package com.lumen.apiexchange.service;

import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.model.AsyncBuildDeployResult;
import com.lumen.apiexchange.model.BuildDeployResult;
import com.lumen.apiexchange.model.InputApiRequest;
import java.util.concurrent.CompletableFuture;

public interface AsyncProxyService {

  CompletableFuture<ApiMediatedResource> getApiProxyEnvDetails(String resourceGuid, String host)
      throws InternalServerException;

  CompletableFuture<ApiMediatedResource> getApiProxyDetails(String env, String taxonomy,
      String resourceName, String version);

  CompletableFuture<AsyncBuildDeployResult> buildDeployApi(InputApiRequest inputapirequest);
  
  void buildDeployAsync(InputApiRequest inputapirequest, BuildDeployResult buildDeployResult);

}
