package com.lumen.apiexchange.exception;

public class OwnershipStatusUniqueRecordNotFoundException extends RuntimeException {

  private static final long serialVersionUID = 1L;
  
  public OwnershipStatusUniqueRecordNotFoundException(String message) {
    super(message);
  }
}
