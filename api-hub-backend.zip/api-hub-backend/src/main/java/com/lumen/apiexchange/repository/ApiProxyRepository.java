package com.lumen.apiexchange.repository;

import com.lumen.apiexchange.entity.ProxyResponse;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApiProxyRepository extends JpaRepository<ProxyResponse, UUID> {


  List<ProxyResponse> findByApiid(UUID apiId);

}
