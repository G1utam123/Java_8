package com.lumen.apiexchange.repository;

import com.lumen.apiexchange.entity.AuditTrail;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuditTrailRepository extends JpaRepository<AuditTrail, UUID> {
}
