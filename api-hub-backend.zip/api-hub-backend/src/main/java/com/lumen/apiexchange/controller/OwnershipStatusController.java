package com.lumen.apiexchange.controller;

import com.lumen.apiexchange.entity.OwnershipStatus;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.OwnershipStatusUniqueRecordNotFoundException;
import com.lumen.apiexchange.repository.OwnershipRepository;
import com.lumen.apiexchange.service.OwnershipStatusService;
import java.util.NoSuchElementException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;




@RestController
public class OwnershipStatusController {

  @Autowired
  private OwnershipStatusService ownershipStatusService;

  @Autowired
  private OwnershipRepository ownershipRepository;

  @CrossOrigin
  @GetMapping(path = "/v1/ownerships/{elementId}")
  public ResponseEntity<OwnershipStatus> getOwnershipStatus(@PathVariable("elementId") String elementId) throws
      InternalServerException, OwnershipStatusUniqueRecordNotFoundException {
    OwnershipStatus ownershipStatus = ownershipStatusService.getOwnershipStatus(elementId.toUpperCase());
    if (ownershipStatus == null) {
      return ResponseEntity.noContent().build();
    }
    return ResponseEntity.ok(ownershipStatus);
  }

  @CrossOrigin
  @DeleteMapping(path = "/v1/ownerships/{elementId}")
  public ResponseEntity<Void> deleteOwnershipStatus(@PathVariable("elementId") String elementId) throws
      InternalServerException, OwnershipStatusUniqueRecordNotFoundException {
    OwnershipStatus ownershipStatus = ownershipStatusService.getOwnershipStatus(elementId.toUpperCase());
    if (ownershipStatus == null) {
      return ResponseEntity.noContent().build();
    }
    ownershipRepository.deleteById(ownershipStatus.getId());
    return new ResponseEntity<Void>(HttpStatus.OK);
  }
  
  @CrossOrigin
  @GetMapping(path = "/v1/ownerships")
  @Validated
  public Page<OwnershipStatus> getOwnerships(
      @RequestParam(value = "status", required = false) String status,
      @RequestParam(value = "type", required = false) String elementType,
      @PageableDefault(size = 10, sort = "id") Pageable pageable)
      throws InternalServerException {
    validateStatus(status);
    validateElementType(elementType);

    Page<OwnershipStatus> ownershipPage;

    if (status != null && elementType != null) {
      ownershipPage = ownershipStatusService.getOwnershipStatusByTypeAndStatus(
              elementType.toUpperCase(), status.toUpperCase(), pageable);
    } else if (status != null) {
      ownershipPage = ownershipStatusService.getOwnershipStatusByStatus(status.toUpperCase(), pageable);
    } else if (elementType != null) {
      ownershipPage = ownershipStatusService.getOwnershipStatusByType(elementType.toUpperCase(), pageable);
    } else {
      ownershipPage = ownershipStatusService.getOwnerships(pageable);
    }

    return ownershipPage;
  }

  private void validateStatus(String status) throws BadInputException {
    if (status != null
        && (!status.equalsIgnoreCase("PROVISIONING")
        && !status.equalsIgnoreCase("PROVISIONED")))  {
      throw new BadInputException("Invalid 'status' value. Valid values are: 'provisioning', 'provisioned'.");
    }
  }

  private void validateElementType(String elementType) throws BadInputException {
    if (elementType != null
        && (!elementType.equalsIgnoreCase("PRODUCT")
        && !elementType.equalsIgnoreCase("PROXY")))  {
      throw new BadInputException("Invalid element 'type' value. Valid values are: product, proxy");
    }
  }
 
  @CrossOrigin
  @PutMapping(path = "/v1/ownerships")
  public ResponseEntity<OwnershipStatus> updateOwnership(
      @Validated(OwnershipStatus.PutValidation.class)
      @RequestBody OwnershipStatus ownership)
      throws BadInputException, NoSuchElementException, InternalServerException,
      OwnershipStatusUniqueRecordNotFoundException {
    OwnershipStatus ownershipStatus = ownershipStatusService.updateOwnership(ownership);
    return ResponseEntity.ok(ownershipStatus);
  }

}
