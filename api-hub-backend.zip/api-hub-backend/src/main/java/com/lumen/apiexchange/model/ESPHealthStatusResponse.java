package com.lumen.apiexchange.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ESPHealthStatusResponse {

  @JsonProperty("ESP-DEV1")
  private int espDev1;

  @JsonProperty("ESP-DEV2")
  private int espDev2;

  @JsonProperty("ESP-DEV3")
  private int espDev3;

  @JsonProperty("ESP-DEV4")
  private int espDev4;

  @JsonProperty("ESP-TEST1")
  private int espTest1;

  @JsonProperty("ESP-TEST2")
  private int espTest2;

  @JsonProperty("ESP-TEST3")
  private int espTest3;

  @JsonProperty("ESP-TEST4")
  private int espTest4;

  @JsonProperty("ESP-PROD")
  private int espProd;

}
