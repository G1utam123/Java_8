package com.lumen.apiexchange.service.apigee;

import com.lumen.apiexchange.api.partner.model.PartnerEndpoint;
import com.lumen.apiexchange.api.partner.model.PartnerProxy;
import com.lumen.apiexchange.client.apigee.ApigeeMgmtApiClient;
import com.lumen.apiexchange.config.PartnerProxyConfigProperties;
import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.exception.NotFoundException;
import com.lumen.apiexchange.exception.PartnerProxyAddToProductException;
import com.lumen.apiexchange.exception.ProductNotFoundException;
import com.lumen.apiexchange.exception.UnauthorizedException;
import com.lumen.apiexchange.exception.apigee.ApigeeMgmtApiClientException;
import com.lumen.apiexchange.model.apigee.ApigeeProduct;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.Access;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.AccessLocation;
import com.lumen.apiexchange.model.apigee.ApigeeProductHubRequest.Planet;
import com.lumen.apiexchange.model.apigee.ApigeeProductRequest;
import com.lumen.apiexchange.model.apigee.ApigeeProductRequest.ApprovalType;
import com.lumen.apiexchange.model.apigee.ApigeeProductRequest.QuotaTimeUnit;
import com.lumen.apiexchange.model.apigee.ApigeeProductResponse;
import com.lumen.apiexchange.model.apigee.Attribute;
import com.lumen.apiexchange.service.EmailBasedAuthzServiceImpl;
import com.lumen.apiexchange.util.BuildHandler;
import io.micrometer.core.instrument.util.StringUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

@RequiredArgsConstructor
@Service
public class ApigeeProductsService {

  protected static final Logger log = LoggerFactory.getLogger(ApigeeProductsService.class);
  private final ApigeeMgmtApiClient apigeeMgmtApiClient;
  private final EmailBasedAuthzServiceImpl emailBasedAuthzSvc;
  private final ApigeeEnvironmentsServiceImpl apigeeEnvService;
  private final PartnerProxyConfigProperties partnerProxyConfigProperties;
  
  public ApigeeProductResponse getProducts(String planet, String org, String productOwner) 
      throws ProductNotFoundException {

    ApigeeProductResponse productList = apigeeMgmtApiClient.getProducts(planet, org);
    
    if (productList.getApiProduct() == null || productList.getApiProduct().isEmpty()) {
      String reason = String.format("No products found for planet: %s, org: %s and productOwner: %s",
          planet, org, productOwner);
      log.warn(reason);
      throw new ProductNotFoundException(reason);
    }

    if (StringUtils.isNotBlank(productOwner)) {
      productList = getMyProductsOnly(productList, productOwner);
      if (productList.getApiProduct().isEmpty()) {
        String reason = String.format("No products found for planet: %s, org: %s and productOwner: %s",
            planet, org, productOwner);
        log.warn(reason);
        throw new ProductNotFoundException(reason);
      }

    }

    return productList;
    
  }

  public ApigeeProduct getProduct(String name, String planet, String org)
      throws ProductNotFoundException {

    ApigeeProduct product;
    
    try {
      
      product = apigeeMgmtApiClient.getProduct(name, planet, org);
      
    } catch (HttpClientErrorException e) {
      String reason = String.format("Product not found for name: %s in planet: %s and org: %s", name, planet, org);
      log.warn(reason, e);
      throw new ProductNotFoundException(reason);
    }
    
    if (product == null) {
      String reason = String.format("Product not found for name: %s in planet: %s and org: %s", name, planet, org);
      log.warn(reason);
      throw new ProductNotFoundException(reason);
    }
    return product;

  }

  /**
  *  **Warning from Apigee:**
  *  * If you don't specify an API proxy in the request body, any app associated with the API product can make calls
  *    to any API in your entire organization.
  *    -   
  *  * If you don't specify an environment in the request body, the API product allows access to all environments.    
  */
  public ApigeeProduct saveProduct(ApigeeProductHubRequest hubProduct) throws BadInputException {

    validateRequest(hubProduct);
    hubProduct.getApigeeProductRequest().setAttributes(setCustomAttributes(hubProduct));

    try {
      return apigeeMgmtApiClient.saveProduct(hubProduct);
    } catch (HttpClientErrorException e) {
      String reason = String.format("Product not saved for name: %s in planet: %s and org: %s",
          hubProduct.getApigeeProductRequest().getName(), hubProduct.getPlanet().toString(),
          hubProduct.getAccessLocation().toString());
      log.error(reason, e);
      throw new ApigeeMgmtApiClientException(reason);
    }

  }

  public ApigeeProduct updateProduct(String name, ApigeeProductHubRequest hubProduct, String userEmail)
      throws BadInputException, ProductNotFoundException, UnauthorizedException {

    /*This productOwner email check on the old Product is only temporary until we get the full IAM solution 
     * built out with Admin groups.
     */
    ApigeeProduct oldProduct = getProduct(name, hubProduct.getPlanet().toString(), 
        hubProduct.getAccessLocation().toString());
    
    // Add tests for HttpClientErrorException
    
    if (isUserTheProductOwnerOrHubAdmin(oldProduct.getAttributes(), userEmail)) {
      try {
        return apigeeMgmtApiClient.updateProduct(name, hubProduct); 
      } catch (HttpClientErrorException e) {
        String reason = String.format("Unable to update Product: %s.", name);
        log.error(reason, e);
        throw new ApigeeMgmtApiClientException(e.getMessage());
      }
    } else {
      String reason = String.format("User not authorized to update this Product: %s " 
            + "User must be the Product owner. User: %s", name, userEmail);
      log.error(reason);
      throw new UnauthorizedException(reason);
    }

  }

  public ApigeeProduct updatePartnerProxyProduct(Planet planet, ApigeeProduct apigeeProduct) {

    ApigeeProductHubRequest hubProduct = new ApigeeProductHubRequest();
    hubProduct.setAccessLocation(AccessLocation.INTERNAL);
    hubProduct.setPlanet(planet);
    hubProduct.setApigeeProductRequest(mapApigeeProductToApigeeProductRequest(apigeeProduct));
    
    try {
      return apigeeMgmtApiClient.updateProduct(apigeeProduct.getName(), hubProduct); 
    } catch (HttpClientErrorException e) {
      String reason = String.format("Unable to update product %s in planet: %s and org: %s", apigeeProduct.getName(),
          planet, AccessLocation.INTERNAL);
      log.warn(reason, e);
      throw new ApigeeMgmtApiClientException(reason);
    }

  }

  public void deleteProduct(String name, String userEmail, String planet, String org)
      throws InternalServerException, ProductNotFoundException, UnauthorizedException {
    
    // This CreatedBy email check is only temporary until we get the full IAM solution built out.
    ApigeeProduct oldProduct = getProduct(name, planet, org);
    if (isUserTheProductOwnerOrHubAdmin(oldProduct.getAttributes(), userEmail)) {
      try {
        apigeeMgmtApiClient.deleteProduct(name, planet, org);
      } catch (HttpClientErrorException e) {
        String reason = String.format("Unable to delete product %s in planet: %s and org: %s", name, planet, org);
        log.warn(reason, e);
        throw new ApigeeMgmtApiClientException(reason);
      }
    } else {
      String reason = String.format("User not authorized to delete this Product: %s " 
          + "User must be the Product owner. User: %s", name, userEmail);
      log.error(reason);
      throw new UnauthorizedException(reason);
    }
    
  }
 
  void validateRequest(ApigeeProductHubRequest hubProduct) throws BadInputException {

    if (hubProduct.getApigeeProductRequest() == null) {
      String reason = "apigeeProductRequest: Missing required request.";
      log.error(reason);
      throw new BadInputException(reason);      
    }
    
    if (hubProduct.getApigeeProductRequest().getProxies() == null
        || hubProduct.getApigeeProductRequest().getProxies().isEmpty()) {
      String reason = "proxies: At least one proxy is required.";
      log.error(reason);
      throw new BadInputException(reason);      
    }
    
    if (hubProduct.getProductOwner() == null || hubProduct.getProductOwner().isEmpty()) {
      String reason = "productOwner: Product Owner is requried.";
      log.error(reason);
      throw new BadInputException(reason);      
    }

    if (hubProduct.getApigeeProductRequest().getEnvironments() == null 
        || hubProduct.getApigeeProductRequest().getEnvironments().isEmpty()) {
      String reason = "environments: At least one environment is required.";
      log.error(reason);
      throw new BadInputException(reason);      
    }
    
    apigeeEnvService.validateEnvironments(hubProduct.getPlanet().toString(), hubProduct.getAccessLocation().toString(), 
        hubProduct.getApigeeProductRequest().getEnvironments());
    
  }
  
  List<Attribute> setCustomAttributes(ApigeeProductHubRequest hubProduct) {

    List<Attribute> attributes = hubProduct.getApigeeProductRequest().getAttributes();
    if (attributes == null) {
      attributes = new ArrayList<>();
    }
    
    attributes.add(new Attribute("PRODUCT_OWNER", hubProduct.getProductOwner()));      

    if (hubProduct.getAccess() == null) {
      hubProduct.setAccess(Access.PRIVATE);
    }
    attributes.add(new Attribute("access", hubProduct.getAccess().toString().toLowerCase()));      

    return attributes;
  }

  boolean isUserTheProductOwnerOrHubAdmin(List<Attribute> attributes, String userEmail) {

    String productOwner = null;
    if (attributes != null && !attributes.isEmpty()) {
      for (Attribute attribute : attributes) {
        if (attribute.getName().equals("PRODUCT_OWNER")) {
          productOwner = attribute.getValue();
          break;
        }
      }
    }

    List<String> allowedEmails = emailBasedAuthzSvc.getOwners(productOwner);
    return allowedEmails.contains(userEmail.toLowerCase());
  }

  ApigeeProductResponse getMyProductsOnly(ApigeeProductResponse productList, String productOwner) {

    ApigeeProductResponse ownerProductList = new ApigeeProductResponse();
    ownerProductList.setApiProduct(new ArrayList<ApigeeProduct>());
    
    productList.getApiProduct().forEach(product -> {
      if (isUserTheProductOwnerOrHubAdmin(product.getAttributes(), productOwner)) {
        ownerProductList.getApiProduct().add(product);
      }
    
    });

    return ownerProductList;
  
  }
  
  ApigeeProductRequest mapApigeeProductToApigeeProductRequest(ApigeeProduct product) {

    ApigeeProductRequest apigeeProductRequest = new ApigeeProductRequest();
    apigeeProductRequest.setApiResources(product.getApiResources());
    if (StringUtils.isNotEmpty(product.getApprovalType())) {
      apigeeProductRequest.setApprovalType(ApprovalType.valueOf(product.getApprovalType()));
    }
    apigeeProductRequest.setAttributes(product.getAttributes());
    apigeeProductRequest.setDescription(product.getDescription());
    apigeeProductRequest.setDisplayName(product.getDisplayName());
    apigeeProductRequest.setEnvironments(product.getEnvironments());
    apigeeProductRequest.setName(product.getName());
    apigeeProductRequest.setProxies(product.getProxies());
    apigeeProductRequest.setQuota(product.getQuota());
    apigeeProductRequest.setQuotaInterval(product.getQuotaInterval());
    if (StringUtils.isNotEmpty(product.getQuotaTimeUnit())) {
      apigeeProductRequest.setQuotaTimeUnit(QuotaTimeUnit.valueOf(product.getQuotaTimeUnit()));
    }
    apigeeProductRequest.setScopes(product.getScopes());

    return apigeeProductRequest;
  
  }
  
  @Retryable(value = NotFoundException.class, maxAttempts = 5, backoff = @Backoff(delay = 10000))
  public void addNewProxyToApiProduct(PartnerProxy partnerProxy, String guid) {
    String org = "INTERNAL";
    String planet = "NONPROD";
    Planet apigeePlanet = Planet.NONPROD;
    partnerProxy.setProxyGuid(UUID.fromString(guid));
    final String errorMessageFormat = "Error adding new proxy to Apigee. Partner Proxy Request: %n%s";
    
    if (partnerProxy.getPartnerEndpoint().getEnvironment().equals(PartnerEndpoint.EnvironmentEnum.PRODUCTION)) {
      planet = "PROD";
      apigeePlanet = Planet.PROD;
    }
    String apigeeProxyName = BuildHandler.buildApigeeProxyName(partnerProxy.getProxyVersion(),
        partnerProxy.getPartnerName(), partnerProxy.getPartnerResource(), guid);

    try {
      log.info("Attempting to GET Apigee proxy: {}", apigeeProxyName);

      apigeeMgmtApiClient.getProxy(apigeeProxyName, planet, org);
      log.info("Apigee proxy found: {}", apigeeProxyName);
      
    } catch (HttpClientErrorException e) {
      if (e.getStatusCode().equals(HttpStatus.NOT_FOUND)) {
        log.info("Still waiting for proxy to be deployed: {}", apigeeProxyName);
        throw new NotFoundException("Still waiting for proxy to be deployed");
      } else {
        String message = String.format(errorMessageFormat, partnerProxy.toString());
        log.error("Partner Proxy Apigee Product update root exception.", e);
        log.error(message);
        throw new PartnerProxyAddToProductException(e.getMessage(), message);
      }
    }
    
    try {
      ApigeeProduct product = getProduct(partnerProxyConfigProperties.getApiProductName(),
          planet, org);
      
      product.getProxies().add(apigeeProxyName);
      
      updatePartnerProxyProduct(apigeePlanet, product);
      
    } catch (ProductNotFoundException e) {
      String message = String.format(errorMessageFormat, partnerProxy.toString());
      log.error("Partner Proxy Apigee Product update root exception.", e);
      log.error(message);
      throw new PartnerProxyAddToProductException(e.getMessage(), message);
      
    } catch (ApigeeMgmtApiClientException e) {
      String message = String.format(errorMessageFormat, partnerProxy.toString());
      log.error("Partner Proxy Apigee Product update root exception.", e);
      log.error(message);
      throw new PartnerProxyAddToProductException(e.getMessage(), message);
    }
    
  }
}
