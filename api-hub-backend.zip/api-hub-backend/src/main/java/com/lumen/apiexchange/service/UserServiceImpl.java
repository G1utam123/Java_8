package com.lumen.apiexchange.service;

import com.lumen.apiexchange.client.LiamSyncClient;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.userprofile.CreateUserRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

  protected static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

  private final LiamSyncClient liamSyncClient;

  public UserServiceImpl(LiamSyncClient liamSyncClient) {
    this.liamSyncClient = liamSyncClient;
  }

  @Override
  public ResponseEntity<?> createUserInApigee(CreateUserRequest request) throws InternalServerException {

    log.info("Inside createUserInApigee method =======>>>>>");
    ResponseEntity<?> userInApigee = liamSyncClient.createUserInApigee(request);
    log.info("User successfully created for the developer with Email ID - {}", request.getEmail());
    return userInApigee;
  }


}
