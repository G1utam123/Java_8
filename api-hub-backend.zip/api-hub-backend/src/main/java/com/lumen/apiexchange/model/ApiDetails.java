package com.lumen.apiexchange.model;

import com.lumen.apiexchange.entity.ApiDocumentation;
import java.util.List;

public class ApiDetails {

  private List<ApiDocumentation> documentations;
  private List<ProxyDetails> proxies;

  public List<ApiDocumentation> getDocumentations() {
    return documentations;
  }

  public void setDocumentations(List<ApiDocumentation> documentations) {
    this.documentations = documentations;
  }

  public List<ProxyDetails> getProxies() {
    return proxies;
  }

  public void setProxies(List<ProxyDetails> proxies) {
    this.proxies = proxies;
  }
}
