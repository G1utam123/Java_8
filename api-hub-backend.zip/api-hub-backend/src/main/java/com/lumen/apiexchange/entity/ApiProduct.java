package com.lumen.apiexchange.entity;

import java.sql.Timestamp;
import java.util.List;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "api_products")
public class ApiProduct {

  @Id
  private UUID id;
  
  @NotBlank(message = "Name is mandatory")
  private String name;
  
  @Column
  @NotBlank(message = "displayName is mandatory")
  private String displayName;
  
  @NotBlank(message = "description is mandatory")
  private String description;
  
  @Column
  @NotBlank(message = "sourceSystem is mandatory")
  private String sourceSystem;
  
  @Column
  @NotBlank(message = "sourceSystemKey is mandatory")
  private String sourceSystemKey;
  
  @NotBlank(message = "planet is mandatory")
  private String planet;
  
  @NotNull(message = "external is mandatory") 
  private Boolean external;
  
  @NotBlank(message = "access is mandatory")
  private String access;

  @Column
  @NotBlank(message = "approvalType is mandatory")
  private String approvalType;
  
  @NotBlank(message = "visibility is mandatory")
  private String visibility;
 
  @Column
  private String createdBy;
  
  @Column
  private Timestamp createdDate;
  
  @Column
  private String lastUpdatedBy;
  
  @Column
  private Timestamp lastUpdatedDate;
  
  @Transient
  private String elementName;
  
  @Transient
  private List<String> admins;
  
  @Transient
  private List<String> owners;
  
}
