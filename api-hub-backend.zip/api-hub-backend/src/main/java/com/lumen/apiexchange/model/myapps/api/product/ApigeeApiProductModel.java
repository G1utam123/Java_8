package com.lumen.apiexchange.model.myapps.api.product;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.lumen.apiexchange.model.myapps.Attribute;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ApigeeApiProductModel {
  private List<Attribute> attributes;
  private String displayName;
  private String name;
  private List<String> environments;
  private List<String> proxies;
  private String description;
  
  public ApigeeApiProductModel() {
  }

  public ApigeeApiProductModel(List<Attribute> attributes, String displayName, String name, List<String> environments,
      List<String> proxies, String description) {
    this.attributes = attributes;
    this.displayName = displayName;
    this.name = name;
    this.environments = environments;
    this.proxies = proxies;
    this.description = description;
  }

  public List<Attribute> getAttributes() {
    return attributes;
  }

  public String getDisplayName() {
    return displayName;
  }

  public String getName() {
    return name;
  }

  public List<String> getEnvironments() {
    return environments;
  }

  public List<String> getProxies() {
    return proxies;
  }

  public String getDescription() {
    return description;
  }

  public void setAttributes(List<Attribute> attributes) {
    this.attributes = attributes;
  }

  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setEnvironments(List<String> environments) {
    this.environments = environments;
  }

  public void setProxies(List<String> proxies) {
    this.proxies = proxies;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  @Override
  public String toString() {
    return "ApiProductModel [attributes=" + attributes + ", displayName=" + displayName + ", name=" + name
        + ", environments=" + environments + ", proxies=" + proxies + ", description=" + description + "]";
  }
  
  
}
