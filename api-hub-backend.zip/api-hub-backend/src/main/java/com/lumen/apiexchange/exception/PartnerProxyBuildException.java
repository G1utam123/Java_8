package com.lumen.apiexchange.exception;

public class PartnerProxyBuildException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public PartnerProxyBuildException(String message) {
    super(message);
  }

}
