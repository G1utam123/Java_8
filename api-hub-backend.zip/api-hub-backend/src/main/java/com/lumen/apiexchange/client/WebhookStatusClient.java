package com.lumen.apiexchange.client;

import com.lumen.apiexchange.api.status.HeartbeatApi;
import com.lumen.apiexchange.api.status.model.ApihubHeartbeatResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class WebhookStatusClient implements HeartbeatApi {
  private final RestTemplate restTemplate;

  @Value("${epb.status.api.url}")
  private String baseUrl;

  @Value("${epb.status.api.endpoint}")
  private String statusEndpoint;

  public WebhookStatusClient() {
    this.restTemplate = new RestTemplate();
  }

  @Override
  public ResponseEntity<ApihubHeartbeatResponse> getApihubHeartbeat() {
    return restTemplate.getForEntity(baseUrl + statusEndpoint, ApihubHeartbeatResponse.class);
  }
}
