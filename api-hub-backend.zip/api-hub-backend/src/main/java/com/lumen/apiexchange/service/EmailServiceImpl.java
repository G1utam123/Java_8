package com.lumen.apiexchange.service;

import com.lumen.apiexchange.config.SMTPEmailConfigProperties;
import com.lumen.apiexchange.model.FeedbackMessage;
import java.nio.charset.StandardCharsets;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmailServiceImpl implements EmailService {

  private final JavaMailSenderImpl javaMailSender;
  private final SpringTemplateEngine templateEngine;
  private final SMTPEmailConfigProperties smtpEmailConfigProp;

  private void sendEmail(String[] to, String from, String subject, String content) {
    MimeMessage message = javaMailSender.createMimeMessage();
    try {
      MimeMessageHelper
          helper =
          new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED, StandardCharsets.UTF_8.name());
      helper.setFrom(from);
      helper.setTo(to);
      helper.setSubject(subject);
      helper.setText(content, true);
      javaMailSender.send(message);
    } catch (MessagingException e) {
      log.error("Could not send email to {}, exception is {}", to, e.getMessage());
    }
  }

  @Override
  public void sendFeedbackReceivedEmail(FeedbackMessage message) {

    log.debug("Sending new feedback received e-email ...");

    Context context = new Context();
    context.setVariable("feedback", message);

    String emailMessage = templateEngine.process("feedback-received-email", context);
    String subject = smtpEmailConfigProp.getSmtpFeedbackSubject();

    sendEmail(new String[] {smtpEmailConfigProp.getSmtpFeedbackAddress()}, message.getEmail(), subject, emailMessage);

  }
}
