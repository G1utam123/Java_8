package com.lumen.apiexchange.util;

import com.lumen.apiexchange.config.ApigeeConfigProperties;
import com.lumen.apiexchange.config.MediationResourceConfigProperties;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.InputApiRequest;
import com.lumen.apiexchange.service.HostServiceImpl;
import io.micrometer.core.instrument.util.StringUtils;
import java.io.IOException;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

@Service 
@EnableRetry
public class BuildHandler {

  private static final Logger log = LoggerFactory.getLogger(BuildHandler.class);

  @Autowired
  private HttpClient httpclient;

  @Autowired
  private ApigeeConfigProperties apigeeConfigProp;

  @Autowired
  private MediationResourceConfigProperties mediationResourceConfigProp;

  @Autowired
  private HostServiceImpl hostServiceImpl;

  @Retryable(value = IOException.class, maxAttempts = 3, backoff = @Backoff(delay = 5000))
  public ResponseEntity<String> buildApi(InputApiRequest inputapirequest) throws IOException, InternalServerException {

    log.info("Calling mediatedResource(Build)");

    String myURL = hostServiceImpl.getEnvHostname(inputapirequest.getEnv())
        + mediationResourceConfigProp.getMediationResourceUri();
    log.info("myURL: " + myURL);

    String myRequest = createBuildRequest(inputapirequest);

    log.info("myRequest " + myRequest);

    String requestorEmail = "";

    if (inputapirequest.getRequestorEmail() != null && !inputapirequest.getRequestorEmail().isEmpty()) {
      requestorEmail = inputapirequest.getRequestorEmail();
    } else {
      requestorEmail = apigeeConfigProp.getApigeeUser();
    }

    log.info("requestorEmail: " + requestorEmail);

    return httpclient.sendRequest(myURL, HttpMethod.POST.toString(), myRequest, requestorEmail);

  }

  @SuppressWarnings("unchecked")
  public String createBuildRequest(InputApiRequest inputapirequest) throws InternalServerException {

    String myActive = "true";
    String throttlingRequestsPerSec = apigeeConfigProp.getApigeeApiBuildDefaultThrottle();
    String timeoutSecs = apigeeConfigProp.getApigeeApiBuildDefaultTimeout();
    String connectionKeepAlive = apigeeConfigProp.getApigeeApiBuildDefaultKeepalive();

    JSONObject request = new JSONObject();

    if (inputapirequest.getEnv().equalsIgnoreCase("mock") || inputapirequest.getEnv().equalsIgnoreCase("sandbox")) {
      request.put("environment", inputapirequest.getEnv());
    }
    
    request.put("resourceTaxonomy", inputapirequest.getTaxonomy());
    request.put("resourceName", inputapirequest.getResourceName());
    request.put("version", inputapirequest.getVersion());

    request.put("serviceType", getServiceType(inputapirequest));

    request.put("type", inputapirequest.getType());
    request.put("internallyAvailable", inputapirequest.getInternal());
    request.put("externallyAvailable", inputapirequest.getExternal());

    if (StringUtils.isNotEmpty(inputapirequest.getActive())) {
      myActive = inputapirequest.getActive();
    }

    request.put("active", myActive);

    request.put("endPointUrl", getEndpointUrl(inputapirequest));

    if (StringUtils.isNotEmpty(inputapirequest.getThrottlingRequestsPerSec())) {
      throttlingRequestsPerSec = inputapirequest.getThrottlingRequestsPerSec();
    }

    request.put("throttlingRequestsPerSec", throttlingRequestsPerSec);

    if (StringUtils.isNotEmpty(inputapirequest.getTimeoutSecs())) {
      timeoutSecs = inputapirequest.getTimeoutSecs();
    }

    request.put("timeoutSecs", timeoutSecs);

    if (StringUtils.isNotEmpty(inputapirequest.getConnectionKeepAlive())) {
      connectionKeepAlive = inputapirequest.getConnectionKeepAlive();
    }

    request.put("connectionKeepAlive", connectionKeepAlive);
    request.put("owningApplicationId", inputapirequest.getMalId());
    request.put("owningApplicationKey", inputapirequest.getOwningAppAppkey());

    String myRouteExpression = "";

    myRouteExpression = getMyRouteExpression(inputapirequest);
    request.put("replaceUrlFromValue", getReplaceUrlFromValue(inputapirequest, myRouteExpression));
    request.put("replaceUrlToValue", inputapirequest.getEndpointPath());
    request.put("routingExpression", getRoutingExpression(inputapirequest, myRouteExpression));
    request.put("resourceGuid", inputapirequest.getGuid());
    request.put("validAuthTypes", inputapirequest.getProxyAuthInternal());
    request.put("validAuthTypesExt", inputapirequest.getProxyAuthExternal());
    request.put("enforceDigest", inputapirequest.getAppkeyEnforceDigest());
    request.put("enforceTaxonomy", inputapirequest.getAppkeyEnforceTaxonomy());
    request.put("authorizedGroups", inputapirequest.getBasicAuthGroups());
    request.put("authorizedUsers", inputapirequest.getBasicAuthUsers());
    request.put("enforceHttps", apigeeConfigProp.getApigeeApiBuildDefaultEnforcehttps());
   
    String myEndpointAuth = "";
    
    myEndpointAuth = getMyEndpointAuth(inputapirequest);
    request.put("endpointAuthType", myEndpointAuth);
    request.put("jwtSubject", inputapirequest.getJwtSubject());
    request.put("jwtIssuer", getJwtIssuer(inputapirequest, myEndpointAuth));

    request.put("basicAuthUser", getBasicAuthUser(inputapirequest));

    request.put("basicAuthPassword", getBasicAuthPassword(inputapirequest));
    request.put("x509CertAlias", inputapirequest.getX509CertAlias());
    request.put("oAuthClientId", inputapirequest.getOauthClientId());
    request.put("oAuthClientSecret", inputapirequest.getOauthSecret());
    request.put("oAuthGrantType", getOauthGrantType(inputapirequest));
    request.put("oAuthUsername", inputapirequest.getOauthUserName());
    request.put("oAuthPassword", inputapirequest.getOauthpw());
    request.put("oAuthTokenServiceHost", inputapirequest.getOauthTokenServiceHost());
    request.put("oAuthTokenServiceUri", inputapirequest.getOauthTokenServiceURI());
    request.put("oAuthScope", inputapirequest.getOauthScope());
    request.put("oAuthClientIdLocation", inputapirequest.getOauthClientIdLocation());
    request.put("oAuthGrantTypeLocation", inputapirequest.getOauthGrantLocation());
    request.put("oAuthUsernameLocation", inputapirequest.getOauthCredentialsLocation());
    request.put("oAuthScopeLocation", inputapirequest.getOauthScopeLocation());
    request.put("documentationUrl", inputapirequest.getDocumentationUrl());
    request.put("pingUrl", inputapirequest.getPingUrl());
    request.put("routingType", inputapirequest.getType());
    request.put("threatProtectionOverrides", inputapirequest.getThreatProtectionOverrides());
    request.put("b2bAuthRequired", inputapirequest.getB2bAuthRequired());
    request.put("b2bCustomerNumberRequired", inputapirequest.getB2bCustomerNumberRequired());
    request.put("b2bBillingAccountNumberRequired", inputapirequest.getB2bBillingAccountNumberRequired());
    request.put("createdBy", inputapirequest.getCreatedBy());
    request.put("createdDate", inputapirequest.getCreatedDate());
    request.put("updatedBy", inputapirequest.getUpdatedBy());
    request.put("updatedDate", inputapirequest.getUpdatedDate());

    return request.toJSONString();
  }

  private Object getBasicAuthPassword(InputApiRequest inputapirequest) {
    String basicAuthPassword = null;

    if (StringUtils.isNotEmpty(inputapirequest.getEndpointBasicAuthPwAll())) {
      basicAuthPassword = inputapirequest.getEndpointBasicAuthPwAll();
    }

    // When UI allows individual passwords by environment, add here.
    
    return basicAuthPassword;
  }

  private String getBasicAuthUser(InputApiRequest inputapirequest) {
    String basicAuthUser = null;

    if (StringUtils.isNotEmpty(inputapirequest.getEndpointBasicAuthUserAll())) {
      basicAuthUser = inputapirequest.getEndpointBasicAuthUserAll();
    }
    
    // When UI allows individual users by environment, add here.

    return basicAuthUser;
  }

  private Object getEndpointUrl(InputApiRequest inputapirequest) throws InternalServerException {
    String endpointUrl = "";
    switch (inputapirequest.getEnv()) {
      case "dev1":
        endpointUrl = inputapirequest.getDev1EndpointHostname();
        break;
      case "dev2":
        endpointUrl = inputapirequest.getDev2EndpointHostname();
        break;
      case "dev3":
        endpointUrl = inputapirequest.getDev3EndpointHostname();
        break;
      case "dev4":
        endpointUrl = inputapirequest.getDev4EndpointHostname();
        break;
      case "test1":
        endpointUrl = inputapirequest.getTest1EndpointHostname();
        break;
      case "test2":
        endpointUrl = inputapirequest.getTest2EndpointHostname();
        break;
      case "test3":
        endpointUrl = inputapirequest.getTest3EndpointHostname();
        break;
      case "test4":
        endpointUrl = inputapirequest.getTest4EndpointHostname();
        break;
      case "mock":
        endpointUrl = inputapirequest.getMockEndpointHostname();
        break;
      case "sandbox":
        endpointUrl = inputapirequest.getSandboxEndpointHostname();
        break;
      case "prod":
        endpointUrl = inputapirequest.getProdEndpointHostname();
        break;
      default:
        throw new InternalServerException("Invalid environment");
    }
    return endpointUrl;
  }

  private String getRoutingExpression(InputApiRequest inputapirequest, String myRouteExpression) {
    String routingExpression = myRouteExpression + "*";
    if (StringUtils.isNotEmpty(inputapirequest.getRoutingExpression())) {
      routingExpression = inputapirequest.getRoutingExpression();
    }
    return routingExpression;
  }

  private String getMyEndpointAuth(InputApiRequest inputapirequest) {
    String myEndpointAuth = "none";
    if (StringUtils.isNotEmpty(inputapirequest.getEndpointAuth())) {
      myEndpointAuth = inputapirequest.getEndpointAuth();
    }
    return myEndpointAuth;
  }

  private String getOauthGrantType(InputApiRequest inputapirequest) {
    String myOauthGrantType = "";
    if (StringUtils.isNotEmpty(inputapirequest.getOauthGrantType())) {
      if (inputapirequest.getOauthGrantType().equalsIgnoreCase("Password")) {
        myOauthGrantType = "password";
      } else {
        myOauthGrantType = inputapirequest.getOauthGrantType();
      }
    }
    return myOauthGrantType;
  }

  public String getMyRouteExpression(InputApiRequest inputapirequest) {
    String myRouteExpression = "";
    String[] taxonomyArray;

    taxonomyArray = inputapirequest.getTaxonomy().split("\\/");

    if (taxonomyArray.length > 1) {
      myRouteExpression = "/" + taxonomyArray[0] + "/" + inputapirequest.getVersion() + "/" + taxonomyArray[1] + "/"
          + inputapirequest.getResourceName();
    } else {
      myRouteExpression = "/" + taxonomyArray[0] + "/" + inputapirequest.getVersion() + "/"
          + inputapirequest.getResourceName();
    }

    return myRouteExpression;
  }

  private String getReplaceUrlFromValue(InputApiRequest inputapirequest, String myRouteExpression) {
    String replaceUrlFromValue = "";
    if (inputapirequest.isMigrationRequest()) {
      if (StringUtils.isNotEmpty(inputapirequest.getReplaceUrlFromValue())) {
        replaceUrlFromValue = inputapirequest.getReplaceUrlFromValue();
      }
    } else {
      replaceUrlFromValue = myRouteExpression;
    }
    return replaceUrlFromValue;
  }

  private String getServiceType(InputApiRequest inputapirequest) {
    String serviceType = null;
    if (inputapirequest.getSoap() != null && inputapirequest.getSoap().equalsIgnoreCase("true")) {
      serviceType = "soap";
    } else {
      // serviceType can only equal 'soap' anything else will cause an error from the
      // backend system (ESP)
      serviceType = "";
    }

    return serviceType;
  }

  private String getJwtIssuer(InputApiRequest inputapirequest, String myEndpointAuth) {

    String myJwtIssuer = null;

    if (myEndpointAuth.equalsIgnoreCase("jwt")) {
      if (inputapirequest.getEnv().equals("prod")) {
        myJwtIssuer = apigeeConfigProp.getApigeeApiBuildDefaultJwtissprod();
      } else {
        myJwtIssuer = apigeeConfigProp.getApigeeApiBuildDefaultJwtissnonprod();
      }
    }
    return myJwtIssuer;
  }
  
  public static String buildApigeeProxyName(String proxyVersion, String partnerName, String partnerResource,
      String guid) {
  
    // Apigee Proxy naming standard: Esp_IntMed_Partner_<version>_<partner name>_<resource>_<resourceGuid>
    String apigeeProxyName = String.format("Esp_IntMed_Partner_%s_%s_%s_%s", proxyVersion, 
        partnerName, partnerResource, guid);
    
    return apigeeProxyName;
  
  }

}
