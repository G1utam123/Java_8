package com.lumen.apiexchange.service;

import com.lumen.apiexchange.model.InputApiRequest;
import com.lumen.apiexchange.util.BuildHandler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class BuildServiceImpl {
  
  private final BuildHandler buildH;
  
  public String buildProxy(InputApiRequest inputapirequest) {
    ResponseEntity<String> myEntity = null;
    JSONParser parser = new JSONParser();
    JSONObject responseJsonObj = null;
    String mediatedResourceId = null;
    
    try {
      myEntity = buildH.buildApi(inputapirequest);
      if (myEntity.getStatusCodeValue() == HttpStatus.OK.value()) {
        responseJsonObj = parseJson(myEntity.getBody(), parser);
        mediatedResourceId = responseJsonObj.get("mediatedResourceId").toString();
      }
    } catch (Exception e) {
      log.error("BuildServiceImpl.buildProxy Exception Occured - {}", inputapirequest, e);
    }
    return mediatedResourceId;
  }

  private JSONObject parseJson(String response, JSONParser parser) throws ParseException {
    Object responseObj = parser.parse(response);
    JSONObject responseJsonObj = (JSONObject) responseObj;

    log.debug("parseJson :: " + responseJsonObj);

    return responseJsonObj;
  } 
  
}
