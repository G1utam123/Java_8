package com.lumen.apiexchange.entity;


import java.util.UUID;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "apidocumentationdata")
public class ApiDocumentation {

  @Id
  private int id;
 
  private UUID apiId;

  private int sectionOrder;
 
  private String apiName;
  
  private String documentation;

  /**
   * @author ac38432
   */
  private String sectionType;

  /**
   * @author ac38432
   */
  private String filecontent;

  /**
   * @author ac38432
   * @return file
   */
  public String getFilecontent() {
    return filecontent;
  }

  public void setFilecontent(String filecontent) {
    this.filecontent = filecontent;
  }

  public ApiDocumentation() {
  }

  public ApiDocumentation(final int sectionId) {
    this.id = sectionId;
  }

  public ApiDocumentation(final int sectionId, final int sectionOrder, final UUID apiNum,
      final String sectionName, final String sectionContent,
      final String secType, final String swaggerfile) {

    this.id = sectionId;
    this.apiId = apiNum;
    this.apiName = sectionName;
    this.documentation = sectionContent;
    this.sectionType = secType;
    this.filecontent = swaggerfile;
    this.sectionOrder = sectionOrder;
  }

  public int getId() {
    return id;
  }

 
  public void setId(final int sectionId) {
    this.id = sectionId;
  }


  public String getApiName() {
    return apiName;
  }

 
  public void setApiName(final String sectionName) {
    this.apiName = sectionName;
  }

 
  public String getDocumentation() {
    return documentation;
  }

 
  public void setDocumentation(final String sectionContent) {
    this.documentation = sectionContent;
  }

 
  public UUID getApiId() {
    return apiId;
  }

 
  public void setApiId(final UUID apiNum) {
    this.apiId = apiNum;
  }

  
  public String getSectionType() {
    return sectionType;

  }

  @Override
  public String toString() {
    return "APIDocumentation [id=" + id + ", apiId=" + apiId
        + ", apiName=" + apiName + ", documentation=" + documentation
        + ", sectionType=" + sectionType + ", filecontent=" + filecontent
        + "]";
  }

  
  public void setSectionType(final String secType) {
    this.sectionType = secType;
  }

  public int getSectionOrder() {
    return sectionOrder;
  }

  public void setSectionOrder(int sectionOrder) {
    this.sectionOrder = sectionOrder;
  }

}
