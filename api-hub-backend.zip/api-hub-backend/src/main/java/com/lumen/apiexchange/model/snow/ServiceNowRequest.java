package com.lumen.apiexchange.model.snow;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ServiceNowRequest {

  @JsonProperty(value = "element_type", required = true)
  private String elementType;

  @JsonProperty(value = "element_name", required = true)
  private String elementName;

  private List<String> admins;
  private List<String> owners;
  private String requester;

}
