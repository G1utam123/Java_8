package com.lumen.apiexchange.exception;

import com.lumen.apiexchange.api.partner.model.Error403;
import com.lumen.apiexchange.api.partner.model.Error403Code;

public class ForbiddenException extends RuntimeException {

  private static final long serialVersionUID = 1L;
  private final Error403 error;

  public ForbiddenException(String message) {
    super(message);
    this.error = new Error403();
  }

  public ForbiddenException(String reason, String message) {
    super(message);
    this.error = buildCommonCode403(reason, message);

  }

  private static Error403 buildCommonCode403(String reason, String message) {
    Error403 error = new Error403();
    error.code(Error403Code.ACCESSDENIED);
    error.setReason(reason);
    error.setMessage(message);
    return error;
  }
  
  public Error403 getError() {
    return error;
  }

}
