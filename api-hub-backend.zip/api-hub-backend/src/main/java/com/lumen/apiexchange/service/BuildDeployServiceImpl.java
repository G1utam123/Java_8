package com.lumen.apiexchange.service;

import com.lumen.apiexchange.exception.BadInputException;
import com.lumen.apiexchange.exception.InternalServerException;
import com.lumen.apiexchange.model.ApiMediatedResource;
import com.lumen.apiexchange.model.AsyncBuildDeployResult;
import com.lumen.apiexchange.model.BuildDeployResult;
import com.lumen.apiexchange.model.InputApiRequest;
import com.lumen.apiexchange.util.BuildHandler;
import com.lumen.apiexchange.util.ValidationHandler;
import io.micrometer.core.instrument.util.StringUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.SerializationUtils;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class BuildDeployServiceImpl {

  private final ValidationHandler valH;
  private final BuildHandler buildH;
  private final HostServiceImpl hostServiceImpl;
  private final AsyncProxyService asyncService;
  
  private static final String COULD_NOT_VALIDATE_IF_PROXY_EXIST =
      "Could not check the state of the proxy in all environments";
  private static final String PROXY_ALREADY_EXISTS = "Proxy already exists: ";
  private static final String DEV1 = "dev1";
  private static final String DEV2 = "dev2";
  private static final String DEV3 = "dev3";
  private static final String DEV4 = "dev4";
  private static final String TEST1 = "test1";
  private static final String TEST2 = "test2";
  private static final String TEST3 = "test3";
  private static final String TEST4 = "test4";
  private static final String MOCK = "mock";
  private static final String SANDBOX = "sandbox";
  private static final String PROD = "prod";
  private static final String CORP = "corp";
  
  public BuildDeployResult buildDeployApi(InputApiRequest inputapirequest) {

    String correlationId = UUID.randomUUID().toString();
    inputapirequest.setGuid(correlationId);

    log.debug("Received Build Deploy Request {}: {}", inputapirequest.getGuid(), inputapirequest.toString());
    
    //Validate request
    validateRequest(inputapirequest);
    
    //Validate API doesn't already exist
    validateIfProxyAlreadyExists(inputapirequest);
 
    //set proxy, guid
    BuildDeployResult buildDeployResult = BuildDeployResult.builder()
        .proxy(buildH.getMyRouteExpression(inputapirequest))
        .guid(inputapirequest.getGuid())
        .proxyBuiltInEnvironments(new ArrayList<>())
        .proxyDeployedToEnvironments(new ArrayList<>())
        .proxyNotBuiltInEnvironments(new ArrayList<>())
        .proxyNotDeployedToEnvironments(new ArrayList<>())
        .build();
    
    if (inputapirequest.callAsyncBuildDeploy()) {
      asyncService.buildDeployAsync(inputapirequest, buildDeployResult);
    } else {
      buildDeployResult = buildDeploy(inputapirequest, buildDeployResult);
    }

    return buildDeployResult;
  }
  
  private BuildDeployResult buildDeploy(InputApiRequest inputapirequest, BuildDeployResult buildDeployResult) {
    
    //get environments to build
    List<String> evnList = getCreateEnvironmentList(inputapirequest);
        
    //build APIs
    List<AsyncBuildDeployResult> asyncBuildDeployResultList = new ArrayList<>();
    List<CompletableFuture<AsyncBuildDeployResult>> asyncBuildDeployResult = new ArrayList<>();
    
    for (String env : evnList) {
      InputApiRequest asyncinputapirequest = SerializationUtils.clone(inputapirequest);
      asyncinputapirequest.setEnv(env);
      asyncBuildDeployResult.add(asyncService.buildDeployApi(asyncinputapirequest));
    }

    asyncBuildDeployResultList =
        asyncBuildDeployResult.stream().map(CompletableFuture::join).collect(Collectors.toList());
    
    asyncBuildDeployResultList.forEach(asyncResult  -> {
      if (asyncResult != null) {
        if (!asyncResult.getProxyBuiltInEnvironments().isEmpty()) {
          buildDeployResult.getProxyBuiltInEnvironments().add(asyncResult.getProxyBuiltInEnvironments());
        }
        if (!asyncResult.getProxyNotBuiltInEnvironments().isEmpty()) {
          buildDeployResult.getProxyNotBuiltInEnvironments().add(asyncResult.getProxyNotBuiltInEnvironments());
        }
        if (!asyncResult.getProxyDeployedToEnvironments().isEmpty()) {
          buildDeployResult.getProxyDeployedToEnvironments().addAll(asyncResult.getProxyDeployedToEnvironments());
        }
        if (!asyncResult.getProxyNotDeployedToEnvironments().isEmpty()) {
          buildDeployResult.getProxyNotDeployedToEnvironments().addAll(asyncResult.getProxyNotDeployedToEnvironments());
        }
      }
    });
    
    return buildDeployResult;
  }

  public List<String> getCreateEnvironmentList(InputApiRequest inputapirequest) {
    List<String> envList = new ArrayList<>();
    
    if (StringUtils.isNotEmpty(inputapirequest.getDev1EndpointHostname())) {
      envList.add(DEV1);
    }
    if (StringUtils.isNotEmpty(inputapirequest.getDev2EndpointHostname())) {
      envList.add(DEV2);
    }
    if (StringUtils.isNotEmpty(inputapirequest.getDev3EndpointHostname())) {
      envList.add(DEV3);
    }
    if (StringUtils.isNotEmpty(inputapirequest.getDev4EndpointHostname())) {
      envList.add(DEV4);
    }
    if (StringUtils.isNotEmpty(inputapirequest.getTest1EndpointHostname())) {
      envList.add(TEST1);
    }
    if (StringUtils.isNotEmpty(inputapirequest.getTest2EndpointHostname())) {
      envList.add(TEST2);
    }
    if (StringUtils.isNotEmpty(inputapirequest.getTest3EndpointHostname())) {
      envList.add(TEST3);
    }
    if (StringUtils.isNotEmpty(inputapirequest.getTest4EndpointHostname())) {
      envList.add(TEST4);
    }
    if (StringUtils.isNotEmpty(inputapirequest.getMockEndpointHostname())) {
      envList.add(MOCK);
    }
    if (StringUtils.isNotEmpty(inputapirequest.getSandboxEndpointHostname())) {
      envList.add(SANDBOX);
    }
    if (StringUtils.isNotEmpty(inputapirequest.getProdEndpointHostname())) {
      envList.add(PROD);
    }

    return envList;
  }

  public void validateIfProxyAlreadyExists(InputApiRequest inputapirequest)
      throws InternalServerException {
    log.info("VALIDATE IF PROXY EXISTS");
    List<ApiMediatedResource> apiMediatedResourceList = new ArrayList<>();
    List<CompletableFuture<ApiMediatedResource>> asyncApiDetails = new ArrayList<>();
    
    for (String host : hostServiceImpl.getHosts()) {
      if (!host.contains(MOCK) && !host.contains(SANDBOX)) {
        asyncApiDetails.add(asyncService.getApiProxyDetails(getEnv(host), inputapirequest.getTaxonomy(),
            inputapirequest.getResourceName(), inputapirequest.getVersion()));
      }
    }
    
    try {
      apiMediatedResourceList = asyncApiDetails.stream().map(CompletableFuture::join).collect(Collectors.toList());
    } catch (CompletionException ce) {
      log.info(COULD_NOT_VALIDATE_IF_PROXY_EXIST);
      throw new InternalServerException(COULD_NOT_VALIDATE_IF_PROXY_EXIST);
    }
    
    apiMediatedResourceList.forEach(resource  -> {
      if (resource != null) {
        //API Found
        if (inputapirequest.bypassApiAlreadyExists()) {
          List<String> evnList = getCreateEnvironmentList(inputapirequest);
          if (evnList.contains(resource.getEnvironment())) {
            StringBuilder sb = new StringBuilder(PROXY_ALREADY_EXISTS);
            sb.append(resource.getEnvironment());
            log.info(sb.toString());
            throw new BadInputException(sb.toString());
          }
        } else {
          StringBuilder sb = new StringBuilder(PROXY_ALREADY_EXISTS);
          sb.append(resource.getEnvironment());
          log.info(sb.toString());
          throw new BadInputException(sb.toString());            
        }
      }
    });
  }
  
  public String getEnv(String host) {
    String env = DEV1;
    if (host.contains(DEV1)) {
      env = DEV1;
    } else if (host.contains(DEV2)) {
      env = DEV2;
    } else if (host.contains(DEV3)) {
      env = DEV3;
    } else if (host.contains(DEV4)) {
      env = DEV4;
    } else if (host.contains(TEST1)) {
      env = TEST1;
    } else if (host.contains(TEST2)) {
      env = TEST2;
    } else if (host.contains(TEST3)) {
      env = TEST3;
    } else if (host.contains(TEST4)) {
      env = TEST4;
    } else if (host.contains(CORP)) {
      env = PROD;
    }
    return env;
  }

  public void validateRequest(InputApiRequest inputapirequest) {
    log.info("VALIDATE REQUEST");

    String requestValidationErrorMessage = valH.validateRequest(inputapirequest);
    
    if (!requestValidationErrorMessage.isEmpty()) {
      log.info("Request Validation Error Occurred: " + requestValidationErrorMessage);
      StringBuffer sb = new StringBuffer("Invalid Request: ");
      sb.append(requestValidationErrorMessage);
      throw new BadInputException(sb.toString());
    }
  }
  
}
