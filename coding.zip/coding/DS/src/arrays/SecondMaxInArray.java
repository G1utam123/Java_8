package arrays;

public class SecondMaxInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] a={3,2,1,4,6,5,8,77,66,55,99};
		
		int max=Integer.MIN_VALUE;
		int secondMax=Integer.MIN_VALUE;
		
		for(int i=0;i<a.length;i++){
			if(a[i]>max){
				secondMax=max;
				max=a[i];
			}
			else if(a[i] > secondMax && a[i] != max){
				secondMax=a[i];
			}
		}
		
		System.out.println(secondMax);

	}

}
