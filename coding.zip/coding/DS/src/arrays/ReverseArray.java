package arrays;

public class ReverseArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int[] a={2,1,4,3,6,5,8,7,9};
		int i=0;
		int j=a.length - 1;
		while(i<j){
			int temp=a[i];
			a[i]=a[j];
			a[j]=temp;
			i++;
			j--;
		}
		
		
		for(int k=0;k<a.length;k++){
			System.out.println(a[k]);
		}
		
	}

}
