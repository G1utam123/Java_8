package arrays;

public class PalindromeString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//String s="madam";
		String s="gautam";
		
		int start=0;
		int end=s.length() - 1 ;
		int flag=0;
		char[] ch=s.toCharArray();
		
		while(start<end){
			if(ch[start] != ch[end]){
				flag=1;
				break;
			}
			start++;
			end--;
		}
		
		if(flag == 1){
			System.out.println("Not palindrome");
		}
		else{
			System.out.println("Palindrome");
		}
		
		
		

	}

}
