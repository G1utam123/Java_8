package arrays;

public class RotateArray {
	
	
	public void rotate(int[] a,int k){
		int temp=a[a.length-1];
		
		for(int i=a.length-1;i>=0;i--){
			a[i]=a[i-1];
			
		}	
		
	}
	
	

	public static void main(String[] args) {
		
		int[] a={2,3,4,5,6,7};
		
		
		
		
	}

}
