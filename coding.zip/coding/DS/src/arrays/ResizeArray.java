package arrays;

public class ResizeArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] a={2,1,3,5,4};
		int capacity=9;
		
		int[] temp=new int[capacity];
		for(int i=0;i<a.length;i++){
			temp[i]=a[i];
		}
		
		a=temp;
		
		for(int i=0;i<a.length;i++){
			System.out.println(a[i]);
		}

	}

}
