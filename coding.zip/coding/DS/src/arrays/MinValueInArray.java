package arrays;

public class MinValueInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] a={3,2,1,7,6,5,9};
		
		int min=a[0];
		for(int i=0;i<a.length;i++){
			if(min>a[i]){
				min=a[i];
			}
		}

		System.out.println(min);
	}

}
