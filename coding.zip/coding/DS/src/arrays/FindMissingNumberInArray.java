package arrays;

public class FindMissingNumberInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] a={2,1,3,4,6,9,8,7};
		
		int n=a.length+1;
		int total=n*(n+1)/2;
		int sum=0;
		for(int i=0;i<a.length;i++){
			sum=sum+a[i];
		}

		System.out.println("Missing number : "+ (total-sum));
		
	}

}
