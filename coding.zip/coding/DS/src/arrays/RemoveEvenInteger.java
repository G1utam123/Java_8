package arrays;

public class RemoveEvenInteger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] a={2,3,5,4,7,6,9,8};
		
		int oddCount=0;
		for(int i=0;i<a.length;i++){
			
			if(a[i]%2 != 0){
				oddCount++;
			}
		}
		
		int[] result=new int[oddCount];
		int j=0;
		for(int i=0;i<a.length;i++){
			if(a[i]%2 != 0){
				result[j]=a[i];
				j++;
			}
		}
		
		for(int i=0;i<result.length;i++){
			System.out.println(result[i]);
		}

	}

}
