package arrays;

public class MoveZeroEndOfArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		int[] a={2,1,3,5,4,0,7,6,0,9,8};
		
		int j=0;
		for(int i=0;i<a.length;i++){
			
			if(a[i]!=0 && a[j]==0){
				int temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
			if(a[j]!=0){
				j++;
			}
		}
		
		for(int i=0;i<a.length;i++){
			System.out.println(a[i]);
		}
		
	}

}
