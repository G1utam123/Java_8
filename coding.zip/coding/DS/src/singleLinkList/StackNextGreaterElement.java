package singleLinkList;

import java.util.Stack;

public class StackNextGreaterElement {
	
	public int[] nextGreaterElement(int[] arr){
		
		int[] result=new int[arr.length];
		Stack<Integer> stack=new Stack<>();
		
		for(int i=arr.length -1 ; i >= 0; i--){
			if(!stack.isEmpty()){
				while(!stack.isEmpty() && stack.peek() <= arr[i]){
					stack.pop();
				}
			}
			
			if(stack.isEmpty()){
				result[i]=-1;
			}else{
				result[i]=stack.peek();
			}
			stack.push(arr[i]);
		}
		
		return result;
		
	}
	
	

	public static void main(String[] args) {
		// i/0 : ar = {4,7,3,4,8,1}
		// o/p : ar = {7,8,4,8,-1,-1}
		
		
		StackNextGreaterElement s=new StackNextGreaterElement();
		int[] arr={4,7,3,4,8,1};
		int result[]=s.nextGreaterElement(arr);
		for(int a:result){
			System.out.println(a);
		}

	}

}
