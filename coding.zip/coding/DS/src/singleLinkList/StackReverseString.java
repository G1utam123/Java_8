package singleLinkList;

import java.util.Stack;

public class StackReverseString {

	public String[] reverse(String str){


		String[] sta=str.split(" ");

		for(int j=0;j<sta.length;j++){
			
			char[] ch=sta[j].toCharArray();
			
			Stack<Character> stack=new Stack<>();
			for(char c: ch){
				stack.push(c);
			}	
			for(int i=0;i<ch.length;i++){
				ch[i]=stack.pop();
			}

			sta[j]=new String(ch)+" ";
		}

		return sta;
	}

	public static void main(String[] args) {

		StackReverseString s=new StackReverseString();
		String[] sta=s.reverse("Gautam kumar chauhan");

		for(String st:sta){
			System.out.print(st);
		}

	}

}
