package singleLinkList;

import java.util.NoSuchElementException;



public class StackUsingLinkList {

	   private ListNode top;
	   private int length;
	   
	   private static class ListNode{
		   private int data;
		  private ListNode next;
		  public ListNode(int data){
			  this.data=data;
		  }
	   }
	   
	   public StackUsingLinkList(){
		   this.top=null;
		   this.length=0;
	   }
	   
	   public int length(){
		   return length;
	   }
	   
	   public boolean isEmpty(){
		   return length == 0;
	   }
	   
	   
	   public void push(int value){
		   ListNode temp=new ListNode(value);
		   
		   temp.next=top;
		   top=temp;
		   length++;
		   
	   }
	   
	   public ListNode pop(){
		   
		   if(isEmpty())
			   throw new NoSuchElementException();
		   
		   ListNode temp=top;
		   top=top.next;
		   temp.next=null;
		   length--;
		   return temp;
	   }
	   
	   public ListNode peek(){
		   if(isEmpty())
			   throw new NoSuchElementException();
		   
		   return top;
	   }
	
	public static void main(String[] args) {
		
		StackUsingLinkList s=new StackUsingLinkList();
		s.push(2);
		s.push(3);
		s.push(4);
		
		System.out.println("Pooped :"+ s.pop().data);
		System.out.println("Peek :"+ s.peek().data);

	}

}
