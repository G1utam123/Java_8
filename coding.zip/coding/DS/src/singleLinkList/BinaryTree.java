package singleLinkList;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class BinaryTree {

	private TreeNode root;
	
	private static class TreeNode{
		private int data;
		private TreeNode left;
		private TreeNode right;
		
		public TreeNode(int data){
			this.data=data;
			this.left=null;
			this.right=null;
		}
	}
	
	public BinaryTree(){
		this.root=null;
	}
	
	public 	void createBinaryTree(){
		
		TreeNode a=new TreeNode(2);
		TreeNode b=new TreeNode(3);
		TreeNode c=new TreeNode(4);
		TreeNode d=new TreeNode(5);
		TreeNode e=new TreeNode(6);
		TreeNode f=new TreeNode(7);
		
		root=a;
		a.left=b;
		a.right=c;
		
		b.left=d;
		b.right=e;
		
		c.left=f;
	}
	
	public void preOrderTravershal(TreeNode root){
		if(root == null){
			return;
		}
		System.out.print(root.data +" ");
		preOrderTravershal(root.left);
		preOrderTravershal(root.right);
	}
	
	public void preOrderIterativeTravershal(){
		if(root == null){
			return;
		}
		
		Stack<TreeNode> stack=new Stack<>();
		stack.push(root);
		
		while(!stack.isEmpty()){
			
			TreeNode temp=stack.pop();
			System.out.print(temp.data +" ");
			
			if(temp.right != null){
				stack.push(temp.right);
			}
			
			if(temp.left != null){
				stack.push(temp.left);
			}
			
		}
		
	}
	
	public void inOrderRecursiveTravershal(TreeNode root){
		if(root == null)
			return;
		
		inOrderRecursiveTravershal(root.left);
		System.out.print(root.data+" ");
		inOrderRecursiveTravershal(root.right);	
			
	}
	
	public void inOrderIterativeTravershal(TreeNode root){
		if(root == null)
			return;
		
		Stack<TreeNode> stack=new Stack<>();
		TreeNode temp=root;
		while(!stack.isEmpty() || temp != null){
			
			if(temp != null){
				stack.push(temp);
				temp=temp.left;
			}else{
				temp=stack.pop();
				System.out.print(temp.data+" ");
				temp=temp.right;
			}
		}
	}
	
	public void postOrderRecursiveTravershal(TreeNode root){
		if(root == null)
			return;
		
		postOrderRecursiveTravershal(root.left);
		postOrderRecursiveTravershal(root.right);
		System.out.print(root.data+" ");
	}
	
	public void postOrderIterativeTravershal(TreeNode root){
		
		TreeNode current=root;
		Stack<TreeNode> stack=new Stack<>();
		
		while(!stack.isEmpty() || current != null){
			
			if(current != null){
				stack.push(current);
				current=current.left;
			}else{
				TreeNode temp=stack.peek().right;
                 if(temp == null){
                	 temp=stack.pop();
                	 System.out.print(temp.data+" ");
                	 while(!stack.isEmpty() && temp == stack.peek().right){
                		 temp=stack.pop();
                		 System.out.print(temp.data+" ");
                	 }
                 }else{
                	 current=temp;
                 }
			}
			
		}
	}
	
	public void levelOrderTrevershal(TreeNode root){
		if(root == null){
			return;
		}
		
		Queue<TreeNode> queue=new LinkedList<>();
		queue.offer(root);
		
		while(!queue.isEmpty()){
			TreeNode temp=queue.poll();
			System.out.print(temp.data+" ");
			
			if(temp.left!=null)
				queue.offer(temp.left);
			if(temp.right!=null)
				queue.offer(temp.right);
			
		}
		
	}
	
	public int findMax(TreeNode root){
		if(root == null)
			return Integer.MIN_VALUE;
		
		int result=root.data;
		int left=findMax(root.left);
		int right=findMax(root.right);
		
		if(left>result)
			result=left;
		if(right>result)
			result=right;
		
		return result;
	}

	public void insertInBST(int value){
		root=insertInBinarySearchTree(root, value);
	}
	
	public TreeNode insertInBinarySearchTree(TreeNode root, int value){
		if(root == null){
			root=new TreeNode(value);
			return root;
		}
		
		if(value < root.data)
			root.left=insertInBinarySearchTree(root.left, value);
		else
			root.right=insertInBinarySearchTree(root.right, value);
		
		return root;
		
	}
	
	
	public TreeNode searchInBST(int key){
		return searchInBST(root,key);
	}
	
	public TreeNode searchInBST(TreeNode root, int key){
		if(root == null || root.data == key)
			return root;
		
        if(key < root.data)
        	return searchInBST(root.left, key);
        else
        	return searchInBST(root.right, key);
        
       
	}
	
	public boolean isValidBST(TreeNode root,int min,int max){
		if(root == null)
			return true;
		
		if(root.data<=min || root.data >= max)
			return false;
		
		boolean left = isValidBST(root.left, min, root.data);
		if(left){
			boolean right = isValidBST(root.right, root.data, max);
			return right;
		}
		return false;
	}
	
	public static void main(String[] args) {
		
		BinaryTree bt=new BinaryTree();
		
//		bt.createBinaryTree();
		
		bt.insertInBST(6);
		bt.insertInBST(4);
		bt.insertInBST(8);
		bt.insertInBST(2);
		bt.insertInBST(5);
		bt.insertInBST(7);
		bt.insertInBST(9);
	  
		System.out.println("Is valid BST :"+ bt.isValidBST(bt.root, Integer.MIN_VALUE, Integer.MAX_VALUE));
		 
//		System.out.println(" Recursive : " );
//		bt.preOrderTravershal(bt.root);
//		bt.inOrderRecursiveTravershal(bt.root);
//		bt.postOrderRecursiveTravershal(bt.root);
//		bt.levelOrderTrevershal(bt.root);
//		System.out.println(" Maximum in BT :"+ bt.findMax(bt.root));
		
//		System.out.println(" Search and found : "+ bt.searchInBST(8).data);
//		
//		System.out.println("\n Iterative : " );
//		bt.createBinaryTree();
		
//		bt.postOrderIterativeTravershal(bt.root);
//		bt.inOrderIterativeTravershal(bt.root);
//		bt.preOrderIterativeTravershal();

	}

}
