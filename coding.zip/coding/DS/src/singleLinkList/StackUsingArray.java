package singleLinkList;

public class StackUsingArray {
	
	private int top;
	private int[] arr;
	
	public StackUsingArray(int capacity){
		this.top=-1;
		this.arr=new int[capacity];
	}

	public boolean isFull(){
		return arr.length == size();
	}
	
	public boolean isEmpty(){
		return top < 0;
	}
	
	public int size(){
		return top + 1;
	}
	
	public void push(int value){
		if(isFull())
			throw new RuntimeException("Stack is full !!!!");
		top++;
		arr[top]=value;
	}
	
	public int pop(){
		if(isEmpty())
			throw new RuntimeException("Stack is Empty !!!!!");
		int result=arr[top];
		top--;
		return result;
	}
	
	public int peek(){
		if(isEmpty())
			throw new RuntimeException("Stack lis Empty !!!!!");
		return arr[top];
	}
	
	
	public static void main(String[] args) {
		
		StackUsingArray s=new StackUsingArray(3);
		s.push(2);
		s.push(3);
		s.push(4);
		
		System.out.println("Pooped : "+ s.pop());
		System.out.println("peeked : "+ s.peek());

	}

}
