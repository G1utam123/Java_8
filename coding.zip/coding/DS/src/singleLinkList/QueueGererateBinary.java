package singleLinkList;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class QueueGererateBinary {
	
	public String[] generateBinary(int n){
		
		String[] str=new String[n];
		Queue<String> queue=new LinkedList<>();
		
		queue.offer("1");
		
		for(int i=0;i<n;i++){
			
			str[i]=queue.poll();
			String n1= str[i]+"0";
			String n2=str[i]+"1";
			queue.offer(n1);
			queue.offer(n2);
		}
		
		return str;	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		QueueGererateBinary b=new QueueGererateBinary();
		for(String s: b.generateBinary(4)){
			System.out.print(s+" ");
		}

	}

}
