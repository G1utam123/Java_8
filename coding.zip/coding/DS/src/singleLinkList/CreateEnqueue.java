package singleLinkList;

import java.util.NoSuchElementException;

public class CreateEnqueue {
	
	private ListNode front;
	private ListNode rear;
	private int length;
	
	private static class ListNode{
		private int data;
		private ListNode next;
		
		public ListNode(int data){
			this.data=data;
			this.next=null;
		}
	}
	
	public CreateEnqueue(){
		this.front=null;
		this.rear=null;
		this.length=0;
	}
	
	public boolean isEmpty(){
		return length == 0;
	}

	public int length(){
		return length;
	}
	
	public void enqueue(int value){
		ListNode temp=new ListNode(value);
		if(isEmpty()){
			front=temp;
		}else{
			rear.next=temp;
		}
		rear=temp;
		length++;
	}
	
	public void print(){
		if(isEmpty()){
			return;
		}
		ListNode current=front;
		while(current!=null){
			System.out.print(current.data+"-->");
			current=current.next;
		}
		System.out.print("null");
	}
	
	public int dequeue(){
		if(isEmpty())
			throw new NoSuchElementException();
		
		int temp=front.data;
		front=front.next;
		if(front == null)
			rear=null;
		length--;
		return temp;
	}
	
	
	
	public static void main(String[] args) {
	
		 CreateEnqueue eq=new CreateEnqueue();
		 
		 eq.enqueue(2);
		 eq.enqueue(4);
		 eq.enqueue(5);
		 
		 eq.dequeue();
		 
		 eq.print();

	}

}
