package singleLinkList;


import java.util.NoSuchElementException;

public class CircularSingleLinkList {
	
	private ListNode last;
	private int length;
	
	private static class ListNode{
		
		private int data;
		private ListNode next;
		
		public ListNode(int data){
			this.data=data;
		}
	}
	
	public CircularSingleLinkList(){
		this.last=null;
		this.length=0;
	}
	
	
	public int length(){
		return length;
	}
	
	public boolean isEmpty(){
		return length == 0;
	}
	
	public void createCircularLinkList(){
		ListNode first=new ListNode(2);
		ListNode second=new ListNode(3);
		ListNode third=new ListNode(4);
		ListNode forth=new ListNode(5);
		ListNode fith=new ListNode(6);
		
		first.next=second;
		second.next=third;
		third.next=forth;
		forth.next=fith;
		fith.next=first;
		
		last=fith;
	}
	
	public void displayCSLL(){
		if(last == null)
			return;
		
		ListNode first=last.next;
		while(first!=last){
			System.out.print(first.data+"-->");
			first=first.next;
		}
		System.out.print(first.data);
	}

	public void insertAtBegininng(int value){
		ListNode temp=new ListNode(value);
		if(last == null){
			last=temp;
		}else{
			temp.next=last.next;
		}
		last.next=temp;
		length++;
	}
	
	public void insertAtEnd(int value){
		
		ListNode temp=new ListNode(value);
		if(last == null){
			last=temp;
			last.next=last;
		}else{
			temp.next=last.next;
			last.next=temp;
			last=temp;
		}
		length++;
	}
	
	public ListNode removeFirstNode(){
		if(isEmpty()){
			throw new NoSuchElementException();
		}
		
		ListNode temp=last.next;
		if(last.next == last){
			last= null;
		}else{
			last.next=temp.next;
		}
		temp.next=null;
		length--;
		return temp;
	}
	
	
	public static void main(String[] args) {
		
		CircularSingleLinkList csll=new CircularSingleLinkList();
//		csll.createCircularLinkList();
		
//		csll.insertAtBegininng(2);
//		csll.insertAtBegininng(4);
//		csll.insertAtBegininng(5);
//		csll.insertAtBegininng(8);
		
		csll.insertAtEnd(2);
		csll.insertAtEnd(3);
		csll.insertAtEnd(4);
		csll.insertAtEnd(5);;
		
//		csll.removeFirstNode();
		
		
		csll.displayCSLL();

	}

}
