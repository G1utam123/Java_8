package singleLinkList;

public class SingleLinkList {


	private ListNode head;
		

	private static class ListNode{

		private int data;
		private ListNode next;

		public ListNode(int data){
			this.data=data;
			this.next=null;
		}
	}


	public static void main(String[] args) {

		SingleLinkList sll=new SingleLinkList();
		

//				sll.head=new ListNode(3);
//				ListNode second=new ListNode(5);
//				ListNode third=new ListNode(7);
//				ListNode fourt=new ListNode(9);
//				ListNode fifth=new ListNode(4);
//				ListNode sixth=new ListNode(8);
//				
//				sll.head.next=second;
//				second.next=third;
//				third.next=fourt;
//				fourt.next=fifth;
//				fifth.next=sixth;
				
		 ListNode head1=new ListNode(6);
		ListNode second=new ListNode(4);
		ListNode third=new ListNode(7);
		ListNode fourt=new ListNode(8);
		ListNode fifth=new ListNode(9);
		ListNode sixth=new ListNode(6);	
		head1.next=second;
		second.next=third;
		third.next=fourt;
		fourt.next=fifth;
		fifth.next=sixth;	
		
		ListNode head2=new ListNode(8);
		ListNode sec=new ListNode(5);
		ListNode trd=new ListNode(7);
		ListNode four=new ListNode(8);
		head2.next=sec;
		sec.next=trd;
		trd.next=four;
			
				

//		sll.insertAtBeginning(6);
//		sll.insertAtBeginning(5);
//		sll.insertAtBeginning(3);
//		sll.insertAtBeginning(2);
//		sll.insertAtBeginning(1);

		//		sll.insertAtEnd(5);
		//		sll.insertAtEnd(8);
		//		sll.insertAtPosition(2, 4);
		//		sll.display();
		//		System.out.println("\n deleted : " + sll.deleteFirstNode().data);

//				sll.display();

		//		System.out.println("\n last node deleted : "+ sll.deleteLastNode().data);

		//		sll.deleteAtPosition(3);
//		System.out.println("The element fount : "+ sll.searchElement(7));
				
//				sll.reverse();
//				System.out.println("\n mid node : "+ sll.middleNode().data);
		
//		System.out.println("\n nTh Node from end : "+ sll.nThNodeFromEnd(3).data);
//				sll.removeDublicateSortedList();
				System.out.println("\n ");
				
//				ListNode newNode=new ListNode(4);
//				sll.insertNodeInSortedList(newNode);
				
//				sll.removeGivenKey(3);
				
//				System.out.println("\n detect loop : "+ sll.detectLoop());
//				System.out.println("\n start of loop : "+ sll.startOfLoop().data);
				
//				sll.removeLoop();
				
//				sll.mergeTwoShortedList(head1, head2);
				
				sll.addTwoNumber(head1, head2);
				
		sll.display();
		System.out.println("\n Length : "+ sll.length());
	}


	public void display(){
		ListNode current=head;
		while(current!=null){
			System.out.print(current.data+"-->");
			current=current.next;
		}
		System.out.print("null");
	}

	public int length(){

		if(head==null){
			return 0;
		}
		ListNode current=head;
		int count=0;
		while(current!=null){
			count++;
			current=current.next;
		}
		return count;
	}

	public void insertAtBeginning(int value){

		ListNode newNode=new ListNode(value);
		newNode.next=head;
		head=newNode;
	}

	public void insertAtEnd(int value){

		ListNode newNode=new ListNode(value);

		if(head == null){
			head=newNode;
			return;
		}

		ListNode current=head;
		while(current.next != null){
			current=current.next;
		}
		current.next=newNode;

	}

	public void insertAtPosition(int value,int position){
		ListNode newNode=new ListNode(value);

		if(position == 1){
			newNode.next=head;
			head=newNode;
		}else{
			ListNode previous=head;
			int	count=1;
			while(count < position - 1){
				previous=previous.next;
				count++;
			}
			ListNode current=previous.next;
			previous.next=newNode;
			newNode.next=current;
		}

	}

	public ListNode deleteFirstNode(){
		if( head == null){
			return null;
		}
		ListNode temp=head;
		head=head.next;
		temp.next=null;
		return temp;
	}

	public ListNode deleteLastNode(){
		if(head == null || head.next == null){
			return head;
		}

		ListNode current = head;
		ListNode previous = null;
		while(current.next != null){
			previous=current;
			current=current.next;
		}
		previous.next=null;
		return current;
	}

	public void deleteAtPosition(int position){
		if(position == 1){
			head=head.next;
		}else{
			ListNode previous=head;
			int count = 1;
			while( count < position - 1){
				previous=previous.next;
				count++;
			}
			ListNode current=previous.next;
			previous.next=current.next;
		}
	}

	public boolean searchElement(int key){


		ListNode current=head;
		while(current != null){
			if(current.data == key){
				return true;
			}
			current=current.next;
		}

		return false;

	}

   public void reverse(){
	   
	   ListNode current=head;
	   ListNode previous=null;
	   ListNode next=null;
	   while(current != null){
		   
		   next=current.next;
		   current.next=previous;
		   previous=current;
		   current=next;
	   }
	   head=previous;
   }

  public ListNode middleNode(){
	  
	  ListNode fastPtr=head;
	  ListNode slowPtr=head;
	  
	  while(fastPtr != null && fastPtr.next != null){
		  slowPtr=slowPtr.next;
		  fastPtr=fastPtr.next.next;
	  }
	  return slowPtr;
  }
  
  public ListNode nThNodeFromEnd(int value){
	  
	  ListNode mainPtr=head;
	  ListNode refPtr=head;
	  int count=0;
	  while(count < value){
		  refPtr=refPtr.next;
		  count++;
	  }
	  
	  while(refPtr != null){
		  refPtr=refPtr.next;
		  mainPtr=mainPtr.next;
	  }
	  return mainPtr;
	  
  }

   public void removeDublicateSortedList(){
	   
	   ListNode current=head;
	   while(current != null && current.next != null){
		   if(current.data == current.next.data){
			   current.next=current.next.next;
		   }else{
		   current=current.next;
		   }
	   }
	   
   }
  
   public void insertNodeInSortedList(ListNode newNode){
	   
	   ListNode current=head;
	   ListNode temp=null;
	   while(current != null && current.data < newNode.data){
		   temp=current;
		   current=current.next;
	   }
	   temp.next=newNode;
	   newNode.next=current;
   }
  
   public void removeGivenKey(int value){
	   
	   ListNode current=head;
	   ListNode previous=null;
	   while(current != null && current.data != value){
		   previous=current;
		   current=current.next;
	   }
	   if(current == null)
		   return;
	   
	   previous.next=current.next;
   }
   
   public boolean detectLoop(){
	   ListNode fastPtr=head;
	   ListNode slowPtr=head;
	   while(fastPtr != null && fastPtr.next != null){
		   fastPtr=fastPtr.next.next;
		   slowPtr=slowPtr.next;
		   if(slowPtr == fastPtr)
			   return true;
	   }
	   return false;
   }

   public ListNode startOfLoop(){
	   ListNode fastPtr=head;
	   ListNode slowPtr=head;
	   while(fastPtr != null && fastPtr.next != null ){
		   fastPtr=fastPtr.next.next;
		   slowPtr=slowPtr.next;
		   if(fastPtr == slowPtr){
			   return getFirstNode(slowPtr);
		   }
	   }
	   return null;
   }
   
   public ListNode getFirstNode(ListNode slowPtr){
	   ListNode current=head;
	   while(current != slowPtr){
		   current=current.next;
		   slowPtr=slowPtr.next;
	   }
	   return slowPtr;
   }
   
   
   public void removeLoop(){
	   ListNode fastPtr=head;
	   ListNode slowPtr=head;
	   while(fastPtr != null && fastPtr.next != null){
		   fastPtr=fastPtr.next.next;
		   slowPtr=slowPtr.next;
		   if(slowPtr == fastPtr){
			   remove(slowPtr);
			   return;
		   }
	   }
		   
   }
   
   public void remove(ListNode slowPtr){
	   ListNode current=head;
	   while(current.next != slowPtr.next){
		   current=current.next;
		   slowPtr=slowPtr.next;
	   }
	   slowPtr.next=null;
   }
 
   public void mergeTwoShortedList(ListNode a,ListNode b){
	   
	   ListNode dummy=new ListNode(0);
	   ListNode tail=dummy;
	   
	   while(a != null && b != null){
		   if(a.data <= b.data){
			   tail.next=a;
			   a=a.next;
		   }else{
			   tail.next=b;
			   b=b.next;
		   }
		   tail=tail.next;
	   }
	   
	   if( a == null){
		   tail.next=b;
	   }else{
		   tail.next=a;
	   }
	   
	   head=dummy.next;
	   
   }
   
 
   
   public void addTwoNumber(ListNode a,ListNode b){
	   ListNode dummy=new ListNode(0);
	   ListNode tail=dummy;
	   int carry=0;
	   while(a!=null || b!=null){
		   int x = (a != null) ? a.data : 0;
		   int y = (b != null) ? b.data :0;
		   int sum = carry + x + y;
		   
		   carry = sum / 10;
		   tail.next = new ListNode(sum % 10);
		   tail=tail.next;
		   if(a!=null)
			   a=a.next;
		   if(b!=null)
			   b=b.next;
	   }
	   
	   if(carry > 0){
		   tail.next=new ListNode(carry);
	   }
	   
	   head=dummy.next;
   }
   
   
   
}
