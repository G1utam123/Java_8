package problems;

public class PrimeNumberCheck {

	public static void main(String[] args) {
		// check if number is prime , time complexity is term of  log 2,3,5,7 (1,13)
		
		
		int n = 13;
		double x =Math.sqrt(n);
		
 
		if (n == 1) {
			System.out.println("not prime");
			return;
		}
		for (int i = 2; i <= x; i++) {
			if (n % i == 0) {
				System.out.println("not prime");
				return;
			}
 
		}
		System.out.println("prime");
		
		
		
		
		
		
		
		
		
		
		
	}

}
