package graph;

public class AdjacencyMatrix {
	
	private int V;                            //No of vertices in graph
	private int E;                            // No of Edges in graph
	private int[][] matrix;
	
	public AdjacencyMatrix(int nodes){
		this.V=nodes;
		this.E=0;
		this.matrix=new int[nodes][nodes];
	}
	
	public void addEdges(int u,int v){
		this.matrix[u][v]=1;
		this.matrix[v][u]=1;
		E++;
	}
	
	public String toString(){
		StringBuilder sb=new StringBuilder();
		sb.append(V+ " Vertices, "+ E + " Edges"+ "\n");
		for(int v=0;v<V;v++){
			sb.append(v +": ");
			for(int w:matrix[v]){
				sb.append(w+" ");
			}
			sb.append("\n");
		}
		return sb.toString();
	}

	public static void main(String[] args) {
		
		AdjacencyMatrix am=new AdjacencyMatrix(4);
		
		am.addEdges(0, 1);
		am.addEdges(1, 2);
		am.addEdges(2, 3);
		am.addEdges(3, 0);
		
		System.out.println(am.toString());
		
//		for(int i=0;i<4;i++){
//			for(int j=0;j<4;j++){
//				System.out.print(am.matrix[i][j]+" ");
//			}
//			System.out.println();
//		}

	}

}
