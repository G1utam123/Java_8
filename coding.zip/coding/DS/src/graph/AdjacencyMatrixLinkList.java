package graph;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class AdjacencyMatrixLinkList {
	
	private LinkedList<Integer>[] adjM;
	private int V;
	private int E;
	
	public AdjacencyMatrixLinkList(int nodes) {
		this.V=nodes;
		this.E=0;
		this.adjM=new LinkedList[nodes];
		for(int v=0;v<V;v++){
			adjM[v]=new LinkedList<>();
		}
	}

	
	public void addEdges(int u,int v){
		adjM[u].add(v);
		adjM[v].add(u);
		E++;
	}
	
	public String toString(){
		StringBuilder sb=new StringBuilder();
		sb.append(V+" Vertices, "+E+" Edges"+"\n");
		for(int v=0;v<V;v++){
			sb.append(v +" : ");
			for(int w:adjM[v]){
				sb.append(w+"-->");
			}
			sb.append("null");
			sb.append("\n");
		}
		return sb.toString();
	}
	
	public void bfs(int s){
		boolean[] visited=new boolean[V];
		Queue<Integer> queue=new LinkedList<>();
		visited[s]=true;
		queue.offer(s);
		
		while(!queue.isEmpty()){
			int u=queue.poll();
			System.out.print(u+" ");
			
			for(int v:adjM[u]){
			if(!visited[v]){
				visited[v]=true;
				queue.offer(v);
			}
			}
		}
		
	}
	
	public void dfs(int s){
		boolean[] visited=new boolean[V];
		Stack<Integer> stack=new Stack<>();
		
		stack.push(s);
		while(!stack.isEmpty()){
			int u=stack.pop();
			
			if(!visited[u]){
				visited[u]=true;
			System.out.print(u+" ");
			for(int v:adjM[u]){
				if(!visited[v]){
					stack.push(v);
				}
			}
			
			
			}	
		}
	}
	
	public void dfsRecursive(){
		boolean[] visited=new boolean[V];
		for(int v=0;v<V;v++){
			if(!visited[v]){
				dfs(v,visited);
			}
		}
	}
	
	public void dfs(int v,boolean[] visited){
		visited[v]=true;
		System.out.print(v+" ");
		for(int w:adjM[v]){
			if(!visited[w]){
				dfs(w,visited);
			}
		}
	}
	
	public static void main(String[] args) {
		
		AdjacencyMatrixLinkList g=new AdjacencyMatrixLinkList(5);
		g.addEdges(0, 1);
		g.addEdges(1, 2);
		g.addEdges(2, 3);
		g.addEdges(3, 0);
		g.addEdges(2, 4);
		
		System.out.println(g.toString());
		System.out.println();
//		g.bfs(0);
		
//		g.dfs(0);
		g.dfsRecursive();

	}

}
