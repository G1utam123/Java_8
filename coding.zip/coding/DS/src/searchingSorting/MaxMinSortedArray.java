package searchingSorting;

public class MaxMinSortedArray {
	
	public int[] sort(int[] a,int low,int high){
		int[] temp=new int[high+1];
		int k=0;
		while(low<=high){
			temp[k]=a[high];
			temp[k+1]=a[low];
			low++;
			high--;
			k=k+2;
		}
		return temp;
	}
	
	public void sortWithoutArray(int[] a){
		int minIdx=0;
		int maxIdx=a.length-1;
		int max=a[maxIdx]+1;
		
		for(int i=0;i<a.length;i++){
			if(i%2==0){
				a[i]=a[i]+(a[maxIdx]%max)*max;
				maxIdx--;
			}else{
				a[i]=a[i]+(a[minIdx]%max)*max;
				minIdx++;
			}
		}
		for(int i=0;i<a.length;i++){
			a[i]=a[i]/max;
		}
	}
	

	public static void main(String[] args) {
		
		MaxMinSortedArray mm=new MaxMinSortedArray();
		int[] a=new int[]{2,3,4,5,6,7,8,9};
		
//		for(int x: mm.sort(a,0,7)){
//			System.out.print(x+" ");
//		}
		
		mm.sortWithoutArray(a);
		for(int x: a){
			System.out.print(x+" ");
		}

	}

}
