package searchingSorting;

public class SquareOfSortedArray {
	
	
	public int[] square(int[] a){
		int[] temp=new int[a.length];
		
		int i=0;
		int j=a.length-1;
		for(int k=j;k>=0;k--){
			if(Math.abs(a[i])>Math.abs(a[j])){
				temp[k]=a[i]*a[i];
				i++;
			}else{
				temp[k]=a[j]*a[j];
				j--;
			}
		}
		return temp;
	}
	

	public static void main(String[] args) {
		
		SquareOfSortedArray s=new SquareOfSortedArray();
		
		for(int x: s.square(new int[]{-4,-2,-1,0,3,5,6,7})){
			System.out.print(x+" ");
		}
		

	}

}
