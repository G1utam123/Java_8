package searchingSorting;

public class BinarySearch {

	

	public static void main(String[] args) {
		
		
		int[] a={2,3,4,5,6,7,8,9};
		int key=7;
		int low=0;
		int high=a.length - 1;
		while(low<=high){
			
			int mid=(low+high)/2;
			
			if(a[mid]==key){
				System.out.println("Element fount at position :"+mid);
				break;
			}
			if(a[mid]>key)
				high=mid -1;
			else
				low=mid+1;
			
		}
		
	}

}
