package searchingSorting;

public class QuickSort {

	   public void sord(int[] a, int low, int high){
		   if(low<high){
			   int p=partition(a,low,high);
			   sord(a, low, p-1);
			   sord(a, p+1, high);
		   }
	   }
	
	
	
	private int partition(int[] a, int low, int high) {
		int pivot=a[high];
		int i=0;
		int j=0;
		while(i<=high){
			if(a[i]<=pivot){
				int temp=a[i];
				a[i]=a[j];
				a[j]=temp;
				j++;
			}
			i++;
		}
		return j-1;
	}



	public static void main(String[] args) {
		
		QuickSort q=new QuickSort();
		
		int[] a={4,3,2,1,9,8,7,6};
		q.sord(a, 0, a.length-1);
		
		for(int x:a){
			System.out.print(x+" ");
		}

	}

}
