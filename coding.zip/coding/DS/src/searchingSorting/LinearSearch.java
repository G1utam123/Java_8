package searchingSorting;

public class LinearSearch {

	
	public int search(int[] a,int n,int key){
		for(int i=0;i<n;i++){
			if(a[i]==key)
				return i;
		}
		return -1;
	}
	

	public static void main(String[] args) {
		
		LinearSearch linearSearch=new LinearSearch();
		
		int[] a={2,5,3,1,8,7,9};
		System.out.println(" The given element fount at position :  "+ linearSearch.search(a, 7, 8));

	}

}
