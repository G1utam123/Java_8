package searchingSorting;

public class ThreeNumberSort {
	
	void sort(int[] a){
		int i=0;
		int j=0;
		int k=a.length-1;
		
		while(i<=k){
			if(a[i]==0){
				swap(a,i,j);
				i++;
				j++;
			}else if(a[i]==1){
				i++;
			}else if(a[i]==2){
				swap(a,i,k);
				k--;
			}
		}
	}
	
	

	private void swap(int[] a, int i, int j) {
		int temp=a[i];
		a[i]=a[j];
		a[j]=temp;
		
	}



	public static void main(String[] args) {
		
		ThreeNumberSort s=new ThreeNumberSort();
		int[] a={1,1,1,2,2,0,0,1,0,2,0,2,1,0};
		s.sort(a);

		for(int x:a){
			System.out.print(x+" ");
		}
	}

}
