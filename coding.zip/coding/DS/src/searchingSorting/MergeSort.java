package searchingSorting;

public class MergeSort {


	public void sort(int[] a, int[] temp, int low, int high){
		int mid=low+(high-low)/2;	
		if(low<high){
			sort(a,temp,low,mid);
			sort(a,temp,mid+1,high);
			merge(a,temp,low,mid,high);
		}	
	}

	private void merge(int[] a, int[] temp, int low, int mid, int high) {

		for(int i=low;i<=high;i++){
			temp[i]=a[i];
		}

		int i=low, j=mid+1, k=low;
		while(i<=mid && j<=high){
			if(temp[i]<=temp[j]){
				a[k]=temp[i];
				i++;
			}else{
				a[k]=temp[j];
				j++;
			}
			k++;	
		}

		while(i<=mid){
			a[k]=temp[i];
			i++;
			k++;
		}

	}





	public static void main(String[] args) {


		int[] a={4,3,2,8,7,6,9,1,24,12,45,67,56};



		MergeSort ms=new MergeSort();
		ms.sort(a, new int[a.length], 0, a.length - 1);

		for(int x:a){
			System.out.print(x+" ");
		}

	}

}
