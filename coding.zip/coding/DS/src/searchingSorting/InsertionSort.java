package searchingSorting;

public class InsertionSort {

	public static void main(String[] args) {
		
		int[] a={4,3,2,8,5,6,7,9};
		int n=a.length;
		
		for(int i=1;i<n;i++){
			int temp=a[i];
			int j=i-1;
			
			while(j>=0 && a[j] > temp){    //select next item and shift in backward sorted array
				a[j+1]=a[j];
				j--;
			}
			a[j+1]=temp;
		}
		
		for(int x:a){
			System.out.print(x+" ");
		}
		

	}

}
