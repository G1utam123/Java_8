package searchingSorting;

public class MergeTwoSorted {

	public static void main(String[] args) {
		
		int[] a={2,3,5,7,8,9,12,24,45};
		int[] b={1,4,6,10,15,25};
		
		int m=a.length;
		int n=b.length;
		int[] result=new int[m+n];
		int i=0,j=0,k=0;
		
		while(i<m && j<n){
			if(a[i]<b[j]){
				result[k]=a[i];
				i++;k++;
			}else{
				result[k]=b[j];
				j++;k++;
			}
		}
		
		while(i<m){
			result[k]=a[i];
			i++;k++;
		}
		
		while(j<n){
			result[k]=b[j];
			j++;k++;
		}
		
		for(int x:result){
			System.out.print(x+" ");
		}
		

	}

}
