package searchingSorting;

public class SearchInsertPosition {

	public static void main(String[] args) {
		
		
		int[] a={2,3,5,6,7,9,14,24,45,67,78,89};
		
		int target=7;
		int low=0;
		int high=a.length-1;
		int flag=0;
		while(low<=high){
			int mid=(low+high)/2;
			if(a[mid]==target){
				System.out.println("Element found at position : "+ mid);
				flag=1;
				break;
			}
			if(a[mid]>target)
				high=mid-1;
			else
				low=mid+1;
			
		}
		if(flag==0){
			System.out.println(" target position be : "+low);
		}

	}

}
