package com.gautam.jwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprintJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
