package com.gautam.jwt.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.gautam.jwt.model.User;

@Service
public class UserService {
	
	List<User> list=new ArrayList<>();
	
	public UserService() {
		
		list.add(new User(UUID.randomUUID().toString(), "gautam", "gk@gmail.com"));
		list.add(new User(UUID.randomUUID().toString(), "kumar", "gaurav@gmail.com"));
		list.add(new User(UUID.randomUUID().toString(), "ram", "saurav@gmail.com"));
		list.add(new User(UUID.randomUUID().toString(), "mohan", "mohan@gmail.com"));
		list.add(new User(UUID.randomUUID().toString(), "sohan", "sohan@gmail.com"));
	}
	
	public List<User> getUsers(){
		return this.list;
	}

}
